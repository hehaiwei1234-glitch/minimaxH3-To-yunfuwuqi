"""Append-only production batches and bounded story memory for an existing series."""
from __future__ import annotations

import copy
import hashlib
import json
import math
import time
import uuid

from . import image_workflows, workflows
from . import timing_policy
from .domain import safe_id
from .episode_recovery import terminal


MEMORY_INSTRUCTIONS = '''你是连续剧情记录员。根据已保存各集的既定剧本，更新供下一批制作使用的剧情记录。待补做的集仍按原剧本承接剧情，不表示已经生成可用视频，不改写或跳过其中的事件。
只记录剧本确实发生的事件、人物关系、人物当前处境、时间地点、尚未解决的伏笔；不续写，不补造事件，不把用户要求当成剧情。
沿用已有记录，并结合本次新增剧本更新。人物外观和场景身份以给出的固定素材目录为准，不改名不换人。
只返回JSON {"summary":"中文剧情记录，最多6000字"}。JSON。'''


def batch_values(body, defaults=None):
    defaults = defaults or {}
    text = str(body.get('text', '')).strip()
    if not text or len(text) > 500000:
        raise ValueError('请填写本批剧本或大纲，最多50万字。')
    mode = body.get('input_type', defaults.get('input_type', 'script'))
    if mode not in {'script', 'outline'}:
        raise ValueError('请选择完整剧本或故事大纲。')
    count = int(body.get('episode_count', 0))
    source=body
    if 'timing_policy' not in body:
        legacy=float(body.get('target_episode_seconds',defaults.get('target_episode_seconds',0)))
        if not math.isfinite(legacy) or not (legacy==0 or 8<=legacy<=1800):raise ValueError('旧版每集目标时长须为0或8至1800秒。')
        source={**body,'target_episode_seconds':legacy}
    policy=timing_policy.from_body(source)
    duration=timing_policy.seconds(policy,'episode')
    if not 0 <= count <= 100:raise ValueError('每批集数为0至100，0由AI决定。')
    count=timing_policy.series_count(policy,count)
    return {'text': text, 'input_type': mode, 'episode_count': count,
            'target_episode_seconds': duration, 'timing_policy':policy, 'instructions': str(body.get('instructions', ''))}


def initial_batch(record):
    return {'id': 'initial', **{k: copy.deepcopy(record[k]) for k in
            ('text', 'input_type', 'episode_count', 'target_episode_seconds', 'timing_policy', 'instructions',
             'workflow_snapshot', 'image_workflow_snapshots') if k in record},
            'status': 'planned' if record.get('plan') else 'pending',
            'start_index': 0, 'episode_total': len((record.get('plan') or {}).get('episodes', [])),
            'created_at': record['created_at']}


class SeriesBatchesMixin:
    def record(self, id):
        record = self.store.get('series', id)
        changed = False
        for key, value in [('revision', 1), ('continuity_summary', ''), ('memory_through', 0),
                           ('removed_episodes', {}), ('batches', [initial_batch(record)])]:
            if key not in record:
                record[key] = value
                changed = True
        # Also supports old records/tests where the initial plan was retained
        # before batch metadata existed.
        if record.get('plan') and record['batches'][0]['status'] == 'pending':
            record['batches'][0].update(status='planned', start_index=0,
                                      episode_total=len(record['plan']['episodes']))
            changed = True
        for batch in record['batches']:
            if batch['status']=='pending' and 'timing_policy' not in batch:
                batch.update(timing_policy=timing_policy.normalize(),target_episode_seconds=0)
                if batch['id']=='initial':record.update(timing_policy=timing_policy.normalize(),target_episode_seconds=0)
                changed=True
        if record.get('status')=='partial' and record.get('project_ids') and not self.pending_batch(record):
            if all(self.store.get('project',pid)['status']=='complete' for pid in record['project_ids']):
                record.update(status='complete',phase='全部成片已完成，待补做的集已补齐',error='')
                changed=True
        if changed:
            self.store.put('series', id, record)
        return record

    def batch_for(self, record, episode=None):
        bid = (episode or {}).get('batch_id', 'initial')
        return next(b for b in record['batches'] if b['id'] == bid)

    def pending_batch(self, record):
        return next((b for b in record['batches'] if b['status'] == 'pending'), None)

    def ensure_idle(self, id):
        record = self.record(id)
        if record['status'] in {'running', 'queued', 'pausing'} or (
                id in self.tasks and not self.tasks[id].done()):
            raise ValueError('请先暂停整剧，等当前任务结束后再修改或追加。')
        for project in self.store.list('project'):
            if project.get('series_id') != id:
                continue
            task = self.engine.tasks.get(project['id'])
            if project['status'] in {'running', 'queued', 'pausing'} or task and not task.done():
                raise ValueError('本剧还有正在执行的单集，请等当前任务结束。')
        return record

    def append(self, id, body):
        with self.store.lock:
            record = self.record(id)
            values = batch_values(body, record['batches'][-1])
            request_id = str(body.get('request_id', '')).strip()
            if not request_id or len(request_id) > 100:
                raise ValueError('追加请求缺少有效标记，请重新打开追加窗口。')
            fingerprint = hashlib.sha256(json.dumps(
                {**values, 'workflow_id': body.get('workflow_id', '')},
                sort_keys=True, ensure_ascii=False).encode()).hexdigest()
            for batch in record['batches']:
                if batch.get('request_id') == request_id:
                    if batch.get('request_sha256') != fingerprint:
                        raise ValueError('同一次追加请求的内容已经改变，请重新打开追加窗口。')
                    return record
            record = self.ensure_idle(id)
            if record.get('archived'):
                raise ValueError('请先恢复已归档的整剧。')
            if body.get('expected_revision') != record['revision']:
                raise ValueError('整剧内容已改变，请重新打开追加窗口。')
            if self.pending_batch(record) or not record.get('plan'):
                raise ValueError('请先完成当前批次；未开始的单集可使用“修改剧本”。')
            removed = record.get('removed_episodes', {})
            for i, episode in enumerate(record['plan']['episodes']):
                pid = self.episode_id(id, i)
                if pid in removed:
                    continue
                project = self.store.get('project', pid)
                if not terminal(project):
                    raise ValueError('请先完成当前批次，再追加后续剧本。')
            previous = record['batches'][-1]
            workflow = copy.deepcopy(self.store.get('workflow', safe_id(body['workflow_id']))) if body.get('workflow_id') else copy.deepcopy(previous['workflow_snapshot'])
            workflow = workflows.resolved(workflow)
            if body.get('workflow_id') and workflow.get('archived'):
                raise ValueError('请选择未归档的视频工作流。')
            cfg = self.engine.config({'settings': {}, 'workflow_snapshot': workflow})
            timing_policy.check_workflow(values['timing_policy'],workflow)
            # Retain the last batch's image snapshots when the backend remains
            # local, even if its source templates have since been deleted.
            images = None
            if cfg['image_provider'] == 'local':
                if cfg['image_workflow_id'] and (cfg['image_reference_workflow_id'] or not cfg['generate_shot_images']):
                    images = image_workflows.snapshots(self.store,cfg)
                else:
                    images = copy.deepcopy(previous.get('image_workflow_snapshots')) or image_workflows.snapshots(self.store,cfg)
            batch = {'id': uuid.uuid4().hex, **values, 'workflow_snapshot': workflow,
                     'image_workflow_snapshots': images, 'status': 'pending',
                     'request_id': request_id, 'request_sha256': fingerprint,
                     'start_index': len(record['plan']['episodes']), 'episode_total': 0,
                     'created_at': time.time()}
            record['batches'].append(batch)
            record.update(revision=record['revision'] + 1, status='draft', error='',
                          phase=f'后续剧本已保存，将从第{batch["start_index"] + 1}集开始',
                          pause_requested=False, updated_at=time.time())
            self.store.put('series', id, record)
            self.event(id, f'已保存第{len(record["batches"])}批剧本；人物、场景和集数沿用本剧。')
            return self.record(id)

    @staticmethod
    def episode_id(id, index):
        return hashlib.sha256(f'{id}:episode:{index}'.encode()).hexdigest()[:40]

    async def remember_previous(self, id, ai):
        record = self.record(id)
        episodes = (record.get('plan') or {}).get('episodes', [])
        through = int(record.get('memory_through', 0))
        if through >= len(episodes):
            return
        texts = []
        for i in range(through, len(episodes)):
            pid = self.episode_id(id, i)
            removed = record.get('removed_episodes', {}).get(pid)
            if removed:
                if removed.get('was_complete'):
                    texts.append(f'第{i + 1}集：{episodes[i]["title"]}\n{episodes[i]["script"]}')
                continue
            project = self.store.get('project', pid)
            if not terminal(project):
                raise ValueError('此前批次尚未完成，不能建立下一批剧情记录。')
            label='（视频待补做，以下为既定剧本）' if project['status']=='deferred' else ''
            texts.append(f'第{i + 1}集{label}：{episodes[i]["title"]}\n{project["script"]}')
        text = '\n\n'.join(texts)
        digest = hashlib.sha256(text.encode()).hexdigest()
        progress = record.get('memory_progress') or {}
        if progress.get('sha256') != digest or progress.get('through') != len(episodes):
            progress = {'sha256': digest, 'through': len(episodes), 'offset': 0,
                        'summary': record.get('continuity_summary', '')}
        assets = [self.store.get('asset', aid) for aid in record['asset_ids']]
        while progress['offset'] < len(text):
            self.paused(id)
            self.set(id, phase='记录此前剧情，供下一批剧本接着使用')
            part = text[progress['offset']:progress['offset'] + 24000]
            request = {'previous_summary': progress['summary'], 'completed_script_excerpt': part,
                       'fixed_characters_and_scenes': self.engine.asset_summary(assets)}
            def check(result):
                summary = result.get('summary') if isinstance(result, dict) else None
                if not isinstance(summary, str) or not summary.strip() or len(summary) > 6000:
                    raise ValueError('剧情记录须为1至6000字的中文文字。')
                return summary.strip()
            summary = await self.engine.checked_text(ai, MEMORY_INSTRUCTIONS,
                        json.dumps(request, ensure_ascii=False), check)
            progress = {**progress, 'summary': summary, 'offset': progress['offset'] + len(part)}
            self.set(id, memory_progress=progress)
        self.set(id, continuity_summary=progress['summary'], memory_through=len(episodes), memory_progress=None)

    def edit_script(self, id, project_id, body):
        with self.store.lock:
            record = self.ensure_idle(id)
            project = self.store.get('project', safe_id(project_id))
            if project.get('series_id') != id or project_id not in record['project_ids']:
                raise ValueError('本集不属于这个整剧。')
            if record.get('archived') or project.get('archived'):
                raise ValueError('请先恢复已归档的整剧或单集。')
            self.engine.check_script_edit(project, body)
            script = str(body.get('script', '')).strip()
            index = next(i for i in range(len(record['plan']['episodes'])) if self.episode_id(id, i) == project_id)
            record['plan']['episodes'][index]['script'] = script
            if index<int(record.get('memory_through',0)):
                record.update(continuity_summary='',memory_through=0,memory_progress=None)
            record['revision'] += 1
            record['updated_at'] = time.time()
            project.update(script=script, script_revision=project.get('script_revision', 1) + 1,
                           error='', phase='剧本已修改，点击继续开始本集', updated_at=time.time())
            self.store.apply_changes([('series', id, record), ('project', project_id, project)])
            self.event(id, f'已修改第{index + 1}集未开始制作的剧本。')
            return self.store.public_project(project_id)
