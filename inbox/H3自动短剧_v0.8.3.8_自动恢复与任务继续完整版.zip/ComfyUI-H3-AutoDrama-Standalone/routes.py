from __future__ import annotations
import json
import logging
import asyncio
from pathlib import Path
from aiohttp import web
from .domain import PREFIX, public_settings, safe_id
from .storage import Store
from .files import Files
from .production_draft.service import Engine
from .comfy_client import ComfyClient
from .media_tools import command
from . import workflows
from . import image_workflows
from .production_draft.service import SeriesManager
from .image_generator import allow_resubmit
from .management import RecordsManager
from .production_draft.service import save_bindings
from .version import VERSION
import aiohttp

ROOT=Path(__file__).resolve().parent

class Application:
    def __init__(self,data_dir,input_dir,output_dir,local_url):
        self.store=Store(data_dir);self.files=Files(input_dir,output_dir)
        self.engine=Engine(self.store,self.files,ROOT,local_url)
        self.series=SeriesManager(self.engine)
        self.management=RecordsManager(self.engine,self.series)
    async def handle(self,request):
        try:
            suffix=request.match_info.get('path','').strip('/')
            if not suffix:
                if not request.path.endswith('/'):raise web.HTTPFound(request.path+'/')
                return web.FileResponse(ROOT/'static/index.html',headers={'Cache-Control':'no-store'})
            if suffix in {'app.js','workflows.js','image_workflows.js','series.js','management.js','timing.js','production.js','production_draft.js','style.css'}:return web.FileResponse(ROOT/'static'/suffix,headers={'Cache-Control':'no-store'})
            if not suffix.startswith('api/'):raise web.HTTPNotFound()
            parts=suffix[4:].split('/');method=request.method
            body=await request.json() if method=='POST' and not request.content_type.startswith('multipart/') else {}
            if parts[0]=='production-draft':
                from .production_draft.http import handle
                return await handle(self,parts,method,body)
            def visible(kind):
                return [r for r in self.store.list(kind) if request.query.get('include_archived')=='1' or not r.get('archived')]
            if parts==['version'] and method=='GET':
                return web.json_response({'software_version':VERSION},headers={'Cache-Control':'no-store'})
            if parts==['manage','cleanup']:
                if method=='GET':return web.json_response({'pending':len(self.store.list('cleanup_job'))})
                if method=='POST':return web.json_response(await asyncio.to_thread(self.management.retry_cleanup))
            if len(parts)==4 and parts[0]=='manage' and method=='POST':
                kind,id,action=parts[1:]
                if action=='archive':return web.json_response(self.management.archive(kind,id,True))
                if action=='restore':return web.json_response(self.management.archive(kind,id,False))
                if action=='delete-preview':return web.json_response(await asyncio.to_thread(self.management.preview,kind,id))
                if action=='delete':return web.json_response(await asyncio.to_thread(self.management.delete,kind,id,body))
                raise web.HTTPNotFound()
            if len(parts)==3 and parts[0] in {'projects','series'} and parts[2]=='bindings' and method=='POST':
                kind='project' if parts[0]=='projects' else 'series'
                return web.json_response(save_bindings(self.store,kind,safe_id(parts[1]),body))
            if parts==['settings']:
                if method=='GET':return web.json_response(public_settings(self.store.settings()))
                if method=='POST':return web.json_response(self.store.save_settings(body))
            if parts==['connection'] and method=='POST':
                cfg=self.engine.config({'settings':{}})
                async with aiohttp.ClientSession() as session:
                    info=await ComfyClient(cfg,session).get('/object_info')
                await command([cfg['ffmpeg'],'-version'])
                await command([cfg['ffprobe'],'-version'])
                return web.json_response({'ok':True,'nodes':len(info),'independent_nodes':sorted(k for k in info if k.startswith('H3ADv1')),
                                          'media_tools':{name:cfg[name] for name in ('ffmpeg','ffprobe')}})
            if parts==['workflows','preview'] and method=='POST':
                return web.json_response(workflows.preview(body.get('graph')))
            if parts==['workflows']:
                if method=='GET':return web.json_response([workflows.summary(w) for w in visible('workflow')])
                if method=='POST':
                    graph=workflows.api_graph(body.get('graph'));contract=workflows.validate_bindings(graph,body)
                    cfg=self.engine.config({'settings':{}})
                    async with aiohttp.ClientSession() as session:
                        await ComfyClient(cfg,session).preflight(graph,contract['output_node_id'])
                    return web.json_response(workflows.summary(workflows.save(self.store,{**body,'graph':graph})))
            if len(parts)==2 and parts[0]=='workflows' and method=='GET':
                return web.json_response(self.store.get('workflow',safe_id(parts[1])))
            if parts==['image-workflows','preview'] and method=='POST':return web.json_response(image_workflows.preview(body.get('graph')))
            if parts==['image-workflows','install-qwen'] and method=='POST':
                drafts=[]
                async with aiohttp.ClientSession() as session:
                    client=ComfyClient(self.engine.config({'settings':{}}),session)
                    for key in ('base','reference'):
                        draft=json.loads((ROOT/'bundled_image_workflows'/f'qwen_{key}.json').read_text(encoding='utf-8'))
                        draft['configured_by_bundle']=True
                        contract=image_workflows.validate_bindings(draft['graph'],draft)
                        await client.preflight(draft['graph'],contract['output_node_id'],dynamic_inputs=contract['reference_bindings'])
                        drafts.append((key,draft))
                with self.store.lock:
                    selected={}
                    for key,draft in drafts:
                        existing=next((w for w in self.store.list('image_workflow') if w.get('bundle_key')=='qwen21_'+key and not w.get('archived')),None)
                        if existing:draft.update(id=existing['id'],expected_version=existing['version'])
                        saved=image_workflows.save(self.store,draft)
                        self.store.update('image_workflow',saved['id'],lambda w:w.update(bundle_key='qwen21_'+key))
                        selected['image_workflow_id' if key=='base' else 'image_reference_workflow_id']=saved['id']
                    self.store.save_settings({'image_provider':'local',**selected})
                return web.json_response({'ok':True,**selected})
            if parts==['image-workflows']:
                if method=='GET':return web.json_response([image_workflows.summary(w) for w in visible('image_workflow')])
                if method=='POST':
                    graph=image_workflows.api_graph(body.get('graph'));contract=image_workflows.validate_bindings(graph,body)
                    async with aiohttp.ClientSession() as session:
                        await ComfyClient(self.engine.config({'settings':{}}),session).preflight(graph,contract['output_node_id'],dynamic_inputs=contract['reference_bindings'])
                    return web.json_response(image_workflows.summary(image_workflows.save(self.store,{**body,'graph':graph})))
            if len(parts)==2 and parts[0]=='image-workflows' and method=='GET':return web.json_response(self.store.get('image_workflow',safe_id(parts[1])))
            if parts==['series']:
                if method=='GET':return web.json_response([{k:s.get(k) for k in ('id','title','status','phase','created_at','project_ids','archived')} for s in visible('series')])
                if method=='POST':return web.json_response(self.series.public(self.series.create(body)['id']))
            if len(parts)>=2 and parts[0]=='series':
                sid=safe_id(parts[1]);record=self.store.get('series',sid)
                if len(parts)==2 and method=='GET':return web.json_response(self.series.public(sid))
                if len(parts)==3 and method=='POST':
                    if parts[2]=='start':self.series.start(sid)
                    elif parts[2]=='pause':self.series.pause(sid)
                    elif parts[2]=='append':return web.json_response(self.series.public(self.series.append(sid,body)['id']))
                    else:raise web.HTTPNotFound()
                    return web.json_response(self.series.public(sid))
                if len(parts)==3 and parts[2]=='export' and method=='GET':
                    return web.Response(text=json.dumps(self.series.public(sid,export=True),ensure_ascii=False,indent=2),content_type='application/json',headers={'Content-Disposition':'attachment; filename="series.json"'})
                if len(parts)==3 and parts[2]=='diagnostics' and method=='GET':
                    from .api_diagnostics import export
                    return web.Response(text=json.dumps(export(self.store,'series',sid),ensure_ascii=False,indent=2),content_type='application/json',headers={'Content-Disposition':'attachment; filename="series_api_diagnostics.json"'})
                if len(parts)==5 and parts[2]=='episodes' and parts[4]=='script' and method=='POST':
                    return web.json_response(self.series.edit_script(sid,parts[3],body))
                if len(parts)==5 and parts[2]=='episodes' and parts[4]=='retry' and method=='POST':
                    self.series.retry_episode(sid,parts[3])
                    return web.json_response(self.series.public(sid))
            if parts==['image-jobs'] and method=='GET':
                owner=request.query.get('owner','')
                return web.json_response([{k:j.get(k) for k in ('id','owner_id','status','job_id','prompt_id','submission_unknown','error','workflow_name')} for j in self.store.list('image_job') if j['owner_id']==owner])
            if len(parts)==3 and parts[0]=='image-jobs' and parts[2]=='resubmit' and method=='POST':
                jid=safe_id(parts[1]);job=self.store.get('image_job',jid)
                tasks={**self.engine.tasks,**self.series.tasks};task=tasks.get(job['owner_id'])
                if job['owner_id'] in self.engine.preparing_projects or task and not task.done():raise ValueError('请先暂停对应项目或整剧。')
                allow_resubmit(self.store,jid);return web.json_response({'ok':True})
            if parts==['assets'] and method=='GET':return web.json_response(visible('asset'))
            if parts==['existing'] and method=='GET':return web.json_response(self.files.existing_input())
            if parts==['import'] and method=='POST':return web.json_response(self.files.import_asset(self.store,body['relative_path'],body))
            if parts==['upload'] and method=='POST':
                reader=await request.multipart();uploaded=[];meta={};total=0
                while True:
                    field=await reader.next()
                    if field is None:break
                    if field.filename:
                        chunks=[]
                        while True:
                            chunk=await field.read_chunk()
                            if not chunk:break
                            total+=len(chunk)
                            if total>512*1024*1024:raise ValueError('一次上传不能超过512MB。')
                            chunks.append(chunk)
                        uploaded.append((field.filename,b''.join(chunks)))
                    elif field.name=='metadata':meta=json.loads(await field.text())
                if not uploaded:raise ValueError('请选择素材文件。')
                return web.json_response([self.files.write_asset(self.store,name,blob,meta) for name,blob in uploaded])
            if len(parts)>=2 and parts[0]=='assets':
                aid=safe_id(parts[1]);a=self.store.get('asset',aid)
                if len(parts)==3 and parts[2]=='file' and method=='GET':return web.FileResponse(self.files.asset_path(a))
                if len(parts)==2 and method=='POST':
                    for k in ('label','description','speaker','role'):
                        if k in body:a[k]=str(body[k])
                    self.store.put('asset',aid,a);return web.json_response(a)
            if parts==['projects']:
                if method=='GET':return web.json_response([{k:p.get(k) for k in ('id','title','status','phase','created_at','updated_at','series_id','archived')} for p in visible('project')])
                if method=='POST':
                    if not body.get('workflow_id'):raise ValueError('请先导入并选择你在ComfyUI跑通的工作流。')
                    snapshot=image_workflows.snapshots(self.store,self.engine.config({'settings':{}}))
                    project=self.store.create_project({**body,'settings':{}})
                    if snapshot:self.engine.set(project['id'],image_workflow_snapshots=snapshot)
                    return web.json_response(self.store.public_project(project['id']))
            if len(parts)>=2 and parts[0]=='projects':
                pid=safe_id(parts[1]);p=self.store.get('project',pid)
                if len(parts)==2 and method=='GET':return web.json_response(self.store.public_project(pid))
                action=parts[2] if len(parts)>2 else ''
                if method=='POST' and len(parts)==3:
                    if action=='start':
                        if p['status']=='deferred' and p.get('series_id'):self.series.retry_episode(p['series_id'],pid)
                        else:self.engine.start(pid,require_workflow=True)
                    elif action=='script':return web.json_response(self.engine.edit_script(pid,body))
                    elif action=='pause':self.engine.pause(pid)
                    elif action=='dialogue':return web.json_response(self.engine.resolve_dialogue(pid,body))
                    elif action=='workflow':self.engine.assign_workflow(pid,safe_id(body['workflow_id']))
                    elif action=='redo':return web.json_response({'affected':self.engine.redo(pid,body['indices'],body.get('feedback',''),bool(body.get('new_seed',True)),bool(body.get('regenerate_image',False)))})
                    elif action=='resubmit':self.engine.allow_resubmit(pid,int(body['index']));self.engine.start(pid)
                    else:raise web.HTTPNotFound()
                    return web.json_response(self.store.public_project(pid))
                if method=='GET' and action=='final':
                    if not p.get('final'):raise ValueError('成片尚未完成。')
                    return web.FileResponse(self.files.output_path(p['final']))
                if method=='GET' and action=='export':
                    clean=self.store.public_project(pid)
                    return web.Response(text=json.dumps(clean,ensure_ascii=False,indent=2),content_type='application/json',headers={'Content-Disposition':'attachment; filename="project.json"'})
                if method=='GET' and action=='diagnostics':
                    from .api_diagnostics import export
                    return web.Response(text=json.dumps(export(self.store,'project',pid),ensure_ascii=False,indent=2),content_type='application/json',headers={'Content-Disposition':'attachment; filename="project_api_diagnostics.json"'})
                if method=='GET' and action=='workflow':
                    if not p.get('workflow_snapshot'):raise ValueError('此旧项目未关联导入工作流。')
                    return web.Response(text=json.dumps(p['workflow_snapshot'],ensure_ascii=False,indent=2),content_type='application/json',headers={'Content-Disposition':'attachment; filename="workflow_snapshot.json"'})
                if method=='GET' and action=='clips' and len(parts)==5:
                    i=int(parts[3]);c=p['clips'][i]
                    if parts[4]=='video':return web.FileResponse(self.files.output_path(c['output']))
                    if parts[4]=='image':return web.FileResponse(self.files.asset_path(self.store.get('asset',c['frame_asset_id'])))
                    if parts[4]=='workflow':
                        return web.Response(text=json.dumps(c['api_graph'],ensure_ascii=False,indent=2),content_type='application/json',headers={'Content-Disposition':f'attachment; filename="clip_{i+1:03d}_api.json"'})
            raise web.HTTPNotFound()
        except web.HTTPException:raise
        except (ValueError,KeyError,IndexError,TypeError) as e:return web.json_response({'error':str(e)},status=400)
        except Exception as e:
            logging.exception('H3 AutoDrama request failed')
            return web.json_response({'error':str(e)},status=500)

def register_routes(prompt_server,folder_paths):
    # Lazily initialise after the native nodes are loaded and the server listens.
    holder={}
    async def handler(request):
        if 'app' not in holder:
            sock=request.transport.get_extra_info('sockname') if request.transport else None
            port=sock[1] if sock else getattr(prompt_server,'port',None)
            if not port:return web.json_response({'error':'无法自动取得ComfyUI端口，请从正常ComfyUI网页入口打开。'},status=500)
            host=sock[0] if sock else '127.0.0.1'
            if host=='0.0.0.0':host='127.0.0.1'
            if host=='::':host='::1'
            if ':' in host:host='['+host+']'
            local_url=f'{"https" if request.secure else "http"}://{host}:{port}'
            user_dir=folder_paths.get_user_directory() if hasattr(folder_paths,'get_user_directory') else str(Path(folder_paths.base_path)/'user')
            holder['app']=Application(Path(user_dir)/PREFIX,folder_paths.get_input_directory(),folder_paths.get_output_directory(),local_url)
        return await holder['app'].handle(request)
    prompt_server.routes.get('/'+PREFIX)(handler)
    prompt_server.routes.get('/'+PREFIX+'/')(handler)
    prompt_server.routes.get('/'+PREFIX+'/{path:.*}')(handler)
    prompt_server.routes.post('/'+PREFIX+'/{path:.*}')(handler)
