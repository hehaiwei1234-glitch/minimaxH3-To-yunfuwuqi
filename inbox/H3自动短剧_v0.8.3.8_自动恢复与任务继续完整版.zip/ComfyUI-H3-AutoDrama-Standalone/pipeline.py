"""Bounded preparation with adopted-output dependency gates and one GPU."""
import asyncio
from .production import fingerprint, preparation_dependency
from .telemetry import measure, scope
from .review import enabled, ReviewPaused
from .providers import APIError
from .comfy_client import SubmissionUnknown
from .media_tools import command
from . import dialogue_check
from . import episode_recovery
from . import task_recovery

class ProductionPipelineMixin:
    async def render_measured(self,identity,index,comfy,cfg):
        if self.store.get('project',identity)['clips'][index].get('output'):return
        with measure('video_gpu_wait',str(index+1)):
            await self.render_lock.acquire()
        try:
            with measure('video_generation',str(index+1)):
                await self.render_with_retries(identity,index,comfy,cfg)
        finally:
            self.render_lock.release()

    async def state_reference(self,identity,index,cfg):
        p=self.store.get('project',identity);clip=p['clips'][index]
        prior_final=False
        if index:
            if preparation_dependency(clip,index) is None:return None
            previous=p['clips'][index-1]
        else:
            prior=p.get('previous_episode_id')
            if not prior or not clip.get('use_previous_episode_state',True):return None
            previous_project=self.store.get('project',prior)
            if previous_project.get('status')=='deferred':return None
            if not previous_project.get('clips'):return None
            previous=previous_project['clips'][-1]
            prior_final=bool(previous_project.get('final'))
        if not previous.get('output') or (not prior_final and not dialogue_check.resolved(self.files,previous,cfg)) or (enabled(cfg,'video') and not previous.get('quality_accepted') and not prior_final):
            raise ReviewPaused('前段尚未最终采用，不能生成依赖它的开场图。')
        key=fingerprint({'output':previous['output'],'generation':previous.get('generation'),
                         'seed':previous.get('seed')})
        aid='state_'+key[:32]
        if clip.get('state_reference_source') and clip['state_reference_source']!=key and (clip.get('frame_asset_id') or clip.get('job_id')):
            raise ReviewPaused('前段已改变，此镜头的参考已过期；请选择该镜头重做，避免使用旧画面。')
        try:
            asset=self.store.get('asset',aid)
        except KeyError:
            source=self.files.output_path(previous['output'])
            dest=self.files.project_dir(identity)/'状态参考'/f'{key[:24]}.png'
            dest.parent.mkdir(parents=True,exist_ok=True)
            meta=previous.get('meta') or {}
            video=meta.get('video') or {}
            try:seconds=float(video.get('duration') or 0)
            except (TypeError,ValueError):seconds=0.
            if not 0<seconds<float('inf'):
                seconds=float(meta.get('duration') or previous.get('duration_seconds',1))
            with measure('state_frame',str(index+1)):
                await command([cfg['ffmpeg'],'-y','-v','error','-ss',str(max(0,seconds-.08)),
                               '-i',source,'-frames:v','1',dest])
                if not dest.is_file() or not dest.stat().st_size:
                    # A missing/incorrect stream duration can produce zero
                    # frames with FFmpeg exit status 0. Use decoded frame order
                    # as a rare fallback; never seek into an audio-only tail.
                    try:last=int(video.get('nb_frames') or 0)-1
                    except (TypeError,ValueError):last=-1
                    if last>=0:
                        await command([cfg['ffmpeg'],'-y','-v','error','-i',source,
                                       '-map','0:v:0','-an','-vf',f'select=eq(n\\,{last})',
                                       '-frames:v','1',dest])
                if not dest.is_file() or not dest.stat().st_size:
                    raise RuntimeError('前段视频未提取到有效画面，原视频与进度已保留；请检查视频流时长。')
            asset=self.files.write_asset(self.store,'前段状态.png',dest.read_bytes(),
                {'role':'scene','label':'前段最终采用状态','description':'仅参考人物位置、道具和环境状态；身份以固定角色图为准。','generated':True},id=aid)
        self.clip_set(identity,index,state_reference_id=aid,state_reference_source=key)
        return self.files.asset_path(asset)

    async def pipeline(self,identity,ai,comfy,cfg):
        from .engine import Paused
        initial=self.store.get('project',identity)['clips']
        resolved=[asyncio.Event() for _ in initial]
        preparations={};blocked=[]
        def adopted(index):
            c=self.store.get('project',identity)['clips'][index]
            return bool(c.get('output') and dialogue_check.resolved(self.files,c,cfg) and (not enabled(cfg,'video') or c.get('quality_accepted')))
        for i in range(len(initial)):
            if adopted(i):resolved[i].set()
        async def prepare(index):
            clip=self.store.get('project',identity)['clips'][index]
            if clip.get('output') or clip.get('api_graph') or clip.get('job_id') or task_recovery.failed(clip):return
            dependency=preparation_dependency(clip,index)
            if dependency is not None:
                await resolved[dependency].wait()
                task_recovery.independent_after_gap(self,identity,index)
                clip=self.store.get('project',identity)['clips'][index]
                if preparation_dependency(clip,index) is not None and not adopted(dependency):
                    raise ReviewPaused(f'第{index+1}段缺少前段可用视频')
            async with self.prepare_slots:
                self.paused(identity)
                await self.prepare_clip(identity,index,ai,cfg)
        try:
            for i in range(len(initial)):
                self.paused(identity)
                if task_recovery.failed(self.store.get('project',identity)['clips'][i]):
                    resolved[i].set()
                    continue
                # Current shot plus no more than two following shots can prepare.
                for j in range(i,min(i+3,len(initial))):
                    if j not in preparations:
                        preparations[j]=asyncio.create_task(prepare(j))
                try:
                    await preparations[i]
                    self.paused(identity)
                    if enabled(cfg,'video') or dialogue_check.enabled(cfg):
                        await self.reviewed_clip(identity,i,ai,comfy,cfg)
                    else:
                        await self.render_measured(identity,i,comfy,cfg)
                        self.clip_set(identity,i,quality_accepted=True,video_reviewed=False)
                except Paused:raise
                except Exception as error:
                    self.paused(identity)
                    await task_recovery.record_failure(self,identity,i,error,cfg)
                finally:
                    resolved[i].set()
        finally:
            for task in preparations.values():
                if not task.done():task.cancel()
            if preparations:await asyncio.gather(*preparations.values(),return_exceptions=True)

    async def prepare_episode(self,identity,previous=None,images=False):
        if identity in self.preparing_projects:raise ReviewPaused('本集已在提前准备。')
        project=self.store.get('project',identity)
        if project.get('final') or project.get('archived'):return
        self.paused(identity)
        self.preparing_projects.add(identity)
        self.set(identity,status='running')
        complete=False
        try:
            await self._prepare_episode(identity,previous,images)
            complete=True
        finally:
            self.preparing_projects.discard(identity)
            current=self.store.get('project',identity)
            if not current.get('final'):
                self.set(identity,status=('draft' if complete and not current.get('pause_requested') else 'paused'))

    async def _prepare_episode(self,identity,previous=None,images=False):
        """Text may prepare early. Images start only after previous clips are adopted."""
        import aiohttp
        from .providers import AIClient
        p=self.store.get('project',identity)
        if p.get('final') or p.get('archived'):return
        cfg=self.config(p)
        with scope(self.store,'project',identity):
            async with aiohttp.ClientSession() as session:
                ai=AIClient(cfg,session)
                self.paused(identity)
                await self.plan(identity,ai,cfg)
                episode_recovery.prepare_boundary(self,identity)
                if not images:
                    self.set(identity,phase='分镜已提前准备，等待上集最终画面')
                    return
                if previous:self.set(identity,previous_episode_id=previous)
                self.paused(identity)
                await self.create_missing_assets(identity,ai,cfg)
                self.paused(identity)
                await self.prepare_clip(identity,0,ai,cfg)
                self.set(identity,phase='首段已准备，等待整集队列')
