"""Pure validation and graph assembly; no dependency on an older custom plugin."""
from __future__ import annotations
import copy
import json
import math
import re
from pathlib import Path

PREFIX = "h3_autodrama_v1"
NODE_PREFIX = "H3ADv1"
REFERENCE = re.compile(r"<(Picture|Video|Audio)\s+(\d+)>")
SECTIONS = ("subject_definitions", "summary", "retention_analysis", "detailed_description", "overall_soundscape", "non_diegetic_music")
DEFAULTS = {
    "comfy_url": "", "comfy_api_key": "", "provider": "openai",
    "openai_base_url": "https://api.openai.com/v1", "openai_model": "gpt-6-astra", "openai_api_key": "",
    "deepseek_base_url": "https://api.deepseek.com", "deepseek_model": "deepseek-chat", "deepseek_api_key": "",
    "image_base_url": "https://api.openai.com/v1", "image_model": "gpt-image-2.5-sunburst", "image_api_key": "",
    "image_size": "1792x672", "image_quality": "high", "api_timeout_seconds": 900,
    "image_provider": "api", "image_workflow_id": "", "image_reference_workflow_id": "",
    "poll_seconds": 5, "render_timeout_minutes": 180, "retry_limit": 2, "max_segments": 500,
    "width": 1792, "height": 672, "duration_seconds": 8, "steps": 15, "turbo": False, "turbo_steps": 4,
    "seed": 636323908608123, "seed_mode": "fixed", "upscale": False, "upscale_factor": 1.5,
    "refine_steps": 8, "refine_start_step": 4, "refine_save_vram": True,
    "bit_depth": 10, "color_space": "sRGB", "overlap_seconds": 1.0, "continue_audio": True,
    "ffmpeg": "ffmpeg", "ffprobe": "ffprobe", "generate_shot_images": True,
}
DEFAULTS.update({
    "local_base_url":"http://127.0.0.1:1234/v1", "local_model":"", "local_api_key":"", "local_vision":False,
    "review_enabled":False, "review_image_enabled":None, "review_video_enabled":None, "pipeline_enabled":True, "review_provider":"compatible", "review_base_url":"https://api.openai.com/v1",
    "review_model":"", "review_api_key":"", "review_image_attempts":3, "review_video_attempts":1,
    "review_image_exhausted":"accept", "review_video_exhausted":"accept", "review_frames":8,
    "review_rules":"检查人数、身份、服装、站位、动作和剧本要求；不要因个人审美偏好判失败。",
    "review_audio":False, "asr_provider":"auto", "asr_base_url":"https://api.openai.com/v1", "asr_model":"", "asr_api_key":"",
    "dialogue_padding_seconds":1.5, "dialogue_language":"auto",
    "gpu_handoff":False, "local_unload_url":"", "local_unload_body":"{}",
    "review_unload_url":"", "review_unload_body":"{}",
})
SECRET_KEYS = {"local_api_key", "review_api_key", "asr_api_key","comfy_api_key", "openai_api_key", "deepseek_api_key", "image_api_key"}

def public_settings(config):
    out = copy.deepcopy(config)
    for k in SECRET_KEYS:
        out[k] = ""
        out[k + "_configured"] = bool(config.get(k))
    out['seed']=str(config['seed'])
    for kind in ('image','video'):
        key='review_'+kind+'_enabled'
        if out.get(key) is None:out[key]=bool(out.get('review_enabled'))
    return out

def validate_settings(config):
    from urllib.parse import urlsplit
    out = {**DEFAULTS, **{k:v for k,v in config.items() if k in DEFAULTS}}
    from .dialogue_language import canonical
    out['dialogue_language']=canonical(out['dialogue_language'])
    if out["provider"] not in {"openai", "deepseek", "local"}: raise ValueError("请选择有效的创作模型来源。")
    if out['image_provider'] not in {'api','local'}:raise ValueError('生图方式请选择 API 或本地 ComfyUI 工作流。')
    for key in ('image_workflow_id','image_reference_workflow_id'):
        out[key]=str(out[key]).strip()
        if out[key]:safe_id(out[key])
    # Local model sizes belong to the graph, never to Images API settings.
    if out['image_provider']=='api':
        size=str(out['image_size']).strip().lower()
        if size!='auto':
            match=re.fullmatch(r'(\d+)x(\d+)',size)
            if not match:raise ValueError('API 图片尺寸请填写宽x高，例如1536x576，或auto。')
            w,h=map(int,match.groups())
            if w<=0 or h<=0 or w%16 or h%16:raise ValueError('API 图片宽、高必须都是16的倍数；1536x572请改为1536x576。')
        out['image_size']=size
    for k in ("comfy_url", "openai_base_url", "deepseek_base_url", "image_base_url", "local_base_url", "review_base_url", "asr_base_url", "local_unload_url", "review_unload_url"):
        u = str(out[k]).strip().rstrip("/")
        if u:
            p = urlsplit(u)
            if p.scheme not in {"http", "https"} or not p.netloc or p.username or p.password or p.query or p.fragment:
                raise ValueError(f"{k} 必须是完整的 HTTP/HTTPS 服务地址。")
        out[k] = u
    for k, minimum, maximum in (("review_image_attempts",1,1000),("review_video_attempts",1,1000),("review_frames",2,32),("width",256,5760),("height",256,5760),("steps",1,100),("turbo_steps",1,100),("retry_limit",0,10),("max_segments",1,5000),("api_timeout_seconds",30,7200),("render_timeout_minutes",1,1440),("poll_seconds",1,60),("refine_steps",1,100),("refine_start_step",0,99)):
        value = int(out[k])
        if not minimum <= value <= maximum: raise ValueError(f"{k} 超出允许范围 {minimum}–{maximum}。")
        out[k] = value
    if out["width"] % 32 or out["height"] % 32: raise ValueError("H3 宽高请使用32的倍数。")
    for k,a,b in (("duration_seconds",2,15),("overlap_seconds",0.21,5),("upscale_factor",1,8),("dialogue_padding_seconds",0,5)):
        if k=='dialogue_padding_seconds' and isinstance(out[k],bool):raise ValueError('对白余量须填写秒数。')
        value=float(out[k])
        if not math.isfinite(value) or not a<=value<=b: raise ValueError(f"{k} 超出范围。")
        out[k]=value
    out["seed"] = int(out["seed"])
    if not 0<=out["seed"]<2**64: raise ValueError("seed 必须在0到2^64-1之间。")
    if out["seed_mode"] not in {"fixed","random"}: raise ValueError("seed模式无效。")
    if int(out["bit_depth"]) not in {8,10,12,16}: raise ValueError("位深参数无效。")
    if out['refine_start_step'] >= out['refine_steps']: raise ValueError('二次采样起点必须小于二次采样步数。')
    for k in ("turbo","upscale","refine_save_vram","continue_audio","generate_shot_images","review_enabled","local_vision","review_audio","gpu_handoff"):
        if not isinstance(out[k],bool): raise ValueError(f"{k} 必须是开关。")
    for key in ('review_image_enabled','review_video_enabled'):
        if out[key] is not None and type(out[key]) is not bool:raise ValueError(key+' 必须是开关。')
    if type(out['pipeline_enabled']) is not bool:raise ValueError('pipeline_enabled 必须是开关。')
    if out['review_provider'] not in {'compatible','local'}:raise ValueError('自检来源无效。')
    from .speech_recognition import PROVIDERS as ASR_PROVIDERS, protocol as asr_protocol
    if not isinstance(out['asr_provider'],str) or out['asr_provider'] not in ASR_PROVIDERS:raise ValueError('语音识别接口类型无效。')
    if out['review_audio']:asr_protocol(out)
    for key in ('review_image_exhausted','review_video_exhausted'):
        if out[key] not in {'accept','pause'}:raise ValueError('次数耗尽策略无效。')
    for key in ('local_unload_body','review_unload_body'):
        try:value=json.loads(out[key])
        except (ValueError,TypeError):raise ValueError('卸载请求体必须是JSON对象。')
        if not isinstance(value,dict):raise ValueError('卸载请求体必须是JSON对象。')
    return out

def safe_name(name):
    value = str(name)
    if not value.strip() or value in {".",".."} or "/" in value or "\\" in value or "\0" in value or len(value)>240:
        raise ValueError("文件名无效；请使用原始文件名，不包含路径。")
    return value

def safe_id(value):
    value=str(value)
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}",value): raise ValueError("编号无效。")
    return value

def kind_for(name):
    ext=Path(name).suffix.lower()
    for kind, endings in {"image":{'.png','.jpg','.jpeg','.webp','.bmp'},"audio":{'.wav','.mp3','.flac','.ogg','.m4a','.aac'},"video":{'.mp4','.mov','.mkv','.webm'}}.items():
        if ext in endings:return kind
    raise ValueError("支持图片、音频和视频素材。")

def validate_plan(plan, assets, max_segments, min_duration=2):
    if not isinstance(plan,dict) or not isinstance(plan.get("segments"),list) or not plan["segments"]:
        raise ValueError("AI 没有返回有效的分镜任务清单。")
    if len(plan["segments"])>max_segments: raise ValueError("分镜数量超过项目设置上限。")
    known={a['id'] for a in assets}
    kinds={a['id']:a['kind'] for a in assets}
    generated=plan.get("assets_to_create",[])
    if not isinstance(generated,list) or len(generated)>100: raise ValueError("AI新增素材清单无效。")
    for a in generated:
        safe_id(a['id'])
        if a['id'] in known:raise ValueError("AI生成的素材编号重复。")
        if a.get('role') not in {'character','scene','prop','style'}:raise ValueError("新增素材角色类型无效。")
        if not a.get('image_prompt') or not a.get('label'):raise ValueError("新增素材缺少图像描述。")
        refs=a.get('reference_asset_ids',[])
        if not isinstance(refs,list) or len(refs)>8 or any(x not in known or kinds.get(x)!='image' for x in refs):raise ValueError('新增素材只可参考最多8张已有或先前创建的图片素材。')
        known.add(a['id'])
        kinds[a['id']]='image'
    for i,s in enumerate(plan['segments']):
        if not isinstance(s,dict):raise ValueError("分镜格式无效。")
        d=float(s['duration_seconds'])
        if not min_duration<=d<=15 or not math.isfinite(d):raise ValueError(f"第{i+1}段时长必须为{min_duration:g}–15秒。")
        s['duration_seconds']=d
        if s.get('continuity') not in {'cut','continue'}:raise ValueError("分镜必须说明独立镜头或续接。")
        if i==0:s['continuity']='cut'
        for f in ['asset_ids','image_reference_ids']:
            ids=s.get(f,[])
            if not isinstance(ids,list) or any(not isinstance(x,str) for x in ids) or len(ids)!=len(set(ids)) or any(x not in known for x in ids):
                raise ValueError(f"第{i+1}段引用了不存在或重复的素材。")
        s.setdefault('asset_ids',[]);s.setdefault('image_reference_ids',[])
        if any(kinds[x]!='image' for x in s['image_reference_ids']):raise ValueError('生成开场图只能使用图片参考，声音和视频请放在asset_ids。')
        used=set(s['asset_ids']+s['image_reference_ids'])
        counts={k:sum(kinds[x]==k for x in used) for k in ('image','video','audio')}
        if counts['image']>8 or counts['video']>3 or counts['audio']>3 or len(used)>11:raise ValueError('单段参考素材超过H3限额，请为开场图预留一个位置。')
        if not s.get('visual_zh') or not s.get('image_prompt'):raise ValueError(f"第{i+1}段缺少画面或参考图描述。")
        if not isinstance(s.get('dialogue',[]),list):raise ValueError("台词格式无效。")
        from .dialogue_language import canonical
        canonical(s.get('dialogue_language','auto'))
        for line in s.get('dialogue',[]):
            if not isinstance(line,dict) or not isinstance(line.get('text'),str) or not isinstance(line.get('speaker'),str) or not line['speaker']:raise ValueError("台词缺少说话人或原文。")
            canonical(line.get('language','auto'))
        if 'depends_on_previous' in s and type(s['depends_on_previous']) is not bool:raise ValueError('depends_on_previous须为布尔值。')
        if i==0:s['depends_on_previous']=False
        s['index']=i
    return plan

def validate_rewrite(result, media, dialogue=None):
    if not isinstance(result,dict) or not isinstance(result.get('prompt_en'),str):raise ValueError("AI未返回H3提示词。")
    prompt=result['prompt_en'].strip()
    positions=[]
    for section in SECTIONS:
        m=re.search(r'(?m)^\s*'+section+r'\s*:',prompt)
        if not m:raise ValueError("H3提示词缺少规范区域："+section)
        positions.append(m.start())
    if positions!=sorted(positions):raise ValueError("H3六个区域顺序不符合规范。")
    if re.search(r'(?mi)^\s*asset_bindings\s*:',prompt):raise ValueError("AI把软件素材绑定表混入了H3正文。")
    maximum={"Picture":len(media.get('images',[])),"Video":len(media.get('videos',[])),"Audio":len(media.get('audios',[]))}
    actual={(k,int(n)) for k,n in REFERENCE.findall(prompt)}
    expected={(k,n) for k,m in maximum.items() for n in range(1,m+1)}
    if actual!=expected:
        missing=expected-actual;invalid=actual-expected
        raise ValueError("H3素材引用与实际素材不一致。未引用："+str(sorted(missing))+"；不存在："+str(sorted(invalid)))
    music=prompt[positions[-1]:].lower()
    if not any(x in music for x in ('n/a','none','no background music','music=0','music = 0')):raise ValueError("音乐区域必须说明无背景音乐。")
    result['prompt_en']=prompt
    if not isinstance(result.get('prompt_zh'),str) or not result['prompt_zh'].strip():raise ValueError('AI未返回提示词的中文对照。')
    for line in dialogue or []:
        if line['text'] not in prompt: raise ValueError('H3提示词遗漏或改写了原文台词：'+line['text'])
    return result

def media_state(images, videos, audios):
    if len(images)>9 or len(videos)>3 or len(audios)>3 or len(images)+len(videos)+len(audios)>12:
        raise ValueError("单段素材超过H3限制：9图、3视频、3音频、合计12个。")
    return {'version':1,'images':images,'videos':[{'name':v,'include_audio':False} for v in videos],'audios':audios}

def h3_frames(seconds):
    frames=max(5,round(float(seconds)*24))
    return frames+(5-frames%17)%17

def video_timing(clip,config,previous_clip=None):
    frames=h3_frames(clip['duration_seconds']);guide=0
    if clip.get('continuity')=='continue':
        requested=max(5,round(config['overlap_seconds']*24))
        requested=5+17*((requested-5)//17)
        available=h3_frames(previous_clip['duration_seconds']) if previous_clip else requested
        guide=min(requested,available)
    total=frames+guide;total+=(5-total%17)%17
    if clip.get('timing_version'):
        frames=round(clip['duration_seconds']*24)
        if previous_clip:guide=min(guide,5+17*((max(5,round(previous_clip['duration_seconds']*24))-5)//17))
        if clip.get('continuity')=='continue':
            from .dialogue_retention import actual_guide_frames
            actual=actual_guide_frames(previous_clip)
            if actual is not None:guide=min(requested,actual)
        total=h3_frames(clip['generation_seconds'])+guide;total+=(5-total%17)%17
    return {'new_content_start_seconds':guide/24,'new_content_end_seconds':(guide+frames)/24,
            'effective_new_video_seconds':frames/24,'generated_total_seconds':total/24,
            'guide_frames':guide,'output_frames':frames}

def build_graph(template, clip, config, media, previous, output_prefix):
    graph=copy.deepcopy(template)
    graph['39']['inputs']['value']=clip['prompt_en']
    graph['38']['inputs'].update(width=config['width'],height=config['height'],batch_media_json=json.dumps(media,ensure_ascii=False))
    graph['31']['inputs']['value']=float(clip.get('generation_seconds',clip['duration_seconds']))
    frames=h3_frames(clip.get('generation_seconds',clip['duration_seconds']))
    graph['10']={'class_type':'PrimitiveInt','inputs':{'value':frames}}
    graph['38']['inputs']['length']=['10',0]
    graph['18']['inputs']['noise_seed']=int(clip['seed'])
    graph['12']['inputs']['value']=int(config['steps']);graph['16']['inputs']['value']=int(config['turbo_steps'])
    graph['17']['inputs']['value']=bool(config['turbo'])
    continued=clip.get('continuity')=='continue'
    if continued and not previous:raise ValueError("续接任务缺少已完成的上一段视频。")
    graph['34']['inputs']['value']=continued
    graph['40']['inputs'].update(previous_video_name=previous or '',overlap_seconds=config['overlap_seconds'],include_audio=config['continue_audio'])
    graph['37']['inputs']['value']=bool(config['upscale'])
    graph['35']['inputs']['mode.scale']=float(config['upscale_factor'])
    graph['23']['inputs']['steps']=int(config['refine_steps']);graph['24']['inputs']['step']=int(config['refine_start_step'])
    graph['36']['inputs']['save_vram']=bool(config['refine_save_vram'])
    graph['30']['inputs'].update(bit_depth=int(config['bit_depth']),color_space=config['color_space'])
    graph['20']['inputs']['filename_prefix']=output_prefix
    # Resolve switches from their literal inputs before pruning. Unused LoRA and
    # upscale dependencies must not prevent the normal rendering branch running.
    def literal(link):
        if isinstance(link,list) and len(link)==2 and link[0] in graph:
            n=graph[link[0]]
            if n['class_type'].startswith('Primitive'):return n['inputs'].get('value')
        return link
    for nid,node in list(graph.items()):
        if node['class_type']=='ComfySwitchNode':
            flag=literal(node['inputs']['switch'])
            if isinstance(flag,bool):
                chosen=node['inputs']['on_true' if flag else 'on_false']
                for other in graph.values():
                    for k,v in other['inputs'].items():
                        if v==[nid,0]:other['inputs'][k]=copy.deepcopy(chosen)
    used=set()
    def walk(nid):
        if nid in used:return
        if nid not in graph:raise ValueError("工作流引用不存在的节点。")
        used.add(nid)
        for v in graph[nid]['inputs'].values():
            if isinstance(v,list) and len(v)==2 and isinstance(v[0],str) and v[0] in graph:walk(v[0])
    walk('20')
    return {k:v for k,v in graph.items() if k in used}

def dependent_indices(clips, selected):
    affected=set(selected)
    for i in range(len(clips)):
        if i and (clips[i].get('continuity')=='continue' or clips[i].get('depends_on_previous')) and i-1 in affected:affected.add(i)
    return sorted(affected)
