"""Opt-in adapters. Original Engine/SeriesManager are called unchanged for old modes."""
from __future__ import annotations
import asyncio
import copy
import json
import time
import uuid
from ..engine import Engine as OriginalEngine
from ..series import SeriesManager as OriginalSeriesManager
from ..series_batches import initial_batch
from .. import image_workflows, workflows, timing_policy, dialogue_timing
from ..production import fingerprint, validate_bindings, binding_ids
from ..character_bindings import save_bindings as original_save_bindings
from ..telemetry import _owner, measure
from ..domain import safe_id
from . import MODE
from . import schema, runtime

def is_draft(record): return record.get('input_type')==MODE or record.get('execution_mode')==MODE

class Engine(OriginalEngine):
    def config(self,p):
        context=p if is_draft(p) else runtime.active.get()
        if not context: return super().config(p)
        cfg=super().config({**p,'settings':{**p.get('settings',{}),'generate_shot_images':True}})
        # No creative model is loaded in this mode. Retain conservative scheduling
        # when the user selected a shared local GPU; don't redesign the pipeline.
        if cfg['provider']=='local': cfg['pipeline_enabled']=False
        cfg['provider']='openai'
        if context.get('draft_needs_images',True):
            if not context.get('allow_image_api',False): cfg['image_provider']='local'
        else:
            # No image-generation methods run when every opening is supplied.
            # Avoid requiring an unused local image template during preflight.
            cfg['image_provider']='api'
        if p.get('series_id'):
            parent=self.store.get('series',p['series_id'])
            batch=next((b for b in parent.get('batches',[]) if b.get('id')==p.get('series_batch_id','initial')),None)
            if batch:cfg['_dialogue_fixed_total']=bool(timing_policy.seconds(batch.get('timing_policy'),'total'))
        return cfg

    async def checked_text(self,*args,**kwargs):
        if runtime.active.get():
            owner=_owner.get()
            if owner:
                store,kind,identity=owner
                store.update(kind,identity,lambda r:r.update(draft_api_guard_blocks=r.get('draft_api_guard_blocks',0)+1))
            raise RuntimeError('制作稿模式禁止调用创作API；缺少安排应在制作稿中补全。')
        return await super().checked_text(*args,**kwargs)

    async def run(self,identity):
        p=self.store.get('project',identity)
        if not is_draft(p): return await super().run(identity)
        token=runtime.active.set(p)
        try: return await super().run(identity)
        finally: runtime.active.reset(token)

    async def _prepare_episode(self,identity,previous=None,images=False):
        p=self.store.get('project',identity)
        if not is_draft(p): return await super()._prepare_episode(identity,previous,images)
        token=runtime.active.set(p)
        try: return await super()._prepare_episode(identity,previous,images)
        finally: runtime.active.reset(token)

    async def plan(self,identity,ai,cfg):
        if not is_draft(self.store.get('project',identity)): return await super().plan(identity,ai,cfg)
        return await runtime.plan(self,identity,cfg)

    async def prepare_clip(self,identity,index,ai,cfg):
        if not is_draft(self.store.get('project',identity)): return await super().prepare_clip(identity,index,ai,cfg)
        return await runtime.prepare(self,identity,index,ai,cfg)

    def script_editable(self,p):
        if is_draft(p): return False
        return super().script_editable(p)

    def check_script_edit(self,p,body):
        if is_draft(p): raise ValueError('制作稿的原文、对白和时间轴属于同一安排；请修改完整制作稿后新建，不能单独改剧本文字。')
        return super().check_script_edit(p,body)

    def redo(self,identity,indices,feedback='',new_seed=True,regenerate_image=False):
        p=self.store.get('project',identity)
        if is_draft(p) and regenerate_image and any(p['clips'][int(i)].get('opening_frame_key') for i in indices):
            raise ValueError('所选镜头使用制作稿指定的现成开场图；取消“重新生成开场图”可直接重做视频。更换该图请修改制作稿。')
        return super().redo(identity,indices,feedback,new_seed,regenerate_image)

class SeriesManager(OriginalSeriesManager):
    def start(self,identity):
        super().start(identity)
        record=self.store.get('series',identity)
        if is_draft(record) and record['status']=='queued': self.set(identity,phase='已排队，将按制作稿直接执行各集')

    def prepared(self,body,previous=None):
        d=schema.loads(body.get('text',''))
        policy=timing_policy.from_body(body)
        try: count=int(body.get('episode_count',0))
        except (TypeError,ValueError): raise ValueError('集数须为整数。')
        if not 0<=count<=100: raise ValueError('集数须为0至100，0采用制作稿集数。')
        wf=workflows.resolved(self.store.get('workflow',safe_id(body['workflow_id']))) if body.get('workflow_id') else copy.deepcopy((previous or {}).get('batches',[{}])[-1].get('workflow_snapshot'))
        if not wf: raise ValueError('请选择视频工作流。')
        if body.get('workflow_id') and wf.get('archived'): raise ValueError('请选择未归档的视频工作流。')
        allow=body.get('allow_image_api',False)
        if type(allow) is not bool: raise ValueError('允许生图API须为开关。')
        settings={'execution_mode':MODE,'allow_image_api':allow,'draft_needs_images':schema.needs_images(d),'settings':{},'workflow_snapshot':wf}
        cfg=self.engine.config(settings)
        from ..dialogue_language import canonical
        if canonical(d.get('dialogue_language','auto'))=='auto' and cfg['dialogue_language']!='auto':
            d['dialogue_language']=cfg['dialogue_language']
            # Validate the actual execution language before generating images.
            schema.validate(d)
        snapshot=None
        if settings['draft_needs_images'] and cfg['image_provider']=='local':
            try: snapshot=image_workflows.snapshots(self.store,cfg)
            except ValueError as e: raise ValueError('制作稿默认使用本地生图。请先配置本地生图工作流，或明确勾选允许按当前设置调用生图API。'+str(e))
        if previous:
            old=previous['production_draft']
            if d['style']!=old['style']: raise ValueError('追加制作稿须沿用本剧风格。')
            old_assets={a['key']:a for a in old['assets']}
            for a in d['assets']:
                if a['key'] in old_assets and a!=old_assets[a['key']]: raise ValueError('追加制作稿改变了已有素材声明：'+a['key']+'；请复用原声明，新素材另设键。')
            for name,c in d['characters'].items():
                if name in old['characters'] and c!=old['characters'][name]: raise ValueError('追加制作稿改变了固定角色声明：'+name)
        selected=body.get('asset_ids',[]) or (previous or {}).get('asset_ids',[])
        if not isinstance(selected,list) or any(not isinstance(a,str) for a in selected): raise ValueError('素材选择格式无效。')
        mapping,catalog,generated,bindings=schema.resolve_assets(d,self.store,self.files,selected,(previous or {}).get('generated_assets'))
        durations=schema.validate_execution(d,mapping,catalog,generated,wf,cfg,policy,count)
        if snapshot:
            # Shared assets use the same base/reference selection as runtime.
            # Validate them before creating records or starting earlier images.
            for item in generated:
                refs=item.get('reference_asset_ids',[])
                image_workflow=snapshot.get('reference' if refs else 'base')
                if not image_workflow:
                    raise ValueError('制作稿共用素材 '+item['id']+' 缺少对应的本地生图工作流。')
                try:
                    image_workflows.instantiate(image_workflow,item['image_prompt'],
                        [f'validation_{i}.png' for i in range(len(refs))],'validation')
                except ValueError as e:
                    raise ValueError('制作稿共用素材 '+item['id']+'：'+str(e)) from e
            for e in d['episodes']:
                for s in e['segments']:
                    if s.get('opening_frame_key'): continue
                    refs=set(s['image_reference_keys'])
                    for name in s['characters']: refs.update(d['characters'][name]['image_keys'])
                    if not refs: refs.update(k for k in s['asset_keys'] if next(a for a in d['assets'] if a['key']==k)['kind']=='image')
                    capacity=snapshot['reference']['metadata'].get('reference_capacity',8) if snapshot.get('reference') else 0
                    if len(refs)+bool(s['depends_on_previous'] or s['use_previous_episode_state'])>min(8,capacity): raise ValueError('制作稿生图参考数量（含前段状态）超过所选参考工作流容量。')
        for e in d['episodes']:
            runtime.validate_compilation({'production_draft':{**d,'episodes':[e]},'draft_asset_bindings':mapping,'character_bindings':bindings},catalog,wf)
        return d,policy,wf,snapshot,mapping,catalog,generated,bindings,durations,allow

    def create(self,body):
        if body.get('input_type')!=MODE: return super().create(body)
        values=self.prepared(body)
        d,policy,wf,snapshot,mapping,catalog,generated,bindings,durations,allow=values
        now=time.time();identity=uuid.uuid4().hex
        episodes=[{**copy.deepcopy(e),'batch_id':'initial','target_seconds':duration} for e,duration in zip(d['episodes'],durations)]
        record={'id':identity,'title':str(body.get('title') or d['title'])[:160],'text':json.dumps(d,ensure_ascii=False),
                'input_type':MODE,'execution_mode':MODE,'episode_count':len(episodes),'target_episode_seconds':timing_policy.seconds(policy,'episode'),
                'instructions':str(body.get('instructions','')),'timing_policy':policy,'workflow_snapshot':wf,'image_workflow_snapshots':snapshot,
                'asset_ids':[a['id'] for a in catalog if a['id'] not in {g['id'] for g in generated}], 'character_bindings':{},
                'generated_assets':{k:v for k,v in mapping.items() if k not in {g['id'] for g in generated}},
                'plan':{'style':d['style'],'shared_assets':generated,'episodes':episodes},'project_ids':[],'events':[],
                'status':'draft','phase':'制作稿已完整校验，等待开始','error':'','pause_requested':False,'created_at':now,'updated_at':now,
                'revision':1,'continuity_summary':'','memory_through':0,'removed_episodes':{},'production_draft':d,
                'draft_asset_bindings':mapping,'allow_image_api':allow,'draft_needs_images':schema.needs_images(d),
                'draft_sha256':fingerprint(d),'draft_api_guard_blocks':0}
        # Pins that include images not generated yet are bound after shared_assets.
        record['character_bindings']={name:b for name,b in bindings.items() if all(k in record['asset_ids'] for k in b['image_ids']+([b['voice_id']] if b['voice_id'] else []))}
        batch=initial_batch(record)
        batch.update(production_draft=copy.deepcopy(d),draft_asset_bindings=mapping,allow_image_api=allow,draft_needs_images=schema.needs_images(d))
        record['batches']=[batch]
        result=self.store.put('series',identity,record)
        self.event(identity,f'制作稿导入通过：{len(episodes)}集，{sum(len(e["segments"]) for e in episodes)}个任务。分集、编剧、分镜、翻译及提示词修正的创作API均已跳过。')
        return result

    async def run(self,identity):
        record=self.store.get('series',identity)
        if not is_draft(record): return await super().run(identity)
        token=runtime.active.set(record)
        try: return await super().run(identity)
        finally: runtime.active.reset(token)

    async def plan(self,identity,ai,cfg):
        if not is_draft(self.store.get('series',identity)): return await super().plan(identity,ai,cfg)
        self.set(identity,phase='按制作稿读取已编排各集')

    async def write_scripts(self,identity,ai):
        if not is_draft(self.store.get('series',identity)): return await super().write_scripts(identity,ai)

    async def remember_previous(self,identity,ai):
        if not is_draft(self.store.get('series',identity)): return await super().remember_previous(identity,ai)
        r=self.record(identity)
        self.set(identity,continuity_summary='\n'.join(f'第{i+1}集：'+e['summary'] for i,e in enumerate(r['plan']['episodes'])),memory_through=len(r['plan']['episodes']))

    def create_children(self,identity):
        record=self.record(identity)
        if not is_draft(record): return super().create_children(identity)
        for i,e in enumerate(record['plan']['episodes']):
            pid=self.episode_id(identity,i)
            if pid in record['removed_episodes']: continue
            batch=self.batch_for(record,e);d=copy.deepcopy(batch['production_draft']);d['episodes']=[{k:v for k,v in e.items() if k not in {'batch_id','target_seconds'}}]
            mapping={k:record['generated_assets'].get(k,v) for k,v in batch['draft_asset_bindings'].items()}
            bindings={name:{'image_ids':[mapping[k] for k in c['image_keys']],'voice_id':mapping.get(c.get('voice_key'),'')} for name,c in d['characters'].items()}
            bindings=validate_bindings(bindings,self.store)
            p=self.store.create_project({'title':f'{record["title"]}·第{i+1}集：{e["title"]}','script':e['script'],
                'instructions':record['instructions']+'\n'+batch['instructions'],'asset_ids':list(dict.fromkeys(mapping.values())),
                'series_id':identity,'character_bindings':bindings},project_id=pid)
            if not is_draft(p):
                policy=copy.deepcopy(batch['timing_policy']);policy['total']={'enabled':False,'seconds':None}
                self.engine.set(pid,execution_mode=MODE,production_draft=d,draft_asset_bindings=mapping,draft_sha256=fingerprint(d),
                    allow_image_api=batch['allow_image_api'],draft_needs_images=batch['draft_needs_images'],
                    workflow_snapshot=copy.deepcopy(batch['workflow_snapshot']),image_workflow_snapshots=copy.deepcopy(batch['image_workflow_snapshots']),
                    episode_number=i+1,series_batch_id=batch['id'],episode_target_seconds=e['target_seconds'],timing_policy=policy,
                    previous_episode_id=self.episode_id(identity,i-1) if i else None,draft_api_guard_blocks=0)
                # Local, deterministic plans are saved immediately. Generic script
                # editing must never detach the source dialogue from this timeline.
                project=self.store.get('project',pid);cfg=self.engine.config(project);plan=runtime.materialize(project)
                for segment in plan['segments']:dialogue_timing.prepare(project,segment,cfg)
                import secrets
                clips=[{**s,'seed':s.get('seed',secrets.randbits(63) if cfg['seed_mode']=='random' else cfg['seed']) if batch['workflow_snapshot']['bindings'].get('seed') else None,
                        'status':'pending','generation':1,'versions':[]} for s in plan['segments']]
                self.engine.set(pid,plan=plan,clips=clips,planned_duration_seconds=sum(c['duration_seconds'] for c in clips))
            self.store.update('series',identity,lambda r:r['project_ids'].append(pid) if pid not in r['project_ids'] else None)
        latest=self.record(identity)
        self.set(identity,character_bindings={name:{'image_ids':[latest['generated_assets'].get(k,latest['draft_asset_bindings'][k]) for k in c['image_keys']],
                 'voice_id':latest['generated_assets'].get(c.get('voice_key'),latest['draft_asset_bindings'].get(c.get('voice_key'),''))} for name,c in latest['production_draft']['characters'].items()})

    def append(self,identity,body):
        record=self.record(identity)
        if not is_draft(record): return super().append(identity,body)
        if body.get('input_type')!=MODE: raise ValueError('本剧按制作稿执行，追加时请继续导入已编排制作稿。')
        request_id=body.get('request_id');signature=fingerprint({k:v for k,v in body.items() if k!='expected_revision'})
        if not isinstance(request_id,str) or not 1<=len(request_id)<=100: raise ValueError('请重新打开追加窗口。')
        with self.store.lock:
            record=self.record(identity)
            for b in record['batches']:
                if b.get('request_id')==request_id:
                    if b['request_sha256']!=signature: raise ValueError('同一次追加内容已改变，请重新打开窗口。')
                    return record
            self.ensure_idle(identity)
            if record.get('archived'): raise ValueError('请先恢复整剧。')
            if body.get('expected_revision')!=record['revision']: raise ValueError('整剧内容已变化，请重新打开追加窗口。')
            if any(self.store.get('project',p)['status']!='complete' for p in record['project_ids']): raise ValueError('请先完成本批，再追加。')
            d,policy,wf,snapshot,mapping,catalog,generated,bindings,durations,allow=self.prepared(body,record)
            bid=uuid.uuid4().hex;start=len(record['plan']['episodes'])
            batch={'id':bid,'input_type':MODE,'text':json.dumps(d,ensure_ascii=False),'episode_count':len(d['episodes']),
                   'target_episode_seconds':timing_policy.seconds(policy,'episode'),'timing_policy':policy,'instructions':str(body.get('instructions','')),
                   'workflow_snapshot':wf,'image_workflow_snapshots':snapshot,'status':'planned','start_index':start,'episode_total':len(d['episodes']),
                   'created_at':time.time(),'request_id':request_id,'request_sha256':signature,'production_draft':d,
                   'draft_asset_bindings':mapping,'allow_image_api':allow,'draft_needs_images':schema.needs_images(d)}
            record['batches'].append(batch)
            record['plan']['episodes'] += [{**copy.deepcopy(e),'batch_id':bid,'target_seconds':duration} for e,duration in zip(d['episodes'],durations)]
            record['plan']['shared_assets']+=generated
            record['asset_ids']=list(dict.fromkeys(record['asset_ids']+[a['id'] for a in catalog if a['id'] not in {g['id'] for g in generated}]))
            record['generated_assets'].update({k:v for k,v in mapping.items() if k not in {g['id'] for g in generated}})
            record['draft_asset_bindings'].update(mapping)
            oldkeys={a['key'] for a in record['production_draft']['assets']}
            record['production_draft']['assets'] += [a for a in d['assets'] if a['key'] not in oldkeys]
            record['production_draft']['characters'].update(d['characters'])
            record.update(status='draft',phase='后续制作稿已校验，等待继续',error='',revision=record['revision']+1,
                          allow_image_api=allow,draft_needs_images=schema.needs_images(d),updated_at=time.time())
            record['continuity_summary']='\n'.join(f'第{i+1}集：'+e['summary'] for i,e in enumerate(record['plan']['episodes'][:start]))
            record['memory_through']=start
            self.store.put('series',identity,record)
            self.event(identity,'追加制作稿已本地校验；沿用素材和事先写好的剧情记录，不调用剧情总结API。')
            return record

    def public(self,identity,export=False):
        result=super().public(identity,export)
        if is_draft(result) and not export:
            result.pop('production_draft',None)
            for batch in result['batches']: batch.pop('production_draft',None)
        return result

def production_started(project):
    """Authored opening images are inputs, not evidence of generation.

    Committed image/video intents and previous takes remain immutable even if
    an interrupted task has not linked its final output yet.
    """
    if project.get('final') or project.get('final_versions'): return True
    mapping=project.get('draft_asset_bindings',{})
    for clip in project.get('clips',[]):
        if any(clip.get(key) for key in ('image_asset_id','job_id','prompt_id',
                'output','raw_output','versions','submission_unknown')): return True
        frame=clip.get('frame_asset_id')
        authored=mapping.get(clip.get('opening_frame_key'))
        if frame and frame!=authored: return True
    return False

def save_bindings(store,kind,identity,body):
    record=store.get(kind,identity)
    if not is_draft(record): return original_save_bindings(store,kind,identity,body)
    if kind!='series': raise ValueError('请在所属整剧修改固定角色与声音。')
    with store.lock:
        record=store.get(kind,identity)
        if record.get('archived') or record['status'] in {'running','queued','pausing'}: raise ValueError('请先暂停制作。')
        if body.get('expected_revision')!=record.get('bindings_revision',1): raise ValueError('角色绑定已改变，请重新打开。')
        bindings=validate_bindings(body.get('character_bindings',{}),store)
        # Semantic references need a stable one-to-one pin replacement. Removing
        # or adding a pin requires a revised complete draft, not an AI repair.
        d=record['production_draft'];replacement={}
        for name,c in d['characters'].items():
            b=bindings.get(name,{'image_ids':[],'voice_id':''})
            if len(b['image_ids'])!=len(c['image_keys']) or bool(b.get('voice_id'))!=bool(c.get('voice_key')):
                raise ValueError('制作稿固定引用数量不能改变；可替换已有角色图片/声音，新增或删除引用请修改制作稿。')
            replacement.update(zip(c['image_keys'],b['image_ids']))
            if c.get('voice_key'): replacement[c['voice_key']]=b['voice_id']
        writes=[];updated=retained=0
        for pid in record['project_ids']:
            p=store.get('project',pid)
            if p['status'] in {'running','queued','pausing'}: raise ValueError('还有单集正在运行，请先暂停。')
            if production_started(p): retained+=1;continue
            p['draft_asset_bindings'].update({k:v for k,v in replacement.items() if k in p['draft_asset_bindings']})
            p['character_bindings']={name:bindings[name] for name in p['production_draft']['characters'] if name in bindings}
            p['asset_ids']=list(dict.fromkeys(p['draft_asset_bindings'].values()))
            catalog=[store.get('asset',aid) for aid in p['asset_ids']]
            plan=runtime.validate_compilation(p,catalog,p['workflow_snapshot'])
            for clip,segment in zip(p['clips'],plan['segments']):
                clip.update(segment)
                for k in ('prompt_en','prompt_zh','prompt_compiler_version',
                          'compiled_media_bindings','compiled_asset_versions',
                          'compiler_warnings','draft_compiler_version'): clip.pop(k,None)
            p['plan']=plan;writes.append(('project',pid,p));updated+=1
        record['draft_asset_bindings'].update(replacement);record['generated_assets'].update(replacement)
        record['character_bindings']=bindings;record['bindings_revision']=record.get('bindings_revision',1)+1
        record['asset_ids']=list(dict.fromkeys(record['asset_ids']+binding_ids(bindings)))
        writes.append(('series',identity,record));store.apply_changes(writes)
        return {'updated_episodes':updated,'retained_episodes':retained,'bindings_revision':record['bindings_revision']}
