"""Configurable paid API clients. No API call is made at plugin import time."""
from __future__ import annotations
import asyncio
import base64
import io
import json
import time
from contextvars import ContextVar
from . import api_diagnostics as diagnostics
from pathlib import Path
import aiohttp
from PIL import Image, ImageOps

class APIError(RuntimeError): pass

class ContentFormatError(APIError):
    """Successful text response whose requested JSON content is malformed."""
    pass

def thumbnail(path):
    with Image.open(path) as source:
        im=ImageOps.exif_transpose(source).convert('RGB')
        im.thumbnail((1024,1024));buffer=io.BytesIO();im.save(buffer,'JPEG',quality=85)
    return 'data:image/jpeg;base64,'+base64.b64encode(buffer.getvalue()).decode('ascii')

def json_object(text):
    value=str(text).strip()
    if value.startswith('```'):
        value=value.split('\n',1)[-1].rsplit('```',1)[0].strip()
    try:body=json.loads(value)
    except json.JSONDecodeError as e:raise ContentFormatError('AI返回的JSON无法读取：'+str(e)) from e
    if not isinstance(body,dict):raise ContentFormatError('AI必须返回JSON对象。')
    return body

def responses_text(data):
    if not isinstance(data,dict):raise APIError('Responses返回不是JSON对象。')
    if data.get('status') in {'failed','incomplete','cancelled'}:
        raise APIError('AI任务未完整返回：'+str(data.get('error') or data.get('incomplete_details')))
    output=data.get('output') or []
    if not isinstance(output,list):raise APIError('Responses的output格式无效。')
    pieces=[]
    for item in output:
        if not isinstance(item,dict):continue
        content=item.get('content') or []
        if not isinstance(content,list):continue
        for part in content:
            if not isinstance(part,dict):continue
            if part.get('type')=='refusal':raise APIError('AI拒绝了这次请求：'+str(part.get('refusal') or '未提供原因'))
            if part.get('type')=='output_text' and isinstance(part.get('text'),str):pieces.append(part['text'])
    text=''.join(pieces).strip()
    if not text:raise APIError('Responses没有返回有效文字内容；候选与进度已保留。')
    return text


def chat_text(data):
    if not isinstance(data,dict):raise APIError('对话接口返回不是JSON对象。')
    choices=data.get('choices')
    if not isinstance(choices,list) or not choices or not isinstance(choices[0],dict):raise APIError('模型没有返回有效choices。')
    choice=choices[0]
    if choice.get('finish_reason') in {'length','content_filter'}:raise APIError('模型返回未完成：'+str(choice['finish_reason']))
    message=choice.get('message')
    if not isinstance(message,dict):raise APIError('模型没有返回有效message。')
    if message.get('refusal'):raise APIError('模型拒绝了这次请求：'+str(message['refusal']))
    content=message.get('content')
    if isinstance(content,list):content=''.join(p['text'] for p in content if isinstance(p,dict) and p.get('type') in {'text','output_text'} and isinstance(p.get('text'),str))
    if not isinstance(content,str) or not content.strip():raise APIError('模型没有返回正文；思考过程不能代替正文。')
    return content


class AIClient:
    def __init__(self,config,session):
        self.config=config;self.session=session
        self._last_request=ContextVar('api_last_request',default=None)
        self._last_response=ContextVar('api_last_response',default=None)
    @property
    def last_request(self):return self._last_request.get()
    @last_request.setter
    def last_request(self,value):self._last_request.set(value)
    @property
    def last_response(self):return self._last_response.get()
    @last_response.setter
    def last_response(self,value):self._last_response.set(value)
    def validation_failed(self,error,result=None):
        if self.last_request:
            diagnostics.save(self.last_request,self.config,response=self.last_response,error=error)
    def parse_text(self,data,parser):
        try:return json_object(parser(data))
        except APIError as error:
            self.validation_failed(error)
            raise
    async def _request(self,url,key,payload=None,form_factory=None,allow_empty_key=False):
        if not key and not allow_empty_key:raise APIError('请先在设置中填写对应服务的API Key。')
        cfg=self.config
        for attempt in range(cfg['retry_limit']+1):
            record=diagnostics.begin(url,payload);record['attempt']=attempt+1
            self.last_request=record;self.last_response=None
            diagnostics.save(record,cfg)
            try:
                kwargs={'headers':({'Authorization':'Bearer '+key} if key else {}),'timeout':aiohttp.ClientTimeout(total=cfg['api_timeout_seconds'])}
                if form_factory:kwargs['data']=form_factory()
                else:kwargs['json']=payload
                async with self.session.post(url,**kwargs) as response:
                    record.update(http_status=response.status,request_id=response.headers.get('x-request-id') or response.headers.get('request-id') or response.headers.get('x-dashscope-request-id'))
                    raw=await response.text()
                    record.update(finished_at=time.time(),seconds=round(time.time()-record['started_at'],3))
                    try:data=json.loads(raw)
                    except (ValueError,TypeError):data=None
                    self.last_response=data if data is not None else raw[:40000]
                    if response.status in (429,500,502,503,504) and attempt<cfg['retry_limit']:
                        diagnostics.save(record,cfg,response=self.last_response,error='HTTP '+str(response.status)+'；按原技术重试预算重试')
                        await asyncio.sleep(min(30,2**(attempt+1)));continue
                    if response.status>=400:raise APIError(f'AI接口返回 HTTP {response.status}：'+str(diagnostics.redact(raw[:1500],cfg)))
                    if not isinstance(data,dict):raise APIError('AI接口没有返回有效JSON对象。')
                    if data.get('error'):raise APIError('AI接口返回错误：'+str(diagnostics.redact(data['error'],cfg))[:1500])
                    record.update(status='received',usage=data.get('usage'),response_id=data.get('id'))
                    diagnostics.save(record,cfg)
                    return data
            except (aiohttp.ClientError,asyncio.TimeoutError) as error:
                message='AI连接中断或超时；提交结果可能未知，不自动重复请求。项目已保存。'+str(error)
                diagnostics.save(record,cfg,error=message)
                raise APIError(message) from error
            except APIError as error:
                diagnostics.save(record,cfg,response=self.last_response,error=error)
                raise
            except asyncio.CancelledError:
                diagnostics.save(record,cfg,error='任务暂停或服务退出；API请求结果未知，不自动重试。')
                raise
        raise APIError('AI接口重试次数已用完。')

    async def text(self,instructions,prompt,images=()):
        cfg=self.config
        if cfg['provider']=='local':
            from .review import release_comfy, release_local
            await release_comfy(cfg,self.session)
            try:
                return await self.compatible(instructions,prompt,images if cfg.get('local_vision') else (),
                    cfg['local_base_url'],cfg['local_model'],cfg['local_api_key'],True)
            finally:await release_local(cfg,self.session)
        if cfg['provider']=='openai':
            # Responses JSON-mode validation checks input messages, not only
            # the separate instructions field. Preserve the task text intact.
            content=[{'type':'input_text','text':prompt},
                     {'type':'input_text','text':'请按要求只返回一个有效的 JSON 对象，不要使用 Markdown 代码块。'}]
            for item in images:
                content.append({'type':'input_text','text':'素材编号 '+item['id']+'：'+item['name']})
                content.append({'type':'input_image','image_url':thumbnail(item['path'])})
            payload={'model':cfg['openai_model'],'instructions':instructions+'\n只返回一个JSON对象。',
                     'input':[{'role':'user','content':content}],
                     'text':{'format':{'type':'json_object'}}}
            data=await self._request(cfg['openai_base_url']+'/responses',cfg['openai_api_key'],payload)
            return self.parse_text(data,responses_text)
        payload={'model':cfg['deepseek_model'],'messages':[{'role':'system','content':instructions+'\n只返回JSON对象（JSON）。'},{'role':'user','content':prompt}],
                 'response_format':{'type':'json_object'},'max_tokens':8192}
        data=await self._request(cfg['deepseek_base_url']+'/chat/completions',cfg['deepseek_api_key'],payload)
        return self.parse_text(data,chat_text)

    async def compatible(self,instructions,prompt,images,base,model,key,local=False):
        if not model.strip():raise APIError('请填写模型名称。')
        content=[{'type':'text','text':prompt}]
        for item in images:
            content.extend([{'type':'text','text':item.get('name','图片')},
                            {'type':'image_url','image_url':{'url':thumbnail(item['path'])}}])
        payload={'model':model,'messages':[{'role':'system','content':instructions+'\n只返回JSON对象。'},
                 {'role':'user','content':content if images else prompt}], 'max_tokens':8192}
        data=await self._request(base.rstrip('/')+'/chat/completions',key,payload,allow_empty_key=local)
        return self.parse_text(data,chat_text)

    async def image(self,prompt,reference_paths=()):
        cfg=self.config;key=cfg['image_api_key'] or cfg['openai_api_key']
        fields={'model':cfg['image_model'],'prompt':prompt,'n':'1','size':cfg['image_size'],'quality':cfg['image_quality'],'output_format':'png'}
        refs=list(reference_paths)
        if refs:
            blobs=[]
            for path in refs[:8]:
                with Image.open(path) as image:
                    im=ImageOps.exif_transpose(image).convert('RGB');im.thumbnail((2048,2048))
                    data=io.BytesIO();im.save(data,'PNG');blobs.append(data.getvalue())
            def form():
                body=aiohttp.FormData()
                for k,v in fields.items():body.add_field(k,v)
                for i,blob in enumerate(blobs):body.add_field('image[]',blob,filename=f'reference_{i+1}.png',content_type='image/png')
                return body
            result=await self._request(cfg['image_base_url']+'/images/edits',key,payload=fields,form_factory=form)
        else:
            fields['n']=1
            result=await self._request(cfg['image_base_url']+'/images/generations',key,fields)
        rows=result.get('data')
        if not isinstance(rows,list) or not rows or not isinstance(rows[0],dict):
            self.validation_failed('生图API没有返回有效图片',result)
            raise APIError('生图API没有返回有效图片。')
        item=rows[0]
        if item.get('b64_json'):
            try:blob=base64.b64decode(item['b64_json'],validate=True)
            except ValueError as e:raise APIError('生图API返回的图片编码无效。') from e
        elif item.get('url'):
            async with self.session.get(item['url'],timeout=aiohttp.ClientTimeout(total=cfg['api_timeout_seconds'])) as r:
                if r.status!=200:raise APIError('下载生成图片失败。')
                blob=await r.read()
        else:raise APIError('生图API没有返回图片数据。')
        try:
            with Image.open(io.BytesIO(blob)) as im:
                im.load();result=io.BytesIO();ImageOps.exif_transpose(im).save(result,'PNG');return result.getvalue()
        except Exception as e:raise APIError('生图API返回内容不是有效图片。') from e
