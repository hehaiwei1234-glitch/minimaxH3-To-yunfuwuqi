"""Optional serial quality gate. Persist candidates before reviewing or retrying."""
from __future__ import annotations
import hashlib
import json
import os
import shutil
from pathlib import Path
import aiohttp
from .providers import AIClient, APIError
from .media_tools import command, probe
from .telemetry import measure

class ReviewPaused(RuntimeError): pass

def enabled(cfg,kind):
    value=cfg.get('review_'+kind+'_enabled')
    return bool(cfg.get('review_enabled')) if value is None else bool(value)

def validate_review(cfg):
    if enabled(cfg,'image') or enabled(cfg,'video'):
        if not cfg.get('review_model','').strip() or not cfg.get('review_base_url'):raise APIError('开启自检前请填写视觉模型名称和API地址。')
        if cfg.get('review_provider')!='local' and not cfg.get('review_api_key'):raise APIError('请填写自检API Key。')
    if cfg.get('review_audio') and (not cfg.get('asr_model') or not cfg.get('asr_base_url')):raise APIError('开启独立对白核对前，请在设置中填写语音识别模型与地址；不需要开启视频视觉审核。')
    if cfg.get('provider')=='local' and not cfg.get('local_model','').strip():raise APIError('请填写本地创作模型名称。')
    if cfg.get('gpu_handoff'):
        if cfg.get('provider')=='local' and not cfg.get('local_unload_url'):raise APIError('请填写本地创作模型卸载接口。')
        if (enabled(cfg,'image') or enabled(cfg,'video')) and cfg.get('review_provider')=='local' and not cfg.get('review_unload_url'):raise APIError('请填写本地自检模型卸载接口。')


async def post_control(session,url,body,key=''):
    async with session.post(url,json=body,headers={'Authorization':'Bearer '+key} if key else {},
                            timeout=aiohttp.ClientTimeout(total=120)) as response:
        if response.status>=400:raise RuntimeError('模型释放失败 HTTP '+str(response.status)+'；已暂停，避免显存冲突。')

async def release_local(cfg,session,review=False):
    if not cfg.get('gpu_handoff'):return
    prefix='review' if review else 'local'
    active=cfg.get('review_provider')=='local' if review else cfg.get('provider')=='local'
    if not active:return
    url=cfg.get(prefix+'_unload_url','')
    if not url:raise RuntimeError('共用显卡模式需要填写'+('自检' if review else '创作')+'模型卸载URL和JSON请求体。')
    await post_control(session,url,json.loads(cfg[prefix+'_unload_body']),cfg.get(prefix+'_api_key',''))

async def release_comfy(cfg,session):
    if cfg.get('gpu_handoff'):
        await post_control(session,cfg['comfy_url'].rstrip('/')+'/free',{'unload_models':True,'free_memory':True},cfg.get('comfy_api_key',''))

class Reviewer:
    def __init__(self,store,files,cfg,session):
        self.store=store;self.files=files;self.cfg=cfg;self.session=session
    async def judge(self,paths,requirements,references=(),transcript=None):
        cfg=self.cfg
        if not cfg.get('review_model'):raise APIError('请填写自检模型名称，并选择支持视觉的模型。')
        await release_comfy(cfg,self.session)
        images=[{'path':p,'name':f'待审核画面 {i+1}（按时间顺序）'} for i,p in enumerate(paths)]
        images += [{'path':p,'name':f'身份/场景参考 {i+1}'} for i,p in enumerate(references[:8])]
        prompt=json.dumps({'requirements':requirements,'rules':cfg['review_rules'],'transcript':transcript,
                           'audio_checked':transcript is not None},ensure_ascii=False)
        instructions=('你是影视制作质量检查员。依据要求和参考图检查待审核画面。只判断可见证据，不猜测未提供的帧或声音。'
            '抽帧不能证明连续运动无瑕疵。没有转录时不能评价台词正确性、声音、背景音乐。'
            '转录存在时逐字对照原台词，允许标点差异，注意语音识别可能出错。'
            '检查生成画面不得有字幕。视频要求标明opening_frame_reference时，参考图1是开场图。'
            '返回JSON {"passed":true或false,"reasons":["具体问题"],"summary":"简短结论"}。')
        # Transport/format failures propagate; they are NOT a failed generation.
        try:
            client=AIClient(cfg,self.session)
            result=await client.compatible(instructions,prompt,images,cfg['review_base_url'],
                cfg['review_model'],cfg['review_api_key'],cfg['review_provider']=='local')
            if type(result.get('passed')) is not bool or not isinstance(result.get('reasons'),list) or any(not isinstance(x,str) for x in result['reasons']):
                client.validation_failed('自检模型未返回有效passed布尔值和reasons列表',result)
                raise APIError('自检模型未返回有效passed布尔值和reasons列表；保留候选，不重新生成。')
            return result
        finally:await release_local(cfg,self.session,True)
    def folder(self,owner,key):
        path=self.files.project_dir(owner)/'自检记录'/key;path.mkdir(parents=True,exist_ok=True);return path
    def save(self,path,data):
        tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,path)
    def archive(self,owner,key,attempt,source,verdict):
        dest=self.files.project_dir(owner)/'NG'/key/f'{attempt:03d}_{Path(source).name}'
        dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():
            tmp=dest.with_suffix(dest.suffix+'.partial');shutil.copy2(source,tmp);os.replace(tmp,dest)
        self.save(dest.with_suffix(dest.suffix+'.json'),verdict)
        return dest
    async def image(self,ai,asset_id,owner,prompt,refs,generate):
        if not enabled(self.cfg,'image'):return await generate(asset_id,prompt)
        folder=self.folder(owner,'image_'+asset_id);state_path=folder/'state.json'
        state=json.loads(state_path.read_text('utf-8')) if state_path.exists() else {'attempts':[]}
        limit=self.cfg['review_image_attempts']
        while True:
            if state.get('accepted'):
                self.store.put('quality_asset',asset_id,{'adopted_ng':state.get('adopted_ng',False),'attempts':len(state['attempts']),'verdict':state['attempts'][-1]['verdict'],'seed':state['attempts'][-1].get('seed')})
                return Path(state['accepted']).read_bytes()
            for kind in ('project','series'):
                try:record=self.store.get(kind,owner)
                except KeyError:continue
                if record.get('pause_requested'):raise ReviewPaused('已暂停；图片候选和审核次数已保存。')
            attempts=state['attempts']
            if attempts and attempts[-1].get('verdict'):
                last=attempts[-1]
                if last['verdict']['passed'] or len(attempts)>=limit:
                    if not last['verdict']['passed'] and self.cfg['review_image_exhausted']=='pause':
                        raise ReviewPaused('图片自检次数已用完；候选已保留。调整次数或改为采用最后结果后继续。')
                    state.update(accepted=last['path'],adopted_ng=not last['verdict']['passed']);self.save(state_path,state)
                    continue
            if not attempts or attempts[-1].get('verdict'):
                attempt=len(attempts)+1
                path=folder/f'candidate_{attempt:03d}.png'
                if not path.exists():
                    feedback=('\nCorrect these previously observed problems: '+json.dumps(attempts[-1]['verdict']['reasons'],ensure_ascii=False)) if attempts else ''
                    blob=await generate(asset_id+f'_q{attempt}',prompt+feedback)
                    tmp=path.with_suffix('.partial');tmp.write_bytes(blob);os.replace(tmp,path)
                seed=None
                try:seed=self.store.get('image_job',asset_id+f'_q{attempt}').get('seed')
                except KeyError:pass
                attempts.append({'path':str(path),'attempt':attempt,'seed':seed});self.save(state_path,state)
            last=attempts[-1]
            with measure('image_review',asset_id):
                verdict=await self.judge([Path(last['path'])],prompt,list(refs))
            if not verdict['passed']:
                last['path']=str(self.archive(owner,'image_'+asset_id,last['attempt'],last['path'],verdict))
            original=folder/f'candidate_{last["attempt"]:03d}.png'
            last['verdict']=verdict;self.save(state_path,state)
            if not verdict['passed']:original.unlink(missing_ok=True)
    async def video(self,owner,index,clip,references):
        path=self.files.output_path(clip['output']);meta=await probe(path,self.cfg)
        key='video_'+str(index)+'_'+hashlib.sha256(str(path).encode()).hexdigest()[:16]
        folder=self.folder(owner,key);report=folder/'verdict.json'
        if report.exists():return json.loads(report.read_text('utf-8'))
        frames=[];n=self.cfg['review_frames'];duration=meta['duration']
        for i in range(n):
            t=max(0,min(duration-0.05,duration*i/(n-1)))
            frame=folder/f'frame_{i:02d}.jpg'
            await command([self.cfg['ffmpeg'],'-y','-ss',str(t),'-i',path,'-frames:v','1','-vf','scale=1024:-2',frame])
            frames.append(frame)
        transcript=(clip.get('dialogue_check') or {}).get('transcript') if self.cfg['review_audio'] else None
        with measure('video_review_api',str(index+1)):
            verdict=await self.judge(frames,{**{k:clip.get(k) for k in ('visual_zh','camera_zh','dialogue','sound_zh','prompt_zh')},'opening_frame_reference':bool(clip.get('frame_asset_id'))},references,transcript)
        verdict.update(audio_checked=transcript is not None,transcript=transcript,frames=n)
        self.save(report,verdict);return verdict
