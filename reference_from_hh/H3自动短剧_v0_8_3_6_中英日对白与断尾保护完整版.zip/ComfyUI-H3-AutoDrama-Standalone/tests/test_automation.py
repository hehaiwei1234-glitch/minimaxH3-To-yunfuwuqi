from __future__ import annotations

import copy
import importlib
import json
import tempfile
import unittest
from pathlib import Path

from aiohttp import web
from test_core import ROOT, Store, Files, domain, ComfyClient
from test_workflows import fixture, w
import test_integration as integration
import test_image_series as pipelines

Engine=importlib.import_module('h3ad_test.engine').Engine
SeriesManager=importlib.import_module('h3ad_test.series').SeriesManager
batch_values=importlib.import_module('h3ad_test.series_batches').batch_values
ExecutionFailed=importlib.import_module('h3ad_test.comfy_client').ExecutionFailed


def enabled_workflow():
    body=fixture()
    for node in body['graph'].values():
        if node['class_type'].startswith('H3ADv1'):
            node['class_type']=node['class_type'].replace('H3ADv1','H3Continue',1)
    body['graph']['node_34']['inputs']['value']=True
    body['graph']['node_40']['inputs']['previous_video_name']=''
    return body


class AutomaticContractTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.store=Store(self.root/'data');self.files=Files(self.root/'input',self.root/'output')
        self.engine=Engine(self.store,self.files,ROOT,'http://127.0.0.1:8188')
        self.manager=SeriesManager(self.engine);self.body=enabled_workflow()

    def tearDown(self):self.temp.cleanup()

    def test_enabled_import_with_no_previous_video_is_automatically_managed(self):
        before=copy.deepcopy(self.body['graph']);saved=w.save(self.store,self.body)
        self.assertTrue(saved['metadata']['continuation'])
        self.assertEqual(saved['bindings']['continuation_enable'],{'node':'node_34','input':'value'})
        self.assertEqual(saved['bindings']['previous_video'],{'node':'node_40','input':'previous_video_name'})
        self.assertEqual(before,saved['graph'])
        g=w.instantiate(saved,{'prompt_en':'first','continuity':'cut','seed':None},domain.media_state([],[],[]),None,'first')
        self.assertFalse(g['node_34']['inputs']['value'])
        self.assertEqual(g['node_40']['inputs']['previous_video_name'],'')
        self.assertEqual(g['node_12'],before['node_12'])
        self.assertEqual(g['node_38']['inputs']['width'],before['node_38']['inputs']['width'])

    def test_continue_uses_previous_output_and_cut_clears_old_video(self):
        saved=w.save(self.store,self.body)
        g=w.instantiate(saved,{'prompt_en':'second','continuity':'continue','seed':None},domain.media_state([],[],[]),'first/中文.mp4 [output]','second')
        self.assertTrue(g['node_34']['inputs']['value'])
        self.assertEqual(g['node_40']['inputs']['previous_video_name'],'first/中文.mp4 [output]')
        g=w.instantiate(saved,{'prompt_en':'third','continuity':'cut','seed':None},domain.media_state([],[],[]),'stale.mp4 [output]','third')
        self.assertFalse(g['node_34']['inputs']['value'])
        self.assertEqual(g['node_40']['inputs']['previous_video_name'],'')

    def test_missing_previous_video_stops_before_submission(self):
        saved=w.save(self.store,self.body)
        with self.assertRaisesRegex(ValueError,'缺少上段视频'):
            w.instantiate(saved,{'prompt_en':'second','continuity':'continue','seed':None},domain.media_state([],[],[]),None,'second')

    def test_separate_trim_and_model_switches_follow_prepare(self):
        body=self.body
        for node in body['graph'].values():
            if node['class_type'] in {'H3ContinueTrim','H3ContinueModelCompat'}:
                node['inputs']['enable_continue']=False
        saved=w.save(self.store,body)
        for continued in (False,True):
            g=w.instantiate(saved,{'prompt_en':'p','continuity':'continue' if continued else 'cut','seed':None},domain.media_state([],[],[]),'old.mp4 [output]' if continued else None,'p')
            for n in g.values():
                if n['class_type'] in {'H3ContinueTrim','H3ContinueModelCompat'}:
                    self.assertIs(n['inputs']['enable_continue'],continued)

    def test_hidden_empty_video_widget_can_be_missing_from_api_export(self):
        del self.body['graph']['node_40']['inputs']['previous_video_name']
        saved=w.save(self.store,self.body)
        self.assertTrue(saved['metadata']['continuation'])
        self.assertEqual(saved['graph']['node_40']['inputs']['previous_video_name'],'')

    def test_wrong_manual_switch_binding_is_rejected(self):
        self.body['graph']['other']={'class_type':'PrimitiveBoolean','inputs':{'value':True}}
        self.body['bindings']['continuation_enable']={'node':'other','input':'value'}
        with self.assertRaisesRegex(ValueError,'实际续接准备节点'):w.save(self.store,self.body)

    def test_dynamic_switch_is_rejected_before_paid_calls(self):
        self.body['graph']['node_34']['class_type']='ThirdPartyBooleanCalculation'
        with self.assertRaisesRegex(ValueError,'动态计算'):w.save(self.store,self.body)

    def test_old_snapshot_is_repaired_without_changing_its_models(self):
        saved=w.save(self.store,self.body)
        old=copy.deepcopy(saved)
        for role in ('previous_video','continuation_enable','overlap','continue_audio'):
            old['bindings'].pop(role,None)
        old['metadata']['continuation']=False;old.pop('continuation_switches',None)
        repaired=w.resolved(old)
        self.assertTrue(repaired['metadata']['continuation'])
        self.assertEqual(repaired['graph'],old['graph'])
        self.assertFalse(old['metadata']['continuation'])
        self.assertTrue(w.summary(old)['metadata']['continuation'])
        self.assertTrue(w.preview(old['graph'])['automatic_bindings']['previous_video'])

    def test_auto_duration_is_accepted_for_initial_and_appended_batches(self):
        saved=w.save(self.store,self.body)
        s=self.manager.create({'text':'林悦：你好。','workflow_id':saved['id'],'episode_count':1,'target_episode_seconds':0})
        self.assertEqual(s['target_episode_seconds'],0)
        self.assertEqual(s['batches'][0]['target_episode_seconds'],0)
        s['plan']={'style':'写实','shared_assets':[],'episodes':[{'title':'第一集','script':'林悦：你好。','batch_id':'initial'}]}
        self.store.put('series',s['id'],s);self.manager.create_children(s['id'])
        s=self.manager.record(s['id']);pid=s['project_ids'][0]
        self.assertEqual(self.store.get('project',pid)['episode_target_seconds'],0)
        self.engine.set(pid,status='complete');self.manager.set(s['id'],status='complete')
        s=self.manager.record(s['id'])
        appended=self.manager.append(s['id'],{'text':'林悦：明天见。','target_episode_seconds':0,'episode_count':1,'request_id':'batch2','expected_revision':s['revision']})
        self.assertEqual(appended['batches'][-1]['target_episode_seconds'],0)

    def test_auto_does_not_replace_an_existing_manual_duration(self):
        self.assertEqual(batch_values({'text':'继续'}, {'target_episode_seconds':90})['target_episode_seconds'],90)
        self.assertEqual(batch_values({'text':'继续','target_episode_seconds':0}, {'target_episode_seconds':90})['target_episode_seconds'],0)
        for value in (-1,1,7,1801,float('nan'),float('inf')):
            with self.subTest(value=value),self.assertRaises(ValueError):
                batch_values({'text':'继续','target_episode_seconds':value})

    def test_tensor_payload_does_not_hide_real_comfy_error(self):
        status={'completed':False,'status_str':'error','messages':[['execution_error',{
            'node_id':'40','node_type':'H3ContinuePrepare',
            'exception_message':'已开启上一段续接，但还没有选择上一段 MP4。',
            'current_inputs':{'latent':'tensor('+('0.,'*30000)+')'}}]]}
        with self.assertRaisesRegex(ExecutionFailed,'没有选择上一段 MP4') as caught:
            ComfyClient.output({'status':status})
        self.assertLess(len(str(caught.exception)),200)


class AutomaticPipelineTests(unittest.IsolatedAsyncioTestCase):
    queue=integration.IntegrationTests.queue
    history=integration.IntegrationTests.history
    responses=integration.IntegrationTests.responses
    chat=integration.IntegrationTests.chat
    image=integration.IntegrationTests.image
    asyncTearDown=pipelines.NewPipelineTests.asyncTearDown

    async def asyncSetUp(self):
        self.requests=[];self.fail_first_video=False
        await pipelines.NewPipelineTests.asyncSetUp(self)
        self.video=w.save(self.store,enabled_workflow())

    async def object_info(self,request):
        names={n['class_type'] for n in self.video['graph'].values()} if hasattr(self,'video') else set()
        names|={n['class_type'] for n in self.engine.template.values()}
        names|={'PrimitiveInt','CLIPTextEncode','EmptyLatentImage','MockImageSampler','H3ADv1ImageReferenceBatch','LoadImage','SaveImage'}
        return web.json_response({name:{'output_node':name in {'SaveImage','SaveVideo'}} for name in names})

    async def prompt(self,request):
        data=await request.json();g=data['prompt']
        if 'node_40' in g:
            enabled=g['node_34']['inputs']['value'];previous=g['node_40']['inputs']['previous_video_name']
            if enabled:
                self.assertTrue(previous.endswith(' [output]'))
                self.assertTrue((self.files.output/previous[:-len(' [output]')]).exists())
            else:self.assertEqual(previous,'')
        reply=await integration.IntegrationTests.prompt(self,request)
        if self.fail_first_video:
            self.fail_first_video=False
            self.pending['pid_'+str(len(self.graphs))]['status']={'status_str':'error','completed':False,
                'messages':[['execution_error',{'exception_message':'temporary failure'}]]}
        return reply

    def ai_result(self,instructions,prompt):
        data=json.loads(prompt.split('\n修正上一次JSON',1)[0]);self.requests.append((instructions,data))
        result=pipelines.NewPipelineTests.ai_result(self,instructions,prompt)
        if '整剧策划' in instructions and data['input_type']=='script':
            result['episodes']=[{'title':'原文这一集','end_unit':len(data['text_units'])}]
        if '分镜导演' in instructions:
            for i,s in enumerate(result['segments']):s['continuity']='continue' if i<2 else 'cut'
        return result

    def create_series(self):
        return self.manager.create({'text':'女主：你好。\n女主：再见。\n女主：明天见。','episode_count':1,
            'target_episode_seconds':0,'workflow_id':self.video['id']})

    async def test_automatic_duration_and_cut_continue_cut_reach_real_submissions(self):
        s=self.create_series();self.manager.start(s['id'])
        await self.manager.tasks[s['id']];s=self.manager.record(s['id'])
        self.assertEqual(s['status'],'complete',s['error'])
        self.assertEqual(len(self.graphs),3)
        self.assertEqual([g['node_34']['inputs']['value'] for g in self.graphs],[False,True,False])
        self.assertIn(s['project_ids'][0],self.graphs[1]['node_40']['inputs']['previous_video_name'])
        project=self.store.get('project',s['project_ids'][0])
        self.assertEqual(project['episode_target_seconds'],0)
        self.assertAlmostEqual(project['planned_duration_seconds'],6)
        planner=[d for i,d in self.requests if '整剧策划' in i][0]
        director=[d for i,d in self.requests if '分镜导演' in i][0]
        self.assertEqual(planner['target_episode_seconds'],0);self.assertEqual(planner['duration_mode'],'auto')
        self.assertEqual(director['target_episode_seconds'],0);self.assertEqual(director['episode_duration_mode'],'auto')
        self.assertEqual([line['text'] for c in project['clips'] for line in c['dialogue']],['你好。','再见。','明天见。'])

    async def test_failed_first_clip_resume_repairs_old_snapshot_without_duplicate_assets(self):
        old=copy.deepcopy(self.video)
        for role in ('previous_video','continuation_enable','overlap','continue_audio'):old['bindings'].pop(role,None)
        old['metadata']['continuation']=False;old.pop('continuation_switches',None)
        self.store.put('workflow',old['id'],old)
        s=self.create_series();self.fail_first_video=True;self.manager.start(s['id']);await self.manager.tasks[s['id']]
        s=self.manager.record(s['id']);self.assertEqual(s['status'],'error')
        images=self.image_calls;ids=s['project_ids'][:]
        before=self.store.get('project',ids[0]);first_frame=before['clips'][0]['frame_asset_id']
        missing=sum(not c.get('frame_asset_id') for c in before['clips'])
        self.manager.start(s['id']);await self.manager.tasks[s['id']];s=self.manager.record(s['id'])
        self.assertEqual(s['status'],'complete',s['error']);self.assertEqual(s['project_ids'],ids)
        self.assertEqual(self.image_calls,images+missing)
        self.assertEqual(self.store.get('project',ids[0])['clips'][0]['frame_asset_id'],first_frame)
        self.assertEqual([g['node_34']['inputs']['value'] for g in self.graphs],[False,False,True,False])


if __name__=='__main__':unittest.main()
