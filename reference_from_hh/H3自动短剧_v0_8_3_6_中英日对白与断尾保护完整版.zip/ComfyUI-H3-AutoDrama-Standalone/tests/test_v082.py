"""Shared generation budget, explicit NG adoption and two ASR protocols."""
import asyncio
import copy
import importlib
import unittest
from unittest.mock import AsyncMock, patch
from aiohttp import web
from test_core import domain
from test_v08 import Fixture, speech, review
from test_workflows import fixture as video_fixture

workflows=importlib.import_module('h3ad_test.workflows')
series=importlib.import_module('h3ad_test.series')
asr=importlib.import_module('h3ad_test.speech_recognition')


class SharedSpeechFixture(Fixture):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.asr_calls=0;self.asr_status=200;self.transcripts=['错词。']
        self.asr_seen=[];self.managers=[]
        app=web.Application()
        app.router.add_post('/audio/transcriptions',self.transcribe)
        app.router.add_post('/compatible-mode/v1/chat/completions',self.transcribe_qwen)
        self.asr_runner=web.AppRunner(app);await self.asr_runner.setup()
        site=web.TCPSite(self.asr_runner,'127.0.0.1',0);await site.start()
        self.asr_url=f'http://127.0.0.1:{site._server.sockets[0].getsockname()[1]}'
        self.store.save_settings({'review_audio':True,'asr_provider':'auto',
            'asr_base_url':self.asr_url,'asr_model':'gpt-4o-mini-transcribe',
            'asr_api_key':'test-secret-speech','review_image_enabled':False,
            'review_video_enabled':False,'review_video_attempts':1,'review_video_exhausted':'accept'})

    async def asyncTearDown(self):
        for manager in self.managers:
            tasks=list(manager.tasks.values())
            for task in tasks:
                if not task.done():task.cancel()
            await asyncio.gather(*tasks,return_exceptions=True)
        await self.asr_runner.cleanup();await super().asyncTearDown()

    def response(self,qwen=False):
        self.asr_calls+=1
        if self.asr_status!=200:return web.json_response({'error':'ASR unavailable'},status=self.asr_status)
        text=self.transcripts[min(self.asr_calls-1,len(self.transcripts)-1)]
        body={'choices':[{'finish_reason':'stop','message':{'content':text}}]} if qwen else {'text':text}
        return web.json_response(body)

    async def transcribe(self,request):
        self.assertEqual(request.headers['Authorization'],'Bearer test-secret-speech')
        reader=await request.multipart();fields={}
        while (field:=await reader.next()) is not None:
            content=await field.read()
            fields[field.name]=content if field.name=='file' else content.decode()
        self.assertEqual(set(fields),{'model','file','response_format','language'})
        self.assertEqual(fields['language'],'zh')
        self.assertEqual(fields['response_format'],'json')
        self.assertTrue(fields['file'].startswith(b'RIFF'))
        self.asr_seen.append({'protocol':'openai','model':fields['model'],'fields':list(fields)})
        return self.response()

    async def transcribe_qwen(self,request):
        data=await request.json()
        self.assertEqual(set(data),{'model','messages','stream','asr_options'})
        self.assertEqual(len(data['messages']),1)
        self.assertEqual(data['messages'][0]['content'][0]['type'],'input_audio')
        self.assertEqual(data['asr_options'],{'enable_itn':False,'language':'zh'})
        self.asr_seen.append({'protocol':'qwen','model':data['model']})
        return self.response(qwen=True)

    def drama(self,count=3):
        plan=Fixture.plan_result(self);plan['segments']=plan['segments'][:count]
        self.plan_result=lambda:copy.deepcopy(plan)
        script='\n'.join('女主：'+clip['dialogue'][0]['text'] for clip in plan['segments'])
        return self.store.create_project({'script':script,'asset_ids':[self.asset['id']]})


class SharedRetryTests(SharedSpeechFixture):
    async def test_audio_only_reads_shared_limit_and_adopts_after_three_generations(self):
        self.store.save_settings({'review_video_attempts':3})
        with patch.object(review.Reviewer,'video',AsyncMock(side_effect=AssertionError('visual off'))):
            p=await self.finish(self.drama(1)['id'])
        self.assertEqual(p['status'],'complete',p.get('error'))
        self.assertEqual(len(self.graphs),3);self.assertEqual(self.asr_calls,3)
        clip=p['clips'][0]
        self.assertEqual(clip['quality_attempt'],3);self.assertTrue(clip['adopted_ng'])
        self.assertFalse(clip['dialogue_check']['passed']);self.assertFalse(speech.approved(self.files,clip,self.store.settings()))
        self.assertTrue(speech.resolved(self.files,clip,self.store.settings()))
        self.assertEqual(clip['dialogue_adoption']['limit'],3)
        self.assertEqual(len({str(clip['seed'])}|{str(c['seed']) for c in clip['quality_history']}),3)

    async def test_one_attempt_ng_continues_dependent_shot_and_merge(self):
        self.assertEqual(domain.DEFAULTS['review_video_exhausted'],'accept')
        p=await self.finish(self.drama(2)['id'])
        self.assertEqual(p['status'],'complete',p.get('error'))
        self.assertEqual(len(self.graphs),2);self.assertEqual(self.asr_calls,2)
        self.assertTrue(p.get('final'));self.assertTrue(p['clips'][1].get('state_reference_id'))
        for clip in p['clips']:
            self.assertTrue(clip['quality_accepted']);self.assertTrue(clip['adopted_ng'])
            self.assertFalse(clip['dialogue_check']['passed'])
            self.assertEqual(clip['dialogue_adoption']['attempt'],1)

    async def test_two_reviews_combine_feedback_and_use_one_retry(self):
        self.store.save_settings({'review_video_enabled':True,'review_video_attempts':2,
            'review_model':'mock-vision','review_api_key':'test-secret-vision'})
        self.transcripts=['你','你好。']
        checks=AsyncMock(side_effect=[{'passed':False,'reasons':['人物错误'],'summary':'人物错误'},
                                     {'passed':True,'reasons':[],'summary':'画面通过'}])
        with patch.object(review.Reviewer,'video',checks):p=await self.finish(self.drama(1)['id'])
        self.assertEqual(p['status'],'complete',p.get('error'))
        self.assertEqual(len(self.graphs),2);self.assertEqual(self.asr_calls,2);self.assertEqual(checks.await_count,2)
        clip=p['clips'][0];self.assertFalse(clip['adopted_ng']);self.assertTrue(clip['dialogue_check']['passed'])
        reasons=clip['quality_history'][0]['verdict']['reasons']
        self.assertTrue(any('末尾' in reason for reason in reasons));self.assertIn('人物错误',reasons)

    async def test_two_failed_checks_do_not_multiply_the_generation_budget(self):
        self.store.save_settings({'review_video_enabled':True,'review_video_attempts':2,
            'review_model':'mock-vision','review_api_key':'test-secret-vision'})
        checks=AsyncMock(return_value={'passed':False,'reasons':['人物错误'],'summary':'人物错误'})
        with patch.object(review.Reviewer,'video',checks):p=await self.finish(self.drama(1)['id'])
        self.assertEqual(p['status'],'complete',p.get('error'))
        self.assertEqual(len(self.graphs),2);self.assertEqual(self.asr_calls,2);self.assertEqual(checks.await_count,2)
        clip=p['clips'][0];self.assertTrue(clip['video_reviewed']);self.assertTrue(clip['adopted_ng'])
        self.assertFalse(clip['dialogue_check']['passed']);self.assertEqual(clip['quality_attempt'],2)

    async def test_explicit_pause_then_accept_resumes_without_rerendering_saved_ng(self):
        self.store.save_settings({'review_video_exhausted':'pause'})
        p=await self.finish(self.drama(2)['id'])
        self.assertEqual(p['status'],'paused',p.get('error'));self.assertEqual(len(self.graphs),1)
        saved=copy.deepcopy(p['clips'][0]['output']);self.assertFalse(p['clips'][0].get('dialogue_adoption'))
        self.store.save_settings({'review_video_exhausted':'accept'});p=await self.finish(p['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertEqual(p['clips'][0]['output'],saved)
        self.assertEqual(len(self.graphs),2);self.assertEqual(self.asr_calls,2)

    async def test_nonpipeline_audio_ng_can_continue_and_merge(self):
        self.store.save_settings({'pipeline_enabled':False})
        p=await self.finish(self.drama(2)['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertEqual(len(self.graphs),2)
        self.assertTrue(all(clip['dialogue_adoption'] for clip in p['clips']))

    async def test_adoption_signature_and_manual_redo_never_approve_a_different_take(self):
        p=await self.finish(self.drama(2)['id']);clip=copy.deepcopy(p['clips'][0])
        clip['dialogue_adoption']['signature']='old'
        self.assertFalse(speech.resolved(self.files,clip,self.store.settings()))
        self.engine.redo(p['id'],[0],new_seed=True)
        pending=self.store.get('project',p['id'])
        self.assertTrue(all(not clip.get('dialogue_adoption') for clip in pending['clips']))
        self.transcripts=['错词。','错词。','你好。','再见。']
        p=await self.finish(p['id']);self.assertEqual(p['status'],'complete',p.get('error'))
        self.assertEqual(len(self.graphs),4)
        self.assertTrue(all(clip['dialogue_check']['passed'] and not clip.get('dialogue_adoption') for clip in p['clips']))

    async def test_openai_explicit_model_and_http_error_resume_reuse_the_video(self):
        self.store.save_settings({'asr_provider':'openai','asr_model':'gpt-4o-transcribe'})
        self.asr_status=401;p=await self.finish(self.drama(1)['id'])
        self.assertEqual(p['status'],'error');self.assertEqual(len(self.graphs),1)
        saved=copy.deepcopy(p['clips'][0]['output'])
        self.asr_status=200;self.transcripts=['你好。'];p=await self.finish(p['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertEqual(p['clips'][0]['output'],saved)
        self.assertEqual(len(self.graphs),1);self.assertEqual(self.asr_calls,2)
        self.assertEqual(p['clips'][0]['dialogue_check']['provider'],'openai')
        self.assertTrue(all(row['model']=='gpt-4o-transcribe' for row in self.asr_seen))

    async def test_qwen_ng_adoption_uses_same_budget_and_allows_continuation(self):
        self.store.save_settings({'asr_provider':'qwen','asr_model':'qwen3-asr-flash',
                                 'asr_base_url':self.asr_url+'/compatible-mode/v1'})
        p=await self.finish(self.drama(2)['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertEqual(len(self.graphs),2)
        self.assertTrue(all(row['protocol']=='qwen' for row in self.asr_seen))
        self.assertTrue(all(clip['dialogue_check']['provider']=='qwen' and clip['dialogue_adoption'] for clip in p['clips']))

    async def test_series_continues_second_episode_after_adopting_failed_dialogue(self):
        manager=series.SeriesManager(self.engine);self.managers.append(manager)
        workflow=workflows.save(self.store,video_fixture())
        original=self.ai_result
        def result(instructions,prompt):
            import json
            data=json.loads(prompt.split('\n修正上一次JSON',1)[0])
            if '整剧策划' in instructions:
                return {'style':'realistic','shared_assets':[],
                    'episodes':[{'title':'第一集','end_unit':1},
                                {'title':'第二集','end_unit':len(data['text_units'])}]}
            if '分镜导演' in instructions:
                plan=Fixture.plan_result(self);plan['segments']=plan['segments'][:1]
                plan['segments'][0]['dialogue'][0]['text']='你好。' if '你好。' in data['script'] else '再见。'
                return plan
            return original(instructions,prompt)
        self.ai_result=result
        record=manager.create({'title':'两集','input_type':'script','episode_count':2,
            'text':'女主：你好。\n女主：再见。','workflow_id':workflow['id'],'asset_ids':[self.asset['id']]})
        manager.start(record['id']);await asyncio.wait_for(manager.tasks[record['id']],30)
        record=self.store.get('series',record['id'])
        self.assertEqual(record['status'],'complete',record.get('error'))
        self.assertEqual(len(record['project_ids']),2);self.assertEqual(len(self.graphs),2)
        for identity in record['project_ids']:
            p=self.store.get('project',identity)
            self.assertEqual(p['status'],'complete');self.assertTrue(p.get('final'))
            self.assertTrue(p['clips'][0]['dialogue_adoption'])


class OpenAIConfigurationTests(unittest.TestCase):
    def test_openai_stable_and_snapshot_models_are_auto_detected(self):
        for model in ('gpt-transcribe','gpt-4o-transcribe','gpt-4o-mini-transcribe',
                      'gpt-4o-mini-transcribe-2025-12-15','whisper-1'):
            cfg=domain.validate_settings({'review_audio':True,'asr_provider':'auto',
                'asr_base_url':'https://api.openai.com/v1','asr_model':model})
            self.assertEqual(asr.protocol(cfg),'openai')
        with self.assertRaisesRegex(ValueError,'普通聊天模型'):
            domain.validate_settings({'review_audio':True,'asr_provider':'openai',
                'asr_base_url':'https://api.openai.com/v1','asr_model':'gpt-6-astra'})


if __name__=='__main__':unittest.main()
