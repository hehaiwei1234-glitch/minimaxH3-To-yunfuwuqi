import importlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, AsyncMock
from PIL import Image
from test_core import Store, Files, domain
import test_integration as integration
review=importlib.import_module('h3ad_test.review')
providers=importlib.import_module('h3ad_test.providers')

class ImageReviewTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();root=Path(self.tmp.name)
        self.store=Store(root/'data');self.files=Files(root/'input',root/'output')
        self.cfg={**domain.DEFAULTS,'review_enabled':True,'review_image_attempts':3}
        buf=io.BytesIO();Image.new('RGB',(16,16)).save(buf,'PNG');self.blob=buf.getvalue()
        self.calls=[]
    def tearDown(self):self.tmp.cleanup()
    async def generate(self,aid,prompt):self.calls.append(aid);return self.blob
    def reviewer(self):return review.Reviewer(self.store,self.files,self.cfg,None)
    async def test_ng_limit_and_resume_do_not_generate_again(self):
        r=self.reviewer();r.judge=AsyncMock(return_value={'passed':False,'reasons':['wrong person']})
        self.assertEqual(await r.image(None,'asset','owner','prompt',[],self.generate),self.blob)
        self.assertEqual(len(self.calls),3)
        self.assertEqual(len(list((self.files.project_dir('owner')/'NG').rglob('*.png'))),3)
        await r.image(None,'asset','owner','prompt',[],self.generate)
        self.assertEqual(len(self.calls),3);self.assertEqual(r.judge.await_count,3)
        self.assertTrue(self.store.get('quality_asset','asset')['adopted_ng'])
    async def test_success_stops_early(self):
        r=self.reviewer();r.judge=AsyncMock(side_effect=[{'passed':False,'reasons':['x']},{'passed':True,'reasons':[]}])
        await r.image(None,'asset','owner','p',[],self.generate)
        self.assertEqual(len(self.calls),2)
    async def test_api_error_keeps_candidate_and_retry_budget(self):
        r=self.reviewer();r.judge=AsyncMock(side_effect=providers.APIError('offline'))
        with self.assertRaises(providers.APIError):await r.image(None,'asset','owner','p',[],self.generate)
        r.judge=AsyncMock(return_value={'passed':True,'reasons':[]})
        await r.image(None,'asset','owner','p',[],self.generate)
        self.assertEqual(len(self.calls),1)
    async def test_pause_then_adopt(self):
        self.cfg.update(review_image_attempts=1,review_image_exhausted='pause')
        r=self.reviewer();r.judge=AsyncMock(return_value={'passed':False,'reasons':['x']})
        with self.assertRaises(review.ReviewPaused):await r.image(None,'a','o','p',[],self.generate)
        self.cfg['review_image_exhausted']='accept'
        await r.image(None,'a','o','p',[],self.generate)
        self.assertEqual(len(self.calls),1)
    async def test_disabled_is_original_single_call(self):
        self.cfg['review_enabled']=False
        r=self.reviewer();r.judge=AsyncMock()
        await r.image(None,'a','o','p',[],self.generate)
        self.assertEqual(self.calls,['a']);r.judge.assert_not_awaited()
    def test_separate_limits_and_secret_masking(self):
        cfg=domain.validate_settings({'review_image_attempts':4,'review_video_attempts':1,'provider':'local','review_api_key':'secret'})
        self.assertEqual(cfg['review_image_attempts'],4);self.assertEqual(cfg['review_video_attempts'],1)
        self.assertEqual(domain.public_settings(cfg)['review_api_key'],'')

class VideoReviewTests(integration.IntegrationTests):
    async def test_ng_video_continuation_and_merge(self):
        self.store.save_settings({'review_enabled':True,'review_model':'mock','review_api_key':'mock','review_video_attempts':1,'review_image_attempts':2,'review_frames':2})
        async def judge(*args,**kwargs):return {'passed':False,'reasons':['mock quality failure']}
        with patch.object(review.Reviewer,'judge',judge):p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'complete',p.get('error'))
        self.assertEqual(self.image_calls,6);self.assertEqual(len(self.graphs),3)
        self.assertTrue(all(c['adopted_ng'] for c in p['clips']))
        self.assertTrue(all('/NG/' in self.files.output_path(c['output']).as_posix() for c in p['clips']))
        self.assertIn('/NG/',json.dumps(self.graphs[1]))
        self.assertTrue(self.files.output_path(p['final']).is_file())
    async def test_video_retry_then_pass(self):
        self.store.save_settings({'review_enabled':True,'review_model':'mock','review_api_key':'mock','review_video_attempts':2,'review_frames':2})
        counts={}
        async def video(self_,owner,index,clip,refs):
            counts[index]=counts.get(index,0)+1
            return {'passed':counts[index]==2,'reasons':[]}
        with patch.object(review.Reviewer,'judge',AsyncMock(return_value={'passed':True,'reasons':[]})),patch.object(review.Reviewer,'video',video):
            p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertEqual(len(self.graphs),6)
        self.assertEqual(self.image_calls,3)
        self.assertTrue(all(c['quality_attempt']==2 and not c['adopted_ng'] for c in p['clips']))
    async def test_local_without_key_text_endpoint(self):
        self.store.save_settings({'provider':'local','local_base_url':self.url,'local_model':'mock','local_api_key':''})
        p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'complete',p.get('error'))
    async def test_pause_blocks_continuation_but_runs_independent_cut(self):
        self.store.save_settings({'review_enabled':True,'review_model':'mock','review_api_key':'mock','review_video_attempts':1,'review_video_exhausted':'pause'})
        async def video(self_,owner,index,clip,refs):return {'passed':index!=0,'reasons':['x'] if index==0 else []}
        with patch.object(review.Reviewer,'judge',AsyncMock(return_value={'passed':True,'reasons':[]})),patch.object(review.Reviewer,'video',video):
            p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'paused');self.assertEqual(len(self.graphs),2)
        self.assertEqual(p['clips'][1]['status'],'blocked');self.assertTrue(p['clips'][2]['quality_accepted'])
        self.store.save_settings({'review_video_exhausted':'accept'})
        with patch.object(review.Reviewer,'judge',AsyncMock(return_value={'passed':True,'reasons':[]})),patch.object(review.Reviewer,'video',video):
            p=await self.finish(p['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertEqual(len(self.graphs),3)
