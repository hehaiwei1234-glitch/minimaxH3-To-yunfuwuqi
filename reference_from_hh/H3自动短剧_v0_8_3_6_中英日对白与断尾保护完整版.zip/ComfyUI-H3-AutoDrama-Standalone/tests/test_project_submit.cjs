const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../static/app.js'), 'utf8');
const handler = source.slice(source.indexOf('$("#project-form").onsubmit='), source.indexOf('async function openProject'));
async function check(startFails) {
  const button = {disabled:false};
  const input = {disabled:false};
  const form = {elements:[input,button]};
  const newButton = {disabled:false};
  const calls = [];
  let finishCreate;
  const context = {creatingProject:false,timingFromForm:()=>({version:1}), FormData:class {constructor() {return [['workflow_id','w1'],['script','剧本']]}},
    $:s => s === '#project-form' ? form : newButton, $$:() => [], guarded:fn => fn,
    api:async (path, body) => {calls.push(path);if(path === 'projects')return new Promise(resolve => finishCreate=resolve);if(startFails)throw Error('启动失败');return {};},
    openProject:async id => calls.push('open:'+id), notice:()=>{}};
  vm.createContext(context);vm.runInContext(handler,context);
  const event={target:form,preventDefault(){}};
  const first=form.onsubmit(event);
  assert.equal(button.disabled,true);assert.equal(newButton.disabled,true);
  await form.onsubmit(event);
  assert.deepEqual(calls,['projects']);
  finishCreate({id:'existing-project'});
  if(startFails)await assert.rejects(first,/启动失败/);else await first;
  assert.equal(calls.filter(x=>x==='projects').length,1);
  assert.ok(calls.indexOf('open:existing-project')<calls.indexOf('projects/existing-project/start'));
  assert.equal(button.disabled,false);assert.equal(newButton.disabled,false);assert.equal(context.creatingProject,false);
}
(async()=>{await check(false);await check(true);console.log('2 checks passed: repeated click submits once; failed start opens the saved project and unlocks controls.');})().catch(error=>{console.error(error);process.exitCode=1;});
