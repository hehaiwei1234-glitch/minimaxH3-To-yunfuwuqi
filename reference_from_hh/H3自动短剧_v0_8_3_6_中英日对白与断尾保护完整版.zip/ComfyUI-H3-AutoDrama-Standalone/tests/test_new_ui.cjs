const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.join(__dirname,'../static');
const source=fs.readFileSync(path.join(root,'series.js'),'utf8');
const start=source.indexOf('$("#series-form").onsubmit=');
const end=source.indexOf('$("#resume-series").onclick=');
async function seriesSubmit(startFails){
 const submit={disabled:false},input={disabled:false},form={elements:[input,submit]},newButton={disabled:false},calls=[];let finishCreate;
 const context={timingFromForm:()=>({version:1}),restoreTiming:()=>{},creatingSeries:false,FormData:class{constructor(){return [['workflow_id','video'],['text','整篇剧本']]}},
   $:s=>s==='#new-series'?newButton:form,$$:()=>[],guarded:fn=>fn,notice:()=>{},
   api:async route=>{calls.push(route);if(route==='series')return new Promise(r=>finishCreate=r);if(startFails)throw Error('启动失败');return{}},
   openSeries:async id=>calls.push('open:'+id)};
 vm.createContext(context);vm.runInContext(source.slice(start,end),context);
 const event={target:form,preventDefault(){}};const running=form.onsubmit(event);
 assert.equal(submit.disabled,true);await form.onsubmit(event);assert.deepEqual(calls,['series']);finishCreate({id:'existing-series'});
 if(startFails)await assert.rejects(running,/启动失败/);else await running;
 assert.equal(calls.filter(r=>r==='series').length,1);assert.ok(calls.indexOf('open:existing-series')<calls.indexOf('series/existing-series/start'));
 assert.equal(context.creatingSeries,false);assert.equal(input.disabled,false);assert.equal(newButton.disabled,false);
}
function imageSwitch(){
 const code=fs.readFileSync(path.join(root,'image_workflows.js'),'utf8');
 const mode={value:'api'},visible={};const apiPanel={classList:{toggle:(c,v)=>visible.api=!v}},localPanel={classList:{toggle:(c,v)=>visible.local=!v}};
 const context={timingFromForm:()=>({version:1}),restoreTiming:()=>{},$:s=>s==='#image-provider'?mode:s==='#image-api-settings'?apiPanel:localPanel};vm.createContext(context);
 vm.runInContext(code.slice(code.indexOf('function imageProviderView'),code.indexOf('function imageFieldOptions')),context);
 context.imageProviderView();assert.equal(visible.api,true);assert.equal(visible.local,false);
 mode.value='local';context.imageProviderView();assert.equal(visible.api,false);assert.equal(visible.local,true);
 mode.value='api';context.imageProviderView();assert.equal(visible.api,true);assert.equal(visible.local,false);
}
async function importDispatch(){
 const code=fs.readFileSync(path.join(root,'image_workflows.js'),'utf8'),calls=[];
 const context={timingFromForm:()=>({version:1}),restoreTiming:()=>{},openWorkflowDraft:async()=>calls.push('video'),openImageWorkflowDraft:async()=>calls.push('image')};vm.createContext(context);
 vm.runInContext(code.slice(code.indexOf('async function openImportedDraft'),code.indexOf('async function renderImageJobs')),context);
 await context.openImportedDraft(JSON.stringify({a:{class_type:'H3ADv1ImageReferenceBatch',inputs:{}}}));
 await context.openImportedDraft(JSON.stringify({a:{class_type:'MiniMaxH3ReferenceToVideo',inputs:{}}}));
 assert.deepEqual(calls,['image','video']);
}
(async()=>{await seriesSubmit(false);await seriesSubmit(true);imageSwitch();await importDispatch();console.log('4 checks passed: series double click; start failure keeps saved series; image mode panels; image/video import dispatch.')})().catch(e=>{console.error(e);process.exitCode=1});
