"""Qwen's documented JSON audio contract, legacy compatibility and resume."""
import base64
import importlib
import io
import json
import unittest
import wave
from aiohttp import web
from test_core import domain
from test_v08 import Fixture, diagnostics, speech

asr = importlib.import_module('h3ad_test.speech_recognition')


class QwenConfigurationTests(unittest.TestCase):
    def settings(self, **changes):
        return domain.validate_settings({'review_audio': True,
            'asr_base_url': 'https://dashscope.aliyuncs.com/compatible-mode/v1',
            'asr_model': 'qwen3-asr-flash', **changes})

    def test_auto_and_explicit_qwen_support_stable_and_snapshot_models(self):
        for provider in ('auto', 'qwen'):
            for model in ('qwen3-asr-flash', 'qwen3-asr-flash-2026-02-10'):
                self.assertEqual(asr.protocol(self.settings(asr_provider=provider, asr_model=model)), 'qwen')
        self.assertEqual(asr.protocol(self.settings(asr_base_url=
            'https://workspace.cn-beijing.maas.aliyuncs.com/compatible-mode/v1')), 'qwen')

    def test_invalid_qwen_models_and_native_or_generic_route_are_rejected_before_run(self):
        for model in ('qwen3.8-flash', 'qwen-plus', 'qwen-vl-plus',
                      'qwen3-asr-flash-realtime', 'qwen3-asr-flash-filetrans', ''):
            with self.subTest(model=model), self.assertRaisesRegex(ValueError, 'qwen3-asr-flash|语音'):
                self.settings(asr_model=model)
        with self.assertRaisesRegex(ValueError, 'compatible-mode/v1'):
            self.settings(asr_base_url='https://dashscope.aliyuncs.com/api/v1')
        with self.assertRaisesRegex(ValueError, 'audio/transcriptions'):
            self.settings(asr_provider='compatible')
        with self.assertRaisesRegex(ValueError, '百炼地址'):
            self.settings(asr_base_url='https://api.openai.com/v1')

    def test_legacy_model_and_disabled_unconfigured_gate_remain_valid(self):
        cfg = self.settings(asr_base_url='http://127.0.0.1:9876/v1', asr_model='local-asr')
        self.assertEqual(asr.protocol(cfg), 'compatible')
        self.assertFalse(domain.validate_settings({})['review_audio'])
        self.assertEqual(domain.validate_settings({})['asr_provider'], 'auto')
        self.assertEqual(asr.endpoint('https://example.test/v1/chat/completions',
                                     '/chat/completions'), 'https://example.test/v1/chat/completions')
        self.assertEqual(asr.endpoint('http://localhost/v1/audio/transcriptions',
                                     '/audio/transcriptions'), 'http://localhost/v1/audio/transcriptions')

    def test_plain_and_empty_transcripts_and_malformed_results(self):
        for content in ('你好。', '', [{'type': 'text', 'text': '你好。'}]):
            expected = content if isinstance(content, str) else '你好。'
            self.assertEqual(asr.qwen_text({'choices': [{'finish_reason': 'stop',
                'message': {'content': content}}]}), expected)
        for response in ({'choices': None}, {'choices': [None]},
                         {'choices': [{'message': None}]},
                         {'choices': [{'message': {'content': None}}]},
                         {'choices': [{'finish_reason': 'length', 'message': {'content': '你'}}]}):
            with self.subTest(response=response), self.assertRaises(asr.APIError):
                asr.qwen_text(response)
        self.assertFalse(speech.compare('你好。', '')['passed'])


class QwenSpeechPipelineTests(Fixture):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.asr_calls = 0
        self.asr_status = 200
        self.asr_bad = False
        self.transcripts = ['你好。', '再见。', '明天见。']
        self.payloads = []
        app = web.Application()
        app.router.add_post('/compatible-mode/v1/chat/completions', self.transcribe)
        self.asr_runner = web.AppRunner(app)
        await self.asr_runner.setup()
        site = web.TCPSite(self.asr_runner, '127.0.0.1', 0)
        await site.start()
        self.asr_url = f'http://127.0.0.1:{site._server.sockets[0].getsockname()[1]}/compatible-mode/v1'
        self.store.save_settings({'review_audio': True, 'asr_provider': 'auto',
            'asr_base_url': self.asr_url, 'asr_model': 'qwen3-asr-flash',
            'asr_api_key': 'test-secret-qwen', 'review_image_enabled': False,
            'review_video_enabled': False, 'review_video_attempts': 1})

    async def asyncTearDown(self):
        await self.asr_runner.cleanup()
        await super().asyncTearDown()

    async def transcribe(self, request):
        self.asr_calls += 1
        self.assertEqual(request.headers['Authorization'], 'Bearer test-secret-qwen')
        self.assertEqual(request.content_type, 'application/json')
        payload = await request.json()
        self.payloads.append(payload)
        self.assertEqual(set(payload), {'model', 'messages', 'stream', 'asr_options'})
        self.assertEqual(payload['asr_options'], {'enable_itn': False,'language':'zh'})
        self.assertIs(payload['stream'], False)
        self.assertEqual(len(payload['messages']), 1)
        message = payload['messages'][0]
        self.assertEqual(message['role'], 'user')
        self.assertEqual(len(message['content']), 1)
        self.assertEqual(message['content'][0]['type'], 'input_audio')
        data = message['content'][0]['input_audio']['data']
        self.assertTrue(data.startswith('data:audio/wav;base64,'))
        with wave.open(io.BytesIO(base64.b64decode(data.split(',', 1)[1])), 'rb') as audio:
            self.assertEqual(audio.getframerate(), 16000)
            self.assertEqual(audio.getnchannels(), 1)
            self.assertGreater(audio.getnframes(), 0)
        headers = {'x-dashscope-request-id': f'qwen-asr-{self.asr_calls}'}
        if self.asr_status != 200:
            return web.json_response({'error': {'message': 'ASR unavailable'}},
                                     status=self.asr_status, headers=headers)
        content = None if self.asr_bad else self.transcripts[min(self.asr_calls-1, len(self.transcripts)-1)]
        return web.json_response({'choices': [{'finish_reason': 'stop',
            'message': {'role': 'assistant', 'content': content}}],
            'usage': {'seconds': 2}}, headers=headers)

    async def test_qwen_audio_json_runs_without_visual_review_or_expected_script(self):
        p = await self.finish(self.project()['id'])
        self.assertEqual(p['status'], 'complete', p.get('error'))
        self.assertEqual(self.asr_calls, 3)
        self.assertEqual(len(self.graphs), 3)
        for clip in p['clips']:
            self.assertTrue(clip['dialogue_check']['passed'])
            self.assertEqual(clip['dialogue_check']['provider'], 'qwen')
            self.assertNotIn('last_word_end', clip['dialogue_check'])
        self.assertNotIn('你好', json.dumps(self.payloads, ensure_ascii=False))

    async def test_qwen_http_error_retains_video_and_resume_only_checks(self):
        self.asr_status = 401
        p = await self.finish(self.project()['id'])
        self.assertEqual(p['status'], 'error')
        self.assertEqual(len(self.graphs), 1)
        output = p['clips'][0]['output']
        self.assertTrue(self.files.output_path(output).exists())
        self.asr_status = 200
        self.asr_calls = 0
        p = await self.finish(p['id'])
        self.assertEqual(p['status'], 'complete', p.get('error'))
        self.assertEqual(p['clips'][0]['output'], output)
        self.assertEqual(len(self.graphs), 3)
        records = diagnostics.export(self.store, 'project', p['id'])['requests']
        self.assertTrue(any(row.get('request_id') == 'qwen-asr-1' and
                            row['status'] == 'error' for row in records))
        self.assertNotIn('test-secret-qwen', json.dumps(records))
        self.assertNotIn('data:audio', json.dumps(records))

    async def test_qwen_null_transcript_preserves_video_and_response_diagnostic(self):
        self.asr_bad = True
        p = await self.finish(self.project()['id'])
        self.assertEqual(p['status'], 'error')
        self.assertEqual(len(self.graphs), 1)
        records = diagnostics.export(self.store, 'project', p['id'])['requests']
        self.assertTrue(any(row.get('response', {}).get('choices') for row in records))
        self.asr_bad = False
        self.asr_calls = 0
        p = await self.finish(p['id'])
        self.assertEqual(p['status'], 'complete', p.get('error'))
        self.assertEqual(len(self.graphs), 3)

    async def test_qwen_missing_tail_keeps_existing_budget_and_blocks_merge(self):
        self.store.save_settings({'review_video_exhausted':'pause'})
        self.transcripts = ['你', '明天见。']
        p = await self.finish(self.project()['id'])
        self.assertEqual(p['status'], 'paused', p.get('error'))
        self.assertFalse(p.get('final'))
        self.assertEqual(len(self.graphs), 2)
        self.assertEqual(p['clips'][0]['dialogue_check']['status'], 'incomplete')
        self.assertFalse(p['clips'][0]['quality_accepted'])


if __name__ == '__main__':
    unittest.main()
