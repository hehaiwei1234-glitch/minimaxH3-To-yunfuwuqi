from __future__ import annotations
import asyncio
import copy
import importlib
import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
import aiohttp
from aiohttp import web
from test_core import Store, domain, ComfyClient, rewrite
import test_integration as integration
from test_workflows import fixture as video_fixture, w
iw=importlib.import_module('h3ad_test.image_workflows')
ig=importlib.import_module('h3ad_test.image_generator')
sm=importlib.import_module('h3ad_test.series')

def image_fixture(mode='none',slots=2):
    graph={'text':{'class_type':'CLIPTextEncode','inputs':{'text':'old positive'}},
           'latent':{'class_type':'EmptyLatentImage','inputs':{'width':512,'height':320,'batch_size':1}},
           'sample':{'class_type':'MockImageSampler','inputs':{'positive':['text',0],'latent':['latent',0],'seed':2**63+39,'steps':17}},
           'out':{'class_type':'SaveImage','inputs':{'images':['sample',0],'filename_prefix':'old/image'}}}
    refs=[]
    if mode=='batch':
        graph['ref']={'class_type':'H3ADv1ImageReferenceBatch','inputs':{'images_json':'["old.png"]','width':512,'height':512}}
        graph['sample']['inputs']['images']=['ref',0];refs=[{'node':'ref','input':'images_json'}]
    if mode=='slots':
        for i in range(slots):
            key='ref'+str(i);graph[key]={'class_type':'LoadImage','inputs':{'image':'old.png'}}
            graph['sample']['inputs'][key]=[key,0];refs.append({'node':key,'input':'image'})
    return {'name':'本地生图 '+mode,'graph':graph,'bindings':{'prompt':{'node':'text','input':'text'},'prefix':{'node':'out','input':'filename_prefix'},'seed':{'node':'sample','input':'seed'}},
            'reference_mode':mode,'reference_bindings':refs,'output_node_id':'out','seed_mode':'original','tested_by_user':True}

class ImageAndSeriesContractTests(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.store=Store(Path(self.temp.name))
    def tearDown(self):self.temp.cleanup()
    def test_image_workflow_changes_only_bound_contents_and_preserves_large_seed(self):
        body=image_fixture('batch');body['graph']=json.dumps(body['graph']);saved=iw.save(self.store,body);before=copy.deepcopy(saved['graph'])
        graph=iw.instantiate(saved,'new positive',['人物 中文.png','房间.png'],'new/image')
        changed={(nid,k) for nid,n in before.items() for k,v in n['inputs'].items() if graph[nid]['inputs'][k]!=v}
        self.assertEqual(changed,{('text','text'),('out','filename_prefix'),('ref','images_json')})
        self.assertEqual(graph['sample']['inputs']['seed'],2**63+39);self.assertEqual(before,saved['graph'])
        self.assertEqual(graph['sample']['inputs']['steps'],17);self.assertEqual(graph['latent']['inputs']['height'],320)
        self.assertEqual(json.loads(graph['ref']['inputs']['images_json']),['人物 中文.png','房间.png'])
    def test_fixed_slots_keep_all_references_and_reject_capacity_overflow(self):
        saved=iw.save(self.store,image_fixture('slots'))
        graph=iw.instantiate(saved,'new',['a.png'],'prefix');self.assertEqual(graph['ref0']['inputs']['image'],'a.png');self.assertEqual(graph['ref1']['inputs']['image'],'a.png')
        with self.assertRaisesRegex(ValueError,'只关联了2'):iw.instantiate(saved,'new',['a.png','b.png','c.png'],'prefix')
        with self.assertRaises(ValueError):iw.instantiate(saved,'new',[],'prefix')
    def test_text_to_image_never_silently_discards_character_reference(self):
        saved=iw.save(self.store,image_fixture())
        with self.assertRaisesRegex(ValueError,'不能接收参考图'):iw.instantiate(saved,'new',['a.png'],'prefix')
    def test_binding_cannot_target_negative_or_unconnected_branch_by_accident(self):
        body=image_fixture();body['graph']['unused']={'class_type':'CLIPTextEncode','inputs':{'text':'unused'}}
        body['bindings']['prompt']={'node':'unused','input':'text'}
        with self.assertRaisesRegex(ValueError,'没有连接'):iw.save(self.store,body)
        body=image_fixture();body['bindings']['prompt']={'node':'out','input':'images'}
        with self.assertRaisesRegex(ValueError,'上游'):iw.save(self.store,body)
    def test_only_supported_saved_image_output_is_accepted(self):
        body=image_fixture();body['graph']['out']['class_type']='PreviewImage'
        with self.assertRaisesRegex(ValueError,'SaveImage'):iw.save(self.store,body)
        body=image_fixture('batch');body['graph']['ref']['class_type']='UnknownListLoader'
        with self.assertRaisesRegex(ValueError,'批量参考'):iw.save(self.store,body)
    def test_wrong_prefix_binding_is_rejected_and_primitive_prefix_is_supported(self):
        body=image_fixture();body['bindings']['prefix']={'node':'text','input':'text'};body['graph']['text']['inputs']['other']='other';body['bindings']['prompt']={'node':'text','input':'other'}
        with self.assertRaisesRegex(ValueError,'实际filename_prefix'):iw.save(self.store,body)
        body=image_fixture();body['graph']['prefix']={'class_type':'PrimitiveString','inputs':{'value':'old/image'}}
        body['graph']['out']['inputs']['filename_prefix']=['prefix',0];body['bindings']['prefix']={'node':'prefix','input':'value'}
        saved=iw.save(self.store,body);graph=iw.instantiate(saved,'prompt',[],'new/image')
        self.assertEqual(graph['out']['inputs']['filename_prefix'],['prefix',0]);self.assertEqual(graph['prefix']['inputs']['value'],'new/image')
    def test_generated_filenames_are_portable_without_renaming_original_assets(self):
        function=importlib.import_module('h3ad_test.files').generated_image_name
        self.assertEqual(function('室内:房间/客厅'),'室内_房间_客厅.png')
        self.assertEqual(function('室内：房间'),'室内：房间.png')
        self.assertEqual(function('CON'),'_CON.png');self.assertEqual(function('中文 素材'),'中文 素材.png')
    def test_api_size_is_validated_without_constraining_local_model_size(self):
        with self.assertRaisesRegex(ValueError,'16的倍数'):domain.validate_settings({'image_size':'1536x572'})
        self.assertEqual(domain.validate_settings({'image_size':'1536x576'})['image_size'],'1536x576')
        self.assertEqual(domain.validate_settings({'image_provider':'local','image_size':'1536x572'})['image_size'],'1536x572')
    def test_image_history_uses_selected_output_and_rejects_multi_image_batch(self):
        entry={'status':{'completed':True},'outputs':{'wrong':{'images':[{'filename':'wrong.png'}]},'out':{'images':[{'filename':'right.png','type':'output'}]}}}
        self.assertEqual(ComfyClient.output(entry,'out','image')['filename'],'right.png')
        entry['outputs']['out']['images'].append({'filename':'second.png'})
        with self.assertRaisesRegex(Exception,'多张'):ComfyClient.output(entry,'out','image')
    def test_script_partition_preserves_every_original_character(self):
        text='第一场\n女主：你好。\n\n第二场\n女主：再见。'
        record={'text':text,'input_type':'script','episode_count':2}
        result=sm.validate_series_plan({'episodes':[{'title':'甲','end_unit':3},{'title':'乙','end_unit':5}],'shared_assets':[]},record,[])
        self.assertEqual(''.join(e['script'] for e in result['episodes']),text)
        self.assertEqual(''.join(sm.source_units('你好。再见！明天见。')),'你好。再见！明天见。')
        result['episodes'][1]['end_unit']=4
        with self.assertRaisesRegex(ValueError,'遗漏'):sm.validate_series_plan(result,record,[])
        result['episodes'][1]['end_unit']=2
        with self.assertRaisesRegex(ValueError,'递增'):sm.validate_series_plan(result,record,[])
    def test_image_template_versions_do_not_mutate_retained_snapshot(self):
        body=image_fixture();first=iw.save(self.store,body);snapshot=copy.deepcopy(first)
        body['id']=first['id'];body['expected_version']=1;body['graph']['sample']['inputs']['steps']=5
        revised=iw.save(self.store,body);self.assertEqual(revised['version'],2);self.assertEqual(snapshot['graph']['sample']['inputs']['steps'],17)
        with self.assertRaisesRegex(ValueError,'版本'):iw.save(self.store,body)

class NewPipelineTests(unittest.IsolatedAsyncioTestCase):
    queue=integration.IntegrationTests.queue;history=integration.IntegrationTests.history;responses=integration.IntegrationTests.responses
    chat=integration.IntegrationTests.chat;image=integration.IntegrationTests.image
    async def asyncSetUp(self):
        self.fail_images=False;self.force_unknown=False;self.lose_image_reply=False;self.series_plan_calls=0;self.writer_calls=0
        await integration.IntegrationTests.asyncSetUp(self)
        self.video=w.save(self.store,video_fixture());self.base=iw.save(self.store,image_fixture());self.reference=iw.save(self.store,image_fixture('batch'))
        self.manager=sm.SeriesManager(self.engine)
    async def asyncTearDown(self):
        for task in self.manager.tasks.values():
            if not task.done():task.cancel()
        await asyncio.gather(*self.manager.tasks.values(),return_exceptions=True)
        await integration.IntegrationTests.asyncTearDown(self)
    async def object_info(self,request):
        classes={n['class_type'] for n in self.engine.template.values()}|{'PrimitiveInt','CLIPTextEncode','EmptyLatentImage','MockImageSampler','H3ADv1ImageReferenceBatch','LoadImage','SaveImage'}
        return web.json_response({name:{'output_node':name in {'SaveImage','SaveVideo'}} for name in classes})
    async def prompt(self,request):
        data=await request.json();graph=data['prompt']
        if not any(n['class_type']=='SaveImage' for n in graph.values()):
            frame_node=graph.get('node_10') or graph.get('10')
            if frame_node and frame_node['class_type']=='PrimitiveInt':
                duration=frame_node['inputs']['value']/24;movie=self.dir/f'fixture_{frame_node["inputs"]["value"]}.mp4'
                if not movie.exists():
                    await integration.media.command(['ffmpeg','-y','-v','error','-f','lavfi','-i',f'color=c=blue:s=64x64:r=24:d={duration}',
                        '-f','lavfi','-i',f'sine=frequency=440:duration={duration}','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',movie])
                self.fixture=movie
            # Integration fixture reads the same body a second time; aiohttp
            # caches it and produces real FFmpeg video output.
            return await integration.IntegrationTests.prompt(self,request)
        self.graphs.append(graph);pid='pid_'+str(len(self.graphs));nid=next(k for k,n in graph.items() if n['class_type']=='SaveImage')
        prefix=graph[nid]['inputs']['filename_prefix'];path=self.files.output/(prefix+'_00001_.png');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(self.png)
        entry={'prompt':[0,pid,graph,data['extra_data'],[nid]],'outputs':{nid:{'images':[self.files.descriptor(path)]}},
               'status':{'completed':True,'status_str':'success','messages':[]},'ready_at':time.monotonic()+.04}
        if self.fail_images:entry['status']={'completed':False,'status_str':'error','messages':[['execution_error',{'exception_message':'mock image VRAM failure'}]]}
        self.pending[pid]=entry
        if self.force_unknown:raise web.HTTPServiceUnavailable()
        if self.lose_image_reply:self.lose_image_reply=False;request.transport.close();return web.Response()
        return web.json_response({'prompt_id':pid,'node_errors':{}})
    def ai_result(self,instructions,prompt):
        self.ai_calls+=1;data=json.loads(prompt.split('\n修正上一次JSON',1)[0])
        if '整剧策划' in instructions:
            self.series_plan_calls+=1
            episodes=[{'title':'见面','end_unit':2},{'title':'告别','end_unit':len(data.get('text_units',[]))}]
            if data['input_type']=='outline':episodes=[{'title':'见面','outline':'女主说你好和再见。'},{'title':'告别','outline':'女主说明天见和晚安。'}]
            return {'style':'realistic, same black hair and white coat','shared_assets':[
                {'id':'woman','role':'character','label':'女主','description':'黑发白衣','image_prompt':'Woman with black hair, white coat.'},
                {'id':'room','role':'scene','label':'房间','description':'朴素房间','image_prompt':'Simple warm room.'}],'episodes':episodes}
        if '短剧编剧' in instructions:
            self.writer_calls+=1;return {'script':'女主：你好。\n女主：再见。' if data['current_episode']==1 else '女主：明天见。\n女主：晚安。'}
        if '分镜导演' in instructions:
            images=[a['id'] for a in data['assets'] if a['kind']=='image']
            lines=[line.split('：',1)[-1] for line in data['script'].splitlines() if '：' in line]
            chosen=data['target_episode_seconds']/len(lines) if data.get('target_episode_seconds') else 2
            return {'style':'realistic','assets_to_create':[], 'segments':[{'title':'片段'+str(i+1),'duration_seconds':chosen,'continuity':'cut',
                'visual_zh':'女主说话。','camera_zh':'中景','image_prompt':'The same woman in the room.','asset_ids':images[:2],'image_reference_ids':images[:2],
                'dialogue':[{'speaker':'女主','text':line}],'sound_zh':'安静'} for i,line in enumerate(lines)]}
        if data.get('compiler_contract'):
            from test_core import compiler_result
            return compiler_result(data)
        count=sum(x['reference'].startswith('<Picture') for x in data['reference_map'])
        return rewrite(count,data['segment']['dialogue'][0]['text'])
    def local(self):self.store.save_settings({'image_provider':'local','image_workflow_id':self.base['id'],'image_reference_workflow_id':self.reference['id']})
    def series(self,**changes):return self.manager.create({'title':'连续测试','text':'女主：你好。\n女主：再见。\n女主：明天见。\n女主：晚安。','episode_count':2,'target_episode_seconds':8,'workflow_id':self.video['id'],**changes})
    async def finish_series(self,id):
        self.manager.start(id);await asyncio.wait_for(self.manager.tasks[id],35);return self.store.get('series',id)
    async def test_local_images_and_videos_complete_two_episodes_with_shared_identity(self):
        self.local();s=await self.finish_series(self.series()['id']);self.assertEqual(s['status'],'complete',s['error'])
        self.assertEqual(self.image_calls,0);self.assertEqual(self.series_plan_calls,1);self.assertEqual(len(s['project_ids']),2);self.assertEqual(len(self.graphs),10)
        projects=[self.store.get('project',pid) for pid in s['project_ids']];self.assertTrue(all(p['status']=='complete' for p in projects))
        self.assertEqual(len(set(s['generated_assets'].values())),2)
        local_graphs=[g for g in self.graphs if 'out' in g];self.assertEqual(len(local_graphs),6)
        paths=[self.store.get('asset',aid)['relative_path'] for aid in s['generated_assets'].values()]
        from test_core import assert_state_references
        for g in local_graphs[2:]:assert_state_references(self,json.loads(g['ref']['inputs']['images_json']),paths)
        videos=[g for g in self.graphs if 'node_20' in g];self.assertEqual(len(videos),4)
        first_last=max(i for i,g in enumerate(self.graphs) if 'node_20' in g and s['project_ids'][0] in g['node_20']['inputs']['filename_prefix'])
        second_first=min(i for i,g in enumerate(self.graphs) if 'node_20' in g and s['project_ids'][1] in g['node_20']['inputs']['filename_prefix'])
        self.assertLess(first_last,second_first)
        for p in projects:
            self.assertTrue(self.files.output_path(p['final']).exists());self.assertEqual(p['workflow_snapshot']['graph'],self.video['graph'])
    async def test_api_mode_is_preserved_and_creates_shared_assets_once(self):
        s=await self.finish_series(self.series()['id']);self.assertEqual(s['status'],'complete',s['error'])
        self.assertEqual(self.image_calls,6);self.assertEqual(len(self.graphs),4);self.assertFalse(self.store.list('image_job'))
    async def test_outline_is_written_automatically_before_episode_tasks(self):
        s=await self.finish_series(self.series(input_type='outline',text='女主回家，打招呼，第二天告别。')['id'])
        self.assertEqual(s['status'],'complete',s['error']);self.assertEqual(self.writer_calls,2)
        self.assertEqual(self.store.get('project',s['project_ids'][1])['script'],'女主：明天见。\n女主：晚安。')
    async def test_failure_resume_keeps_projects_shared_images_and_existing_completed_clip(self):
        self.local();s=self.series();self.fail_job=True;s=await self.finish_series(s['id'])
        self.assertEqual(s['status'],'error');ids=s['project_ids'][:];shared=copy.deepcopy(s['generated_assets'])
        following=self.store.get('project',ids[1])
        self.assertIsNotNone(following['plan'])
        self.assertFalse(any(c.get('frame_asset_id') or c.get('output') for c in following['clips']))
        self.assertEqual(self.series_plan_calls,1)
        self.fail_job=False;s=await self.finish_series(s['id']);self.assertEqual(s['status'],'complete',s['error'])
        self.assertEqual(s['project_ids'],ids);self.assertEqual(s['generated_assets'],shared);self.assertEqual(len(self.store.list('project')),2)
        self.assertEqual(len([g for g in self.graphs if 'out' in g]),6);self.assertEqual(self.series_plan_calls,1)
    async def test_lost_local_image_reply_reuses_same_prompt_and_cached_output(self):
        self.local();self.lose_image_reply=True;cfg=self.engine.config({'settings':{}})
        async with aiohttp.ClientSession() as session:
            generator=ig.ImageGenerator(self.store,self.files,cfg,session,self.engine.render_lock)
            ai=importlib.import_module('h3ad_test.providers').AIClient(cfg,session)
            first=await generator.image(ai,'saved_image','owner','woman',[])
            second=await generator.image(ai,'saved_image','owner','woman',[])
        self.assertEqual(first,second);self.assertEqual(len(self.graphs),1);self.assertEqual(self.image_calls,0)
    async def test_unknown_local_submission_never_automatically_posts_again(self):
        self.local();cfg=self.engine.config({'settings':{}})
        async with aiohttp.ClientSession() as session:
            generator=ig.ImageGenerator(self.store,self.files,cfg,session,self.engine.render_lock)
            ai=importlib.import_module('h3ad_test.providers').AIClient(cfg,session)
            async def unknown(*args):raise ig.SubmissionUnknown('lost response')
            with patch.object(generator.comfy,'submit',unknown):
                with self.assertRaises(ig.SubmissionUnknown):await generator.image(ai,'unknown_image','owner','woman',[])
            with self.assertRaises(ig.SubmissionUnknown):await generator.image(ai,'unknown_image','owner','woman',[])
            self.assertEqual(len(self.graphs),0)
            ig.allow_resubmit(self.store,'unknown_image');await generator.image(ai,'unknown_image','owner','woman',[])
        self.assertEqual(len(self.graphs),1)
    async def test_explicit_failed_local_image_can_resume_without_switching_to_api(self):
        self.local();self.fail_images=True;cfg=self.engine.config({'settings':{}})
        async with aiohttp.ClientSession() as session:
            generator=ig.ImageGenerator(self.store,self.files,cfg,session,self.engine.render_lock)
            ai=importlib.import_module('h3ad_test.providers').AIClient(cfg,session)
            with self.assertRaises(ig.ExecutionFailed):await generator.image(ai,'failed_image','owner','woman',[])
            self.fail_images=False;result=await generator.image(ai,'failed_image','owner','woman',[])
        self.assertEqual(result,self.png);self.assertEqual(len(self.graphs),2);self.assertEqual(self.image_calls,0)
        prefixes=[g['out']['inputs']['filename_prefix'] for g in self.graphs];self.assertNotEqual(prefixes[0],prefixes[1])
    async def test_pause_then_continue_does_not_create_duplicate_episode_projects(self):
        self.local();s=self.series();first_done=asyncio.Event();release=asyncio.Event();original_run=self.engine.run
        async def gated_run(pid):
            await original_run(pid)
            if not first_done.is_set():first_done.set();await release.wait()
        with patch.object(self.engine,'run',gated_run):
            self.manager.start(s['id']);await asyncio.wait_for(first_done.wait(),20)
            self.manager.pause(s['id']);release.set();await asyncio.wait_for(self.manager.tasks[s['id']],10)
        s=self.store.get('series',s['id']);self.assertEqual(s['status'],'paused');ids=s['project_ids'][:]
        self.assertEqual(self.store.get('project',ids[0])['status'],'complete')
        following=self.store.get('project',ids[1]);self.assertIsNotNone(following['plan'])
        self.assertFalse(any(c.get('output') for c in following['clips']))
        s=await self.finish_series(s['id']);self.assertEqual(s['status'],'complete',s['error']);self.assertEqual(s['project_ids'],ids)
        self.assertEqual(len(self.store.list('project')),2);self.assertEqual(len(self.graphs),10)
    async def test_children_restore_idempotently_and_use_original_workflow_snapshot(self):
        s=self.series();s['plan']=sm.validate_series_plan({'style':'realistic','shared_assets':[], 'episodes':[{'title':'甲','end_unit':2},{'title':'乙','end_unit':4}]},s,[]);self.store.put('series',s['id'],s)
        revised=video_fixture();revised.update(id=self.video['id'],expected_version=1);revised['graph']['node_12']['inputs']['value']=7;w.save(self.store,revised)
        self.manager.create_children(s['id']);ids=self.store.get('series',s['id'])['project_ids'][:]
        self.manager.create_children(s['id']);self.assertEqual(self.store.get('series',s['id'])['project_ids'],ids);self.assertEqual(len(self.store.list('project')),2)
        self.assertTrue(all(self.store.get('project',pid)['workflow_snapshot']['graph']['node_12']['inputs']['value']==23 for pid in ids))
    async def test_http_image_import_and_settings_keep_video_templates_separate(self):
        application=importlib.import_module('h3ad_test.routes').Application(self.store.root,self.files.input,self.files.output,self.url)
        host=web.Application();host.router.add_route('*','/h3_autodrama_v1/{path:.*}',application.handle)
        runner=web.AppRunner(host);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();port=site._server.sockets[0].getsockname()[1]
        url=f'http://127.0.0.1:{port}/h3_autodrama_v1/api/'
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url+'image-workflows',json={**image_fixture(),'graph':json.dumps(image_fixture()['graph'])}) as response:
                    saved=await response.json();self.assertEqual(response.status,200,saved)
                async with session.get(url+'workflows') as response:videos=await response.json()
                self.assertEqual([v['id'] for v in videos],[self.video['id']]);self.assertEqual(self.ai_calls,0);self.assertFalse(self.graphs)
                async with session.post(url+'settings',json={'image_provider':'local','image_workflow_id':saved['id'],'image_reference_workflow_id':self.reference['id'],'image_size':'1536x572'}) as response:
                    cfg=await response.json();self.assertEqual(response.status,200,cfg);self.assertEqual(cfg['image_provider'],'local')
                async with session.post(url+'series',json={'title':'HTTP整剧','text':'女主：你好。\n女主：再见。','workflow_id':self.video['id'],'episode_count':2,'target_episode_seconds':8}) as response:
                    record=await response.json();self.assertEqual(response.status,200,record)
                self.assertEqual(record['episodes'],[]);self.assertEqual(record['image_workflow_snapshots']['base']['id'],saved['id'])
                self.assertEqual(self.ai_calls,0);self.assertEqual(self.image_calls,0);self.assertFalse(self.graphs)
                async with session.get(url.removesuffix('api/')+'image_workflows.js?v=0.3') as response:self.assertEqual(response.status,200)
        finally:await runner.cleanup()

if __name__=='__main__':unittest.main()
