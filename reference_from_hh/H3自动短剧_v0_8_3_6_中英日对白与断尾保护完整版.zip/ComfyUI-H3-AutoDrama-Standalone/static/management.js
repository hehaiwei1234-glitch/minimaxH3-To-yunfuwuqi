"use strict";
let deleteReview=null,scriptEdit=null,appendingSeries=false,appendRequestId="",appendContext=null;
const managementPending=new Set();
const managementViews={series:"loadSeries",project:"loadProjects",asset:"loadAssets",workflow:"loadWorkflows",image_workflow:"loadImageWorkflows"};
function managementQuery(kind){return $("#show-archived-"+kind)?.checked?"?include_archived=1":""}
function managementButtons(kind,id,archived){return `<span class="record-actions"><button type="button" data-manage="${archived?"restore":"archive"}" data-kind="${kind}" data-id="${esc(id)}">${archived?"恢复":"归档"}</button><button type="button" class="danger" data-manage="delete-preview" data-kind="${kind}" data-id="${esc(id)}">删除</button></span>`}
async function refreshManagement(){
 if(current){try{current=await api("projects/"+current.id);renderProject()}catch{current=null;$("#project-detail").classList.add("hidden");$("#project-form").classList.remove("hidden")}}
 if(currentSeries){try{currentSeries=await api("series/"+currentSeries.id);renderSeries()}catch{currentSeries=null;$("#series-detail").classList.add("hidden");$("#series-form").classList.remove("hidden")}}
 await loadSettings();await Promise.all([loadAssets(),loadProjects(),loadSeries(),loadWorkflows(),loadImageWorkflows()]);
 const cleanup=await api("manage/cleanup");$("#retry-cleanup").classList.toggle("hidden",!cleanup.pending);
}
function renderDeleteReview(){
 const r=deleteReview,lines=[`将删除：${r.title}`,`包含 ${r.projects} 个单集项目；可清理 ${r.files} 个文件，约 ${(r.bytes/1024/1024).toFixed(1)} MB。`];
 if(r.unused_generated_assets)lines.push(`同时清理文件时，可删除 ${r.unused_generated_assets} 个无人使用的自动素材。`);
 if(r.shared_assets_kept)lines.push(`${r.shared_assets_kept} 个共享素材会保留。`);
 if(r.files_kept)lines.push(`${r.files_kept} 个被其他项目引用或不属本软件的文件会保留。`);
 if(r.kind==="workflow"||r.kind==="image_workflow")lines.push("已有项目保留工作流副本，可继续执行。");
 if(r.clears_image_selection)lines.push("这是当前选用的生图模板；删除后，新项目需要重新选择模板。");
 if(r.episode_number_kept)lines.push("本集编号保留，后续追加不会复用这个编号。");
 $("#delete-scope").textContent=lines.join("\n");
 $("#delete-form").elements.delete_files.disabled=!r.files&&!r.unused_generated_assets;
 $("#delete-form").elements.delete_files.checked=!!(r.files||r.unused_generated_assets);
}
function bindManagement(){
 $$("[data-manage]").forEach(button=>button.onclick=guarded(async()=>{
   const {kind,id,manage:action}=button.dataset,key=kind+":"+id;if(managementPending.has(key))return;
   managementPending.add(key);button.disabled=true;
   try{
     const response=await api("manage/"+kind+"/"+id+"/"+action,{});
     if(action==="delete-preview"){deleteReview=response;renderDeleteReview();$("#delete-dialog").showModal()}
     else{await refreshManagement();notice(action==="archive"?"已归档；勾选显示已归档可恢复":"已恢复")}
   }finally{managementPending.delete(key);button.disabled=false}
 }));
}
function scriptEditable(p){return !p.archived&&!p.plan&&!p.clips?.length&&!Object.keys(p.generated_assets||{}).length&&!p.final&&!['running','queued','pausing','complete'].includes(p.status)}
async function openScriptEditor(id){
 const p=await api("projects/"+id);if(!scriptEditable(p))throw Error("本集已开始准备，请使用镜头重做。");
 scriptEdit={id:p.id,series_id:p.series_id,revision:p.script_revision||1};
 $("#script-edit-title").textContent=p.title;$("#script-edit-form").elements.script.value=p.script;$("#script-edit-dialog").showModal();
}
function requestId(){return globalThis.crypto?.randomUUID?.()||"request-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2)}
function openAppendDialog(){
 if(!currentSeries?.can_append)throw Error("请先完成当前批次，再追加后续剧本。");
 const last=currentSeries.batches.at(-1),form=$("#append-form");form.reset();appendRequestId=requestId();appendContext={id:currentSeries.id,revision:currentSeries.revision};
 form.elements.input_type.value=last.input_type;form.elements.episode_count.value=0;restoreTiming(form,last.timing_policy);
 $("#append-start").textContent=`属于《${currentSeries.title}》，从第${currentSeries.next_episode_number}集开始；自动复用本剧人物、场景和风格。`;
 form.elements.workflow_id.innerHTML='<option value="">沿用上一批的视频工作流</option>'+workflowTemplates.filter(w=>!w.archived).map(w=>`<option value="${esc(w.id)}">${esc(w.name)} · v${w.version}</option>`).join("");
 $("#append-dialog").showModal();
}
async function initManagement(){
 for(const [kind,name]of Object.entries(managementViews))$("#show-archived-"+kind).onchange=guarded(()=>globalThis[name]());
 $("#delete-refresh").onclick=guarded(async()=>{deleteReview=await api(`manage/${deleteReview.kind}/${deleteReview.id}/delete-preview`,{});renderDeleteReview()});
 $("#delete-form").onsubmit=guarded(async event=>{
   event.preventDefault();const form=event.target,button=form.querySelector('button[type="submit"]');if(button.disabled)return;button.disabled=true;
   try{
     const r=deleteReview,result=await api(`manage/${r.kind}/${r.id}/delete`,{review_token:r.review_token,delete_files:form.elements.delete_files.checked});
     $("#delete-dialog").close();
     if(r.kind==="project"&&current?.id===r.id||r.kind==="series"&&current?.series_id===r.id){current=null;$("#project-detail").classList.add("hidden");$("#project-form").classList.remove("hidden")}
     if(r.kind==="series"&&currentSeries?.id===r.id){currentSeries=null;$("#series-detail").classList.add("hidden");$("#series-form").classList.remove("hidden")}
     await refreshManagement();notice(result.pending_cleanup?"记录已删除；部分文件待清理，请关闭占用后到设置重试":"已删除；仍被其他项目使用的素材和文件已保留");
   }finally{button.disabled=false}
 });
 $("#retry-cleanup").onclick=guarded(async()=>{await api("manage/cleanup",{});await refreshManagement();notice("待清理文件已清理")});
 $("#script-edit-form").onsubmit=guarded(async event=>{
   event.preventDefault();const form=event.target,button=form.querySelector('button[type="submit"]');if(button.disabled)return;button.disabled=true;
   try{const edit=scriptEdit,route=edit.series_id?`series/${edit.series_id}/episodes/${edit.id}/script`:`projects/${edit.id}/script`;
     await api(route,{script:form.elements.script.value,expected_revision:edit.revision});$("#script-edit-dialog").close();await refreshManagement();notice("未开始的本集剧本已保存")
   }finally{button.disabled=false}
 });
 $("#edit-project-script").onclick=guarded(()=>openScriptEditor(current.id));
 $("#append-series").onclick=guarded(openAppendDialog);
 $("#append-text-file").onchange=guarded(async event=>{const file=event.target.files[0];if(file){if(file.size>3*1024*1024)throw Error("TXT超过3MB，请分批输入。");const value=await file.text();if(value.includes("\ufffd"))throw Error("请将TXT另存为UTF-8。");$("#append-form").elements.text.value=value}});
 $("#append-form").onsubmit=guarded(async event=>{
   event.preventDefault();if(appendingSeries)return;
   const form=event.target,id=appendContext.id,body={...Object.fromEntries(new FormData(form)),expected_revision:appendContext.revision,request_id:appendRequestId};
   body.timing_policy=timingFromForm(form);
   appendingSeries=true;const controls=[...form.elements].map(el=>[el,el.disabled]);controls.forEach(([el])=>el.disabled=true);
   try{await api(`series/${id}/append`,body);$("#append-dialog").close();await openSeries(id);await api(`series/${id}/start`,{});await openSeries(id);notice("后续剧本已开始，集数和人物场景沿用原剧")}
   finally{appendingSeries=false;controls.forEach(([el,disabled])=>el.disabled=disabled)}
 });
 const cleanup=await api("manage/cleanup");$("#retry-cleanup").classList.toggle("hidden",!cleanup.pending);
}
