"use strict";
// Add-on handlers only. Existing form handlers continue to own script/outline.
(()=>{
 const mode="production_draft";
 const forms=[document.getElementById("series-form"),document.getElementById("append-form")];
 const $draft=(form)=>form.elements.input_type.value===mode;
 for(const form of forms){
   const panel=document.createElement("div");panel.className="panel hidden";panel.dataset.draftPanel="";
   panel.innerHTML=`<b>按既定分镜直接制作</b><p>导入我为你编排好的制作稿 JSON。程序直接读取分集、对白时间、镜头、提示词和素材引用，不调用创作模型补写或翻译。图片、视频审核和对白识别继续按设置开关执行。</p><label>导入制作稿（UTF-8 JSON，最多3MB）<input type="file" accept=".json,application/json" data-draft-file></label><label class="check"><input type="checkbox" data-draft-image-api>允许按当前设置调用图片生成 API（可选，默认使用本地工作流）</label><p>时长约束有冲突会直接指出，不会自动删台词或改写安排。补充要求仅作为原文指令发送，不会由创作 API 解释。</p><div class="row"><button type="button" data-draft-validate>仅校验制作稿</button><a class="link" href="api/production-draft/examples/example.json" download>下载制作稿示例</a><a class="link" href="api/production-draft/examples/guide.md" download>下载制作稿规范</a></div><p data-draft-result aria-live="polite"></p>`;
   form.elements.input_type.closest("label").after(panel);
   const oldFile=document.getElementById(form.id==="series-form"?"series-text-file":"append-text-file").closest("label");
   const count=form.elements.episode_count,oldCountLabel=count.parentElement.firstChild.textContent;
   function sync(){
     if(form.id==="append-form")for(const option of Array.from(form.elements.input_type.options||[])){
       option.disabled=currentSeries?.input_type===mode?option.value!==mode:option.value===mode;
     }
     const enabled=$draft(form);panel.classList.toggle("hidden",!enabled);oldFile.classList.toggle("hidden",enabled);
     count.parentElement.firstChild.textContent=enabled?"本批集数（0＝采用制作稿）":oldCountLabel;
   }
   form.elements.input_type.addEventListener("change",sync);
   form.addEventListener("reset",()=>queueMicrotask(sync));
   if(form.id==="append-form")new MutationObserver(sync).observe(document.getElementById("append-dialog"),{attributes:true,attributeFilter:["open"]});
   panel.querySelector("[data-draft-file]").addEventListener("change",event=>guarded(async()=>{
     const file=event.target.files[0];if(!file)return;
     if(file.size>3*1024*1024)throw Error("制作稿超过3MB，请分批导入。");
     const value=await file.text();const parsed=JSON.parse(value.replace(/^\uFEFF/,""));
     if(parsed.schema!=="h3-production-draft"||parsed.version!==1)throw Error("这不是支持的已编排制作稿 v1。");
     form.elements.text.value=value;
     if(form.elements.title&&!form.elements.title.value)form.elements.title.value=parsed.title||"";
     panel.querySelector("[data-draft-result]").textContent="制作稿已导入。点击校验或开始后，由程序检查全部安排。";
   })());
   function body(){
     const data=Object.fromEntries(new FormData(form));data.timing_policy=timingFromForm(form);
     data.allow_image_api=panel.querySelector("[data-draft-image-api]").checked;
     if(form.id==="series-form")data.asset_ids=$$("#series-asset-choices input:checked").map(x=>x.value);
     return data;
   }
   panel.querySelector("[data-draft-validate]").addEventListener("click",event=>guarded(async()=>{
     const button=event.target;button.disabled=true;
     try{
       const data=body();if(form.id==="append-form")data.series_id=currentSeries.id;
       const result=await api("production-draft/preview",data);
       panel.querySelector("[data-draft-result]").textContent=`校验通过：${result.episodes}集，${result.tasks}次任务，保留${result.seconds.toFixed(2)}秒。${result.image_backend}；本次未调用创作API，未提交渲染。`;
     }finally{button.disabled=false}
   })());
   let submitting=false;
   form.addEventListener("submit",event=>{
     if(!$draft(form))return;
     event.preventDefault();event.stopImmediatePropagation();
     guarded(async()=>{
       if(submitting)return;const data=body();
       if(form.id==="series-form"&&!data.workflow_id)throw Error("请先选择视频工作流。");
       submitting=true;const controls=[...form.elements].map(el=>[el,el.disabled]);controls.forEach(([el])=>el.disabled=true);
       try{
         let result;
         if(form.id==="series-form")result=await api("series",data);
         else{
           data.expected_revision=appendContext.revision;data.request_id=appendRequestId;
           result=await api(`series/${appendContext.id}/append`,data);document.getElementById("append-dialog").close();
         }
         await openSeries(result.id);await api(`series/${result.id}/start`,{});await openSeries(result.id);
         notice("制作稿已开始：按既定安排执行，创作API已跳过");
       }finally{submitting=false;controls.forEach(([el,disabled])=>el.disabled=disabled)}
     })();
   },true);
   sync();
 }
 for(const [kind,id] of [["series","series-detail"],["project","project-detail"]]){
   const block=document.createElement("div");block.className="panel hidden";
   block.innerHTML='<b>已编排制作稿</b><p>分集、分镜、提示词与剧情记录直接读取；创作 API 禁用。实际审核、识别与生图请求可下载核对。</p><a class="link" download>下载本模式 API 调用证据</a>';
   document.getElementById(id).prepend(block);
   setInterval(()=>{
     const record=kind==="series"?currentSeries:current;
     const visible=record&&(record.input_type===mode||record.execution_mode===mode);
     block.classList.toggle("hidden",!visible);
     if(visible)block.querySelector("a").href=BASE+`api/production-draft/report/${kind}/${record.id}`;
   },1000);
 }
})();
