"use strict";
let imageWorkflowTemplates=[],imageWorkflowDraft=null,savingImageWorkflow=false;
function imageProviderView(){const local=$("#image-provider").value==="local";$("#image-api-settings").classList.toggle("hidden",local);$("#image-local-settings").classList.toggle("hidden",!local)}
function imageFieldOptions(fields){return '<option value="">不关联</option>'+fields.map(f=>`<option value="${esc(fieldToken(f))}">${esc(f.node)} · ${esc(f.title)} · ${esc(f.input)} = ${esc(f.display_value.slice(0,60))}</option>`).join("")}
function imageReferenceInputs(existing=[]){
 const mode=$("#image-workflow-form").elements.reference_mode.value,area=$("#image-reference-bindings");area.innerHTML="";
 if(mode==="none")return;
 const fields=imageWorkflowDraft.fields.filter(f=>mode==="slots"?f.class_type==="LoadImage"&&f.input==="image":f.class_type==="H3ADv1ImageReferenceBatch"&&f.input==="images_json");
 for(let i=0;i<(mode==="batch"?1:8);i++){
   const label=document.createElement("label");label.textContent=mode==="batch"?"参考图JSON写入位置":"参考图片位置 "+(i+1)+(i?"（选填）":"（必选）");
   const select=document.createElement("select");select.name="reference_"+i;select.required=i===0;select.innerHTML=imageFieldOptions(fields);
   if(existing[i])select.value=JSON.stringify([existing[i].node,existing[i].input]);
   else if(i===0&&fields.length===1)select.value=fieldToken(fields[0]);
   label.append(select);area.append(label);
 }
}
async function loadImageWorkflows(){
 imageWorkflowTemplates=await api("image-workflows"+managementQuery("image_workflow"));
 const defaults={};
 for(const [id,reference,key] of [["image-base-workflow",false,"image_workflow_id"],["image-reference-workflow",true,"image_reference_workflow_id"]]){
   const element=$("#"+id),old=element.value||settings[key],templates=imageWorkflowTemplates.filter(w=>!w.archived).filter(w=>reference?w.reference_mode!=="none":w.reference_mode==="none");
   element.innerHTML='<option value="">请选择已导入的生图模板</option>'+templates.map(w=>`<option value="${esc(w.id)}">${esc(w.name)} · v${w.version}</option>`).join("");
   if(templates.some(w=>w.id===old))element.value=old;
   else if(!old&&templates.length===1){element.value=templates[0].id;defaults[key]=element.value}
 }
 if(Object.keys(defaults).length){const saved=await api("settings",defaults);for(const key of Object.keys(defaults))settings[key]=saved[key]}
 $("#image-workflow-list").innerHTML=imageWorkflowTemplates.length?imageWorkflowTemplates.map(w=>`<div class="row spread"><span><b>${esc(w.name)}</b>${w.archived?" · 已归档":""} · v${w.version} · ${w.reference_mode==="none"?"纯文生图":"最多"+w.metadata.reference_capacity+"张参考图"}</span><span class="row"><button data-image-workflow="${esc(w.id)}">另存新版</button>${managementButtons("image_workflow",w.id,w.archived)}</span></div>`).join(""):"尚未导入本地生图模板。使用API生图可跳过此页。";
 $$("[data-image-workflow]").forEach(button=>button.onclick=guarded(async()=>{
   const response=await fetch(BASE+"api/image-workflows/"+button.dataset.imageWorkflow),source=await response.text(),w=JSON.parse(source);
   if(!response.ok)throw Error(w.error||"读取生图模板失败");await openImageWorkflowDraft(source,w.name,w);
 }));bindManagement();
}
async function openImageWorkflowDraft(source,name,existing=null,asNew=false){
 const data=await api("image-workflows/preview",{graph:source});imageWorkflowDraft={source,fields:data.fields,id:asNew?undefined:existing?.id,version:asNew?undefined:existing?.version};
 const inferred=!existing;existing=existing||data.suggested||null;
 tab("image-workflows");const form=$("#image-workflow-form");form.elements.name.value=name;$("#image-workflow-binding-panel").classList.remove("hidden");$("#image-workflow-bindings").innerHTML="";
 for(const [role,title]of [["prompt","正向生图提示词写入位置（必选）"],["prefix","图片文件名前缀（必选）"],["seed","Seed（选填）"]]){
   const label=document.createElement("label");label.textContent=title;const select=document.createElement("select");select.name="image_binding_"+role;select.required=role!=="seed";
   const fields=data.fields.filter(f=>f.value_type===(role==="seed"?"number":"string"));select.innerHTML=imageFieldOptions(fields);
   if(existing?.bindings[role])select.value=JSON.stringify([existing.bindings[role].node,existing.bindings[role].input]);
   else if(role==="prefix"){const saves=fields.filter(f=>f.class_type==="SaveImage"&&f.input==="filename_prefix");if(saves.length===1)select.value=fieldToken(saves[0])}
   label.append(select);$("#image-workflow-bindings").append(label);
 }
 const saves=data.nodes.filter(n=>n.class_type==="SaveImage");form.elements.output_node_id.innerHTML='<option value="">请选择SaveImage输出</option>'+saves.map(n=>`<option value="${esc(n.id)}">${esc(n.id)} · ${esc(n.title)}</option>`).join("");
 form.elements.output_node_id.value=existing?.output_node_id||(saves.length===1?saves[0].id:"");
 form.elements.reference_mode.value=existing?.reference_mode||"none";form.elements.seed_mode.value=existing?.seed_mode||"original";form.elements.tested_by_user.checked=false;
 imageReferenceInputs(existing?.reference_bindings||[]);$("#image-workflow-status").textContent=existing?.version&&!asNew?`将保存为v${existing.version+1}；已有项目保留原副本。`:inferred&&existing?.complete?`已自动识别提示词、保存位置和${existing.reference_bindings.length}个参考图输入，可直接保存。运行时自动填入真实参考图，无需上传占位图片。`:`已读取${data.nodes.length}个节点，请检查下方关联。`;
}
async function openImportedDraft(source){
 const value=JSON.parse(source),graph=value.graph||value.prompt||value.output||value;
 const video=Object.values(graph).some(n=>/minimaxh3|H3ADv1BatchReferenceToVideo|H3ADv1Prepare/i.test(n?.class_type||""));
 if(video)await openWorkflowDraft(source,"当前ComfyUI视频工作流");else await openImageWorkflowDraft(source,"当前ComfyUI生图工作流");
}
async function renderImageJobs(owner,area){
 area.dataset.owner=owner;
 const jobs=await api("image-jobs?owner="+encodeURIComponent(owner));
 if(area.dataset.owner!==owner)return;
 const rows=jobs.filter(j=>j.submission_unknown&&!j.prompt_id),key=JSON.stringify([owner,rows]);
 if(area.dataset.jobs===key)return;area.dataset.jobs=key;
 area.innerHTML=rows.map(j=>`<div class="error"><p>${j.status==="missing"?"原图片任务已不在队列和历史中":"图片提交结果不明"} · ${esc(j.workflow_name)} · 任务标记 ${esc(j.job_id)}</p>${j.error?`<p>${esc(j.error)}</p>`:""}<button data-image-resubmit="${esc(j.id)}">确认原图片任务不存在，允许重新提交</button></div>`).join("");
 area.querySelectorAll("[data-image-resubmit]").forEach(button=>button.onclick=guarded(async()=>{
   if(!confirm("先在ComfyUI核对队列、历史和图片输出。只有确定原任务没有生成、没有排队，才允许重新提交。"))return;
   await api("image-jobs/"+button.dataset.imageResubmit+"/resubmit",{});await renderImageJobs(owner,area);notice("已允许重新提交，请点击对应项目或整剧的继续按钮");
 }));
}
async function initImageWorkflows(){
 $("#install-qwen-templates").onclick=guarded(async event=>{
   const button=event.currentTarget;button.disabled=true;
   try{notice("正在检查千问节点和模型…");await api("image-workflows/install-qwen",{});await loadSettings();await loadImageWorkflows();$("#image-workflow-status").textContent="两份千问模板已启用：人物场景基础图 + 镜头多图参考。无需上传占位图片，也无需手动关联节点。";notice("两份千问生图模板已保存并启用")}
   finally{button.disabled=false}
 });
 $("#image-provider").onchange=imageProviderView;imageProviderView();
 for(const id of ["image-base-workflow","image-reference-workflow"]){
   $("#"+id).onchange=guarded(async event=>{
     const select=event.target,value=select.value;select.disabled=true;
     try{const saved=await api("settings",{[select.name]:value});if(saved[select.name]!==value)throw Error("生图模板选择未保存成功。");settings[select.name]=value;$("#image-settings-status").textContent="模板选择已保存，刷新页面也会保留。";notice("生图模板选择已保存")}
     finally{select.disabled=false}
   });
 }
 $("#image-workflow-form").elements.reference_mode.onchange=()=>imageReferenceInputs();
 $("#image-workflow-file").onchange=guarded(async event=>{
   const file=event.target.files[0];if(!file)return;if(file.size>2*1024*1024)throw Error("生图JSON超过2MB，请导出精简API格式。");
   const source=await file.text(),value=JSON.parse(source),restored=value.graph&&value.bindings&&value.reference_mode?value:null;
   await openImageWorkflowDraft(source,restored?restored.name+" · 副本":file.name.replace(/\.json$/i,""),restored,true);
 });
 $("#image-workflow-new").onclick=()=>{if(imageWorkflowDraft){delete imageWorkflowDraft.id;delete imageWorkflowDraft.version;$("#image-workflow-status").textContent="将保存为独立新模板。"}};
 $("#image-workflow-form").onsubmit=guarded(async event=>{
   event.preventDefault();if(savingImageWorkflow)return;if(!imageWorkflowDraft)throw Error("请先导入生图API工作流。");
   const form=event.target,bindings={},refs=[];
   for(const role of ["prompt","prefix","seed"]){const v=form.elements.namedItem("image_binding_"+role).value;if(v){const[node,input]=JSON.parse(v);bindings[role]={node,input}}}
   for(let i=0;i<8;i++){const v=form.elements.namedItem("reference_"+i)?.value;if(v){const[node,input]=JSON.parse(v);refs.push({node,input})}}
   savingImageWorkflow=true;const submit=form.querySelector('button[type="submit"]');submit.disabled=true;
   try{
     const w=await api("image-workflows",{name:form.elements.name.value,graph:imageWorkflowDraft.source,bindings,reference_bindings:refs,reference_mode:form.elements.reference_mode.value,
       output_node_id:form.elements.output_node_id.value,seed_mode:form.elements.seed_mode.value,tested_by_user:form.elements.tested_by_user.checked,
       ...(imageWorkflowDraft.id?{id:imageWorkflowDraft.id,expected_version:imageWorkflowDraft.version}:{})});
     imageWorkflowDraft.id=w.id;imageWorkflowDraft.version=w.version;
     const key=w.reference_mode==="none"?"image_workflow_id":"image_reference_workflow_id";
     const saved=await api("settings");let assigned=false;
     if(!saved[key]||saved[key]===w.id){const result=await api("settings",{[key]:w.id});settings[key]=result[key];assigned=true}
     await loadImageWorkflows();$("#image-workflow-status").textContent=`已保存${w.name} v${w.version}。`+(assigned?"已自动设为"+(w.reference_mode==="none"?"人物和场景基础图":"镜头参考图")+"模板，无需再选一次。":"设置中已有其他模板，原选择保留。");notice("本地生图模板已保存");
   }finally{savingImageWorkflow=false;submit.disabled=false}
 });
 await loadImageWorkflows();
}
