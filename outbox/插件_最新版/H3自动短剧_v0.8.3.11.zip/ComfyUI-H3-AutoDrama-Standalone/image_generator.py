"""Image backend selection and durable local prompt recovery."""
from __future__ import annotations
import asyncio
import io
import secrets
import re
from .telemetry import measure
import time
import uuid
from PIL import Image
from .comfy_client import ComfyClient, ExecutionFailed, SubmissionRejected, SubmissionUnknown, TaskMissing
from .domain import PREFIX, safe_id
from . import image_workflows

class ImageGenerator:
    def __init__(self,store,files,cfg,session,gpu_lock,snapshots=None):
        self.store=store;self.files=files;self.cfg=cfg;self.comfy=ComfyClient(cfg,session)
        self.gpu_lock=gpu_lock;self.snapshots=snapshots;self.session=session
    async def preflight(self):
        if self.cfg['image_provider']!='local':return
        if not self.snapshots:self.snapshots=image_workflows.snapshots(self.store,self.cfg)
        for w in self.snapshots.values():
            if w:await self.comfy.preflight(w['graph'],w['output_node_id'],dynamic_inputs=w['reference_bindings'])
    async def image(self,ai,asset_id,owner_id,prompt,references=()):
        from .review import Reviewer
        async def generate(candidate_id,candidate_prompt):
            return await self.raw_image(ai,candidate_id,owner_id,candidate_prompt,references)
        return await Reviewer(self.store,self.files,self.cfg,self.session).image(ai,asset_id,owner_id,prompt,references,generate)
    async def raw_image(self,ai,asset_id,owner_id,prompt,references=()):
        try:job=self.store.get('image_job',asset_id)
        except KeyError:job=None
        if not job and self.cfg['image_provider']=='api':
            with measure('image_generation',asset_id):return await ai.image(prompt,references)
        with measure('image_gpu_wait',asset_id):
            await self.gpu_lock.acquire()
        try:
            with measure('image_generation',asset_id):
                return await self.local_image(asset_id,owner_id,prompt,references,job)
        finally:self.gpu_lock.release()
    async def local_image(self,asset_id,owner_id,prompt,references,job):
        safe_id(asset_id);safe_id(owner_id)
        if not job:
            if not self.snapshots:self.snapshots=image_workflows.snapshots(self.store,self.cfg)
            record=self.snapshots['reference' if references else 'base']
            if not record:raise ValueError('未选择带参考图生图工作流；不会自动切到收费API。')
            relative=[]
            for path in references:
                path=path.resolve()
                if not path.is_relative_to(self.files.input) or not path.is_file():raise ValueError('生图参考文件必须已保存在本机ComfyUI input目录。')
                relative.append(path.relative_to(self.files.input).as_posix())
            prefix=f'{PREFIX}/images/{asset_id}_a0'
            seed=secrets.randbits(63) if record['seed_mode']=='random' or (re.search(r'_q(\d+)$',asset_id) and int(re.search(r'_q(\d+)$',asset_id)[1])>1) else None
            graph=image_workflows.instantiate(record,prompt,relative,prefix,seed)
            job={'id':asset_id,'owner_id':owner_id,'job_id':uuid.uuid4().hex,'graph':graph,'output_prefix':prefix,
                 'output_node_id':record['output_node_id'],'prefix_binding':record['bindings']['prefix'],
                 'workflow_name':record['name'],'workflow_version':record['version'],
                 'status':'ready','submission_unknown':False,'created_at':time.time(),'attempt':0}
            seed_binding=record['bindings'].get('seed')
            if seed_binding:job['seed']=str(graph[seed_binding['node']]['inputs'][seed_binding['input']])
        elif job['status'] in {'rejected','failed'}:
            # The server explicitly rejected/failed it: a new attempt is safe.
            job.setdefault('failed_attempts',[]).append({k:job.get(k) for k in ('job_id','prompt_id','error')})
            job['attempt']=int(job.get('attempt',0))+1
            job.update(job_id=uuid.uuid4().hex,status='ready',submission_unknown=False,
                       output_prefix=f'{PREFIX}/images/{asset_id}_a{job["attempt"]}')
            for key in ('prompt_id','output','error'):job.pop(key,None)
            ref=job['prefix_binding'];job['graph'][ref['node']]['inputs'][ref['input']]=job['output_prefix']
        if job['status']=='ready':
            checked_files=[]
            for nid,node in job['graph'].items():
                if node['class_type']!='LoadImage':continue
                name=node['inputs'].get('image')
                if not isinstance(name,str):continue
                root=self.files.input
                if name.endswith(' [output]'):root=self.files.output;name=name[:-9]
                elif name.endswith(' [input]'):name=name[:-8]
                path=(root/name).resolve()
                if not path.is_relative_to(root.resolve()) or not path.is_file():raise ValueError('生图参考文件不存在：'+name)
                checked_files.append({'node':nid,'input':'image'})
            await self.comfy.preflight(job['graph'],job['output_node_id'],dynamic_inputs=checked_files)
            job.update(status='submitting',submission_unknown=True)
            self.store.put('image_job',asset_id,job)
            try:job['prompt_id']=await self.comfy.submit(job['graph'],job['job_id'],owner_id)
            except SubmissionRejected as e:
                job.update(status='rejected',submission_unknown=False,error=str(e));self.store.put('image_job',asset_id,job);raise
            job.update(status='submitted',submission_unknown=False);self.store.put('image_job',asset_id,job)
        if not job.get('prompt_id') and not job.get('output'):
            found=await self.comfy.find(job['job_id'])
            if found:job.update(prompt_id=found,status='submitted',submission_unknown=False)
            else:
                recovered=self.files.recover_output(job['output_prefix'],kind='image')
                if recovered:job['output']=recovered
                else:raise SubmissionUnknown('本地生图提交结果不明，已暂停且不会重复提交。先核对ComfyUI原任务；确认不存在后，在页面允许该图片重新提交。')
            self.store.put('image_job',asset_id,job)
        if not job.get('output'):
            try:job['output']=await self.comfy.wait(job['prompt_id'],job['output_node_id'],kind='image')
            except TaskMissing as error:
                recovered=self.files.recover_output(job['output_prefix'],kind='image')
                if recovered:
                    job['output']=recovered
                else:
                    job.update(status='missing',submission_unknown=True,error=str(error),
                               missing_prompt_id=job.pop('prompt_id',None))
                    self.store.put('image_job',asset_id,job)
                    raise
            except ExecutionFailed as e:
                job.update(status='failed',error=str(e));self.store.put('image_job',asset_id,job);raise
            job.update(status='complete',submission_unknown=False);self.store.put('image_job',asset_id,job)
        path=self.files.output_path(job['output'])
        if not path.is_file():raise ValueError('本地生图输出不在本机output目录；请使用软件所在的同一个ComfyUI实例。')
        # Normalize the stored asset extension without altering workflow settings.
        with Image.open(path) as img:
            if getattr(img,'n_frames',1)!=1:raise ValueError('生图输出必须是单帧图片。')
            img.load();buffer=io.BytesIO();img.convert('RGB').save(buffer,'PNG')
        return buffer.getvalue()

def allow_resubmit(store,asset_id):
    job=store.get('image_job',safe_id(asset_id))
    if not job.get('submission_unknown') or job.get('prompt_id'):raise ValueError('该图片不属于提交结果未知状态。')
    # Explicit user confirmation is required, exactly as for video prompts.
    job.update(status='rejected',submission_unknown=False,error='用户确认原图片任务不存在，允许重新提交。')
    store.put('image_job',asset_id,job)
