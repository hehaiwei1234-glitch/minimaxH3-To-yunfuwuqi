import { app } from "../../scripts/app.js";

app.registerExtension({
  name: "H3.AutoDrama.Standalone.v1",
  async setup() {
    if (document.getElementById("h3-autodrama-v1-launch")) return;
    const link = document.createElement("a");
    link.id = "h3-autodrama-v1-launch";
    const base = new URL("../../", import.meta.url);
    link.href = new URL("h3_autodrama_v1/", base).href;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = "H3 自动短剧";
    Object.assign(link.style, { position: "fixed", bottom: "12px", right: "18px", zIndex: "1000", padding: "9px 15px", borderRadius: "10px", background: "#087e71", color: "white", font: "14px sans-serif", textDecoration: "none", boxShadow: "0 2px 12px #0006" });
    document.body.appendChild(link);
    const transfer=document.createElement("button");
    transfer.id="h3-autodrama-v1-transfer";
    transfer.textContent="导入当前工作流";
    Object.assign(transfer.style,{position:"fixed",bottom:"54px",right:"18px",zIndex:"1000",padding:"9px 15px",borderRadius:"10px",background:"#087e71",color:"white",border:"0",font:"14px sans-serif",cursor:"pointer"});
    transfer.onclick=async()=>{
      const popup=window.open("about:blank","_blank");
      if(popup)popup.opener=null;
      transfer.disabled=true;
      try {
        if(typeof app.graphToPrompt!=="function")throw Error("当前ComfyUI版本没有公开工作流转换接口，请用API格式导出JSON。");
        const result=await app.graphToPrompt();
        if(!result?.output||!Object.keys(result.output).length)throw Error("当前工作流没有可执行节点。");
        const token=globalThis.crypto?.randomUUID?.()||String(Date.now())+Math.random().toString(16).slice(2);
        localStorage.setItem("h3ad_workflow_draft_"+token,JSON.stringify(result.output));
        const url=new URL("h3_autodrama_v1/",base);url.searchParams.set("workflow_draft",token);
        if(!popup)throw Error("浏览器拦截了新窗口，请允许此站点弹出窗口后再试。");
        popup.location.href=url.href;
      } catch(error) { if(popup)popup.close();alert("工作流没有导入："+error.message); }
      finally { transfer.disabled=false; }
    };
    document.body.appendChild(transfer);
  },
});
