"""Host contract checks with light stubs, without Torch or any model download."""
from __future__ import annotations
import importlib.util
import sys
import types
import unittest
from unittest.mock import patch
from test_core import ROOT

class Specification:
    def __init__(self,**kwargs):self.__dict__.update(kwargs)
class Type:
    @staticmethod
    def Input(id,**kwargs):return Specification(id=id,**kwargs)
    @staticmethod
    def Output(**kwargs):return Specification(**kwargs)
class NativeH3:
    shared=Specification(node_id='MiniMaxH3ReferenceToVideo',display_name='Original',description='native',inputs=[Specification(id='clip'),Specification(id='ref_images'),Specification(id='ref_audios')])
    @classmethod
    def define_schema(cls):return cls.shared
    @classmethod
    def INPUT_TYPES(cls):return {'required':{'clip':('CLIP',)},'optional':{'ref_images':('IMAGE',),'ref_audios':('AUDIO',)}}
    @classmethod
    def execute(cls,**kwargs):cls.called=kwargs;return ('POS','LAT')

def module(name,**kwargs):m=types.ModuleType(name);m.__dict__.update(kwargs);return m

class HostContractTests(unittest.TestCase):
    def setUp(self):
        io=types.SimpleNamespace(ComfyNode=object,Schema=Specification,NodeOutput=lambda *x:x,**{k:Type for k in ('String','Int','Float','Boolean','Image','Audio','Model','Conditioning','Latent','Vae')})
        extras=module('comfy_extras');minimax=module('comfy.ldm.minimax.model')
        mods={name:module(name) for name in ('comfy','comfy.conds','comfy.utils','comfy.ldm','comfy.ldm.common_dit','comfy.ldm.minimax','comfy.nested_tensor','comfy.ops','torch','torchaudio')}
        mods.update({'comfy.ldm.minimax.model':minimax,'comfy_api':module('comfy_api'), 'comfy_api.latest':module('comfy_api.latest',ComfyExtension=object,io=io),
                     'comfy_api.latest._input_impl':module('comfy_api.latest._input_impl',VideoFromFile=object),
                     'folder_paths':module('folder_paths'),'nodes':module('nodes'),'node_helpers':module('node_helpers'),
                     'comfy_extras':extras,'comfy_extras.nodes_audio':module('comfy_extras.nodes_audio'),
                     'comfy_extras.nodes_minimax_h3':module('comfy_extras.nodes_minimax_h3',MiniMaxH3ReferenceToVideo=NativeH3)})
        for name,m in mods.items():
            if '.' in name and name.rsplit('.',1)[0] in mods:setattr(mods[name.rsplit('.',1)[0]],name.rsplit('.',1)[1],m)
        self.modules=patch.dict(sys.modules,mods);self.modules.start()
        spec=importlib.util.spec_from_file_location('render_contract_fixture',ROOT/'render_nodes.py');self.render=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.render)
    def tearDown(self):self.modules.stop()
    def test_schema_does_not_mutate_native_node(self):
        old=[s.id for s in NativeH3.shared.inputs];new=self.render.H3ADv1BatchReferenceToVideo.define_schema()
        self.assertEqual([s.id for s in NativeH3.shared.inputs],old);self.assertEqual(NativeH3.shared.node_id,'MiniMaxH3ReferenceToVideo');self.assertEqual(new.node_id,'H3ADv1BatchReferenceToVideo')
        self.assertIn('batch_media_json',[s.id for s in new.inputs]);self.assertNotIn('ref_images',[s.id for s in new.inputs])
    def test_batch_calls_native_in_same_reference_order(self):
        self.render._load_image=lambda x:'IMAGE:'+x;self.render._load_audio=lambda x:'AUDIO:'+x;self.render._load_video=lambda x:('VIDEO:'+x,'SOUND:'+x)
        result=self.render.H3ADv1BatchReferenceToVideo.execute('clip','v','a','prompt',1792,672,192,batch_media_json={'images':['中文1.png','中文2.png'],'videos':[{'name':'动作.mp4','include_audio':False}],'audios':['声音.mp3']})
        self.assertEqual(result,('POS','LAT'));call=NativeH3.called
        self.assertEqual(call['ref_images'],{'ref_image_0':'IMAGE:中文1.png','ref_image_1':'IMAGE:中文2.png'});self.assertEqual(call['ref_audios'],{'ref_audio_0':'AUDIO:声音.mp3'});self.assertIsNone(call['ref_video_audios'])
    def test_extension_registers_only_new_names(self):
        import asyncio
        classes=asyncio.run(self.render.comfy_entrypoint().get_node_list());self.assertEqual(len(classes),7);self.assertTrue(all(c.__name__.startswith('H3ADv1') for c in classes))
    def test_total_reference_limit_in_node_itself(self):
        with self.assertRaises(ValueError):self.render.parse_media_state({'images':['x']*9,'audios':['a']*3,'videos':['v']})
    def test_model_compatibility_patches_only_a_clone(self):
        class Model:
            def __init__(self):self.model=types.SimpleNamespace(extra_conds=lambda **x:x);self.patches=[]
            def clone(self):return Model()
            def add_object_patch(self,name,value):self.patches.append((name,value))
        original=Model();self.render._core_supports_multiframe_guides=lambda:False
        patched=self.render.H3ADv1ModelCompat.execute(original,True)[0]
        self.assertIsNot(patched,original);self.assertFalse(original.patches);self.assertEqual(patched.patches[0][0],'extra_conds')
        self.assertIs(self.render.H3ADv1ModelCompat.execute(original,False)[0],original)
    def test_route_names_are_independent(self):
        from test_core import importlib
        register=importlib.import_module('h3ad_test.routes').register_routes
        class Routes:
            def __init__(self):self.paths=[]
            def get(self,path):self.paths.append(('GET',path));return lambda f:f
            def post(self,path):self.paths.append(('POST',path));return lambda f:f
        server=types.SimpleNamespace(routes=Routes());register(server,types.SimpleNamespace())
        self.assertEqual(len(server.routes.paths),4);self.assertTrue(all(path.startswith('/h3_autodrama_v1') for _,path in server.routes.paths))

if __name__=='__main__':unittest.main()
