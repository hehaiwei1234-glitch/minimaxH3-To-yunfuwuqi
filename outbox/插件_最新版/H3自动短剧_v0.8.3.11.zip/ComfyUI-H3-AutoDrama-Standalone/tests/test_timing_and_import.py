import copy
import importlib
import json
import tempfile
import unittest
from unittest.mock import AsyncMock, patch
import aiohttp
from test_core import ROOT, Store, domain, ComfyClient
import test_image_series as pipeline
from test_workflows import fixture
tp=importlib.import_module('h3ad_test.timing_policy')
iw=importlib.import_module('h3ad_test.image_workflows')
w=importlib.import_module('h3ad_test.workflows')
ImageGenerator=importlib.import_module('h3ad_test.image_generator').ImageGenerator

class PolicyTests(unittest.TestCase):
    def test_disabled_values_do_not_override_ai(self):
        policy=tp.normalize({'episode':{'enabled':False,'seconds':60},'task':{'enabled':False,'seconds':'bad'}})
        self.assertEqual(tp.seconds(policy,'episode'),0);self.assertIsNone(policy['task']['seconds'])
        plan=tp.prepare_segments({'segments':[{'duration_seconds':3.5},{'duration_seconds':6}]},policy)
        self.assertEqual([s['generation_seconds'] for s in plan['segments']],[3.5,6])
    def test_checked_but_empty_or_nonfinite_is_not_silently_auto(self):
        for value in (None,'',True,float('nan'),float('inf'),-1,16):
            with self.subTest(value=value),self.assertRaises(ValueError):tp.normalize({'task':{'enabled':True,'seconds':value}})
    def test_manual_task_and_story_tail_are_independent(self):
        policy=tp.normalize({'task':{'enabled':True,'seconds':5},'episode':{'enabled':True,'seconds':8}})
        plan=tp.prepare_segments({'segments':[{'duration_seconds':5},{'duration_seconds':3}]},policy)
        self.assertEqual([s['generation_seconds'] for s in plan['segments']],[5,5])
        self.assertEqual([s['duration_seconds'] for s in plan['segments']],[5,3])
        with self.assertRaisesRegex(ValueError,'拆成多个'):tp.prepare_segments({'segments':[{'duration_seconds':8}]},policy)
        with self.assertRaisesRegex(ValueError,'合计'):tp.prepare_segments({'segments':[{'duration_seconds':4}]},policy)
    def test_series_total_is_allocated_and_conflicts_fail_before_ai(self):
        policy=tp.normalize({'total':{'enabled':True,'seconds':30}})
        plan=tp.assign_episodes({'episodes':[{'duration_seconds':12},{'duration_seconds':18}]},policy)
        self.assertEqual([e['target_seconds'] for e in plan['episodes']],[12,18])
        with self.assertRaisesRegex(ValueError,'合计'):tp.assign_episodes({'episodes':[{'duration_seconds':10}]},policy)
        policy['episode']={'enabled':True,'seconds':8}
        with self.assertRaisesRegex(ValueError,'冲突'):tp.series_count(policy,0)
        policy['episode']['seconds']=10;self.assertEqual(tp.series_count(policy,0),3)
    def test_only_duration_and_runtime_fields_change_in_both_binding_units(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory)
            for mode in ('frames','seconds'):
                body=fixture()
                if mode=='seconds':body['duration_mode']='seconds';body['graph']['node_10']['inputs']['value']=4.0
                saved=w.save(store,body);before=copy.deepcopy(saved['graph'])
                clip={'prompt_en':'new','duration_seconds':3,'generation_seconds':5,'timing_version':1,'continuity':'cut'}
                graph=w.instantiate(saved,clip,domain.media_state([],[],[]),None,'test/output')
                changed={(nid,key) for nid in before for key,v in before[nid]['inputs'].items() if graph[nid]['inputs'][key]!=v}
                self.assertEqual(changed,{('node_39','value'),('node_38','batch_media_json'),('node_20','filename_prefix'),('node_10','value')})
                self.assertEqual(graph['node_10']['inputs']['value'],domain.h3_frames(5) if mode=='frames' else 5)
                self.assertEqual(saved['graph'],before)
                axis=w.timing(saved,clip);self.assertEqual(axis['new_content_end_seconds'],3)
                self.assertAlmostEqual(axis['generated_total_seconds'],domain.h3_frames(5)/24)
    def test_qwen_raw_api_graph_recovers_all_bindings(self):
        for name,n in [('qwen_base.json',0),('qwen_reference.json',8)]:
            body=json.loads((ROOT/'bundled_image_workflows'/name).read_text())
            result=iw.preview(body['graph'])['suggested']
            self.assertTrue(result['complete']);self.assertEqual(len(result['reference_bindings']),n)
            self.assertEqual(result['bindings'],body['bindings'])
            if n:
                record={**body,**iw.validate_bindings(body['graph'],body)}
                graph=iw.instantiate(record,'test',['generated/real.png'],'qa/image')
                self.assertTrue(all(graph[ref['node']]['inputs'][ref['input']]=='generated/real.png' for ref in record['reference_bindings']))

class TimingPipelineTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=pipeline.NewPipelineTests.asyncSetUp;asyncTearDown=pipeline.NewPipelineTests.asyncTearDown
    queue=pipeline.NewPipelineTests.queue;history=pipeline.NewPipelineTests.history
    responses=pipeline.NewPipelineTests.responses;chat=pipeline.NewPipelineTests.chat;image=pipeline.NewPipelineTests.image
    prompt=pipeline.NewPipelineTests.prompt;object_info=pipeline.NewPipelineTests.object_info
    def ai_result(self,instructions,prompt):
        result=pipeline.NewPipelineTests.ai_result(self,instructions,prompt)
        data=json.loads(prompt.split('\n修正上一次JSON',1)[0])
        if '分镜导演' in instructions and len(result['segments'])==3:
            for i,(s,duration) in enumerate(zip(result['segments'],[2,3,1])):
                s['duration_seconds']=duration;s['continuity']='continue' if i==1 else 'cut'
        if '整剧策划' in instructions and tp.seconds(data.get('timing_policy'),'total'):
            for e in result['episodes']:e['duration_seconds']=4
        return result
    async def make_movie(self,manual):
        policy={'task':{'enabled':True,'seconds':5}} if manual else {}
        p=self.store.create_project({'title':'安全屋测试','script':'女主：你好。\n女主：再见。\n女主：明天见。',
            'asset_ids':[self.asset['id']],'workflow_id':self.video['id'],'timing_policy':policy})
        self.engine.start(p['id']);await self.engine.tasks[p['id']];p=self.store.get('project',p['id'])
        # v0.8 protects the three-character final line: one second is too tight.
        self.assertEqual(p['status'],'complete',p['error']);self.assertAlmostEqual(p['planned_duration_seconds'],7)
        if manual:
            self.assertAlmostEqual(p['final']['duration'],7,delta=.15)
        else:
            # v0.8.3.4 preserves generated dialogue tails, including alignment
            # frames. The final movie must contain the adopted complete files.
            adopted=sum(float(c['meta']['video']['duration']) for c in p['clips'])
            self.assertAlmostEqual(p['final']['duration'],adopted,delta=.15)
            for clip in p['clips']:
                self.assertEqual(clip['output'],clip['raw_output'])
                self.assertEqual(clip['retention_audit']['application_removed_tail_seconds'],0)
        videos=[g for g in self.graphs if 'node_10' in g]
        self.assertEqual([g['node_10']['inputs']['value'] for g in videos],[domain.h3_frames(n) for n in ([5,5,5] if manual else [2,3,2])])
        previous=self.files.output_path(p['clips'][0]['output']).relative_to(self.files.output).as_posix()+' [output]'
        self.assertEqual(videos[1]['node_40']['inputs']['previous_video_name'],previous)
        self.assertEqual([c['duration_seconds'] for c in p['clips']],[2,3,2])
        for clip in p['clips']:self.assertTrue(clip['meta']['audio']);self.assertTrue(self.files.output_path(clip['raw_output']).exists())
        n=len(self.graphs);self.engine.set(p['id'],status='paused');self.engine.start(p['id']);await self.engine.tasks[p['id']]
        self.assertEqual(len(self.graphs),n)
    async def test_ai_variable_tasks_trim_merge_and_continue_from_kept_movie(self):await self.make_movie(False)
    async def test_manual_five_second_tasks_do_not_force_five_second_shots(self):await self.make_movie(True)
    async def test_series_total_reaches_child_budgets_and_real_final_movies(self):
        s=self.manager.create({'text':'女主：你好。\n女主：再见。\n女主：明天见。\n女主：晚安。','workflow_id':self.video['id'],
            'timing_policy':{'total':{'enabled':True,'seconds':8}}})
        self.manager.start(s['id']);await self.manager.tasks[s['id']];s=self.store.get('series',s['id'])
        self.assertEqual(s['status'],'complete',s['error']);children=[self.store.get('project',pid) for pid in s['project_ids']]
        self.assertEqual([c['episode_target_seconds'] for c in children],[4,4])
        self.assertAlmostEqual(sum(c['final']['duration'] for c in children),8,delta=.15)
    async def test_placeholders_ignored_only_at_import_real_files_checked_at_runtime(self):
        body=json.loads((ROOT/'bundled_image_workflows/qwen_reference.json').read_text());body['configured_by_bundle']=True
        saved=iw.save(self.store,body)
        classes={n['class_type']:{'input':{'required':{}}} for n in body['graph'].values()}
        classes['LoadImage']['input']['required']['image']=[['some_other.png']]
        client=ComfyClient(self.store.settings(),None);client.get=AsyncMock(return_value=classes)
        with self.assertRaisesRegex(ValueError,'不可用'):await client.preflight(body['graph'],'9')
        await client.preflight(body['graph'],'9',dynamic_inputs=body['reference_bindings'])
        original=ComfyClient.get
        async def get(comfy,route):return classes if route=='/object_info' else await original(comfy,route)
        with patch.object(ComfyClient,'get',get):
            async with aiohttp.ClientSession() as session:
                cfg={**self.store.settings(),'image_provider':'local'}
                generator=ImageGenerator(self.store,self.files,cfg,session,self.engine.render_lock,{'base':self.base,'reference':saved})
                result=await generator.raw_image(None,'file_test','owner','prompt',[self.files.asset_path(self.asset)])
                self.assertTrue(result.startswith(b'\x89PNG'))
                with self.assertRaisesRegex(ValueError,'必须已保存在'):
                    await generator.raw_image(None,'missing','owner','prompt',[self.files.input/'not_here.png'])
    async def test_empty_old_settings_recover_unique_templates_and_secrets_survive(self):
        self.store.save_settings({'image_provider':'local','openai_api_key':'retained'})
        cfg=self.store.settings();snapshot=iw.snapshots(self.store,cfg)
        self.assertEqual(snapshot['base']['id'],self.base['id'])
        self.assertEqual(self.store.settings()['image_reference_workflow_id'],self.reference['id'])
        public=self.store.save_settings({'image_workflow_id':self.base['id']})
        self.assertEqual(public['openai_api_key'],'');self.assertEqual(self.store.settings()['openai_api_key'],'retained')
