// 素材勾选器的真实浏览器测试（假后端，不调用任何付费接口，不需要 GPU）。
// 运行：node tests/test_asset_picker_browser.cjs   需要 playwright 和 Chromium。
const assert = require('node:assert/strict');
const F = require('./fake_backend.cjs');

const asset = (id, label, kind, extra = {}) => ({id, name: label + '.png', kind, label, role: '', speaker: '', description: '', created_at: 1700000000, generated: false, ...extra});
// a1,a2,a3 属于较早的剧；a1,a2,a4,a5,g1 属于最近的剧；h1、s1 是软件自动生成的单镜头参考图（开场图、前段状态图）。
const ASSETS = [
  asset('a1', '莉莉', 'image', {role: 'character'}), asset('a2', '基利安正面', 'image'), asset('a3', '旧酒馆', 'image'),
  asset('a4', '大厅', 'image'), asset('a5', '莉莉声音', 'audio', {role: 'voice', speaker: '莉莉'}), asset('a6', '无关路人', 'image'),
  asset('a7', '莉莉旧声音', 'audio', {role: 'voice', speaker: '莉莉'}),
  asset('g1', '共用_场景', 'image', {generated: true}),
  asset('h1', '片段 1 开场图', 'image', {generated: true, name: '片段_001_开场图_v1.png'}),
  asset('s1', '前段最终采用状态', 'image', {generated: true, name: '前段状态.png', label: '前段最终采用状态'}),
];
const rec = (id, title, created_at, extra) => F.seriesRecord({id, title, created_at, project_ids: [], episodes: [], ...extra});
const SERIES = {
  old: rec('old', '旧剧', 1700000100, {asset_ids: ['a1', 'a2', 'a3']}),
  new: rec('new', '最近的剧', 1700009000, {asset_ids: ['a2', 'a4', 'a7'], generated_assets: {scene: 'g1'}, character_bindings: {莉莉: {image_ids: ['a1'], voice_id: 'a5'}}}),
  gone: rec('gone', '已归档的剧', 1700099999, {asset_ids: ['a6'], archived: true}),
};
const state = {assets: ASSETS, series: SERIES};

const ids = (page, selector) => page.$$eval(selector, els => els.map(e => e.value));
const checked = page => ids(page, '#series-asset-choices input:checked');
const visible = page => page.$$eval('#series-asset-choices label:not(.hidden) input', els => els.map(e => e.value));
const status = page => page.textContent('#series-form [data-asset-status]');
const sorted = a => [...a].sort();

(async () => {
  const {server, url} = await F.startServer(state);
  const browser = await F.launch();
  const page = await F.openPage(browser, url);
  const errors = page.pageErrors;
  try {
    await F.waitReady(page);

    // 1. 起始状态：自动生成的参考图默认隐藏，但数量会说明；其余素材都显示，什么都没选。
    assert.deepEqual(await checked(page), []);
    assert.deepEqual(sorted(await visible(page)), ['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'g1']);
    assert.match(await status(page), /已选 0 个素材，当前显示 8 个/);
    assert.match(await status(page), /已隐藏 2 个自动生成的参考图/);

    // 2. 一键全选：只选当前显示的，不会悄悄把隐藏的开场图也选上。
    await page.click('#series-form [data-asset-act="all"]');
    assert.deepEqual(sorted(await checked(page)), ['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'g1']);
    await page.click('#series-form [data-asset-act="none"]');
    assert.deepEqual(await checked(page), []);

    // 3. 沿用最近一部剧：全选它用过的素材（含人物绑定的图和声音、自动生成的共用图），只显示这些；已归档的剧不算。
    await page.check('#series-form [data-asset-act="recent"]');
    await page.waitForFunction(() => document.querySelectorAll('#series-asset-choices input:checked').length > 0);
    assert.deepEqual(sorted(await checked(page)), ['a1', 'a2', 'a4', 'a5', 'g1']);
    assert.deepEqual(sorted(await visible(page)), ['a1', 'a2', 'a4', 'a5', 'g1']);
    assert.match(await status(page), /已沿用《最近的剧》的 5 个素材/);

    // 4. 取消其中一个（比如不想要大厅）：它还在列表里，但不再勾选。
    await page.uncheck('#series-asset-choices input[value="a4"]');
    assert.deepEqual(sorted(await checked(page)), ['a1', 'a2', 'a5', 'g1']);
    assert.deepEqual(sorted(await visible(page)), ['a1', 'a2', 'a4', 'a5', 'g1']);

    // 5. 想另选其他素材：切到“显示全部”，再勾选旧酒馆。已有的勾选保留，最近一部剧用过的带 ★。
    await page.click('#series-form [data-asset-act="scope"]');
    assert.deepEqual(sorted(await visible(page)), ['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'g1']);
    assert.match(await page.textContent('#series-asset-choices label[data-asset-id="a1"]'), /★/);
    assert.doesNotMatch(await page.textContent('#series-asset-choices label[data-asset-id="a3"]'), /★/);
    await page.check('#series-asset-choices input[value="a3"]');
    assert.deepEqual(sorted(await checked(page)), ['a1', 'a2', 'a3', 'a5', 'g1']);

    // 6. 再切回“只显示这部分”：不在范围内的已选素材（旧酒馆）仍会随表单提交，状态栏明确提示。
    await page.click('#series-form [data-asset-act="scope"]');
    assert.deepEqual(sorted(await visible(page)), ['a1', 'a2', 'a4', 'a5', 'g1']);
    assert.match(await status(page), /另有 1 个已选素材不在当前显示范围内/);
    assert.deepEqual(sorted(await checked(page)), ['a1', 'a2', 'a3', 'a5', 'g1']);

    // 7. 提交：请求里的 asset_ids 就是勾选的那些（含被隐藏的）。
    await page.fill('#series-form [name=title]', '测试剧');
    await page.fill('#series-form [name=text]', '第一集：夜晚。\n莉莉：你好。');
    await page.selectOption('#series-form [name=workflow_id]', 'wf1');
    await page.click('#series-form button[type=submit]');
    // 创建流程（创建、打开、开始、再打开）整个结束后才继续：此时 creatingSeries 已复位，“新建整剧”才不会被忽略。
    await page.waitForFunction(() => document.querySelector('#notice').textContent.includes('已开始整剧') || document.querySelector('#notice').classList.contains('fail'), null, {timeout: 20000});
    assert.ok(state.created, '没有发出创建整剧的请求：' + await page.textContent('#notice'));
    assert.deepEqual(sorted(state.created.asset_ids), ['a1', 'a2', 'a3', 'a5', 'g1']);

    // 8. 重新点“新建整剧”：不能把上一次的勾选带到新剧里。
    await page.click('#new-series');
    await page.waitForSelector('#series-form:not(.hidden)');
    await page.waitForTimeout(300);
    assert.deepEqual(await checked(page), []);
    assert.equal(await page.isChecked('#series-form [data-asset-act="recent"]'), false);

    // 9. 勾选后取消“沿用最近一部剧”：恢复沿用之前的选择，回到显示全部。
    await page.click('#series-asset-choices input[value="a6"]', {force: true});
    await page.check('#series-form [data-asset-act="recent"]');
    await page.waitForFunction(() => document.querySelectorAll('#series-asset-choices input:checked').length === 5);
    await page.uncheck('#series-form [data-asset-act="recent"]');
    assert.deepEqual(await checked(page), ['a6']);
    assert.deepEqual(sorted(await visible(page)), ['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'g1']);

    // 10. 素材被删除后重新载入：已选里不存在的素材要被丢掉，不能偷偷提交已不存在的 ID。
    await page.evaluate(() => { document.querySelector('#series-asset-choices input[value="a1"]').click(); });
    state.assets = ASSETS.filter(a => a.id !== 'a1' && a.id !== 'a6');
    await page.evaluate(() => loadAssets());
    assert.deepEqual(await checked(page), []);
    assert.ok(!(await visible(page)).includes('a1'));

    // 11. 接口失败时：勾选框保持原样，错误显示在状态栏，不会静默失败。
    state.assets = ASSETS;
    await page.evaluate(() => loadAssets());
    const realFetch = await page.evaluate(() => { window.__realFetch = window.fetch; window.fetch = (u, o) => /api\/series$/.test(String(u)) ? Promise.resolve(new Response('<html>502</html>', {status: 502})) : window.__realFetch(u, o); return true; });
    await page.click('#series-form [data-asset-act="recent"]');
    await page.waitForFunction(() => document.querySelector('#notice').classList.contains('fail'));
    assert.equal(await page.isChecked('#series-form [data-asset-act="recent"]'), false);
    await page.evaluate(() => { window.fetch = window.__realFetch; });
    // 12. 填到一半去看别的剧再回来：勾选和填写的内容都保留（只有创建成功后才清空）。
    state.assets = ASSETS;
    await page.evaluate(() => loadAssets());
    await page.click('#new-series');
    await page.waitForSelector('#series-form:not(.hidden)');
    // 点“新建整剧”会重新加载素材并重画列表；等它画完再点勾选框，否则点击可能正好落在被替换掉的旧节点上。
    await page.waitForTimeout(600);
    await page.fill('#series-form [name=title]', '写到一半的剧');
    await page.click('#series-asset-choices input[value="a1"]', {force: true});
    await page.click('#series-asset-choices input[value="a3"]', {force: true});
    await page.click('[data-series="old"]');
    await page.waitForSelector('#series-detail:not(.hidden)');
    await page.click('#new-series');
    await page.waitForSelector('#series-form:not(.hidden)');
    await page.waitForTimeout(300);
    assert.deepEqual(sorted(await checked(page)), ['a1', 'a3'], '回到新建表单后勾选要保留');
    assert.equal(await page.inputValue('#series-form [name=title]'), '写到一半的剧');
    await page.click('#series-form [data-asset-act="none"]');

    // 13. 沿用最近一部剧时，改过绑定后留下的旧声音（a7）不能一起勾上，否则后端会拒绝“多份音色”。
    await page.check('#series-form [data-asset-act="recent"]');
    await page.waitForFunction(() => document.querySelectorAll('#series-asset-choices input:checked').length > 0);
    const reused = await checked(page);
    assert.ok(!reused.includes('a7') && reused.includes('a5'), '只保留现在绑定的声音：' + reused);
    assert.doesNotMatch(await status(page), /这样选会被拒绝/);
    await page.click('#series-form [data-asset-act="none"]');

    // 14. 手动全选会凑出后端必然拒绝的组合时，当场提醒，并写明是谁、多少。
    {
      const many = [1, 2, 3, 4, 5].map(n => asset('k' + n, '基利安', 'image', {role: 'character', name: '基利安' + n + '.png'}));
      const crowded = {assets: [...many, asset('v1', '莉莉声音甲', 'audio', {role: 'voice', speaker: '莉莉'}), asset('v2', '莉莉声音乙', 'audio', {role: 'voice', speaker: '莉莉'})], series: SERIES};
      const second = await F.startServer(crowded);
      const page2 = await F.openPage(browser, second.url);
      await F.waitReady(page2);
      await page2.click('#series-form [data-asset-act="all"]');
      const text = await page2.textContent('#series-form [data-asset-status]');
      assert.match(text, /这样选会被拒绝/);
      assert.match(text, /基利安：已选 5 张人物图，最多 4 张/);
      assert.match(text, /莉莉：已选 2 份声音，只能留 1 份/);
      await page2.uncheck('#series-asset-choices input[value="k5"]');
      await page2.uncheck('#series-asset-choices input[value="v2"]');
      assert.doesNotMatch(await page2.textContent('#series-form [data-asset-status]'), /这样选会被拒绝/);
      second.server.close(); await page2.context().close();
    }

    // 15. 只固定了声音的角色：沿用时，她自动生成的人物图要保留（不能当成“被取代的旧图”丢掉）。
    {
      const voiceOnly = {assets: [asset('v1', '莉莉声音', 'audio', {role: 'voice', speaker: '莉莉'}),
        asset('g1', '莉莉', 'image', {role: 'character', generated: true}), asset('g2', '共用_场景', 'image', {generated: true})],
        series: {only: rec('only', '只有声音的剧', 1700000500, {asset_ids: ['v1', 'g1', 'g2'], character_bindings: {莉莉: {image_ids: [], voice_id: 'v1'}}})}};
      const third = await F.startServer(voiceOnly);
      const page3 = await F.openPage(browser, third.url);
      await F.waitReady(page3);
      await page3.check('#series-form [data-asset-act="recent"]');
      await page3.waitForFunction(() => document.querySelectorAll('#series-asset-choices input:checked').length > 0);
      assert.deepEqual(sorted(await checked(page3)), ['g1', 'g2', 'v1']);
      third.server.close(); await page3.context().close();
    }

    // 16. 制作稿模式下后端不按角色分组检查，所以不能提醒“会被拒绝”；切回剧本方式后才提醒。
    {
      const many = [1, 2, 3, 4, 5, 6].map(n => asset('k' + n, '基利安', 'image', {role: 'character'}));
      const fourth = await F.startServer({assets: many, series: SERIES});
      const page4 = await F.openPage(browser, fourth.url);
      await F.waitReady(page4);
      await page4.selectOption('#series-form [name=input_type]', 'production_draft');
      await page4.click('#series-form [data-asset-act="all"]');
      assert.doesNotMatch(await page4.textContent('#series-form [data-asset-status]'), /这样选会被拒绝/);
      await page4.selectOption('#series-form [name=input_type]', 'script');
      assert.match(await page4.textContent('#series-form [data-asset-status]'), /这样选会被拒绝/);
      fourth.server.close(); await page4.context().close();
    }
    assert.deepEqual(errors, []);
    console.log('asset picker browser: 16 scenarios passed');
  } finally {
    await browser.close();
    server.close();
  }
})().catch(error => { console.error(error); process.exit(1); });
