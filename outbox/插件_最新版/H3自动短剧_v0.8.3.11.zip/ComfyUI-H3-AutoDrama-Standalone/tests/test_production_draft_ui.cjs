const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const root=path.join(__dirname,'../static'),script=fs.readFileSync(path.join(root,'production_draft.js'),'utf8');
class Element{
 constructor(){this.events={};this.children={};this.dataset={};this.disabled=false;this.checked=false;this.value='';this.firstChild={textContent:'集数（0＝AI）'};this.classList={toggle(){},add(){},remove(){}}}
 addEventListener(type,fn,capture=false){(this.events[type]??=[]).push({fn,capture})}
 querySelector(key){return this.children[key]??=new Element()}
 closest(){return this.parentElement??=new Element()}
 after(){} prepend(){} close(){this.closed=true}
}
function environment(){
 const nodes={},panels=[],pending=[],errors=[],calls=[];let oldSubmits=0;
 for(const id of ['series-form','append-form']){
  const f=nodes[id]=new Element(),elements=[];
  for(const key of ['input_type','text','workflow_id','episode_count','title','instructions']){
   const el=new Element();el.name=key;el.value={input_type:'script',text:'{}',workflow_id:'wf',episode_count:'0',title:'test',instructions:''}[key];el.parentElement=new Element();elements.push(el);elements[key]=el;
  }
  f.id=id;f.elements=elements;f.onsubmit=()=>oldSubmits++;
 }
 const ctx={document:{getElementById:id=>nodes[id]??=new Element(),createElement:()=>{const p=new Element();panels.push(p);return p}},
  MutationObserver:class{observe(){}},queueMicrotask,BASE:'/h3_autodrama_v1/',current:null,currentSeries:null,
  FormData:class{constructor(form){return form.elements.map(el=>[el.name,el.value])}},
  $$:()=>[],timingFromForm:()=>({version:1}),notice(){},setInterval(){},
  guarded:fn=>(...args)=>{const p=Promise.resolve().then(()=>fn(...args));pending.push(p);p.catch(e=>errors.push(e));return p},
  openSeries:async id=>calls.push('open:'+id),api:async(route,body)=>{calls.push({route,body});return {id:'saved',episodes:1,tasks:1,seconds:2,image_backend:'本地'}},
  appendContext:{id:'series-existing',revision:3},appendRequestId:'request-id',
  APPEND_POST:{timeoutMs:120000,timeoutHint:''},appendPhase:'',resetAssetPicker(){},
  startAfterAppend:async id=>{calls.push({route:'series/'+id+'/start',body:{}})},
  afterAppendSaved:async id=>{await ctx.openSeries(id);await ctx.startAfterAppend(id);await ctx.openSeries(id)}};
 vm.createContext(ctx);vm.runInContext(script,ctx);
 function submit(form){
  const event={target:form,preventDefault(){this.prevented=true},stopImmediatePropagation(){this.stopped=true}};
  for(const listener of form.events.submit){listener.fn(event);if(event.stopped)break}
  if(!event.stopped)form.onsubmit(event);return event;
 }
 return {ctx,nodes,panels,pending,errors,calls,submit,oldSubmits:()=>oldSubmits,async settle(){await Promise.allSettled(pending)}};
}
(async()=>{
 const a=environment();a.submit(a.nodes['series-form']);assert.equal(a.oldSubmits(),1);assert.equal(a.calls.length,0);
 const f=a.nodes['series-form'];f.elements.input_type.value='production_draft';f.elements.text.value='{"schema":"h3-production-draft","version":1}';
 a.submit(f);a.submit(f);await a.settle();assert.equal(a.errors.length,0);assert.equal(a.oldSubmits(),1);
 assert.equal(a.calls.filter(x=>x.route==='series').length,1);assert.equal(a.calls.find(x=>x.route==='series').body.allow_image_api,false);
 assert.equal(a.calls.find(x=>x.route==='series').body.input_type,'production_draft');assert.equal(f.elements.text.disabled,false);
 const b=environment();const bf=b.nodes['series-form'];bf.elements.input_type.value='production_draft';b.ctx.api=async()=>{throw Error('validation failed')};
 b.submit(bf);await b.settle();assert.equal(b.errors[0].message,'validation failed');assert.equal(bf.elements.text.disabled,false);
 const c=environment();const cf=c.nodes['append-form'];cf.elements.input_type.value='production_draft';c.panels[1].querySelector('[data-draft-image-api]').checked=true;c.panels[1].querySelector('[data-draft-adopt]').checked=true;
 c.submit(cf);await c.settle();const append=c.calls.find(x=>x.route==='series/series-existing/append');assert.equal(append.body.allow_image_api,true);assert.equal(append.body.expected_revision,3);assert.equal(append.body.request_id,'request-id');
 assert.equal(append.body.adopt_series_declarations,true);assert.equal(append.body.input_type,'production_draft');
 assert.ok(c.calls.findIndex(x=>x.route==='series/saved/start')>c.calls.findIndex(x=>x.route==='series/series-existing/append'),'追加之后才开始');
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8');const version=fs.readFileSync(path.join(__dirname,'../version.py'),'utf8').match(/VERSION\s*=\s*['"]([^'"]+)['"]/)[1];assert.equal((html.match(/value="production_draft"/g)||[]).length,2);assert(html.includes('production_draft.js?v='+version+'"'));
 console.log('5 new UI checks passed: old form passes through; draft single submission; failure unlock; append flags, adopt switch, explicit input_type and revision; entry markup.');
})().catch(e=>{console.error(e);process.exitCode=1});
