// 页面启动韧性测试：启动时任何一个请求失败、卡住或断线，按钮都必须照常可用（“追加后续剧本”曾因此没有反应）。
// 运行：node tests/test_startup_browser.cjs   需要 playwright 和 Chromium；不调用付费接口。
const assert = require('node:assert/strict');
const F = require('./fake_backend.cjs');

const HANDLERS = [['new-series', 'onclick'], ['series-form', 'onsubmit'], ['resume-series', 'onclick'], ['pause-series', 'onclick'], ['append-series', 'onclick'],
  ['append-form', 'onsubmit'], ['append-text-file', 'onchange'], ['delete-form', 'onsubmit'], ['script-edit-form', 'onsubmit'], ['show-archived-series', 'onchange'],
  ['workflow-form', 'onsubmit'], ['install-qwen-templates', 'onclick'], ['image-provider', 'onchange'], ['image-workflow-form', 'onsubmit']];

const CASES = [
  ['设置请求返回网关错误页', {method: 'GET', match: /^settings$/, mode: 'html', times: 1}, /设置/],
  ['素材请求 500', {method: 'GET', match: /^assets/, mode: 500, times: 1}, /素材/],
  ['单集列表请求 500', {method: 'GET', match: /^projects/, mode: 500, times: 1}, /单集/],
  ['工作流请求 500', {method: 'GET', match: /^workflows/, mode: 500, times: 1}, /工作流/],
  ['生图工作流请求 500', {method: 'GET', match: /^image-workflows/, mode: 500, times: 1}, /生图工作流/],
  ['整剧列表请求 500', {method: 'GET', match: /^series(\?|$)/, mode: 500, times: 1}, /整剧/],
  ['连接被切断（整剧列表 2.5 秒内一直断线）', {method: 'GET', match: /^series(\?|$)/, mode: 'drop', forMs: 2500}, /无法连接到服务器/],
  ['版本请求 500（会自动重试，不再永远挂着红字）', {method: 'GET', match: /^version$/, mode: 500, times: 1}, /版本/],
  ['待清理文件查询 500（只是附加提示）', {method: 'GET', match: /^manage\/cleanup/, mode: 500, times: 1}, null],
];

async function run(browser, name, rule, expected) {
  const state = {series: {ser1: F.seriesRecord({input_type: 'production_draft'})}, assets: [], fail: [{...rule}]};
  const {server, url} = await F.startServer(state);
  try {
    const page = await F.openPage(browser, url);
    // 第一次失败后，最晚几秒内要有结果：失败说明或直接恢复。
    await page.waitForFunction(() => /就绪：|没有加载成功/.test(document.querySelector('#notice').textContent), null, {timeout: 6000});
    const bound = await F.handlersBound(page, HANDLERS);
    const dead = Object.entries(bound).filter(([, ok]) => !ok).map(([k]) => k);
    assert.deepEqual(dead, [], `${name}：这些按钮没有绑定：${dead}`);
    const first = await page.textContent('#notice');
    if (expected) assert.match(first, expected, `${name}：状态栏没有说明原因：${first}`);
    // 失败的列表要自动补上：整剧列表重新出现，状态栏恢复为就绪（连续 2 次断线的用例最终也应恢复）。
    await page.waitForSelector('[data-series]', {timeout: 12000});
    await page.waitForFunction(() => document.querySelector('#notice').textContent.includes('就绪：'), null, {timeout: 12000});
    // 追加后续剧本按钮此时可用，点击后弹窗确实打开。
    await page.click('[data-series]');
    await page.waitForSelector('#series-detail:not(.hidden)');
    await page.click('#append-series');
    await page.waitForFunction(() => document.querySelector('#append-dialog').open, null, {timeout: 3000});
    assert.deepEqual(page.pageErrors, [], `${name}：页面报错 ${page.pageErrors}`);
    await page.context().close();
  } finally { server.close(); }
  console.log('  ok', name);
}

async function hung(browser) {
  // 请求永远不返回：45 秒的上限在测试里缩短成 1.5 秒；超时后按钮仍然可用，状态栏说明是超时。
  const state = {series: {ser1: F.seriesRecord()}, assets: [], fail: [{method: 'GET', match: /^workflows/, mode: 'hang', times: 1}]};
  const {server, url} = await F.startServer(state);
  try {
    const page = await F.openPage(browser, url, {timeoutMs: 1500});
    // 请求还在卡住的时候（远没到超时）按钮就已经接好：先接按钮，后加载数据。
    const early = await F.handlersBound(page, HANDLERS);
    assert.deepEqual(Object.entries(early).filter(([, ok]) => !ok).map(([k]) => k), [], '页面刚打开、请求还没返回时，按钮就应该可用');
    assert.doesNotMatch(await page.textContent('#notice'), /请求超时/);
    await page.waitForFunction(() => /请求超时/.test(document.querySelector('#notice').textContent), null, {timeout: 8000});
    const bound = await F.handlersBound(page, HANDLERS);
    assert.deepEqual(Object.entries(bound).filter(([, ok]) => !ok).map(([k]) => k), []);
    await page.waitForFunction(() => document.querySelector('#notice').textContent.includes('就绪：'), null, {timeout: 12000});
    await page.context().close();
  } finally { server.close(); }
  console.log('  ok 请求卡住（超时后按钮可用并自动恢复）');
}

async function draftImport(browser) {
  // ComfyUI 页面带来的工作流草稿导入失败：按名字报告、保留草稿以便重试，不被“就绪”盖掉。
  const state = {series: {ser1: F.seriesRecord()}, assets: []};
  const {server, url} = await F.startServer(state);
  try {
    const context = await browser.newContext({viewport: {width: 1280, height: 800}});
    await context.addInitScript(`try{localStorage.setItem('h3ad_workflow_draft_tok', '{"1":{"class_type":"H3ADv1Prepare","inputs":{}}}')}catch{}`);
    const page = await context.newPage();
    await page.goto(url + '?workflow_draft=tok');
    await page.waitForFunction(() => /工作流草稿/.test(document.querySelector('#notice').textContent), null, {timeout: 6000});
    assert.match(await page.textContent('#notice'), /工作流草稿：/);
    await page.waitForFunction(() => /仍有 1 项数据没有加载成功（工作流草稿/.test(document.querySelector('#notice').textContent), null, {timeout: 12000});
    assert.equal(await page.evaluate(() => localStorage.getItem('h3ad_workflow_draft_tok') !== null), true, '导入失败时草稿要保留');
    assert.ok(state.calls.filter(c => c.route === 'workflows/preview').length >= 2, '4 秒后要再导入一次');
    await context.close();
  } finally { server.close(); }
  console.log('  ok 工作流草稿导入失败：按名字报告、保留、重试');
}

async function draftHang(browser) {
  // 工作流草稿导入卡住（预览请求不回复）时：其他加载失败仍然在几秒内报告并自动重试，不被它拖住。
  const state = {series: {ser1: F.seriesRecord()}, assets: [], fail: [
    {method: 'GET', match: /^settings$/, mode: 500, forMs: 3000},
    {method: 'POST', match: /^workflows\/preview$/, mode: 'hang'}]};
  const {server, url} = await F.startServer(state);
  try {
    const context = await browser.newContext({viewport: {width: 1280, height: 800}});
    await context.addInitScript(`try{localStorage.setItem('h3ad_workflow_draft_tok', '{"1":{"class_type":"H3ADv1Prepare","inputs":{}}}')}catch{}`);
    const page = await context.newPage();
    await page.goto(url + '?workflow_draft=tok');
    await page.waitForFunction(() => /设置/.test(document.querySelector('#notice').textContent), null, {timeout: 10000});
    assert.match(await page.textContent('#notice'), /没有加载成功/);
    // 4 秒后自动重试，设置应当加载成功（settings 请求至少 2 次）。
    await page.waitForFunction(() => !/设置：/.test(document.querySelector('#notice').textContent), null, {timeout: 15000});
    assert.ok(state.calls.filter(c => c.route === 'settings').length >= 2, '设置要重试');
    await context.close();
  } finally { server.close(); }
  console.log('  ok 草稿导入卡住：不拖累其他加载的失败说明和重试');
}

(async () => {
  const browser = await F.launch();
  try {
    for (const [name, rule, expected] of CASES) await run(browser, name, rule, expected);
    await hung(browser);
    await draftImport(browser);
    await draftHang(browser);
    console.log('startup resilience browser: all scenarios passed');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });
