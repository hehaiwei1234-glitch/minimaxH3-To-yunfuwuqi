"""Lost-task recovery and in-flight diagnostics; local mocks, no GPU/API fees."""
import asyncio
import copy
import importlib
import json
import shutil
import tempfile
import time
import types
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch
import aiohttp
from aiohttp import web
from test_core import Store, Files, domain, ROOT
import test_integration as integration
import test_image_series as images

comfy=importlib.import_module('h3ad_test.comfy_client')
diagnostics=importlib.import_module('h3ad_test.api_diagnostics')
telemetry=importlib.import_module('h3ad_test.telemetry')
providers=importlib.import_module('h3ad_test.providers')
VERSION=importlib.import_module('h3ad_test.version').VERSION


class WaitRecoveryTests(unittest.IsolatedAsyncioTestCase):
    def client(self):
        cfg={**domain.DEFAULTS,'comfy_url':'http://127.0.0.1:8188','poll_seconds':0,'retry_limit':0}
        client=comfy.ComfyClient(cfg,None);self.clock=0;self.paths=[]
        return client
    def clock_module(self):
        return types.SimpleNamespace(monotonic=lambda:self.clock,time=time.time)
    def entry(self):
        return {'status':{'completed':True},'outputs':{'out':{'images':[{'filename':'frame.png','type':'output'}]}}}
    async def test_missing_task_requires_repeated_absence_and_grace_then_records_reason(self):
        client=self.client()
        async def get(path):
            self.clock+=2;self.paths.append(path)
            return {'queue_running':[],'queue_pending':[]} if path=='/queue' else {}
        client.get=get
        with tempfile.TemporaryDirectory() as folder:
            store=Store(Path(folder));p=store.create_project({'script':'测试'})
            with telemetry.scope(store,'project',p['id']),patch.object(comfy,'time',self.clock_module()):
                with self.assertRaisesRegex(comfy.TaskMissing,'队列和历史'):await client.wait('old','out','image')
            rows=diagnostics.export(store,'project',p['id'])['comfy_waits']
            self.assertEqual(len(rows),1);self.assertEqual(rows[0]['status'],'missing')
            self.assertEqual(rows[0]['prompt_id'],'old');self.assertEqual(rows[0]['kind'],'image')
        self.assertGreaterEqual(self.paths.count('/queue'),3)
        self.assertGreaterEqual(self.clock,client.MISSING_GRACE_SECONDS)
        self.assertGreaterEqual(self.paths.count('/history/old'),2*self.paths.count('/queue'))
    async def test_queued_and_running_tasks_remain_valid_and_later_complete(self):
        for state in ('queue_pending','queue_running'):
            with self.subTest(state=state):
                client=self.client();checks=0
                async def get(path):
                    nonlocal checks
                    self.clock+=2;self.paths.append(path)
                    if path=='/queue':return {'queue_pending':[],'queue_running':[],state:[[0,'old',{},{}]]}
                    checks+=1;return {'old':self.entry()} if checks==12 else {}
                client.get=get
                with patch.object(comfy,'time',self.clock_module()):output=await client.wait('old','out','image')
                self.assertEqual(output['filename'],'frame.png');self.assertEqual(checks,12)
    async def test_completion_between_history_and_queue_reads_is_recovered(self):
        client=self.client();reads=0
        async def get(path):
            nonlocal reads
            self.clock+=2;self.paths.append(path)
            if path=='/queue':return {'queue_pending':[],'queue_running':[]}
            reads+=1;return {'old':self.entry()} if reads==2 else {}
        client.get=get
        with patch.object(comfy,'time',self.clock_module()):output=await client.wait('old','out','image')
        self.assertEqual(output['filename'],'frame.png');self.assertEqual(reads,2)
    async def test_unavailable_or_malformed_queue_does_not_prove_task_missing(self):
        for queue in (None,{}, {'queue_pending':[]}, {'queue_pending':[],'queue_running':[None]}):
            with self.subTest(queue=queue):
                client=self.client();client.config['render_timeout_minutes']=.4
                async def get(path):
                    self.clock+=2;self.paths.append(path)
                    if path!='/queue':return {}
                    if queue is None:raise RuntimeError('queue unavailable')
                    return queue
                client.get=get
                with patch.object(comfy,'time',self.clock_module()),self.assertRaises(TimeoutError):
                    await client.wait('old','out','image')
    async def test_transient_absence_resets_when_task_reappears(self):
        client=self.client();queues=0;history_reads=0
        async def get(path):
            nonlocal queues,history_reads
            self.clock+=2
            if path=='/queue':
                queues+=1;running=[[0,'old',{},{}]] if queues==3 else []
                return {'queue_pending':[],'queue_running':running}
            history_reads+=1
            return {'old':self.entry()} if history_reads>=10 else {}
        client.get=get
        with patch.object(comfy,'time',self.clock_module()):output=await client.wait('old','out','image')
        self.assertEqual(output['filename'],'frame.png');self.assertGreaterEqual(queues,5)
    async def test_connection_errors_never_become_missing_or_resubmit(self):
        client=self.client();client.get=AsyncMock(side_effect=RuntimeError('offline'))
        with self.assertRaisesRegex(RuntimeError,'offline'):await client.wait('old')
        self.assertEqual(client.get.await_count,3)


# Reuse fixture helpers, without executing another class's test cases twice.
class LocalFixture(unittest.IsolatedAsyncioTestCase):pass
for _source in (integration.IntegrationTests,images.NewPipelineTests):
    for _name,_method in vars(_source).items():
        if callable(_method) and not _name.startswith('test_'):setattr(LocalFixture,_name,_method)
del _source,_name,_method


class OutputRecoveryTests(LocalFixture):
    def saved_image_job(self,identity,owner,output=False):
        record=copy.deepcopy(self.base);prefix=domain.PREFIX+'/images/'+identity+'_a0'
        graph=images.iw.instantiate(record,'woman',[],prefix)
        job={'id':identity,'owner_id':owner,'job_id':'marker_'+identity,'prompt_id':'lost_'+identity,
             'graph':graph,'output_prefix':prefix,'output_node_id':'out','prefix_binding':record['bindings']['prefix'],
             'workflow_name':record['name'],'workflow_version':record['version'],'seed':'original-seed',
             'status':'submitted','submission_unknown':False,'attempt':0}
        self.store.put('image_job',identity,job)
        if output:
            path=self.files.output/(prefix+'_00001_.png');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(self.png)
        return job
    async def test_missing_image_recovers_saved_output_without_api_or_gpu_resubmission(self):
        self.local();p=self.project();self.saved_image_job('saved_frame',p['id'],output=True)
        cfg=self.engine.config({'settings':{}})
        async with aiohttp.ClientSession() as session:
            generator=images.ig.ImageGenerator(self.store,self.files,cfg,session,self.engine.render_lock)
            generator.comfy.MISSING_GRACE_SECONDS=0;generator.comfy.config['poll_seconds']=0
            with telemetry.scope(self.store,'project',p['id']):
                result=await generator.raw_image(None,'saved_frame',p['id'],'woman')
        self.assertEqual(result,self.png);self.assertFalse(self.graphs);self.assertEqual(self.image_calls,0)
        job=self.store.get('image_job','saved_frame');self.assertEqual(job['status'],'complete')
        self.assertEqual(job['seed'],'original-seed');self.assertFalse(job['submission_unknown'])
    async def test_missing_image_stops_and_resume_never_posts_without_explicit_confirmation(self):
        self.local();p=self.project();job=self.saved_image_job('lost_frame',p['id']);cfg=self.engine.config({'settings':{}})
        async with aiohttp.ClientSession() as session:
            generator=images.ig.ImageGenerator(self.store,self.files,cfg,session,self.engine.render_lock)
            generator.comfy.MISSING_GRACE_SECONDS=0;generator.comfy.config['poll_seconds']=0
            with self.assertRaises(comfy.TaskMissing):await generator.raw_image(None,'lost_frame',p['id'],'woman')
            lost=self.store.get('image_job','lost_frame');self.assertEqual(lost['status'],'missing')
            self.assertNotIn('prompt_id',lost);self.assertEqual(lost['missing_prompt_id'],job['prompt_id'])
            with self.assertRaises(comfy.SubmissionUnknown):await generator.raw_image(None,'lost_frame',p['id'],'woman')
            self.assertFalse(self.graphs);images.ig.allow_resubmit(self.store,'lost_frame')
            result=await generator.raw_image(None,'lost_frame',p['id'],'woman')
        self.assertEqual(result,self.png);self.assertEqual(len(self.graphs),1);self.assertEqual(self.image_calls,0)
        retried=self.store.get('image_job','lost_frame');self.assertEqual(retried['attempt'],1)
        self.assertEqual(retried['graph']['sample']['inputs']['seed'],job['graph']['sample']['inputs']['seed'])
    async def test_failed_review_candidate_recovers_next_image_without_resetting_review_count(self):
        self.local();p=self.project();identity='review_frame';cfg=self.engine.config({'settings':{}})
        cfg.update(review_image_enabled=True,review_image_attempts=2,review_image_exhausted='pause')
        self.saved_image_job(identity+'_q2',p['id'],output=True)
        review=importlib.import_module('h3ad_test.review');reviewer=review.Reviewer(self.store,self.files,cfg,None)
        folder=reviewer.folder(p['id'],'image_'+identity);old=folder/'old_ng.png';old.write_bytes(self.png)
        reviewer.save(folder/'state.json',{'attempts':[{'attempt':1,'path':str(old),'seed':'old',
                           'verdict':{'passed':False,'reasons':['wrong identity'],'summary':'NG'}}]})
        judge=AsyncMock(return_value={'passed':True,'reasons':[],'summary':'OK'})
        async with aiohttp.ClientSession() as session:
            generator=images.ig.ImageGenerator(self.store,self.files,cfg,session,self.engine.render_lock)
            generator.comfy.MISSING_GRACE_SECONDS=0;generator.comfy.config['poll_seconds']=0
            with patch.object(review.Reviewer,'judge',judge):
                result=await generator.image(None,identity,p['id'],'woman',[])
        self.assertEqual(result,self.png);self.assertFalse(self.graphs);self.assertEqual(judge.await_count,1)
        quality=self.store.get('quality_asset',identity);self.assertEqual(quality['attempts'],2)
        self.assertFalse(quality['adopted_ng']);self.assertEqual(quality['seed'],'original-seed')
    def saved_video_clip(self,p,output=False):
        clip={**self.plan_result()['segments'][0],'status':'submitted','seed':1234,'generation':1,
              'prompt_en':'saved prompt','prompt_zh':'原提示词','job_id':'marker_video','prompt_id':'lost_video',
              'api_graph':{'20':{'class_type':'SaveVideo','inputs':{'filename_prefix':'saved'}}},
              'output_prefix':domain.PREFIX+'/projects/'+p['id']+'/saved_clip',
              'output_node_id':'20','submission_unknown':False}
        self.engine.set(p['id'],clips=[clip])
        if output:
            path=self.files.output/(clip['output_prefix']+'_00001_.mp4');path.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(self.fixture,path)
        return clip
    async def test_missing_video_recovers_and_probes_saved_output_without_new_render(self):
        p=self.project();original=self.saved_video_clip(p,True);cfg=self.engine.config({'settings':{}})
        async with aiohttp.ClientSession() as session:
            client=comfy.ComfyClient(cfg,session);client.MISSING_GRACE_SECONDS=0;cfg['poll_seconds']=0
            await self.engine.render_clip(p['id'],0,client,cfg)
        clip=self.store.get('project',p['id'])['clips'][0]
        self.assertTrue(self.files.output_path(clip['output']).is_file());self.assertTrue(clip['meta']['audio'])
        self.assertEqual(clip['seed'],original['seed']);self.assertEqual(clip['prompt_en'],original['prompt_en'])
        self.assertFalse(self.graphs);self.assertEqual(clip['status'],'complete')
    async def test_missing_video_stops_without_spending_retry_budget_or_posting(self):
        p=self.project();original=self.saved_video_clip(p);cfg=self.engine.config({'settings':{}})
        cfg.update(retry_limit=3,poll_seconds=0)
        async with aiohttp.ClientSession() as session:
            client=comfy.ComfyClient(cfg,session);client.MISSING_GRACE_SECONDS=0
            with self.assertRaises(comfy.TaskMissing):await self.engine.render_with_retries(p['id'],0,client,cfg)
            with self.assertRaises(comfy.SubmissionUnknown):await self.engine.render_with_retries(p['id'],0,client,cfg)
        clip=self.store.get('project',p['id'])['clips'][0];self.assertTrue(clip['submission_unknown'])
        self.assertIsNone(clip['prompt_id']);self.assertEqual(clip['missing_prompt_id'],original['prompt_id'])
        self.assertFalse(clip.get('retry_count'));self.assertFalse(self.graphs)
    async def test_in_flight_api_is_exportable_before_reply_and_remains_one_request(self):
        p=self.project();entered=asyncio.Event();release=asyncio.Event()
        async def gated_result(request):
            entered.set();await release.wait();return web.json_response({'ok':True})
        app=web.Application();app.router.add_post('/pending',gated_result)
        runner=web.AppRunner(app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
        port=site._server.sockets[0].getsockname()[1]
        try:
            async with aiohttp.ClientSession() as session:
                client=providers.AIClient(self.store.settings(),session)
                with telemetry.scope(self.store,'project',p['id']):
                    task=asyncio.create_task(client._request(f'http://127.0.0.1:{port}/pending','mock',{'model':'mock'}))
                try:
                    await asyncio.wait_for(entered.wait(),3)
                    report=diagnostics.export(self.store,'project',p['id'])
                    self.assertEqual(report['software_version'],VERSION)
                    self.assertEqual(len(report['requests']),1);self.assertEqual(report['requests'][0]['status'],'requesting')
                    self.assertNotIn('mock',json.dumps(report['requests'][0].get('Authorization','')))
                finally:release.set()
                self.assertEqual(await asyncio.wait_for(task,3),{'ok':True})
                self.assertEqual(len(diagnostics.export(self.store,'project',p['id'])['requests']),1)
        finally:await runner.cleanup()
    async def test_runtime_version_endpoint_reads_loaded_python_version(self):
        application=integration.routes.Application(self.store.root,self.files.input,self.files.output,self.url)
        from aiohttp.test_utils import make_mocked_request
        request=make_mocked_request('GET','/h3_autodrama_v1/api/version',match_info={'path':'api/version'})
        response=await application.handle(request)
        self.assertEqual(response.status,200);self.assertEqual(json.loads(response.text)['software_version'],VERSION)
        self.assertEqual(response.headers['Cache-Control'],'no-store')


class DiagnosticOwnershipTests(unittest.TestCase):
    def test_export_and_cleanup_keep_other_owners_and_redact_keys(self):
        with tempfile.TemporaryDirectory() as folder:
            store=Store(Path(folder)/'data');files=Files(Path(folder)/'input',Path(folder)/'output')
            a=store.create_project({'script':'甲'});b=store.create_project({'script':'乙'})
            store.save_settings({'comfy_api_key':'private-secret'})
            for p in (a,b):
                store.put('comfy_wait',p['id'],{'id':p['id'],'owner_kind':'project','owner_id':p['id'],'error':'private-secret failed'})
                store.put('image_job','image_'+p['id'],{'id':'image_'+p['id'],'owner_id':p['id'],'status':'missing','graph':{'secret':'private-secret'}})
            report=diagnostics.export(store,'project',a['id'])
            self.assertEqual(len(report['comfy_waits']),1);self.assertEqual(len(report['local_image_jobs']),1)
            self.assertNotIn('private-secret',json.dumps(report));self.assertNotIn('graph',report['local_image_jobs'][0])
            engine=integration.Engine(store,files,ROOT,'http://127.0.0.1:8188')
            manager=importlib.import_module('h3ad_test.management').RecordsManager(engine,importlib.import_module('h3ad_test.series').SeriesManager(engine))
            preview=manager.preview('project',a['id']);manager.delete('project',a['id'],{'review_token':preview['review_token'],'delete_files':False})
            self.assertEqual([row['id'] for row in store.list('comfy_wait')],[b['id']])


if __name__=='__main__':unittest.main()
