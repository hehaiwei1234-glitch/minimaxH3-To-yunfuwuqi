from __future__ import annotations

import asyncio
import copy
import importlib
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import aiohttp
from aiohttp import web
from PIL import Image

from test_core import ROOT, Store, Files
from test_workflows import fixture, w
import test_image_series as image_tests
from test_image_series import image_fixture, iw
from types import SimpleNamespace
Pipeline = SimpleNamespace(**{name: getattr(image_tests.NewPipelineTests, name) for name in (
    "queue", "history", "responses", "chat", "image", "prompt", "object_info", "local", "series", "finish_series", "asyncSetUp", "asyncTearDown", "ai_result")})

Engine = importlib.import_module('h3ad_test.engine').Engine
SeriesManager = importlib.import_module('h3ad_test.series').SeriesManager
management = importlib.import_module('h3ad_test.management')
routes = importlib.import_module('h3ad_test.routes')


class BatchAndDeletionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.dir = Path(self.temp.name)
        self.store = Store(self.dir / 'data')
        self.files = Files(self.dir / 'input', self.dir / 'output')
        self.engine = Engine(self.store, self.files, ROOT, 'http://127.0.0.1:8188')
        self.series = SeriesManager(self.engine)
        self.manage = management.RecordsManager(self.engine, self.series)
        self.workflow = w.save(self.store, fixture())
        buffer = io.BytesIO()
        Image.new('RGB', (32, 32), 'red').save(buffer, 'PNG')
        self.png = buffer.getvalue()
        self.actor = self.files.write_asset(self.store, '林悦 正面.png', self.png,
                    {'label': '林悦', 'role': 'character', 'description': '黑发白衣'})

    def tearDown(self):
        self.temp.cleanup()

    def finished(self, count=2):
        s = self.series.create({'title': '夜归人', 'text': '\n'.join('林悦：你好。' for _ in range(count)),
                'input_type': 'script', 'episode_count': count, 'target_episode_seconds': 8,
                'workflow_id': self.workflow['id'], 'asset_ids': [self.actor['id']]})
        s['plan'] = {'style': '冷灰写实', 'shared_assets': [],
                     'episodes': [{'title': str(i + 1), 'script': '林悦：你好。', 'batch_id': 'initial'} for i in range(count)]}
        self.store.put('series', s['id'], s)
        self.series.create_children(s['id'])
        s = self.series.record(s['id'])
        for pid in s['project_ids']:
            self.engine.set(pid, status='complete')
        self.series.set(s['id'], status='complete')
        return self.series.record(s['id'])

    def append_body(self, s, **changes):
        return {'text': '林悦：我回来了。', 'input_type': 'script', 'episode_count': 1,
                'target_episode_seconds': 8, 'expected_revision': s['revision'],
                'request_id': 'append-one', **changes}

    def test_append_keeps_actor_ids_numbering_and_old_graphs(self):
        s = self.finished()
        before = [self.store.get('project', p) for p in s['project_ids']]
        result = self.series.append(s['id'], self.append_body(s))
        self.assertEqual(result['asset_ids'], s['asset_ids'])
        self.assertEqual(result['batches'][-1]['start_index'], 2)
        self.assertEqual(result['batches'][-1]['workflow_snapshot']['graph'], self.workflow['graph'])
        self.assertEqual(before, [self.store.get('project', p) for p in s['project_ids']])
        self.assertEqual(self.series.public(s['id'])['next_episode_number'], 3)

    def test_duplicate_append_is_idempotent_even_after_start_and_rejects_changed_body(self):
        s = self.finished(); body = self.append_body(s)
        first = self.series.append(s['id'], body)
        self.series.set(s['id'], status='running')
        second = self.series.append(s['id'], body)
        self.assertEqual(len(second['batches']), 2)
        self.assertEqual(first['batches'][-1]['id'], second['batches'][-1]['id'])
        with self.assertRaisesRegex(ValueError, '内容已经改变'):
            self.series.append(s['id'], {**body, 'text': '另一段'})

    def test_stale_revision_and_unfinished_previous_batch_do_not_append(self):
        s = self.finished()
        with self.assertRaisesRegex(ValueError, '内容已改变'):
            self.series.append(s['id'], self.append_body(s, expected_revision=0))
        self.engine.set(s['project_ids'][-1], status='paused')
        with self.assertRaisesRegex(ValueError, '完成当前批次'):
            self.series.append(s['id'], self.append_body(s))
        self.assertEqual(len(self.series.record(s['id'])['batches']), 1)

    def test_old_series_upgrades_without_rebuilding_children(self):
        s = self.finished()
        for key in ('batches', 'revision', 'removed_episodes', 'continuity_summary', 'memory_through'):
            s.pop(key)
        self.store.put('series', s['id'], s)
        updated = self.series.record(s['id'])
        self.series.append(s['id'], self.append_body(updated))
        self.assertEqual(self.series.record(s['id'])['project_ids'], s['project_ids'])
        self.assertEqual(len(self.store.list('project')), 2)

    def test_batch_limit_is_per_batch_and_total_can_exceed_100(self):
        s = self.finished(100)
        result = self.series.append(s['id'], self.append_body(s, episode_count=20))
        self.assertEqual(result['batches'][-1]['start_index'], 100)
        self.assertEqual(self.series.public(s['id'])['next_episode_number'], 101)
        with self.assertRaisesRegex(ValueError, '0至100'):
            self.series.append(s['id'], self.append_body(result, request_id='next', episode_count=101))

    def test_unstarted_script_changes_both_series_and_project_atomically(self):
        s = self.finished(); pid = s['project_ids'][-1]
        self.engine.set(pid, status='draft')
        result = self.series.edit_script(s['id'], pid, {'script': '林悦：修改台词。', 'expected_revision': 1})
        self.assertEqual(result['script'], '林悦：修改台词。')
        self.assertEqual(self.series.record(s['id'])['plan']['episodes'][-1]['script'], result['script'])
        with self.assertRaisesRegex(ValueError, '已被修改'):
            self.series.edit_script(s['id'], pid, {'script': '覆盖', 'expected_revision': 1})
        self.engine.set(pid, plan={'segments': []})
        with self.assertRaisesRegex(ValueError, '已开始准备'):
            self.series.edit_script(s['id'], pid, {'script': '覆盖', 'expected_revision': 2})

    def test_active_series_prevents_script_changes_and_archive(self):
        s = self.finished(); pid = s['project_ids'][-1]
        self.engine.set(pid, status='draft'); self.series.set(s['id'], status='running')
        with self.assertRaises(ValueError):
            self.series.edit_script(s['id'], pid, {'script': '修改', 'expected_revision': 1})
        with self.assertRaises(ValueError): self.manage.archive('project', pid, True)
        with self.assertRaises(ValueError): self.manage.preview('series', s['id'])

    def test_archive_and_restore_series_preserves_individually_archived_child(self):
        s = self.finished(); a, b = s['project_ids']
        self.manage.archive('project', a, True)
        self.manage.archive('series', s['id'], True)
        self.assertTrue(self.store.get('project', b)['archived'])
        self.manage.archive('series', s['id'], False)
        self.assertTrue(self.store.get('project', a)['archived'])
        self.assertFalse(self.store.get('project', b)['archived'])

    def test_shared_asset_deletion_is_blocked_even_if_parent_archived(self):
        s = self.finished(); self.manage.archive('series', s['id'], True)
        with self.assertRaisesRegex(ValueError, '仍被使用'):
            self.manage.preview('asset', self.actor['id'])
        self.assertTrue(self.files.asset_path(self.actor).exists())

    def project_file(self, p, name='镜头_v1.mp4'):
        path = self.files.project_dir(p['id']) / name; path.write_bytes(b'owned video')
        return path

    def test_project_cleanup_keeps_shared_actor_original_and_other_output(self):
        s = self.finished(); pid = s['project_ids'][0]; p = self.store.get('project', pid)
        owned = self.project_file(p); other = self.files.output / '原有视频.mp4'; other.write_bytes(b'keep')
        frame = self.files.write_asset(self.store, '开场图.png', self.png, {'generated': True}, id='frame_one')
        self.engine.set(pid, clips=[{'status': 'complete', 'output': self.files.descriptor(owned), 'frame_asset_id': frame['id']}])
        image = self.files.output / 'h3_autodrama_v1/images/frame_one_a0_00001_.png'
        image.parent.mkdir(parents=True, exist_ok=True); image.write_bytes(self.png)
        self.store.put('image_job', 'frame_one', {'id': 'frame_one', 'owner_id': pid, 'status': 'complete',
                       'output_prefix': 'h3_autodrama_v1/images/frame_one_a0', 'created_at': 0})
        review = self.manage.preview('project', pid)
        self.assertGreaterEqual(review['files'], 3)
        self.manage.delete('project', pid, {'review_token': review['review_token'], 'delete_files': True})
        self.assertFalse(owned.exists()); self.assertFalse(image.exists()); self.assertFalse(self.files.asset_path(frame).exists())
        self.assertTrue(other.exists()); self.assertTrue(self.files.asset_path(self.actor).exists())
        self.series.create_children(s['id'])
        self.assertNotIn(pid, self.series.record(s['id'])['project_ids'])
        self.assertEqual(self.series.public(s['id'])['episodes'][0]['status'], 'deleted')
        self.assertEqual(self.series.public(s['id'])['next_episode_number'], 3)

    def test_delete_whole_series_preserves_material_used_by_another_series(self):
        s = self.finished()
        actor = self.files.write_asset(self.store, '自动角色.png', self.png, {'generated': True})
        self.series.set(s['id'], asset_ids=[actor['id']])
        other = self.series.create({'text': '你好', 'workflow_id': self.workflow['id'], 'asset_ids': [actor['id']]})
        review = self.manage.preview('series', s['id'])
        self.assertEqual(review['shared_assets_kept'], 1)
        self.manage.delete('series', s['id'], {'review_token': review['review_token'], 'delete_files': True})
        self.assertTrue(self.files.asset_path(actor).exists())
        self.assertEqual(self.store.get('series', other['id'])['asset_ids'], [actor['id']])
        self.assertFalse(any(p.get('series_id') == s['id'] for p in self.store.list('project')))

    def test_unchecked_cleanup_preserves_files_and_assets(self):
        p = self.store.create_project({'script': '你好', 'workflow_id': self.workflow['id']})
        path = self.project_file(p); review = self.manage.preview('project', p['id'])
        self.manage.delete('project', p['id'], {'review_token': review['review_token'], 'delete_files': False})
        self.assertTrue(path.exists())

    def test_used_output_file_is_preserved_without_relying_only_on_project_id(self):
        p = self.store.create_project({'script': '你好', 'workflow_id': self.workflow['id']})
        path = self.project_file(p)
        other = self.store.create_project({'script': '再见', 'workflow_id': self.workflow['id']})
        self.engine.set(other['id'], final=self.files.descriptor(path))
        review = self.manage.preview('project', p['id'])
        self.assertEqual(review['files'], 0); self.assertEqual(review['files_kept'], 1)
        self.manage.delete('project', p['id'], {'review_token': review['review_token'], 'delete_files': True})
        self.assertTrue(path.exists())

    def test_output_reference_inside_media_json_or_comfy_annotation_is_protected(self):
        p=self.store.create_project({'script':'你好','workflow_id':self.workflow['id']})
        path=self.project_file(p)
        other=self.store.create_project({'script':'再见','workflow_id':self.workflow['id']})
        self.engine.set(other['id'],clips=[{'api_graph':{'media':{'inputs':{'batch_media_json':json.dumps({'videos':[str(path)+' [output]']})}}}}])
        review=self.manage.preview('project',p['id'])
        self.assertEqual(review['files'],0);self.assertEqual(review['files_kept'],1)

    def test_stale_delete_review_cannot_remove_files(self):
        p = self.store.create_project({'script': '你好', 'workflow_id': self.workflow['id']})
        path = self.project_file(p); review = self.manage.preview('project', p['id'])
        path.write_bytes(b'changed output file')
        with self.assertRaisesRegex(ValueError, '已变化'):
            self.manage.delete('project', p['id'], {'review_token': review['review_token'], 'delete_files': True})
        self.assertTrue(path.exists()); self.assertEqual(self.store.get('project', p['id'])['id'], p['id'])

    def test_file_move_failure_rolls_back_every_staged_file_and_keeps_records(self):
        p = self.store.create_project({'script': '你好', 'workflow_id': self.workflow['id']})
        paths = [self.project_file(p, name) for name in ('a.mp4', 'b.mp4')]
        review = self.manage.preview('project', p['id']); original = os.replace; calls = 0
        def rename(a, b):
            nonlocal calls
            calls += 1
            if calls == 2: raise PermissionError('file in use')
            return original(a, b)
        with patch.object(management.os, 'replace', rename):
            with self.assertRaises(PermissionError):
                self.manage.delete('project', p['id'], {'review_token': review['review_token'], 'delete_files': True})
        self.assertTrue(all(p.exists() for p in paths))
        self.assertEqual(self.store.get('project', p['id'])['id'], p['id'])

    def test_symlink_cannot_lead_cleanup_outside_owned_directory(self):
        p = self.store.create_project({'script': '你好', 'workflow_id': self.workflow['id']})
        folder = self.files.project_dir(p['id']); outside = self.dir / 'models'
        outside.mkdir(); model = outside / 'do_not_delete.bin'; model.write_bytes(b'model')
        (folder / 'linked-models').symlink_to(outside, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, '软链接'):
            self.manage.preview('project', p['id'])
        self.assertTrue(model.exists())

    def test_unknown_submissions_block_cleanup_until_reconciled(self):
        p = self.store.create_project({'script': '你好', 'workflow_id': self.workflow['id']})
        self.engine.set(p['id'], status='paused', clips=[{'status': 'submitting', 'submission_unknown': True}])
        with self.assertRaisesRegex(ValueError, '结果不明'):
            self.manage.preview('project', p['id'])

    def test_template_deletion_does_not_change_project_snapshot(self):
        p = self.store.create_project({'script': '你好', 'workflow_id': self.workflow['id']})
        before = self.store.get('project', p['id'])['workflow_snapshot']
        review = self.manage.preview('workflow', self.workflow['id'])
        self.manage.delete('workflow', self.workflow['id'], {'review_token': review['review_token'], 'delete_files': False})
        self.assertEqual(self.store.get('project', p['id'])['workflow_snapshot'], before)

    def test_archiving_selected_image_template_clears_only_new_default(self):
        base = iw.save(self.store, image_fixture()); ref = iw.save(self.store, image_fixture('batch'))
        self.store.save_settings({'image_provider': 'local', 'image_workflow_id': base['id'], 'image_reference_workflow_id': ref['id']})
        s = self.finished(); before = s['image_workflow_snapshots']
        self.manage.archive('image_workflow', base['id'], True)
        self.assertEqual(self.store.settings()['image_workflow_id'], '')
        self.assertEqual(self.series.record(s['id'])['image_workflow_snapshots'], before)
        appended = self.series.append(s['id'], self.append_body(s))
        self.assertEqual(appended['batches'][-1]['image_workflow_snapshots'], before)


class BatchPipelineTests(unittest.IsolatedAsyncioTestCase):
    queue=Pipeline.queue;history=Pipeline.history;responses=Pipeline.responses;chat=Pipeline.chat;image=Pipeline.image
    prompt=Pipeline.prompt;object_info=Pipeline.object_info;local=Pipeline.local;series=Pipeline.series;finish_series=Pipeline.finish_series

    async def asyncSetUp(self):
        self.memory_requests=[];self.append_plan_requests=[];self.memory_error=False
        await Pipeline.asyncSetUp(self)

    async def asyncTearDown(self):
        await Pipeline.asyncTearDown(self)

    async def responses(self,request):
        data=await request.json()
        if self.memory_error and '连续剧情记录员' in data.get('instructions',''):
            return web.json_response({'error':{'message':'simulated memory network error'}},status=503)
        return await Pipeline.responses(self,request)

    def ai_result(self,instructions,prompt):
        data=json.loads(prompt.split('\n修正上一次JSON',1)[0])
        if '连续剧情记录员' in instructions:
            self.memory_requests.append(data)
            if self.memory_error:raise RuntimeError('simulated memory network error')
            return {'summary':'女主已经回家告别，仍穿白衣，接下来去庭院。'}
        if '整剧策划' in instructions and data.get('next_episode_number',1)>1:
            self.append_plan_requests.append(data)
            if data['input_type']=='outline':
                return {'style':'another style','shared_assets':[], 'episodes':[
                    {'title':'续篇甲','outline':'女主说我回来了。'},{'title':'续篇乙','outline':'女主说晚安。'}]}
            return {'style':'an unwanted new style','shared_assets':[],
                    'episodes':[{'title':'续篇甲','end_unit':2},{'title':'续篇乙','end_unit':len(data['text_units'])}]}
        return Pipeline.ai_result(self,instructions,prompt)

    def append(self,s):
        return self.manager.append(s['id'],{'text':'女主：我回来了。\n女主：灯还亮着。\n女主：一起走吧。\n女主：好。',
            'episode_count':2,'input_type':'script','target_episode_seconds':8,'expected_revision':s['revision'],'request_id':'batch-2'})

    async def test_two_batches_finish_four_episodes_reusing_all_original_character_and_scene_images(self):
        self.local();first=await self.finish_series(self.series()['id'])
        originals=copy.deepcopy(first['generated_assets']);old_outputs=[self.store.get('project',pid)['final'] for pid in first['project_ids']]
        self.append(first);completed=await self.finish_series(first['id'])
        self.assertEqual(completed['status'],'complete',completed['error'])
        self.assertEqual(len(completed['project_ids']),4);self.assertEqual(completed['generated_assets'],originals)
        self.assertEqual(len(self.memory_requests),1);self.assertEqual(self.image_calls,0)
        self.assertEqual(completed['plan']['style'],first['plan']['style'])
        self.assertEqual(self.append_plan_requests[0]['next_episode_number'],3)
        self.assertIn('白衣',self.append_plan_requests[0]['previous_story_summary'])
        self.assertEqual(old_outputs,[self.store.get('project',pid)['final'] for pid in first['project_ids']])
        refs=[self.store.get('asset',aid)['relative_path'] for aid in originals.values()]
        from test_core import assert_state_references
        for graph in self.graphs[10:]:
            if 'out' in graph:assert_state_references(self,json.loads(graph['ref']['inputs']['images_json']),refs)
        self.assertIn('第3集',self.store.get('project',completed['project_ids'][2])['title'])
        self.assertIn('第4集',self.store.get('project',completed['project_ids'][3])['title'])

    async def test_memory_failure_keeps_prior_videos_and_pending_batch_can_resume(self):
        self.local();first=await self.finish_series(self.series()['id']);self.append(first)
        self.memory_error=True;failed=await self.finish_series(first['id'])
        self.assertEqual(failed['status'],'partial');self.assertTrue(self.manager.public(failed['id'])['can_resume']);self.assertEqual(len(self.graphs),10)
        self.assertEqual(len(failed['project_ids']),2)
        self.memory_error=False;completed=await self.finish_series(first['id'])
        self.assertEqual(completed['status'],'complete',completed['error']);self.assertEqual(len(completed['project_ids']),4)
        self.assertEqual(len(self.graphs),18)

    async def test_followup_outline_can_be_written_after_a_script_batch(self):
        self.local();first=await self.finish_series(self.series()['id'])
        self.manager.append(first['id'],{'text':'女主回来，与此前一样的房间和人物，随后道别。',
            'input_type':'outline','episode_count':2,'target_episode_seconds':8,
            'expected_revision':first['revision'],'request_id':'outline-2'})
        completed=await self.finish_series(first['id'])
        self.assertEqual(completed['status'],'complete',completed['error'])
        self.assertEqual(len(completed['project_ids']),4);self.assertEqual(self.writer_calls,2)
        self.assertTrue(all(self.store.get('project',pid)['script'] for pid in completed['project_ids'][2:]))

    async def test_append_resume_after_process_restart_keeps_ids_and_memory(self):
        self.local();first=await self.finish_series(self.series()['id']);self.append(first)
        first_new_done=asyncio.Event();release=asyncio.Event();old_run=self.engine.run
        async def gate(pid):
            await old_run(pid)
            if pid not in first['project_ids'] and not first_new_done.is_set():
                first_new_done.set();await release.wait()
        with patch.object(self.engine,'run',gate):
            self.manager.start(first['id']);await asyncio.wait_for(first_new_done.wait(),35)
            self.manager.pause(first['id']);release.set();await asyncio.wait_for(self.manager.tasks[first['id']],10)
        ids=self.store.get('series',first['id'])['project_ids'][:]
        self.engine=Engine(self.store,self.files,ROOT,self.url);self.manager=SeriesManager(self.engine)
        completed=await self.finish_series(first['id'])
        self.assertEqual(completed['status'],'complete',completed['error'])
        self.assertEqual(completed['project_ids'],ids);self.assertEqual(len(self.memory_requests),1)
        self.assertEqual(len(self.store.list('project')),4);self.assertEqual(len(self.graphs),18)

    async def test_http_archiving_filter_delete_preview_and_script_edit_have_real_routes(self):
        app=routes.Application(self.store.root,self.files.input,self.files.output,self.url)
        project=app.store.create_project({'script':'女主：你好。','workflow_id':self.video['id']})
        host=web.Application();host.router.add_route('*','/h3_autodrama_v1/{path:.*}',app.handle)
        runner=web.AppRunner(host);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
        port=site._server.sockets[0].getsockname()[1];url=f'http://127.0.0.1:{port}/h3_autodrama_v1/api/'
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url+f'projects/{project["id"]}/script',json={'script':'女主：改好了。','expected_revision':1}) as r:
                    self.assertEqual(r.status,200,await r.text())
                async with session.post(url+f'manage/project/{project["id"]}/archive',json={}) as r:self.assertEqual(r.status,200)
                async with session.get(url+'projects') as r:self.assertEqual(await r.json(),[])
                async with session.get(url+'projects?include_archived=1') as r:self.assertEqual(len(await r.json()),1)
                async with session.post(url+f'manage/project/{project["id"]}/delete-preview',json={}) as r:preview=await r.json();self.assertEqual(r.status,200,preview)
                async with session.post(url+f'manage/project/{project["id"]}/delete',json={'review_token':preview['review_token'],'delete_files':True}) as r:self.assertEqual(r.status,200,await r.text())
                async with session.get(url+'projects?include_archived=1') as r:self.assertEqual(await r.json(),[])
        finally:await runner.cleanup()
