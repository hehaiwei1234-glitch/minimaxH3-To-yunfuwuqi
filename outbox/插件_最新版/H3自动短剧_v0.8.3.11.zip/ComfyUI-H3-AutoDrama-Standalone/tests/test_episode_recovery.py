"""Real HTTP/FFmpeg coverage for malformed storyboards and isolated episodes."""
import asyncio
import copy
import importlib
import json
import types
import unittest
import aiohttp
from unittest.mock import AsyncMock
from aiohttp import web
from test_core import ROOT, domain
import test_image_series as image_pipeline

Pipeline=types.SimpleNamespace(**{name:getattr(image_pipeline.NewPipelineTests,name) for name in
    ("queue","history","chat","image","prompt","object_info","local","series","finish_series","asyncSetUp","asyncTearDown","responses","ai_result")})

Engine = importlib.import_module('h3ad_test.engine').Engine
SeriesManager = importlib.import_module('h3ad_test.series').SeriesManager
providers = importlib.import_module('h3ad_test.providers')
recovery = importlib.import_module('h3ad_test.episode_recovery')


class FormatRecoveryTests(unittest.IsolatedAsyncioTestCase):
    async def test_invalid_json_repaired_from_raw_and_original_input(self):
        raw='{"segments" ["原台词不能删"]}'
        with self.assertRaises(providers.ContentFormatError) as caught:
            providers.json_object(raw)
        ai=types.SimpleNamespace(config={'retry_limit':0,'format_retry_limit':1},
                text=AsyncMock(side_effect=[caught.exception,{'ok':True}]))
        result=await Engine.checked_text(None,ai,'分镜导演','{"script":"林川：原台词不能删。"}',lambda r:r)
        self.assertEqual(result,{'ok':True})
        self.assertEqual(ai.text.await_count,2)
        sent=json.loads(ai.text.await_args_list[1].args[1])
        self.assertEqual(sent['malformed_response'],raw)
        self.assertIn('原台词不能删',sent['original_request'])
        self.assertIn('保留所有原台词',ai.text.await_args_list[1].args[0])

    async def test_budget_independent_of_http_and_ng_attempts(self):
        ai=types.SimpleNamespace(config={'retry_limit':9,'format_retry_limit':1,
                'review_image_attempts':10,'review_video_attempts':10},
                text=AsyncMock(side_effect=[providers.ContentFormatError('bad')]*2))
        with self.assertRaises(providers.AIFormatExhausted):
            await Engine.checked_text(None,ai,'instructions','request',lambda r:r)
        self.assertEqual(ai.text.await_count,2)

    async def test_zero_budget_still_runs_initial_request_once(self):
        ai=types.SimpleNamespace(config={'retry_limit':5,'format_retry_limit':0},
                text=AsyncMock(side_effect=providers.ContentFormatError('bad')))
        with self.assertRaises(providers.AIFormatExhausted):
            await Engine.checked_text(None,ai,'instructions','request',lambda r:r)
        self.assertEqual(ai.text.await_count,1)

    async def test_network_and_auth_errors_are_not_format_retries(self):
        ai=types.SimpleNamespace(config={'format_retry_limit':5},
                text=AsyncMock(side_effect=providers.APIError('HTTP 401')))
        with self.assertRaises(providers.APIError):
            await Engine.checked_text(None,ai,'instructions','request',lambda r:r)
        self.assertEqual(ai.text.await_count,1)

    async def test_validation_failure_keeps_original_task_and_is_bounded(self):
        ai=types.SimpleNamespace(config={'format_retry_limit':1},text=AsyncMock(return_value={'bad':True}))
        with self.assertRaises(providers.AIFormatExhausted):
            await Engine.checked_text(None,ai,'instructions','original',lambda r:(_ for _ in ()).throw(ValueError('缺少台词')))
        self.assertEqual(ai.text.await_count,2)
        self.assertTrue(ai.text.await_args.args[1].startswith('original'))

    def test_automatic_failures_are_deferred_without_overriding_manual_pause(self):
        p={'series_id':'s','status':'error','error_kind':'ai_content','clips':[]}
        self.assertTrue(recovery.can_defer(p,{}))
        self.assertTrue(recovery.can_defer(p,{'series_continue_on_error':False}))
        self.assertTrue(recovery.can_defer({**p,'error_kind':'runtime'},{}))
        self.assertTrue(recovery.can_defer({**p,'clips':[{'submission_unknown':True}]},{}))
        self.assertFalse(recovery.can_defer({**p,'pause_requested':True},{}))
        self.assertFalse(recovery.can_defer({**p,'archived':True},{}))
        self.assertFalse(recovery.content_failure(ValueError('bad configuration')))
        self.assertTrue(recovery.content_failure(providers.AIFormatExhausted('bad fields')))

    def test_settings_upgrade_has_bounded_independent_defaults(self):
        cfg=domain.validate_settings({'retry_limit':0})
        self.assertEqual(cfg['format_retry_limit'],2)
        self.assertTrue(cfg['series_continue_on_error'])
        for value in (-1,11):
            with self.assertRaises(ValueError):domain.validate_settings({'format_retry_limit':value})
        with self.assertRaises(ValueError):domain.validate_settings({'series_continue_on_error':'yes'})

    async def test_real_provider_parsers_recover_for_chat_and_responses(self):
        raw='{"ok" true}'
        for provider in ('deepseek','openai'):
            with self.subTest(provider=provider):
                ai=providers.AIClient({**domain.DEFAULTS,'provider':provider,'format_retry_limit':1},None)
                def response(text):
                    return {'choices':[{'finish_reason':'stop','message':{'content':text}}]} if provider=='deepseek' else {
                        'output':[{'content':[{'type':'output_text','text':text}]}]}
                ai._request=AsyncMock(side_effect=[response(raw),response('{"ok":true}')])
                result=await Engine.checked_text(None,ai,'instructions','request',lambda r:r)
                self.assertTrue(result['ok']);self.assertEqual(ai._request.await_count,2)
                payload=ai._request.await_args_list[0].args[2]
                if provider=='deepseek':self.assertEqual(payload['response_format'],{'type':'json_object'})
                else:self.assertEqual(payload['text']['format'],{'type':'json_object'})

    def test_truncation_is_content_failure_but_refusal_is_not(self):
        with self.assertRaises(providers.ContentFormatError):
            providers.chat_text({'choices':[{'finish_reason':'length','message':{'content':'{"ok":'}}]})
        with self.assertRaises(providers.APIError) as caught:
            providers.chat_text({'choices':[{'finish_reason':'content_filter','message':{}}]})
        self.assertFalse(recovery.content_failure(caught.exception))


class EpisodeRecoveryTests(unittest.IsolatedAsyncioTestCase):
    queue=Pipeline.queue; history=Pipeline.history
    chat=Pipeline.chat; image=Pipeline.image
    prompt=Pipeline.prompt; object_info=Pipeline.object_info
    local=Pipeline.local; series=Pipeline.series
    finish_series=Pipeline.finish_series

    async def asyncSetUp(self):
        await Pipeline.asyncSetUp(self)
        self.store.save_settings({'format_retry_limit':1})
        self.failure='json';self.bad_remaining=None
        self.bad_calls=0;self.memory_inputs=[];self.planner_inputs=[];self.bad_line='你好。'
        self.local()

    async def asyncTearDown(self):
        await Pipeline.asyncTearDown(self)

    def original_request(self,text):
        data=json.loads(text.split('\n修正上一次JSON',1)[0])
        return json.loads(data['original_request']) if 'original_request' in data else data

    async def responses(self,request):
        data=await request.json();instructions=data['instructions']
        text=data['input'][0]['content'][0]['text']
        source=self.original_request(text)
        bad='分镜导演' in instructions and self.bad_line in source.get('script','')
        if bad and self.failure and (self.bad_remaining is None or self.bad_remaining>0):
            self.bad_calls+=1
            if self.bad_remaining is not None:self.bad_remaining-=1
            if self.failure=='auth':
                return web.json_response({'error':{'message':'unauthorized'}},status=401)
            value='{"style" "realistic","segments":[]}' if self.failure=='json' else json.dumps({'segments':None})
            return web.json_response({'output':[{'content':[{'type':'output_text','text':value}]}]})
        return await Pipeline.responses(self,request)

    def ai_result(self,instructions,prompt):
        data=self.original_request(prompt)
        if '连续剧情记录员' in instructions:
            self.memory_inputs.append(data)
            return {'summary':'女主按既定剧情告别，所有待补做剧情仍保留。'}
        if '整剧策划' in instructions and data.get('next_episode_number',1)>1:
            return {'style':'realistic','shared_assets':[],
                    'episodes':[{'title':'续篇甲','end_unit':2},{'title':'续篇乙','end_unit':len(data['text_units'])}]}
        # The mock director deliberately asks for missing previous-video state;
        # the program must correct that boundary rather than stop episode 18.
        result=Pipeline.ai_result(self,instructions,json.dumps(data,ensure_ascii=False))
        if '分镜导演' in instructions:
            self.planner_inputs.append((instructions,data))
            if data.get('previous_episode_script'):result['segments'][0]['use_previous_episode_state']=True
        return result

    def seventeen_failure(self):
        s=self.series(episode_count=18)
        s.update(asset_ids=[self.asset['id']],plan={'style':'realistic','shared_assets':[],
            'episodes':[{'title':f'原第{i+1}集','script':'女主：以前的剧情。','batch_id':'initial'} for i in range(16)]
                +[{'title':'故障集','script':'女主：你好。\n女主：再见。','batch_id':'initial'},
                  {'title':'继续集','script':'女主：明天见。\n女主：晚安。','batch_id':'initial'}]})
        self.store.put('series',s['id'],s);self.manager.create_children(s['id'])
        s=self.manager.record(s['id'])
        saved=self.files.output/'existing.mp4'
        saved.write_bytes(self.fixture.read_bytes())
        for pid in s['project_ids'][:16]:
            self.engine.set(pid,status='complete',final=self.files.descriptor(saved))
        return s

    async def test_episode17_exhausted_then18_finishes_with_original_story_and_fixed_assets(self):
        s=self.seventeen_failure();old=[self.store.get('project',p) for p in s['project_ids'][:16]]
        result=await self.finish_series(s['id'])
        self.assertEqual(result['status'],'partial',result['error'])
        failed=self.store.get('project',result['project_ids'][16]);following=self.store.get('project',result['project_ids'][17])
        self.assertEqual(failed['status'],'deferred');self.assertEqual(self.bad_calls,2)
        self.assertEqual(following['status'],'complete',following['error'])
        self.assertEqual(following['previous_episode_script'],failed['script'])
        self.assertFalse(following['clips'][0]['use_previous_episode_state'])
        self.assertNotIn('state_reference_id',following['clips'][0])
        self.assertEqual(following['previous_episode_gap']['episode_number'],17)
        self.assertEqual(old,[self.store.get('project',p) for p in s['project_ids'][:16]])
        public=self.manager.public(s['id'])
        self.assertEqual(public['deferred_count'],1);self.assertTrue(public['can_append'])
        self.assertEqual(sum(e['status']=='complete' for e in public['episodes']),17)

    async def test_bad_json_once_recovers_without_deferring(self):
        self.bad_remaining=1
        s=await self.finish_series(self.series()['id'])
        self.assertEqual(s['status'],'complete',s['error'])
        self.assertEqual(self.bad_calls,1)

    async def test_invalid_fields_are_also_local_episode_failures(self):
        self.failure='fields'
        s=await self.finish_series(self.series()['id'])
        self.assertEqual(s['status'],'partial',s['error'])
        self.assertEqual(self.store.get('project',s['project_ids'][0])['status'],'deferred')
        self.assertEqual(self.store.get('project',s['project_ids'][1])['status'],'complete')

    async def test_legacy_disabled_continue_switch_cannot_stop_the_schedule(self):
        self.store.save_settings({'series_continue_on_error':False})
        s=await self.finish_series(self.series()['id'])
        self.assertEqual(s['status'],'partial')
        self.assertEqual(self.store.get('project',s['project_ids'][0])['status'],'deferred')
        self.assertEqual(self.store.get('project',s['project_ids'][1])['status'],'complete')

    async def test_auth_failure_is_not_retried_as_json_and_later_episode_is_attempted(self):
        self.failure='auth'
        s=await self.finish_series(self.series()['id'])
        self.assertEqual(s['status'],'partial');self.assertEqual(self.bad_calls,1)
        self.assertEqual(self.store.get('project',s['project_ids'][0])['error_kind'],'automatic')
        self.assertEqual(self.store.get('project',s['project_ids'][1])['status'],'complete')

    async def test_restart_does_not_repeat_failed_calls_or_render_completed_episode(self):
        s=await self.finish_series(self.series()['id']);graphs=len(self.graphs);calls=self.bad_calls
        self.engine=Engine(self.store,self.files,ROOT,self.url)
        self.manager=SeriesManager(self.engine)
        result=await self.finish_series(s['id'])
        self.assertEqual(result['status'],'partial')
        self.assertEqual(len(self.graphs),graphs);self.assertEqual(self.bad_calls,calls)

    async def test_retry_only_failed_episode_and_keep_following_final(self):
        s=await self.finish_series(self.series()['id']);failed,following=s['project_ids']
        saved=copy.deepcopy(self.store.get('project',following));graphs=len(self.graphs)
        self.failure=None
        self.manager.retry_episode(s['id'],failed)
        with self.assertRaises(ValueError):self.manager.retry_episode(s['id'],failed)
        await asyncio.wait_for(self.manager.tasks[s['id']],35)
        self.assertEqual(self.store.get('project',failed)['status'],'complete')
        self.assertEqual(self.store.get('project',following),saved)
        self.assertEqual(self.store.get('series',s['id'])['status'],'complete')
        self.assertEqual(len([g for g in self.graphs[graphs:] if 'node_20' in g]),2)

    async def test_failed_retry_is_bounded_and_stays_deferred(self):
        s=await self.finish_series(self.series()['id']);failed=s['project_ids'][0];calls=self.bad_calls
        self.manager.retry_episode(s['id'],failed)
        await asyncio.wait_for(self.manager.tasks[s['id']],35)
        self.assertEqual(self.store.get('series',s['id'])['status'],'partial')
        self.assertEqual(self.store.get('project',failed)['status'],'deferred')
        self.assertEqual(self.bad_calls-calls,2)

    async def test_append_after_deferred_episode_keeps_numbering_and_memory(self):
        s=await self.finish_series(self.series()['id']);old=copy.deepcopy(self.store.get('project',s['project_ids'][1]))
        self.manager.append(s['id'],{'text':'女主：我回来了。\n女主：灯还亮着。\n女主：一起走吧。\n女主：好。',
            'episode_count':2,'input_type':'script','target_episode_seconds':8,'expected_revision':s['revision'],'request_id':'next'})
        result=await self.finish_series(s['id'])
        self.assertEqual(result['status'],'partial',result['error'])
        self.assertEqual(len(result['project_ids']),4)
        self.assertEqual(old,self.store.get('project',s['project_ids'][1]))
        self.assertTrue(all(self.store.get('project',p)['status']=='complete' for p in result['project_ids'][2:]))
        self.assertIn('视频待补做',self.memory_inputs[0]['completed_script_excerpt'])
        self.assertIn('你好。',self.memory_inputs[0]['completed_script_excerpt'])

    async def test_user_pause_is_preserved_and_never_marked_as_content_failure(self):
        self.failure=None
        s=self.series();original=self.engine._run
        async def paused(identity):
            self.engine.pause(identity)
            self.engine.set(identity,status='paused',phase='用户暂停',pause_requested=False)
        self.engine._run=paused
        result=await self.finish_series(s['id'])
        self.assertEqual(result['status'],'paused')
        self.assertEqual(self.store.get('project',result['project_ids'][0])['status'],'paused')
        self.engine._run=original

    async def test_prefetch_exhaustion_does_not_double_the_format_budget(self):
        self.bad_line='故障。'
        s=self.series(episode_count=3)
        s.update(asset_ids=[self.asset['id']],plan={'style':'realistic','shared_assets':[],
                'episodes':[{'title':str(i+1),'script':text,'batch_id':'initial'} for i,text in enumerate(
                    ['女主：你好。\n女主：再见。','女主：故障。','女主：明天见。'])]})
        self.store.put('series',s['id'],s)
        result=await self.finish_series(s['id'])
        self.assertEqual(result['status'],'partial',result['error'])
        projects=[self.store.get('project',pid) for pid in result['project_ids']]
        self.assertEqual([p['status'] for p in projects],['complete','deferred','complete'])
        self.assertEqual(self.bad_calls,2)
        self.assertIn('prefetch_error',projects[1])

    async def test_all_bad_episodes_remain_pending_and_allow_append(self):
        self.bad_line=''
        result=await self.finish_series(self.series()['id'])
        self.assertEqual(result['status'],'partial',result['error'])
        self.assertEqual(self.bad_calls,4)
        public=self.manager.public(result['id'])
        self.assertEqual(public['deferred_count'],2)
        self.assertTrue(public['can_append'])
        self.assertFalse(any(e['final'] for e in public['episodes']))

    async def test_both_retry_http_routes_complete_only_the_failed_episode(self):
        routes=importlib.import_module('h3ad_test.routes')
        app=routes.Application(self.store.root,self.files.input,self.files.output,self.url)
        app.engine=self.engine;app.series=self.manager
        host=web.Application();host.router.add_route('*','/h3_autodrama_v1/{path:.*}',app.handle)
        runner=web.AppRunner(host);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
        url=f'http://127.0.0.1:{site._server.sockets[0].getsockname()[1]}/h3_autodrama_v1/api/'
        try:
            for route in ('series','projects'):
                self.failure='json';s=await self.finish_series(self.series()['id']);failed,following=s['project_ids']
                saved=copy.deepcopy(self.store.get('project',following));self.failure=None
                target=f'series/{s["id"]}/episodes/{failed}/retry' if route=='series' else f'projects/{failed}/start'
                async with aiohttp.ClientSession() as session:
                    async with session.post(url+target,json={}) as response:
                        self.assertEqual(response.status,200,await response.text())
                    async with session.post(url+target,json={}) as response:
                        # Series retry is guarded. A duplicate project start is
                        # idempotent and cannot submit another ComfyUI task.
                        self.assertIn(response.status,(200,400))
                await asyncio.wait_for(self.manager.tasks[s['id']],35)
                self.assertEqual(self.store.get('project',failed)['status'],'complete')
                self.assertEqual(saved,self.store.get('project',following))
        finally:await runner.cleanup()
