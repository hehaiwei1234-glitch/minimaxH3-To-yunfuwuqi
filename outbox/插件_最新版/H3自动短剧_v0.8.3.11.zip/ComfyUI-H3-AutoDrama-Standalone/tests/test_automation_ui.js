"use strict";
const assert=require("node:assert/strict");
const fs=require("node:fs");
const path=require("node:path");
const vm=require("node:vm");
const root=path.resolve(__dirname,"..");
const nodes={};
function node(){return {children:[],classList:{remove(){},add(){},toggle(){}},append(child){this.children.push(child)},innerHTML:"",textContent:"",value:""}}
const form=node();form.elements={name:node(),output_node_id:node(),media_mode:node(),duration_mode:node(),seed_mode:node(),tested_by_user:node()};
nodes["#workflow-form"]=form;
const fields=[
 {node:"40",input:"previous_video_name",value_type:"string",value:"",display_value:"",title:"H3 上一段续接",class_type:"H3ContinuePrepare"},
 {node:"34",input:"value",value_type:"boolean",value:true,display_value:"True",title:"启用上一段续接",class_type:"PrimitiveBoolean"},
 {node:"40",input:"overlap_seconds",value_type:"number",value:1,display_value:"1.0",title:"H3 上一段续接",class_type:"H3ContinuePrepare"},
 {node:"40",input:"include_audio",value_type:"boolean",value:true,display_value:"True",title:"H3 上一段续接",class_type:"H3ContinuePrepare"},
 {node:"39",input:"value",value_type:"string",value:"old",display_value:"old",title:"提示词",class_type:"PrimitiveStringMultiline"},
 {node:"38",input:"batch_media_json",value_type:"string",value:"{}",display_value:"{}",title:"H3参考",class_type:"H3ContinueBatchReferenceToVideo"},
 {node:"31",input:"value",value_type:"number",value:8,display_value:"8",title:"时长",class_type:"PrimitiveFloat"},
 {node:"20",input:"filename_prefix",value_type:"string",value:"v",display_value:"v",title:"保存视频",class_type:"SaveVideo"}
];
const automatic_bindings={previous_video:{node:"40",input:"previous_video_name"},continuation_enable:{node:"34",input:"value"},overlap:{node:"40",input:"overlap_seconds"},continue_audio:{node:"40",input:"include_audio"}};
const data={fields,automatic_bindings,nodes:[{id:"20",title:"保存视频",class_type:"SaveVideo"}]};
const context=vm.createContext({console,document:{createElement:node},$:(id)=>nodes[id]??(nodes[id]=node()),esc:String,tab(){},api:async()=>data});
vm.runInContext(fs.readFileSync(path.join(root,"static/workflows.js"),"utf8"),context);
function selected(name){return ["#workflow-required-bindings","#workflow-optional-bindings"].flatMap(id=>nodes[id].children).flatMap(x=>x.children).find(x=>x.name==="binding_"+name).value}
(async()=>{
 const raw='{"seed":9223372036854775825}';
 await context.openWorkflowDraft(raw,"当前工作流");
 assert.equal(selected("continuation_enable"),'["34","value"]');
 assert.equal(selected("previous_video"),'["40","previous_video_name"]');
 assert.equal(selected("overlap"),'["40","overlap_seconds"]');
 assert.match(nodes["#workflow-import-status"].textContent,/已识别续接/);
 assert.equal(vm.runInContext("workflowDraft.source",context),raw);
 console.log("PASS import automatically binds the actual linked continuation switch and preserves raw JSON");
 await context.openWorkflowDraft(raw,"旧模板",{id:"old",version:3,bindings:{},output_node_id:"20",media_mode:"batch",duration_mode:"seconds",seed_mode:"original"});
 assert.equal(selected("continuation_enable"),'["34","value"]');
 assert.match(nodes["#workflow-import-status"].textContent,/将保存为 v4/);
 assert.match(nodes["#workflow-import-status"].textContent,/首段关闭/);
 console.log("PASS reopening an old template fills its missing continuation bindings");
 const html=fs.readFileSync(path.join(root,"static/index.html"),"utf8");
 assert.equal((html.match(/data-timing-fields=/g)||[]).length,3);
 assert.ok(!html.includes('name="target_episode_seconds"'));
 console.log("PASS initial, single and appended forms use independent optional duration switches");
})().catch(error=>{console.error(error);process.exitCode=1});
