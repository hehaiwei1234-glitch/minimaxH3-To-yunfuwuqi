"""Optional local demo; simulated APIs, no GPU and no paid requests."""
import asyncio
import json
import signal
from aiohttp import web
from test_integration import routes
from test_image_series import NewPipelineTests
from test_core import ROOT

class DemoFixture(NewPipelineTests):
    async def object_info(self,request):
        response=await super().object_info(request);info=json.loads(response.text)
        for path in (ROOT/'bundled_image_workflows').glob('*.json'):
            for node in json.loads(path.read_text())['graph'].values():info.setdefault(node['class_type'],{'output_node':node['class_type']=='SaveImage'})
        info['LoadImage']['input']={'required':{'image':[['manual.png']]}}
        return web.json_response(info)

async def main():
    fixture=DemoFixture();await fixture.asyncSetUp()
    app=routes.Application(fixture.store.root,fixture.files.input,fixture.files.output,fixture.url)
    fixture.engine=app.engine
    fixture.manager=app.series
    server=web.Application(client_max_size=512*1024*1024)
    server.router.add_get('/h3_autodrama_v1/',app.handle)
    server.router.add_get('/h3_autodrama_v1/{path:.*}',app.handle)
    server.router.add_post('/h3_autodrama_v1/{path:.*}',app.handle)
    runner=web.AppRunner(server);await runner.setup()
    site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
    port=site._server.sockets[0].getsockname()[1]
    print(f'模拟界面：http://127.0.0.1:{port}/h3_autodrama_v1/',flush=True)
    print('演示整剧：集数填2，剧本按四行填写：女主：你好。 / 女主：再见。 / 女主：明天见。 / 女主：晚安。',flush=True)
    print('所有AI、视频生成接口均为本机模拟，输出为测试色块和测试音；关闭后临时数据删除。',flush=True)
    stop=asyncio.Event();loop=asyncio.get_running_loop()
    for sig in (signal.SIGINT,signal.SIGTERM):
        try:loop.add_signal_handler(sig,stop.set)
        except NotImplementedError:pass
    try:await stop.wait()
    finally:await runner.cleanup();await fixture.asyncTearDown()

if __name__=='__main__':asyncio.run(main())
