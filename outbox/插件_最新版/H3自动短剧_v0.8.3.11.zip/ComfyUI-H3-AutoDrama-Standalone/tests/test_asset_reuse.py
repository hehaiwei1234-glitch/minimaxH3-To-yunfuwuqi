from __future__ import annotations

import copy
import importlib
import json
import unittest

from test_core import ROOT, domain
import test_batches_management as batch_tests

Engine = batch_tests.Engine
SeriesManager = batch_tests.SeriesManager

plans = importlib.import_module('h3ad_test.asset_plans')
series = importlib.import_module('h3ad_test.series')


def item(id, label='林悦', role='character', refs=()):
    return {'id': id, 'role': role, 'label': label, 'description': '固定外观',
            'image_prompt': 'same appearance', 'reference_asset_ids': list(refs)}


class AssetReuseTests(unittest.TestCase):
    def setUp(self):
        self.actor = {'id': 'saved_actor', 'kind': 'image', 'role': 'character', 'label': '林悦'}
        self.room = {'id': 'saved_room', 'kind': 'image', 'role': 'scene', 'label': '客厅'}
        self.assets = [self.actor, self.room]
        self.record = {'text': '林悦：我回来了。', 'input_type': 'script', 'episode_count': 1}

    def validate(self, generated, **options):
        return series.validate_series_plan({'episodes': [{'title': '续篇', 'end_unit': 1}],
                    'shared_assets': generated}, self.record, self.assets, **options)

    def test_repeated_catalog_actual_ids_are_reused_without_new_assets(self):
        result = self.validate([item('saved_actor'), item('saved_actor'), item('saved_room', '客厅', 'scene')])
        self.assertEqual(result['shared_assets'], [])
        self.assertEqual(result['episodes'][0]['script'], self.record['text'])

    def test_same_character_with_new_local_names_resolves_references_to_old_picture(self):
        result = self.validate([item('character_1'), item('character_2'),
                    item('book', '古书', 'prop', ['character_1', 'character_2', 'saved_actor'])], namespace='batch2')
        self.assertEqual(len(result['shared_assets']), 1)
        self.assertEqual(result['shared_assets'][0]['reference_asset_ids'], ['saved_actor'])

    def test_new_assets_shadow_old_logical_aliases_and_keep_chain_of_references(self):
        result = self.validate([item('room', '庭院', 'scene', ['woman']),
                    item('book', '古书', 'prop', ['room'])], namespace='batch2',
                    aliases={'room': 'saved_room', 'woman': 'saved_actor'})
        courtyard, book = result['shared_assets']
        self.assertNotEqual(courtyard['id'], 'room')
        self.assertEqual(courtyard['reference_asset_ids'], ['saved_actor'])
        self.assertEqual(book['reference_asset_ids'], [courtyard['id']])

    def test_identical_new_materials_are_created_once_even_if_ai_lists_two_ids(self):
        result = self.validate([item('book1', '古书', 'prop'), item('book2', '古书', 'prop'),
                    item('table', '木桌', 'prop', ['book2'])], namespace='batch2')
        book, table = result['shared_assets']
        self.assertEqual(len(result['shared_assets']), 2)
        self.assertEqual(table['reference_asset_ids'], [book['id']])

    def test_ambiguous_ids_cannot_replace_existing_character_or_select_wrong_asset(self):
        with self.assertRaisesRegex(ValueError, '不同素材'):
            self.validate([item('same'), item('same', '庭院', 'scene')])
        with self.assertRaisesRegex(ValueError, '属于已有林悦'):
            self.validate([item('saved_actor', '庭院', 'scene')])

    def test_unknown_or_forward_image_references_still_fail_before_generation(self):
        with self.assertRaisesRegex(ValueError, '只可参考'):
            self.validate([item('book', '古书', 'prop', ['missing'])])
        with self.assertRaisesRegex(ValueError, '只可参考'):
            self.validate([item('book', '古书', 'prop', ['table']), item('table', '木桌', 'prop')])

    def test_program_ids_are_bounded_stable_and_separate_batches_without_mutating_reply(self):
        generated = [item('x'*100, '庭院', 'scene')]
        before = copy.deepcopy(generated)
        first = self.validate(generated, namespace='batch2')['shared_assets'][0]['id']
        self.assertEqual(first, self.validate(generated, namespace='batch2')['shared_assets'][0]['id'])
        self.assertNotEqual(first, self.validate(generated, namespace='batch3')['shared_assets'][0]['id'])
        self.assertLessEqual(len(first), 100)
        self.assertEqual(generated, before)

    def test_episode_reuses_existing_images_and_rewrites_both_reference_lists(self):
        source = {'assets_to_create': [item('woman'), item('woman_again'), item('room', '客厅', 'scene')],
            'segments': [{'duration_seconds': 8, 'continuity': 'cut', 'visual_zh': '林悦回家',
                'image_prompt': 'same woman', 'asset_ids': ['woman', 'woman_again', 'room'],
                'image_reference_ids': ['woman', 'saved_actor', 'room']}]}
        result = plans.normalize_asset_plan(source, self.assets, 'assets_to_create')
        domain.validate_plan(result, self.assets, 1)
        self.assertEqual(result['assets_to_create'], [])
        self.assertEqual(result['segments'][0]['asset_ids'], ['saved_actor', 'saved_room'])
        self.assertEqual(result['segments'][0]['image_reference_ids'], ['saved_actor', 'saved_room'])
        self.assertEqual(source['segments'][0]['asset_ids'], ['woman', 'woman_again', 'room'])

    def test_ambiguous_existing_labels_require_actual_id(self):
        self.assets.append({**self.actor, 'id': 'second_actor'})
        with self.assertRaisesRegex(ValueError, '多个同名素材'):
            self.validate([item('woman')])
        self.assertEqual(self.validate([item('saved_actor')])['shared_assets'], [])


class AssetReusePipelineTests(unittest.IsolatedAsyncioTestCase):
    queue = batch_tests.BatchPipelineTests.queue
    history = batch_tests.BatchPipelineTests.history
    responses = batch_tests.BatchPipelineTests.responses
    chat = batch_tests.BatchPipelineTests.chat
    image = batch_tests.BatchPipelineTests.image
    prompt = batch_tests.BatchPipelineTests.prompt
    object_info = batch_tests.BatchPipelineTests.object_info
    local = batch_tests.BatchPipelineTests.local
    series = batch_tests.BatchPipelineTests.series
    finish_series = batch_tests.BatchPipelineTests.finish_series
    append = batch_tests.BatchPipelineTests.append

    async def asyncSetUp(self):
        await batch_tests.BatchPipelineTests.asyncSetUp(self)
        self.add_new_assets = False
        self.append_episode_plan_calls = 0

    async def asyncTearDown(self):
        await batch_tests.BatchPipelineTests.asyncTearDown(self)

    def ai_result(self, instructions, prompt):
        data = json.loads(prompt.split('\n修正上一次JSON', 1)[0])
        result = batch_tests.BatchPipelineTests.ai_result(self, instructions, prompt)
        if '整剧策划' in instructions and data.get('next_episode_number', 1) > 1:
            actor = next(a['id'] for a in data['assets'] if a['role'] == 'character')
            result['shared_assets'] = [item(actor, '女主'), item('woman', '女主'),
                                      item('woman', '女主'), item('room', '房间', 'scene')]
            if self.add_new_assets:
                # "room" was used in the first batch, but the new response
                # uses "courtyard" and references it from the new prop.
                result['shared_assets'] += [item('courtyard', '庭院', 'scene', ['woman']),
                                           item('book', '古书', 'prop', ['courtyard'])]
        if '分镜导演' in instructions and any(t in data['script'] for t in ('我回来了', '一起走吧')):
            self.append_episode_plan_calls += 1
            result['assets_to_create'] = [item('woman', '女主'), item('room', '房间', 'scene')]
            actor = next(a['id'] for a in data['assets'] if a['role'] == 'character')
            for segment in result['segments']:
                segment['asset_ids'] = ['woman', actor, 'room']
                segment['image_reference_ids'] = ['woman', actor, 'room']
        return result

    async def test_v04_failed_append_resumes_in_same_series_without_recreating_assets_or_completed_episodes(self):
        self.local()
        first = await self.finish_series(self.series()['id'])
        self.assertEqual(first['status'], 'complete', first['error'])
        old_projects = {pid: self.store.get('project', pid) for pid in first['project_ids']}
        old_images = {aid: self.files.asset_path(self.store.get('asset', aid)).read_bytes()
                      for aid in first['asset_ids']}
        self.append(first)
        self.manager.set(first['id'], status='error', error='AI格式校验仍未通过：AI生成的素材编号重复。')
        # Simulate the software update/restart while retaining the same data.
        self.engine = Engine(self.store, self.files, ROOT, self.url)
        self.manager = SeriesManager(self.engine)
        completed = await self.finish_series(first['id'])
        self.assertEqual(completed['status'], 'complete', completed['error'])
        self.assertEqual(completed['generated_assets'], first['generated_assets'])
        self.assertEqual(completed['asset_ids'], first['asset_ids'])
        self.assertEqual(len(self.append_plan_requests), 1)
        self.assertEqual(self.append_episode_plan_calls, 2)
        self.assertEqual(len(self.store.list('project')), 4)
        self.assertEqual(len(self.graphs), 18)
        for pid, saved in old_projects.items():
            self.assertEqual(saved, self.store.get('project', pid))
        for aid, blob in old_images.items():
            self.assertEqual(blob, self.files.asset_path(self.store.get('asset', aid)).read_bytes())
        paths = [self.store.get('asset', aid)['relative_path'] for aid in first['asset_ids']]
        from test_core import assert_state_references
        for graph in self.graphs[10:]:
            if 'out' in graph:
                assert_state_references(self,json.loads(graph['ref']['inputs']['images_json']), paths)

    async def test_followup_creates_only_missing_assets_and_keeps_reused_and_new_references_correct(self):
        self.local()
        first = await self.finish_series(self.series()['id'])
        self.add_new_assets = True
        self.append(first)
        completed = await self.finish_series(first['id'])
        self.assertEqual(completed['status'], 'complete', completed['error'])
        self.assertEqual(len(completed['asset_ids']), 4)
        self.assertEqual(len(completed['plan']['shared_assets']), 4)
        courtyard, book = completed['plan']['shared_assets'][2:]
        actor = completed['generated_assets']['woman']
        self.assertEqual(courtyard['reference_asset_ids'], [actor])
        self.assertEqual(book['reference_asset_ids'], [courtyard['id']])
        courtyard_path = self.store.get('asset', completed['generated_assets'][courtyard['id']])['relative_path']
        actor_path = self.store.get('asset', actor)['relative_path']
        self.assertEqual(json.loads(self.graphs[10]['ref']['inputs']['images_json']), [actor_path])
        self.assertEqual(json.loads(self.graphs[11]['ref']['inputs']['images_json']), [courtyard_path])
        self.assertEqual(len(self.append_plan_requests), 1)
        self.assertEqual(len(self.graphs), 20)
