const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../static/production.js'),'utf8');
const escaped=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
const buttons=[];const calls=[];
const context=vm.createContext({esc:escaped,$$:()=>buttons,guarded:fn=>fn,
 current:{id:'project',clips:[{dialogue_check:{signature:'candidate-one'}}]},
 api:async(...args)=>calls.push(args),openProject:async()=>{},notice:()=>{},confirm:()=>true});
vm.runInContext(source,context);
const render=(clip,locked=false)=>context.renderDialogueCheck(clip,0,locked);
assert.equal(render({dialogue:[]}), '');
assert.match(render({dialogue:[{text:'你好。'}]}),/实际对白未核对/);
const clip={dialogue:[{text:'你好。'}],dialogue_check:{status:'incomplete',passed:false,expected:'你好。',transcript:'你<script>',reason:'疑似缺尾'}};
assert.match(render(clip),/我已试听，确认完整/);
assert.match(render(clip),/&lt;script&gt;/);
assert.doesNotMatch(render(clip,true),/data-dialogue-action/);
assert.doesNotMatch(render({...clip,dialogue_check:{...clip.dialogue_check,passed:true,status:'passed'}}),/data-dialogue-action/);
const html=fs.readFileSync(path.join(__dirname,'../static/index.html'),'utf8');
assert.equal((html.match(/name="review_audio"/g)||[]).length,1);
assert.equal((html.match(/name="asr_provider"/g)||[]).length,1);
assert.match(html,/value="qwen"/);assert.match(html,/qwen3-asr-flash/);
const version=fs.readFileSync(path.join(__dirname,'../version.py'),'utf8').match(/VERSION\s*=\s*['"]([^'"]+)['"]/)[1];
assert(html.includes('页面 v'+version),'HTML version matches the delivered backend');
assert.match(html,/value="openai"/);assert.match(html,/gpt-4o-mini-transcribe/);
const adopted={...clip,quality_accepted:true,adopted_ng:true,dialogue_check:{...clip.dialogue_check,signature:'current'},dialogue_adoption:{status:'adopted_ng',signature:'current',attempt:1,limit:1}};
assert.match(render(adopted,true),/对白未通过，次数耗尽已采用/);
assert.match(render(adopted,true),/对白核对仍未通过/);
assert.doesNotMatch(render({...adopted,dialogue_adoption:{...adopted.dialogue_adoption,signature:'old'}},true),/次数耗尽已采用/);
assert.match(html,/不依赖视频视觉审核/);assert.match(html,/v0\.8/);
async function main(){
 buttons.push({dataset:{dialogueIndex:'0',dialogueAction:'recheck'}});context.bindDialogueActions();await buttons[0].onclick();
 assert.equal(calls[0][0],'projects/project/dialogue');assert.equal(calls[0][1].signature,'candidate-one');assert.equal(calls[0][1].action,'recheck');
 buttons[0].dataset.dialogueAction='confirm';context.confirm=()=>false;await buttons[0].onclick();assert.equal(calls.length,1);
 context.confirm=()=>true;await buttons[0].onclick();assert.equal(calls[1][1].action,'confirm');
 console.log('Dialogue UI checks passed: independent setting, unverified state, escaping, paused-only actions, and explicit listening confirmation.');
}
main().catch(error=>{console.error(error);process.exitCode=1;});
