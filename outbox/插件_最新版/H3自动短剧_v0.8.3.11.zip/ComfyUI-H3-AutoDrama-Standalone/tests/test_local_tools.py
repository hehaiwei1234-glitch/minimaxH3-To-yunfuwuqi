from __future__ import annotations
import asyncio
import importlib
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path, PureWindowsPath
from unittest.mock import patch
from test_core import ROOT, domain

media=importlib.import_module('h3ad_test.media_tools')

class ToolDiscoveryTests(unittest.TestCase):
    def test_windows_private_tools_are_found_without_changing_settings(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)/'ComfyUI'/'custom_nodes'/'plugin'
            tools=root/'tools'/'ffmpeg';tools.mkdir(parents=True)
            for name in ('ffmpeg.exe','ffprobe.exe'):(tools/name).write_bytes(b'fixture')
            config=dict(domain.DEFAULTS)
            with patch.object(media.sys,'platform','win32'):
                result=media.resolve_tools(config,root)
            self.assertEqual(result['ffmpeg'],str((tools/'ffmpeg.exe').resolve()))
            self.assertEqual(result['ffprobe'],str((tools/'ffprobe.exe').resolve()))
            self.assertEqual(config['ffmpeg'],'ffmpeg')

    def test_explicit_paths_are_kept_even_if_missing(self):
        config={**domain.DEFAULTS,'ffmpeg':'D:/自己的工具/ffmpeg.exe','ffprobe':'D:/自己的工具/ffprobe.exe'}
        result=media.resolve_tools(config,ROOT)
        self.assertEqual(result['ffmpeg'],config['ffmpeg'])
        self.assertEqual(result['ffprobe'],config['ffprobe'])

    def test_linux_ignores_windows_binaries(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)/'plugin';tools=root/'tools'/'ffmpeg';tools.mkdir(parents=True)
            for name in ('ffmpeg.exe','ffprobe.exe'):(tools/name).write_bytes(b'fixture')
            with patch.object(media.sys,'platform','linux'),patch.object(media.shutil,'which',side_effect=lambda name:'/usr/bin/'+name if not name.endswith('.exe') else None):
                result=media.resolve_tools(domain.DEFAULTS,root)
            self.assertEqual(result['ffmpeg'],'/usr/bin/ffmpeg')
            self.assertEqual(result['ffprobe'],'/usr/bin/ffprobe')

    def test_concat_uses_windows_drive_and_forward_slashes(self):
        with patch.object(media.Path,'resolve',return_value=PureWindowsPath("D:/项目 文件/角色'1.mp4")):
            line=media.concat_line('fixture')
        self.assertEqual(line,"file 'D:/项目 文件/角色'\\''1.mp4'\n")

class SubprocessFallbackTests(unittest.IsolatedAsyncioTestCase):
    async def test_fallback_runs_real_process_without_blocking_event_loop(self):
        with patch.object(media.asyncio,'create_subprocess_exec',side_effect=NotImplementedError):
            task=asyncio.create_task(media.command([sys.executable,'-c',"import time; time.sleep(.2); print('ready')"]))
            await asyncio.sleep(.03)
            self.assertFalse(task.done())
            self.assertEqual((await task).strip(),b'ready')

    async def test_fallback_reports_actual_process_error(self):
        with patch.object(media.asyncio,'create_subprocess_exec',side_effect=NotImplementedError):
            with self.assertRaisesRegex(RuntimeError,'tool failed'):
                await media.command([sys.executable,'-c',"import sys; sys.stderr.write('tool failed'); sys.exit(3)"])

    async def test_fallback_cancellation_terminates_its_child(self):
        children=[];original_popen=subprocess.Popen
        def spawn(*args,**kwargs):
            process=original_popen(*args,**kwargs);children.append(process);return process
        with patch.object(media.asyncio,'create_subprocess_exec',side_effect=NotImplementedError),patch.object(media.subprocess,'Popen',side_effect=spawn):
            task=asyncio.create_task(media.command([sys.executable,'-c',"import time; time.sleep(30)"]))
            for _ in range(100):
                if children:break
                await asyncio.sleep(.01)
            self.assertTrue(children)
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):await task
        self.assertIsNotNone(children[0].poll())

if __name__=='__main__':unittest.main()
