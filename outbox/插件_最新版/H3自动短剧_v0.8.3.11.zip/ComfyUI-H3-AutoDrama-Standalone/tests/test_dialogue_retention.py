"""Tail retention regressions. Synthetic audio proves slicing, not H3 speech.

Run: python -m unittest discover -s tests -p test_dialogue_retention.py -v
Uses real FFmpeg for accepting, cropping and merging. No GPU or external API.
"""
import array
import copy
import importlib
import math
import tempfile
import types
import unittest
import wave
from pathlib import Path
from unittest.mock import AsyncMock, patch
import aiohttp
from test_core import ROOT, Store, Files, domain, compiler_result
import test_render_contract as host_contract
import test_prompt_recovery as recovery_contract

retain=importlib.import_module('h3ad_test.dialogue_retention')
padding=importlib.import_module('h3ad_test.dialogue_timing')
compiler=importlib.import_module('h3ad_test.prompt_compiler')
media=importlib.import_module('h3ad_test.media_tools')
engine_module=importlib.import_module('h3ad_test.engine')
speech=importlib.import_module('h3ad_test.dialogue_check')
workflows=importlib.import_module('h3ad_test.workflows')


def clip(seconds=5.):
    return {'duration_seconds':seconds,'generation_seconds':seconds,'timing_version':1,
            'continuity':'cut','generation':1,'seed':123,'dialogue':[{'speaker':'林川','text':'先把人住的地方做好。装修以后再说。'}]}


class RetentionContractTests(unittest.TestCase):
    def setUp(self):
        self.p={'timing_policy':{}};self.cfg=domain.validate_settings({});self.c=clip()

    def test_committed_jobs_are_unchanged_and_draft_tails_are_protected(self):
        for key in padding.COMMITTED:
            c={**clip(),key:'existing'};old=copy.deepcopy(c)
            self.assertFalse(retain.prepare(self.p,c,self.cfg));self.assertEqual(c,old)
        c={**clip(), 'generation_exact':True};self.assertTrue(retain.prepare({'production_draft':{'version':1},'episode_target_seconds':5},c,self.cfg))
        self.assertEqual(c['dialogue_retention']['policy'],'preserve_tail')

    def test_manual_caps_and_legacy_target_are_never_relaxed(self):
        for name in ('episode','total','task'):
            c=clip();retain.prepare({'timing_policy':{name:{'enabled':True,'seconds':5}}},c,self.cfg)
            self.assertEqual(c['dialogue_retention']['policy'],'fixed')
        c=clip();retain.prepare({'episode_target_seconds':25},c,self.cfg)
        self.assertEqual(c['dialogue_retention']['policy'],'fixed')

    def test_zero_padding_still_preserves_already_generated_tail(self):
        self.cfg['dialogue_padding_seconds']=0
        padding.prepare(self.p,self.c,self.cfg);retain.prepare(self.p,self.c,self.cfg)
        self.assertEqual(self.c['duration_seconds'],5)
        self.assertEqual(self.c['dialogue_retention']['policy'],'preserve_tail')
        old=copy.deepcopy(self.c);self.assertFalse(retain.prepare(self.p,self.c,self.cfg));self.assertEqual(old,self.c)

    def compile(self,c,result=None):
        assets=[{'id':'a','kind':'image','label':'房间','role':'scene','name':'room.png','relative_path':'room.png'}]
        if result is None:result=compiler_result({'segment':c,'references':compiler.request_references(assets)})
        return compiler.compile_prompt(result,assets,{'images':['room.png'],'audios':[],'videos':[]},c,domain.video_timing(c,self.cfg))

    def test_initial_and_retry_padding_do_not_move_speech_deadline(self):
        base=self.compile(self.c)['dialogue_windows'][0]
        padding.prepare(self.p,self.c,self.cfg);retain.prepare(self.p,self.c,self.cfg)
        first=self.compile(self.c)['dialogue_windows'][0]
        self.assertAlmostEqual(base['end_seconds'],first['end_seconds'])
        self.assertAlmostEqual(first['reserved_tail_seconds'],2.15)
        padding.retry(self.p,self.c,self.cfg,{'status':'incomplete','expected':'再说','transcript':'再'})
        again=self.compile(self.c)['dialogue_windows'][0]
        self.assertAlmostEqual(again['end_seconds'],base['end_seconds'])
        self.assertAlmostEqual(again['reserved_tail_seconds'],3.15)
        self.assertEqual(again['text'],self.c['dialogue'][0]['text'])

    def test_short_shot_boundaries_and_fifteen_second_cap_keep_original_window(self):
        for seconds in (2.,2.125,52/24,14.5,15.):
            with self.subTest(seconds=seconds):
                c=clip(seconds);c['dialogue']=[{'speaker':'林川','text':'你好。'}]
                original=self.compile(c)['dialogue_windows'][0]
                padding.prepare(self.p,c,self.cfg);retain.prepare(self.p,c,self.cfg)
                out=self.compile(c);window=out['dialogue_windows'][0]
                self.assertAlmostEqual(window['start_seconds'],original['start_seconds'])
                self.assertAlmostEqual(window['end_seconds'],original['end_seconds'])
                self.assertLessEqual(c['generation_seconds'],15.)
                self.assertEqual(window['text'],'你好。')
                self.assertEqual(out['prompt_en'].count('<d>[Chinese] 你好。</d>'),1)

    def test_two_speaking_shots_and_silent_tail_keep_each_original_window(self):
        c=clip(8);c['dialogue']=[{'speaker':'林川','text':'你好。'},{'speaker':'林川','text':'再见。'}]
        data=compiler_result({'segment':c,'references':[]})
        data['shots']=[{'start_seconds':a,'end_seconds':b,'visual_en':'He faces the window.',
                        'visual_zh':'他面向窗户。','dialogue_indices':indices}
                       for a,b,indices in ((0,4,[0]),(4,6,[1]),(6,8,[]))]
        before=self.compile(c,data)['dialogue_windows']
        c['prompt_content']={'status':'compiled_content','result':data}
        padding.prepare(self.p,c,self.cfg);retain.prepare(self.p,c,self.cfg)
        saved=c['prompt_content']['result'];after=self.compile(c,saved)['dialogue_windows']
        self.assertEqual([(s['start_seconds'],s['end_seconds']) for s in saved['shots']],[(0,4),(4,7.5),(7.5,9.5)])
        for old,new in zip(before,after):
            self.assertAlmostEqual(old['start_seconds'],new['start_seconds'])
            self.assertAlmostEqual(old['end_seconds'],new['end_seconds'])
            self.assertEqual(old['text'],new['text'])

    def test_headroom_misallocated_to_another_shot_requires_field_repair(self):
        from h3ad_test.prompt_validation import issues
        c=clip(5);c['dialogue']=[{'speaker':'林川','text':'你好。'}]
        padding.prepare(self.p,c,self.cfg);retain.prepare(self.p,c,self.cfg)
        data=compiler_result({'segment':c,'references':[]})
        data['shots']=[{'start_seconds':a,'end_seconds':b,'visual_en':'He faces the window.',
                        'visual_zh':'他面向窗户。','dialogue_indices':indices}
                       for a,b,indices in ((0,5,[]),(5,6.5,[0]))]
        problems=issues(data,[],c)
        self.assertTrue(any('单独留出句尾余量' in reason for _,reason in problems))
        self.assertTrue(all(path.startswith('/shots/') for path,_ in problems))
        with self.assertRaises(ValueError):self.compile(c,data)

    def test_last_speaking_shot_before_silent_shot_owns_headroom(self):
        self.c=clip(8)
        data=compiler_result({'segment':self.c,'references':[]})
        data['shots'][0]['end_seconds']=6
        data['shots'].append({'start_seconds':6,'end_seconds':8,'dialogue_indices':[],
                              'visual_en':'He closes the door.','visual_zh':'他关门。'})
        self.c['prompt_content']={'status':'compiled_content','result':data}
        padding.prepare(self.p,self.c,self.cfg);retain.prepare(self.p,self.c,self.cfg)
        shots=self.c['prompt_content']['result']['shots']
        self.assertEqual(shots[0]['end_seconds'],7.5)
        self.assertEqual(retain.extra_hold(self.c,shots,1),1.5)
        self.assertEqual(retain.extra_hold(self.c,shots,2),0)

    def test_guide_uses_measured_adopted_duration(self):
        c=clip();c['continuity']='continue';cfg={**self.cfg,'overlap_seconds':5}
        before={**clip(3),'meta':{'duration':4.0,'video':{'duration':'4.0'}}}
        self.assertEqual(domain.video_timing(c,cfg,before)['guide_frames'],90)
        # The previous planned 3s would incorrectly yield 56 guide frames.
        self.assertEqual(retain.actual_guide_frames(before),90)

    def test_only_tail_limit_changes_in_submitted_workflow_copy(self):
        import json
        for typ in ('H3Continue','H3ADv1'):
            graph={'1':{'class_type':typ+'Prepare','inputs':{}},
                   '2':{'class_type':typ+'Trim','inputs':{'trim_start_frames':['1',3],'trim_output_frames':['1',4],'enable_continue':True}},
                   '3':{'class_type':'SaveVideo','inputs':{'video':['2',0]}}}
            c=clip();c['continuity']='continue';retain.prepare(self.p,c,self.cfg)
            original=copy.deepcopy(graph);out,audit=retain.protect_graph(graph,'3',c)
            self.assertEqual(graph,original)
            expected=copy.deepcopy(graph);expected['2']['inputs']['trim_output_frames']=0
            self.assertEqual(out,expected);self.assertEqual(len(audit['tail_limit_changes']),1)
            self.assertEqual(json.loads(json.dumps(out)),out)

    def test_unrecognized_continuation_cannot_silently_claim_protection(self):
        c=clip();c['continuity']='continue';retain.prepare(self.p,c,self.cfg)
        with self.assertRaises(ValueError):retain.protect_graph({'1':{'class_type':'SaveVideo','inputs':{}}},'1',c)


class NodeTailTests(unittest.TestCase):
    setUp=host_contract.HostContractTests.setUp
    tearDown=host_contract.HostContractTests.tearDown

    def test_prefix_only_retains_last_twelve_frames_and_audio_samples(self):
        import numpy as np
        images=np.arange(158).reshape(158,1,1,1)
        sr=24000;waveform=np.arange(158000).reshape(1,1,-1)
        audio={'waveform':waveform,'sample_rate':sr}
        old=self.render.H3ADv1Trim.execute(images,audio,22,124,True)
        new=self.render.H3ADv1Trim.execute(images,audio,22,0,True)
        self.assertEqual(old[0].shape[0],124);self.assertEqual(new[0].shape[0],136)
        self.assertEqual(new[0][0,0,0,0],22);self.assertEqual(new[0][-1,0,0,0],157)
        self.assertEqual(new[1]['waveform'][0,0,0],22000)
        self.assertEqual(new[1]['waveform'][0,0,-1],157999)
        self.assertEqual(old[1]['waveform'][0,0,-1],145999)


class CachedPromptUpgradeTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=recovery_contract.PromptRecoveryTests.asyncSetUp
    asyncTearDown=recovery_contract.PromptRecoveryTests.asyncTearDown
    setup_content=recovery_contract.PromptRecoveryTests.setup_content

    async def test_already_padded_v2_and_v3_prompts_upgrade_without_api_or_added_time(self):
        from h3ad_test.prompt_content import actual_assets,asset_key
        cfg=domain.validate_settings({'generate_shot_images':False,'dialogue_padding_seconds':1.5})
        for version in (2,3):
            with self.subTest(compiler_version=version):
                self.setup_content();c=self.clip
                c.update(asset_ids=[self.asset['id']],timing_version=1,generation_seconds=6.,generation=1,seed=123)
                base=compiler.compile_prompt(self.result,self.assets,self.media,c,self.axis)['dialogue_windows']
                c['prompt_content']={'status':'compiled_content','result':copy.deepcopy(self.result)}
                padding.prepare(self.project,c,cfg)
                old=compiler.compile_prompt(c['prompt_content']['result'],self.assets,self.media,c,self.axis)
                c.update(old,prompt_compiler_version=version,
                         compiled_asset_versions=[asset_key(a) for a in actual_assets(self.engine,self.assets)])
                prior_time=copy.deepcopy(c['dialogue_timing'])
                self.engine.set(self.project['id'],clips=[c],plan={'style':'realistic'})
                ai=types.SimpleNamespace(config={'retry_limit':1},text=AsyncMock(side_effect=AssertionError('cache upgrade must stay offline')))
                await self.engine.prepare_clip(self.project['id'],0,ai,cfg)
                new=self.store.get('project',self.project['id'])['clips'][0]
                self.assertEqual(ai.text.await_count,0)
                self.assertEqual(new['prompt_compiler_version'],compiler.VERSION)
                self.assertEqual(new['dialogue_timing'],prior_time)
                self.assertEqual(new['duration_seconds'],7.5)
                self.assertEqual(new['asset_ids'],c['asset_ids'])
                for before,after in zip(base,new['dialogue_windows']):
                    self.assertAlmostEqual(before['start_seconds'],after['start_seconds'])
                    self.assertAlmostEqual(before['end_seconds'],after['end_seconds'])
                    self.assertEqual(before['text'],after['text'])


class RealMediaTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();root=Path(self.temp.name)
        self.store=Store(root/'data');self.files=Files(root/'input',root/'output')
        self.engine=engine_module.Engine(self.store,self.files,ROOT,'http://127.0.0.1:9')
        self.cfg=domain.validate_settings({'ffmpeg':'ffmpeg','ffprobe':'ffprobe','review_audio':True,
                                          'asr_model':'fixture','asr_base_url':'http://127.0.0.1:9'})
        self.p=self.store.create_project({'title':'tail regression','script':'林川：原句。'})
        folder=self.files.project_dir(self.p['id']);self.raw=folder/'raw.mp4';wav=folder/'tail.wav'
        sr=16000;n=round(136/24*sr)
        signal=array.array('h',(int(8000*math.sin(2*math.pi*660*i/sr)) if 5.05<i/sr<5.4 else 0 for i in range(n)))
        with wave.open(str(wav),'wb') as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(sr);f.writeframes(signal.tobytes())
        await media.command(['ffmpeg','-y','-v','error','-f','lavfi','-i','color=c=blue:s=64x64:r=24',
                             '-i',wav,'-frames:v','136','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac',self.raw])
        self.c=clip();retain.prepare(self.p,self.c,self.cfg)
        self.store.update('project',self.p['id'],lambda p:p.update(clips=[self.c]))

    async def asyncTearDown(self):self.temp.cleanup()

    async def accept(self,fixed=False):
        if fixed:
            self.c['dialogue_retention'].update(policy='fixed',fixed_reason='manual_task')
            self.store.update('project',self.p['id'],lambda p:p.update(clips=[self.c]))
        await self.engine.accept_output(self.p['id'],0,self.files.descriptor(self.raw),self.cfg)
        return self.store.get('project',self.p['id'])['clips'][0]

    async def test_flexible_accept_keeps_all_generated_frames_and_tail_audio(self):
        c=await self.accept()
        self.assertEqual(c['output'],c['raw_output'])
        self.assertEqual(int(c['meta']['video']['nb_frames']),136)
        self.assertEqual(c['retention_audit']['application_removed_tail_seconds'],0)
        raw=await media.command(['ffmpeg','-v','error','-i',self.raw,'-ss','5.05','-t','0.35','-f','s16le','-ac','1','-ar','16000','-'])
        samples=array.array('h');samples.frombytes(raw)
        self.assertGreater(max(map(abs,samples)),1000)

    async def test_fixed_duration_is_still_exact_and_raw_is_retained(self):
        c=await self.accept(True)
        self.assertNotEqual(c['output'],c['raw_output']);self.assertTrue(self.raw.is_file())
        self.assertEqual(int(c['meta']['video']['nb_frames']),120)
        self.assertAlmostEqual(c['meta']['duration'],5.,delta=.04)
        self.assertAlmostEqual(c['retention_audit']['application_removed_tail_seconds'],16/24,places=5)

    async def test_merge_does_not_trim_back_to_planned_duration(self):
        c=await self.accept();target=self.raw.with_name('merged.mp4')
        result=await media.merge([self.raw,self.raw],target,self.cfg)
        meta=await media.probe(target,self.cfg)
        self.assertEqual(int(meta['video']['nb_frames']),272)
        self.assertGreater(result['duration'],11.3)

    async def test_full_tail_uses_one_asr_and_never_marks_missing_words_passed(self):
        await self.accept();recognize=AsyncMock(return_value=({'text':'先把人住的地方做好。'},'fixture'))
        with patch.object(speech,'recognize',recognize):
            async with aiohttp.ClientSession() as session:
                report=await self.engine.check_dialogue(self.p['id'],0,self.cfg,session)
                await self.engine.check_dialogue(self.p['id'],0,self.cfg,session)
        self.assertFalse(report['passed']);self.assertEqual(recognize.await_count,1)
        self.assertEqual(report['cause'],'incomplete_in_retained_generation')

    async def test_fixed_crop_diagnostic_preserves_failure_and_caches_both_results(self):
        await self.accept(True)
        recognize=AsyncMock(side_effect=[({'text':'先把人住的地方做好。'},'fixture'),({'text':self.c['dialogue'][0]['text']},'fixture')])
        with patch.object(speech,'recognize',recognize):
            async with aiohttp.ClientSession() as session:
                report=await self.engine.check_dialogue(self.p['id'],0,self.cfg,session)
                await self.engine.check_dialogue(self.p['id'],0,self.cfg,session)
        self.assertFalse(report['passed']);self.assertEqual(report['cause'],'complete_before_application_crop')
        self.assertEqual(recognize.await_count,2)

    async def test_diagnostic_network_failure_reuses_retained_recognition(self):
        await self.accept(True)
        recognize=AsyncMock(side_effect=[({'text':'先把人住的地方做好。'},'fixture'),RuntimeError('network'),({'text':self.c['dialogue'][0]['text']},'fixture')])
        with patch.object(speech,'recognize',recognize):
            async with aiohttp.ClientSession() as session:
                with self.assertRaisesRegex(RuntimeError,'network'):
                    await self.engine.check_dialogue(self.p['id'],0,self.cfg,session)
                report=await self.engine.check_dialogue(self.p['id'],0,self.cfg,session)
        self.assertEqual(recognize.await_count,3);self.assertFalse(report['passed'])


if __name__=='__main__':unittest.main()
