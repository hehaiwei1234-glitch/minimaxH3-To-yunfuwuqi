"""Speech headroom regression: dynamic mock renders, actual FFmpeg cropping.

No inference, paid API or real speech-recognition accuracy is simulated as proof.
"""
import asyncio
import copy
import importlib
import json
import re
import unittest
from unittest.mock import AsyncMock, patch
import aiohttp
from test_core import ROOT, domain
import test_integration as integration
import test_production_draft as drafts
from test_workflows import fixture, w

padding=importlib.import_module('h3ad_test.dialogue_timing')
policy=importlib.import_module('h3ad_test.timing_policy')
speech=importlib.import_module('h3ad_test.dialogue_check')
engine_module=importlib.import_module('h3ad_test.engine')
content=importlib.import_module('h3ad_test.prompt_content')
review=importlib.import_module('h3ad_test.review')
providers=importlib.import_module('h3ad_test.providers')


class SpeechTimingContractTests(unittest.TestCase):
    def setUp(self):
        self.cfg=domain.validate_settings({})
        self.project={'timing_policy':policy.normalize()}
        self.clip={'duration_seconds':8.,'generation_seconds':8.,'generation_exact':False,
                   'timing_version':1,'dialogue':[{'speaker':'林川','text':'能睡暖觉，能吃热饭。'}]}

    def test_default_once_and_cap_do_not_accumulate_on_resume(self):
        padding.prepare(self.project,self.clip,self.cfg)
        self.assertEqual((self.clip['duration_seconds'],self.clip['generation_seconds']),(9.5,9.5))
        saved=copy.deepcopy(self.clip)
        for _ in range(3):self.assertFalse(padding.prepare(self.project,self.clip,self.cfg))
        self.assertEqual(self.clip,saved)
        clip={**self.clip,'duration_seconds':14.5,'generation_seconds':14.5};clip.pop('dialogue_timing')
        padding.prepare(self.project,clip,self.cfg)
        self.assertEqual((clip['duration_seconds'],clip['generation_seconds']),(15.,15.))
        saved=copy.deepcopy(clip)
        self.assertEqual(padding.retry(self.project,clip,self.cfg,{'status':'incomplete','expected':'你好','transcript':'你'}),0)
        self.assertEqual(clip['duration_seconds'],saved['duration_seconds'])

    def test_committed_candidates_are_byte_for_byte_unchanged(self):
        for key in padding.COMMITTED:
            clip={**copy.deepcopy(self.clip),key:{'saved':'original'}};old=copy.deepcopy(clip)
            with self.subTest(key=key):
                self.assertFalse(padding.prepare(self.project,clip,self.cfg))
                self.assertEqual(clip,old)

    def test_all_manual_caps_and_legacy_fixed_timing_are_preserved(self):
        for key in ('episode','total','task'):
            project={'timing_policy':{key:{'enabled':True,'seconds':8}}}
            clip=copy.deepcopy(self.clip)
            with self.subTest(key=key):
                self.assertFalse(padding.prepare(project,clip,self.cfg))
                self.assertEqual(clip,self.clip)
        for cfg in ({**self.cfg,'dialogue_padding_seconds':0},{**self.cfg,'_dialogue_fixed_total':True}):
            clip=copy.deepcopy(self.clip);self.assertFalse(padding.prepare(self.project,clip,cfg));self.assertEqual(clip,self.clip)
        clip=copy.deepcopy(self.clip);clip.pop('timing_version');saved=copy.deepcopy(clip)
        self.assertFalse(padding.prepare(self.project,clip,self.cfg));self.assertEqual(clip,saved)
        clip={**self.clip,'dialogue':[]};saved=copy.deepcopy(clip)
        self.assertFalse(padding.prepare(self.project,clip,self.cfg));self.assertEqual(clip,saved)

    def test_tail_extension_uses_evidence_and_does_not_resize_other_ng(self):
        report={'status':'incomplete','expected':'钱先花在这些上','transcript':'钱先花在这'}
        delta=padding.retry(self.project,self.clip,self.cfg,report)
        self.assertAlmostEqual(delta,34/24)
        self.assertEqual(self.clip['duration_seconds'],8+34/24)
        for report in ({'status':'needs_review','expected':'你好','transcript':'您好'},
                       {'status':'incomplete','expected':'你好','transcript':''},
                       {'status':'needs_review','expected':'你好','transcript':'你好','tail_seconds':1}):
            saved=copy.deepcopy(self.clip)
            self.assertEqual(padding.retry(self.project,self.clip,self.cfg,report),0)
            self.assertEqual(self.clip,saved)
        self.assertEqual(padding.retry(self.project,self.clip,self.cfg,{'status':'needs_review','expected':'你好','transcript':'你好','tail_seconds':.02}),1.)

    def test_small_asr_substitutions_plus_missing_endpoint_extend_without_passing(self):
        expected='能睡暖觉，能吃热饭。门、保温、通风、电源，钱先花在这些上。'
        actual='能睡暖觉，能吃热饭。门、保温、通风、电源，前线花在这些。'
        report={**speech.compare(expected,actual),'expected':expected,'transcript':actual}
        self.assertFalse(report['passed']);self.assertEqual(report['status'],'needs_review')
        self.assertEqual(report['suspected_missing_tail_chars'],1)
        self.assertEqual(padding.retry(self.project,self.clip,self.cfg,report),1.)
        for actual in ('能睡暖觉，能吃热饭。门、保温、通风、电源，钱先花在这些下。','完全无关的句子，根本不是这一句台词。'):
            self.assertEqual(padding.missing_tail(expected,actual),0)

    def test_draft_final_speech_expands_before_following_silent_shot(self):
        clip=copy.deepcopy(self.clip)
        clip['dialogue'][0].update(start_seconds=.1,end_seconds=5.35)
        clip['shots']=[{'start_seconds':0,'end_seconds':6,'dialogue_indices':[0],'visual_en':'Speak'},
                       {'start_seconds':6,'end_seconds':8,'dialogue_indices':[],'visual_en':'Door'}]
        authored=copy.deepcopy(clip)
        padding.prepare({**self.project,'production_draft':{'version':1}},clip,self.cfg)
        self.assertEqual(clip['shots'][0]['end_seconds'],7.5)
        self.assertEqual(clip['shots'][1]['start_seconds'],7.5)
        self.assertEqual(clip['shots'][1]['end_seconds'],9.5)
        self.assertEqual(clip['dialogue'][0]['start_seconds'],.1)
        self.assertAlmostEqual(clip['dialogue'][0]['end_seconds'],5.35)
        self.assertEqual(clip['dialogue'][0]['text'],authored['dialogue'][0]['text'])
        self.assertEqual(clip['shots'][1]['visual_en'],'Door')

    def test_invalid_draft_extension_does_not_partially_mutate(self):
        clip=copy.deepcopy(self.clip);clip['shots']=[{'start_seconds':0,'end_seconds':7,'dialogue_indices':[0]}]
        clip['dialogue'][0].update(start_seconds=.1,end_seconds=6.35)
        saved=copy.deepcopy(clip)
        with self.assertRaisesRegex(ValueError,'安全'):padding.prepare(self.project,clip,self.cfg)
        self.assertEqual(clip,saved)

    def test_canonical_shot_marker_and_fractional_frame_requests(self):
        self.assertEqual(padding.shot_label(1,.917),'[Shot 1]')
        self.assertEqual(padding.shot_label(2,65.917),'[Shot 2] At 01:05.917')
        import tempfile
        from test_core import Store
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory)
            for mode,literal,expected in (('frames',107,domain.h3_frames(9.5)),('seconds',4.0,9.5),('seconds',4,10)):
                body=fixture();body['duration_mode']=mode;body['graph']['node_10']['inputs']['value']=literal
                saved=w.save(store,body);old=copy.deepcopy(saved['graph']);clip=copy.deepcopy(self.clip)
                padding.prepare(self.project,clip,self.cfg);clip.update(prompt_en='Full words.',continuity='cut')
                graph=w.instantiate(saved,clip,domain.media_state(['hero.png'],[],[]),None,'new/clip')
                self.assertEqual(graph['node_10']['inputs']['value'],expected)
                self.assertGreaterEqual(w.timing(saved,clip)['generated_total_seconds'],clip['duration_seconds'])
                self.assertEqual(saved['graph'],old)
                self.assertEqual(graph['node_12'],old['node_12'])


async def dynamic_video_fixture(case, graph):
    """Model Prepare alignment and Trim slicing; no H3 inference is implied."""
    def literal(value):
        if isinstance(value,list) and len(value)==2:
            return graph[value[0]]['inputs']['value']
        return value
    node=graph.get('38') or graph.get('node_38')
    frames=int(literal(node['inputs']['length']))
    prepare=graph.get('40') or graph.get('node_40')
    if prepare and literal(prepare['inputs']['enable_continue']):
        settings=prepare['inputs']
        name=settings['previous_video_name'].rsplit(' [',1)[0]
        previous=await integration.media.probe(case.files.output/name,case.store.settings())
        available=int(float(previous['video']['duration'])*24+1e-6)
        requested=max(5,round(float(literal(settings['overlap_seconds']))*24))
        guide=5+17*((min(available,requested)-5)//17)
        total=domain.h3_frames((frames+guide)/24)
        trim=next(n for n in graph.values() if n['class_type'] in ('H3ADv1Trim','H3ContinueTrim'))
        count=trim['inputs']['trim_output_frames']
        count=frames if isinstance(count,list) else int(count)
        frames=min(count,total-guide) if count else total-guide
    case.rendered_frame_counts=getattr(case,'rendered_frame_counts',[])+[frames]
    seconds=frames/24
    await integration.media.command(['ffmpeg','-y','-v','error','-f','lavfi','-i',f'color=c=blue:s=64x64:r=24:d={seconds}',
        '-f','lavfi','-i',f'sine=frequency=440:duration={seconds}','-frames:v',str(frames),
        '-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',case.fixture])


class PipelineFixture(unittest.IsolatedAsyncioTestCase):pass
for _name,_method in vars(integration.IntegrationTests).items():
    if callable(_method) and not _name.startswith('test_'):setattr(PipelineFixture,_name,_method)
del _name,_method


class SpeechTimingPipelineTests(PipelineFixture):
    async def asyncSetUp(self):
        await PipelineFixture.asyncSetUp(self)
        self.store.save_settings({'dialogue_padding_seconds':1.5})

    async def prompt(self,request):
        data=await request.json()
        await dynamic_video_fixture(self,data['prompt'])
        return await integration.IntegrationTests.prompt(self,request)

    async def test_default_pipeline_keeps_added_time_and_resume_submits_nothing(self):
        p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'complete',p['error'])
        self.assertEqual([c['duration_seconds'] for c in p['clips']],[3.5]*3)
        self.assertEqual(self.rendered_frame_counts,[90,102,90])
        final_meta=await integration.media.probe(self.files.output_path(p['final']),self.store.settings())
        self.assertEqual(int(final_meta['video']['nb_frames']),282)
        self.assertAlmostEqual(p['final']['duration'],282/24,delta=.15)
        for c,g,frames in zip(p['clips'],self.graphs,self.rendered_frame_counts):
            self.assertEqual(int(c['meta']['video']['nb_frames']),frames)
            self.assertAlmostEqual(float(c['meta']['video']['duration']),frames/24,delta=.001)
            self.assertEqual(c['raw_output'],c['output'])
            self.assertEqual(c['retention_audit']['application_removed_tail_seconds'],0)
            self.assertEqual(g['10']['inputs']['value'],domain.h3_frames(3.5))
            self.assertIn('3.500-second',c['prompt_en'])
            self.assertIn('No subtitles',c['prompt_en'])
            self.assertTrue(c['meta']['audio'])
        graphs=len(self.graphs);requests=self.ai_calls;images=self.image_calls;clips=copy.deepcopy(p['clips'])
        self.engine.set(p['id'],status='paused');p=await self.finish(p['id'])
        self.assertEqual(len(self.graphs),graphs);self.assertEqual(self.ai_calls,requests);self.assertEqual(self.image_calls,images)
        self.assertEqual(p['clips'],clips)

    async def test_prepared_old_prompt_retimes_locally_without_another_api(self):
        p=self.project();cfg={**self.engine.config(p),'dialogue_padding_seconds':0}
        async with aiohttp.ClientSession() as session:
            client=providers.AIClient(cfg,session)
            await self.engine.plan(p['id'],client,cfg);await self.engine.prepare_clip(p['id'],0,client,cfg)
            self.engine.clip_set(p['id'],0,prompt_compiler_version=2)
            saved=self.store.get('project',p['id'])['clips'][0];requests=self.ai_calls;images=self.image_calls
            cfg={**cfg,'dialogue_padding_seconds':1.5}
            await self.engine.prepare_clip(p['id'],0,client,cfg)
            self.engine=engine_module.Engine(self.store,self.files,ROOT,self.url)
            await self.engine.prepare_clip(p['id'],0,client,cfg)
        c=self.store.get('project',p['id'])['clips'][0]
        self.assertEqual(c['duration_seconds'],3.5);self.assertIn('3.500-second',c['prompt_en'])
        self.assertEqual(c['frame_asset_id'],saved['frame_asset_id']);self.assertEqual(self.ai_calls,requests);self.assertEqual(self.image_calls,images)
        self.assertEqual(c['prompt_content']['result']['shots'][-1]['end_seconds'],3.5)

    async def run_tail_retry(self,visual,exhaust=False):
        self.store.save_settings({'review_audio':True,'asr_provider':'compatible','asr_model':'mock-asr','asr_base_url':self.url,
                                 'review_video_enabled':visual,'review_image_enabled':False,'review_model':'mock',
                                 'review_api_key':'mock','review_video_attempts':2,'review_frames':2})
        p=self.project();identity=p['id'];asr_calls=[];visual_calls=[]
        async def recognize(client,blob):
            record=self.store.get('project',identity);index=int(re.search(r'核对第(\d+)段实际对白',record['phase'])[1])-1
            clip=record['clips'][index];expected=''.join(x['text'] for x in clip['dialogue']);asr_calls.append((index,clip['generation']))
            return {'text':expected[:-2] if clip['generation']==1 or exhaust else expected},'compatible'
        async def video(_reviewer,owner,index,clip,refs):
            visual_calls.append((index,clip['generation']))
            return {'passed':clip['generation']>1,'reasons':['wrong framing'] if clip['generation']==1 else []}
        with patch.object(speech,'recognize',recognize),patch.object(review.Reviewer,'video',video):p=await self.finish(identity)
        self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),6)
        self.assertEqual(len(asr_calls),6);self.assertEqual(len(visual_calls),6 if visual else 0)
        self.assertEqual(self.image_calls,3)
        for c in p['clips']:
            self.assertEqual(c['generation'],2);self.assertEqual(c['quality_attempt'],2)
            self.assertEqual(c['duration_seconds'],4.5);self.assertEqual(c['dialogue_check']['passed'],not exhaust)
            if exhaust:
                self.assertTrue(c['adopted_ng']);self.assertEqual(c['dialogue_adoption']['status'],'adopted_ng')
            self.assertTrue(c['quality_history'][0]['dialogue_check']['missing_tail_chars'])
            self.assertEqual(c['quality_history'][0]['duration_seconds'],3.5)
            self.assertIn('4.500-second',c['prompt_en'])
            self.assertTrue(self.files.output_path(c['quality_history'][0]['output']).is_file())
        # First takes: 90, 102, 90. Retries: 124, 136, 124. The
        # continuation must remove the guide, retaining its alignment tail.
        self.assertEqual(self.rendered_frame_counts,[90,124,102,136,90,124])
        self.assertEqual([int(c['meta']['video']['nb_frames']) for c in p['clips']],[124,136,124])
        final_meta=await integration.media.probe(self.files.output_path(p['final']),self.store.settings())
        self.assertEqual(int(final_meta['video']['nb_frames']),384)
        self.assertAlmostEqual(p['final']['duration'],16,delta=.15)
        if visual:self.assertIn('wrong framing',p['clips'][0]['redo_feedback'])
        if exhaust:
            self.assertIn('/NG/',self.graphs[2]['40']['inputs']['previous_video_name'])
            self.assertIn('002_',self.graphs[2]['40']['inputs']['previous_video_name'])

    async def test_speech_only_retry_works_with_video_review_off(self):await self.run_tail_retry(False)
    async def test_shared_retry_applies_both_visual_and_speech_feedback(self):await self.run_tail_retry(True)
    async def test_exhausted_tail_ng_continues_from_last_candidate_and_merges(self):await self.run_tail_retry(False,True)

    async def test_manual_task_cap_runs_full_pipeline_without_padding(self):
        p=self.store.create_project({'title':'fixed','script':'女主：你好。女主：再见。女主：明天见。',
                                    'asset_ids':[self.asset['id']],'timing_policy':{'task':{'enabled':True,'seconds':5}}})
        p=await self.finish(p['id']);self.assertEqual(p['status'],'complete',p['error'])
        self.assertEqual([c['duration_seconds'] for c in p['clips']],[2]*3)
        self.assertEqual([c['generation_seconds'] for c in p['clips']],[5]*3)
        self.assertTrue(all('dialogue_timing' not in c for c in p['clips']))
        self.assertAlmostEqual(p['final']['duration'],6,delta=.15)

    async def test_imported_workflow_uses_tail_protection_and_keeps_saved_template(self):
        saved=w.save(self.store,fixture());original=copy.deepcopy(saved['graph'])
        p=self.store.create_project({'title':'imported tail protection','script':'女主：你好。女主：再见。女主：明天见。',
                                    'asset_ids':[self.asset['id']],'workflow_id':saved['id']})
        p=await self.finish(p['id']);self.assertEqual(p['status'],'complete',p['error'])
        self.assertEqual(self.rendered_frame_counts,[90,102,90])
        self.assertEqual([int(c['meta']['video']['nb_frames']) for c in p['clips']],[90,102,90])
        self.assertEqual(self.store.get('workflow',saved['id'])['graph'],original)
        trim=next(n for n in self.graphs[1].values() if n['class_type']=='H3ADv1Trim')
        self.assertEqual(trim['inputs']['trim_output_frames'],0)
        for c in p['clips']:
            self.assertEqual(c['retention_audit']['application_removed_tail_seconds'],0)
            self.assertEqual(c['raw_output'],c['output'])

    async def test_pause_then_restart_reuses_committed_graph_and_retained_tail(self):
        p=self.project();self.engine.start(p['id'])
        for _ in range(300):
            if self.graphs:break
            await asyncio.sleep(.01)
        self.assertTrue(self.graphs)
        self.engine.pause(p['id']);await asyncio.wait_for(self.engine.tasks[p['id']],10)
        p=self.store.get('project',p['id']);self.assertEqual(p['status'],'paused',p['error'])
        saved=copy.deepcopy(p['clips'][0]);self.assertTrue(saved.get('output'))
        self.engine=engine_module.Engine(self.store,self.files,ROOT,self.url)
        p=await self.finish(p['id']);self.assertEqual(p['status'],'complete',p['error'])
        self.assertEqual(len(self.graphs),3);self.assertEqual(self.rendered_frame_counts,[90,102,90])
        for key in ('job_id','prompt_id','api_graph','output','raw_output','meta','seed','generation',
                    'prompt_en','prompt_zh','dialogue_retention','retention_graph','retention_audit','dialogue_timing'):
            self.assertEqual(p['clips'][0].get(key),saved.get(key),key)


class DraftSpeechTimingTests(drafts.Fixture):
    create=drafts.DraftExecutionTests.create
    async def asyncSetUp(self):
        await drafts.DraftExecutionTests.asyncSetUp(self)
        self.store.save_settings({'dialogue_padding_seconds':1.5})

    async def prompt(self,request):
        data=await request.json()
        if any(n['class_type']=='SaveVideo' for n in data['prompt'].values()):await dynamic_video_fixture(self,data['prompt'])
        return await drafts.Fixture.prompt(self,request)

    async def test_draft_default_keeps_words_and_speech_window_with_zero_creative_calls(self):
        with patch.object(providers.AIClient,'text',AsyncMock(side_effect=AssertionError('no creative API'))):
            s=await self.finish_series(self.create()['id'])
        self.assertEqual(s['status'],'complete',s['error'])
        p=self.store.get('project',s['project_ids'][0]);c=p['clips'][0]
        self.assertEqual(c['duration_seconds'],3.5);self.assertEqual(c['dialogue'][0]['start_seconds'],.1)
        self.assertEqual(c['dialogue'][0]['end_seconds'],1.25);self.assertIn('0.100s to 1.250s',c['prompt_en'])
        self.assertEqual(p['production_draft']['episodes'][0]['segments'][0]['duration_seconds'],2)
        self.assertEqual(self.ai_calls,0)
        self.assertGreaterEqual(p['final']['duration'],3.5-1/24)
        self.assertAlmostEqual(p['final']['duration'],c['meta']['duration'],delta=.15)
        self.assertEqual(c['retention_audit']['application_removed_tail_seconds'],0)

    async def test_draft_total_cap_survives_child_total_policy_reset(self):
        s=await self.finish_series(self.create(timing_policy={'total':{'enabled':True,'seconds':2}})['id'])
        self.assertEqual(s['status'],'complete',s['error']);p=self.store.get('project',s['project_ids'][0])
        self.assertFalse(p['timing_policy']['total']['enabled'])
        self.assertEqual(p['clips'][0]['duration_seconds'],2);self.assertNotIn('dialogue_timing',p['clips'][0])
        self.assertAlmostEqual(p['final']['duration'],2,delta=.15)

    async def test_draft_tail_retry_expands_locally_and_never_calls_creative_api(self):
        self.store.save_settings({'review_audio':True,'asr_provider':'compatible','asr_model':'mock','asr_base_url':self.url,'review_video_attempts':2})
        attempts=[]
        async def recognize(client,blob):
            attempts.append(len(blob));return {'text':'你' if len(attempts)==1 else '你好。'},'compatible'
        with patch.object(speech,'recognize',recognize),patch.object(providers.AIClient,'text',AsyncMock(side_effect=AssertionError('no creative API'))):
            s=await self.finish_series(self.create()['id'])
        self.assertEqual(s['status'],'complete',s['error']);p=self.store.get('project',s['project_ids'][0]);c=p['clips'][0]
        self.assertEqual(c['duration_seconds'],4.5);self.assertEqual(c['quality_attempt'],2);self.assertEqual(len(attempts),2)
        self.assertEqual(c['dialogue'][0]['end_seconds'],1.25);self.assertTrue(c['dialogue_check']['passed'])
        self.assertEqual(self.ai_calls,0)
        self.assertGreaterEqual(p['final']['duration'],4.5-1/24)
        self.assertAlmostEqual(p['final']['duration'],c['meta']['duration'],delta=.15)
        self.assertEqual(c['retention_audit']['application_removed_tail_seconds'],0)
