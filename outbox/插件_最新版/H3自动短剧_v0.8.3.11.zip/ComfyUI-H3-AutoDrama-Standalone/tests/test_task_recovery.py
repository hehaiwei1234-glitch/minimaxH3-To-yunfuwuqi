"""Inject the reported HTTP 400 and verify actual later video production."""
import asyncio
import copy
import importlib
import json
import unittest
from unittest.mock import AsyncMock, patch
from aiohttp import web
import aiohttp
import test_integration as integration
import test_episode_recovery as episodes
import test_quality as quality
from test_core import domain

providers=importlib.import_module('h3ad_test.providers')
Engine=importlib.import_module('h3ad_test.engine').Engine
Paused=importlib.import_module('h3ad_test.engine').Paused
recovery=importlib.import_module('h3ad_test.task_recovery')
comfy=importlib.import_module('h3ad_test.comfy_client')
ERROR={'request_id':'73bafab8-2ea1-9913-827e-b32979d8bf35','code':'InvalidParameter',
       'message':'<400> InternalError.Algo.InvalidParameter: Model output became abnormal while generating a JSON response for text.format. The generation was aborted because the partial output may be incomplete or invalid JSON. Please retry the request or adjust your prompt or JSON schema.'}


class ErrorClassificationTests(unittest.TestCase):
    def test_only_exact_generation_error_with_requested_json_is_format_failure(self):
        self.assertTrue(providers.generation_format_failure(400,ERROR,{'text':{'format':{'type':'json_object'}}}))
        self.assertTrue(providers.generation_format_failure(400,ERROR,{'response_format':{'type':'json_object'}}))
        for status,error,payload in [
            (401,ERROR,{'text':{'format':{'type':'json_object'}}}),
            (400,{'code':'Arrearage','message':ERROR['message']},{'response_format':{'type':'json_object'}}),
            (400,{'code':'InvalidParameter','message':'unsupported model or schema'},{'response_format':{'type':'json_object'}}),
            (400,ERROR,{}),
        ]:
            self.assertFalse(providers.generation_format_failure(status,error,payload))


class AutomaticImageRecoveryTests(unittest.IsolatedAsyncioTestCase):
    for _name in ['setUp','tearDown','generate','reviewer']:
        locals()[_name]=getattr(quality.ImageReviewTests,_name)

    async def test_review_service_failure_adopts_real_candidate_without_rerendering(self):
        self.cfg['continue_automatic_errors']=True
        reviewer=self.reviewer();reviewer.judge=AsyncMock(side_effect=providers.APIError('review unavailable'))
        for _ in range(2):
            self.assertEqual(await reviewer.image(None,'asset','owner','prompt',[],self.generate),self.blob)
        self.assertEqual(len(self.calls),1)
        saved=self.store.get('quality_asset','asset')
        self.assertTrue(saved['adopted_ng']);self.assertFalse(saved['verdict']['passed'])
        self.assertTrue(saved['verdict']['unchecked']);self.assertEqual(reviewer.judge.await_count,1)

    async def test_legacy_pause_policy_does_not_stop_automatic_generation(self):
        self.cfg.update(continue_automatic_errors=True,review_image_exhausted='pause',review_image_attempts=2)
        reviewer=self.reviewer();reviewer.judge=AsyncMock(return_value={'passed':False,'reasons':['wrong face']})
        self.assertEqual(await reviewer.image(None,'asset','owner','prompt',[],self.generate),self.blob)
        self.assertEqual(len(self.calls),2)
        self.assertTrue(self.store.get('quality_asset','asset')['adopted_ng'])


class RealHTTP400Tests(unittest.IsolatedAsyncioTestCase):
    for _name in ['queue','history','chat','image','prompt','object_info','local','series',
                  'finish_series','original_request','ai_result']:
        locals()[_name]=getattr(episodes.EpisodeRecoveryTests,_name)
    asyncSetUp=episodes.EpisodeRecoveryTests.asyncSetUp
    asyncTearDown=episodes.EpisodeRecoveryTests.asyncTearDown

    async def responses(self,request):
        data=await request.json();instructions=data['instructions']
        source=self.original_request(data['input'][0]['content'][0]['text'])
        bad='分镜导演' in instructions and self.bad_line in source.get('script','')
        if bad and (self.bad_remaining is None or self.bad_remaining>0):
            self.bad_calls+=1
            if self.bad_remaining is not None:self.bad_remaining-=1
            return web.json_response(ERROR,status=400)
        return await episodes.Pipeline.responses(self,request)

    async def test_reported_400_retries_once_and_finishes_without_manual_continue(self):
        self.bad_remaining=1
        s=await self.finish_series(self.series()['id'])
        self.assertEqual(s['status'],'complete',s['error'])
        self.assertEqual(self.bad_calls,1)
        self.assertEqual(len(s['project_ids']),2)
        self.assertTrue(all(self.files.output_path(self.store.get('project',p)['final']).is_file() for p in s['project_ids']))

    async def test_reported_400_exhaustion_still_produces_next_episode(self):
        s=await self.finish_series(self.series()['id'])
        self.assertEqual(s['status'],'partial',s['error'])
        self.assertEqual(self.bad_calls,2)
        self.assertEqual(self.store.get('project',s['project_ids'][0])['status'],'deferred')
        following=self.store.get('project',s['project_ids'][1])
        self.assertEqual(following['status'],'complete',following['error'])
        self.assertTrue(self.files.output_path(following['final']).is_file())

    async def test_prefetched_image_failure_keeps_other_shot_and_next_episode(self):
        self.bad_remaining=0
        s=self.series(episode_count=3)
        s.update(asset_ids=[self.asset['id']],plan={'style':'realistic','shared_assets':[],
            'episodes':[{'title':str(i+1),'script':text,'batch_id':'initial'} for i,text in enumerate(
                ['女主：你好。\n女主：再见。','女主：开门。\n女主：进来。','女主：明天见。'])]})
        self.store.put('series',s['id'],s)
        target=self.manager.episode_id(s['id'],1)
        original=self.engine.prepare_clip
        failures=[]
        async def prepare(identity,index,ai,cfg):
            if identity==target and index==0 and identity in self.engine.preparing_projects:
                failures.append(identity)
                raise providers.APIError('prefetched image API unavailable')
            return await original(identity,index,ai,cfg)
        with patch.object(self.engine,'prepare_clip',prepare):
            result=await self.finish_series(s['id'])
        projects=[self.store.get('project',pid) for pid in result['project_ids']]
        self.assertEqual(len(failures),1)
        self.assertEqual([p['status'] for p in projects],['complete','deferred','complete'])
        self.assertFalse(projects[1]['clips'][0].get('output'))
        self.assertTrue(projects[1]['clips'][1].get('output'))
        self.assertTrue(projects[1]['final']['partial'])
        self.assertEqual(projects[1]['final']['missing_clips'],[1])

    async def test_no_initial_plan_keeps_input_and_enables_continue(self):
        s=self.series();original=s['text']
        with patch.object(self.manager,'plan',AsyncMock(side_effect=providers.APIError('planner unavailable'))):
            result=await self.finish_series(s['id'])
        self.assertEqual(result['status'],'partial')
        self.assertEqual(result['text'],original)
        self.assertTrue(self.manager.public(s['id'])['can_resume'])
        self.assertFalse(self.graphs)
        self.bad_remaining=0
        result=await self.finish_series(s['id'])
        self.assertEqual(result['status'],'complete',result['error'])

    async def test_missing_writer_script_is_not_rendered_and_can_be_retried(self):
        service=importlib.import_module('h3ad_test.production_draft.service')
        self.engine=service.Engine(self.store,self.files,integration.ROOT,self.url)
        self.manager=service.SeriesManager(self.engine)
        self.bad_remaining=0
        s=self.series(input_type='outline')
        original=self.engine.checked_text
        async def checked(ai,instructions,prompt,validator,*args,**kwargs):
            if '短剧编剧' in instructions and json.loads(prompt)['current_episode']==1:
                raise providers.APIError('writer offline')
            return await original(ai,instructions,prompt,validator,*args,**kwargs)
        with patch.object(self.engine,'checked_text',checked):
            result=await self.finish_series(s['id'])
        failed,following=result['project_ids']
        self.assertTrue(self.store.get('project',failed)['script_pending'])
        saved=copy.deepcopy(self.store.get('project',following))
        self.assertEqual(saved['status'],'complete')
        self.assertFalse(self.store.get('project',failed)['clips'])
        self.manager.retry_episode(s['id'],failed)
        await asyncio.wait_for(self.manager.tasks[s['id']],35)
        fixed=self.store.get('project',failed)
        self.assertFalse(fixed.get('script_pending'))
        self.assertEqual(fixed['status'],'complete',fixed['error'])
        self.assertEqual(self.store.get('project',following),saved)

    async def test_legacy_episode_error_with_saved_storyboard_keeps_later_shots_running(self):
        self.bad_remaining=0;s=self.series()
        async with aiohttp.ClientSession() as session:
            ai=providers.AIClient(self.engine.config({'settings':{},'workflow_snapshot':s['workflow_snapshot']}),session)
            await self.manager.plan(s['id'],ai,ai.config)
            self.manager.create_children(s['id'])
            first=self.store.get('series',s['id'])['project_ids'][0]
            p=self.store.get('project',first);cfg=self.engine.config(p)
            await self.engine.plan(first,providers.AIClient(cfg,session),cfg)
        self.engine.clip_set(first,0,status='preparing')
        self.engine.set(first,status='error',error='旧版首段提示词恢复已耗尽',error_kind='ai_content')
        result=await self.finish_series(s['id'])
        recovered=self.store.get('project',first)
        self.assertEqual(recovered['status'],'deferred')
        self.assertTrue(recovered['clips'][1].get('output'))
        self.assertEqual(recovered['final']['missing_clips'],[1])
        self.assertEqual(self.store.get('project',result['project_ids'][1])['status'],'complete')


class ShotContinuationTests(unittest.IsolatedAsyncioTestCase):
    for _name in ['queue','history','prompt','object_info','image','chat','responses','ai_result',
                  'plan_result','project','finish','asyncSetUp','asyncTearDown']:
        locals()[_name]=getattr(integration.IntegrationTests,_name)

    async def fail_first_preparation(self,serial=False):
        self.store.save_settings({'pipeline_enabled':not serial,'format_retry_limit':1})
        original=self.engine.prepare_clip
        async def prepare(identity,index,ai,cfg):
            if index==0:raise providers.APIError('HTTP 400: '+ERROR['message'])
            return await original(identity,index,ai,cfg)
        with patch.object(self.engine,'prepare_clip',prepare):
            return await self.finish(self.project()['id'])

    async def test_parallel_failure_generates_two_later_shots_and_partial_movie(self):
        p=await self.fail_first_preparation()
        self.assertEqual(p['status'],'deferred',p['error'])
        self.assertEqual(p['clips'][0]['status'],'deferred')
        self.assertTrue(all(c.get('output') for c in p['clips'][1:]))
        self.assertEqual(p['clips'][1]['continuity'],'cut')
        self.assertEqual(p['clips'][1]['dialogue'][0]['text'],'再见。')
        self.assertEqual(p['final']['missing_clips'],[1]);self.assertTrue(p['final']['partial'])
        self.assertTrue(self.files.output_path(p['final']).is_file());self.assertEqual(len(self.graphs),2)

    async def test_serial_failure_also_generates_later_shots(self):
        p=await self.fail_first_preparation(serial=True)
        self.assertEqual(p['status'],'deferred');self.assertEqual(len(self.graphs),2)
        self.assertTrue(p['clips'][1].get('output'));self.assertEqual(p['clips'][1]['continuity'],'cut')

    async def test_unknown_submission_is_skipped_without_duplicate_post(self):
        original=comfy.ComfyClient.submit
        async def submit(client,graph,job,identity):
            if '_001_' in next(n['inputs']['filename_prefix'] for n in graph.values() if n['class_type']=='SaveVideo'):
                raise comfy.SubmissionUnknown('reply lost')
            return await original(client,graph,job,identity)
        with patch.object(comfy.ComfyClient,'submit',submit):
            p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'deferred');self.assertTrue(p['clips'][0]['submission_unknown'])
        job=p['clips'][0]['job_id'];before=len(self.graphs)
        p=await self.finish(p['id'])
        self.assertEqual(p['clips'][0]['job_id'],job)
        self.assertEqual(len(self.graphs),before);self.assertTrue(p['clips'][1].get('output'))

    async def test_asr_error_keeps_video_as_unchecked_ng_and_continues(self):
        self.store.save_settings({'review_audio':True,'asr_model':'gpt-4o-mini-transcribe'})
        with patch.object(self.engine,'check_dialogue',AsyncMock(side_effect=providers.APIError('ASR unavailable'))):
            p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),3)
        self.assertTrue(all(c.get('output') and c.get('adopted_ng') and c.get('recovery_unchecked') for c in p['clips']))
        self.assertTrue(all(recovery.adopted_unchecked(self.files,c) for c in p['clips']))
        self.assertTrue(all(not c.get('dialogue_check',{}).get('passed') for c in p['clips']))

    async def test_image_review_error_marks_opening_ng_and_still_generates_videos(self):
        self.store.save_settings({'review_image_enabled':True,'review_video_enabled':False,
                                 'review_model':'mock','review_api_key':'mock'})
        with patch.object(quality.review.Reviewer,'judge',AsyncMock(side_effect=providers.APIError('image review down'))):
            p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),3)
        self.assertEqual(self.image_calls,3)
        self.assertTrue(all(c.get('output') and c['image_quality']['adopted_ng'] and c['image_quality']['verdict']['unchecked'] for c in p['clips']))
        self.assertEqual(len(list((self.files.project_dir(p['id'])/'NG').rglob('*.png'))),3)

    async def test_retry_missing_only_preserves_later_videos_seeds_and_partial_export(self):
        p=await self.fail_first_preparation();before=copy.deepcopy(p['clips'][1:]);old_final=p['final']
        p=await self.finish(p['id'])
        self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),3)
        self.assertEqual([c['output'] for c in p['clips'][1:]],[c['output'] for c in before])
        self.assertEqual([c['seed'] for c in p['clips'][1:]],[c['seed'] for c in before])
        self.assertIn(old_final,p['final_versions']);self.assertFalse(p['final']['partial'])

    async def test_execution_failure_keeps_progress_and_later_render_attempts(self):
        self.store.save_settings({'retry_limit':0})
        original_render=self.engine.render_with_retries
        async def render(identity,index,client,cfg):
            if index==0:raise comfy.ExecutionFailed('mock GPU error')
            return await original_render(identity,index,client,cfg)
        with patch.object(self.engine,'render_with_retries',render):
            p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'deferred');self.assertEqual(len(self.graphs),2)
        self.assertTrue(p['clips'][1].get('output'));self.assertTrue(p['clips'][2].get('output'))

    async def test_missing_output_descriptor_does_not_poison_partial_merge(self):
        p=self.project()
        p=await self.finish(p['id'])
        missing=copy.deepcopy(p['clips'][0]['output'])
        self.files.output_path(missing).unlink()
        cfg=self.engine.config(p)
        self.engine.clip_set(p['id'],0,raw_output=None,quality_history=[])
        await recovery.record_failure(self.engine,p['id'],0,FileNotFoundError('deleted video'),cfg)
        c=self.store.get('project',p['id'])['clips'][0]
        self.assertTrue(recovery.failed(c));self.assertFalse(c.get('output'))
        self.assertEqual(c['missing_output'],missing)

    async def test_submitted_continuation_recovers_original_job_despite_previous_gap(self):
        p=await self.finish(self.project()['id']);before=len(self.graphs)
        graph=copy.deepcopy(p['clips'][1]['api_graph'])
        p['clips'][0].update(output=None,status='deferred')
        p['clips'][1].pop('output',None);p['clips'][1].pop('raw_output',None)
        self.store.put('project',p['id'],p)
        async with aiohttp.ClientSession() as session:
            await self.engine.render_clip(p['id'],1,comfy.ComfyClient(self.engine.config(p),session),self.engine.config(p))
        fixed=self.store.get('project',p['id'])['clips'][1]
        self.assertTrue(fixed.get('output'));self.assertEqual(fixed['api_graph'],graph)
        self.assertEqual(len(self.graphs),before)

    async def test_pipeline_recovers_committed_following_job_without_missing_predecessor(self):
        p=await self.finish(self.project()['id']);before=len(self.graphs)
        graph=copy.deepcopy(p['clips'][1]['api_graph'])
        p['clips'][0].update(output=None,status='deferred')
        p['clips'][1].pop('output',None);p['clips'][1].pop('raw_output',None)
        p.update(status='draft',final=None)
        self.store.put('project',p['id'],p)
        self.engine.start(p['id'],retry_failed=False)
        await asyncio.wait_for(self.engine.tasks[p['id']],30)
        result=self.store.get('project',p['id'])
        self.assertEqual(result['status'],'deferred',result['error'])
        self.assertEqual(result['final']['missing_clips'],[1])
        self.assertTrue(result['clips'][1].get('output'));self.assertEqual(result['clips'][1]['api_graph'],graph)
        self.assertEqual(len(self.graphs),before)

    async def test_manual_pause_still_stops_remaining_schedule(self):
        original=self.engine.prepare_clip
        async def prepare(identity,index,ai,cfg):
            if index==0:
                self.engine.pause(identity);self.engine.paused(identity)
            return await original(identity,index,ai,cfg)
        with patch.object(self.engine,'prepare_clip',prepare):
            p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'paused');self.assertEqual(len(self.graphs),0)


if __name__=='__main__':unittest.main()
