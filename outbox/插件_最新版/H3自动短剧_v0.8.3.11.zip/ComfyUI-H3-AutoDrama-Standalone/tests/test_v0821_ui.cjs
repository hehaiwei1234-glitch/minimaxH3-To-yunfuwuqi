const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.join(__dirname,'../static');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const image=fs.readFileSync(path.join(root,'image_workflows.js'),'utf8');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function runtimeVersion(){
 const label={textContent:''},context={FRONTEND_VERSION:'0.8.2.1',runtimeIssue:'',$:()=>label,api:async()=>({software_version:'0.8.2.1'})};
 vm.createContext(context);vm.runInContext(app.slice(app.indexOf('async function loadRuntimeVersion'),app.indexOf('function tab(')),context);
 await context.loadRuntimeVersion();assert.match(label.textContent,/后端 v0\.8\.2\.1/);assert.equal(context.runtimeIssue,'');
 context.api=async()=>({software_version:'0.8'});await context.loadRuntimeVersion();assert.match(context.runtimeIssue,/版本不一致/);
 context.api=async()=>{throw Error('old backend')};await context.loadRuntimeVersion();assert.match(label.textContent,/后端版本未确认/);
}
async function lostImageControls(){
 let html='',writes=0,confirmCount=0;const calls=[],button={dataset:{imageResubmit:'q2'}};
 const area={dataset:{},get innerHTML(){return html},set innerHTML(value){html=value;writes++},querySelectorAll:()=>[button]};
 let rows=[{id:'q2',job_id:'saved-marker',workflow_name:'reference',status:'missing',submission_unknown:true,error:'lost <script>'}];
 const context={esc,guarded:fn=>fn,notice:()=>{},confirm:()=>{confirmCount++;return false},api:async(route,body)=>{if(body){calls.push(route);rows=[];return{}}return rows}};
 vm.createContext(context);vm.runInContext(image.slice(image.indexOf('async function renderImageJobs'),image.indexOf('async function initImageWorkflows')),context);
 await context.renderImageJobs('project',area);assert.match(html,/原图片任务已不在队列和历史中/);assert.match(html,/&lt;script&gt;/);
 await context.renderImageJobs('project',area);assert.equal(writes,1);
 await button.onclick();assert.equal(confirmCount,1);assert.equal(calls.length,0);
 context.confirm=()=>true;await button.onclick();assert.deepEqual(calls,['image-jobs/q2/resubmit']);assert.equal(html,'');
 let releases={};context.api=route=>new Promise(resolve=>releases[route]=resolve);
 const old=context.renderImageJobs('old',area),fresh=context.renderImageJobs('fresh',area);
 releases['image-jobs?owner=fresh']([]);await fresh;
 releases['image-jobs?owner=old']([{id:'old',status:'missing',submission_unknown:true}]);await old;
 assert.equal(html,'');assert.equal(area.dataset.owner,'fresh');
}
(async()=>{await runtimeVersion();await lostImageControls();console.log('Runtime version and lost-image UI checks passed: escaping, stable refresh, owner changes, explicit resubmission.')})().catch(error=>{console.error(error);process.exitCode=1});
