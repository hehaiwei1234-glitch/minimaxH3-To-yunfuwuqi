from __future__ import annotations
import asyncio
import base64
import copy
import importlib
import io
import json
import shutil
import tempfile
import time
import unittest
from pathlib import Path
from aiohttp import web
import aiohttp
from PIL import Image
from test_core import ROOT, Store, Files, domain, rewrite, ComfyClient
Engine=importlib.import_module('h3ad_test.engine').Engine
media=importlib.import_module('h3ad_test.media_tools')
routes=importlib.import_module('h3ad_test.routes')

class IntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();self.dir=Path(self.temp.name)
        self.store=Store(self.dir/'data');self.files=Files(self.dir/'input',self.dir/'output')
        buffer=io.BytesIO();Image.new('RGB',(64,64),'teal').save(buffer,'PNG');self.png=buffer.getvalue()
        self.asset=self.files.write_asset(self.store,'角色 中文.png',self.png,{'role':'character','label':'女主','speaker':'女主'})
        self.fixture=self.dir/'fixture.mp4'
        await media.command(['ffmpeg','-y','-v','error','-f','lavfi','-i','color=c=blue:s=64x64:r=24:d=2','-f','lavfi','-i','sine=frequency=440:duration=2','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',self.fixture])
        self.jobs={};self.pending={};self.graphs=[];self.ai_calls=0;self.image_calls=0;self.lose_response=False;self.fail_job=False;self.history_polls=0
        app=web.Application();app.router.add_get('/object_info',self.object_info);app.router.add_get('/queue',self.queue);app.router.add_get('/history',self.history);app.router.add_get('/history/{id}',self.history)
        app.router.add_post('/prompt',self.prompt);app.router.add_post('/responses',self.responses);app.router.add_post('/chat/completions',self.chat);app.router.add_post('/images/generations',self.image);app.router.add_post('/images/edits',self.image)
        self.runner=web.AppRunner(app);await self.runner.setup();self.site=web.TCPSite(self.runner,'127.0.0.1',0);await self.site.start();self.port=self.site._server.sockets[0].getsockname()[1];self.url=f'http://127.0.0.1:{self.port}'
        # Legacy behavior coverage uses a fixed two-second mock renderer.
        # test_dialogue_timing covers the enabled default with dynamic outputs.
        self.store.save_settings({'comfy_url':self.url,'openai_base_url':self.url,'image_base_url':self.url,'deepseek_base_url':self.url,'openai_api_key':'mock','deepseek_api_key':'mock','poll_seconds':1,'retry_limit':0,'dialogue_padding_seconds':0})
        self.engine=Engine(self.store,self.files,ROOT,self.url)
    async def asyncTearDown(self):
        for t in self.engine.tasks.values():
            if not t.done():t.cancel()
        for t in self.engine.tasks.values():
            try:await t
            except asyncio.CancelledError:pass
        await self.runner.cleanup();self.temp.cleanup()
    async def object_info(self,request):return web.json_response({n['class_type']:{} for n in self.engine.template.values()}|{'PrimitiveInt':{}})
    async def queue(self,request):return web.json_response({'queue_running':[x['prompt'] for x in self.pending.values()],'queue_pending':[]})
    async def history(self,request):
        self.history_polls+=1
        now=time.monotonic()
        for id,entry in list(self.pending.items()):
            if now>=entry['ready_at']:
                self.jobs[id]=entry;del self.pending[id]
        id=request.match_info.get('id')
        return web.json_response({id:self.jobs[id]} if id and id in self.jobs else {} if id else self.jobs)
    async def prompt(self,request):
        data=await request.json();g=data['prompt'];self.graphs.append(g);id=f'pid_{len(self.graphs)}'
        output_id=next(nid for nid,n in g.items() if n['class_type']=='SaveVideo')
        prefix=g[output_id]['inputs']['filename_prefix'];path=self.files.output/(prefix+'_00001_.mp4');path.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(self.fixture,path)
        result={'prompt':[0,id,g,data['extra_data'],[output_id]],'outputs':{output_id:{'images':[self.files.descriptor(path)]}},'status':{'completed':True,'status_str':'success','messages':[]},'ready_at':time.monotonic()+0.15}
        if self.fail_job:result['status']={'completed':False,'status_str':'error','messages':[['execution_error',{'exception_message':'mock VRAM failure'}]]}
        self.pending[id]=result
        if self.lose_response:self.lose_response=False;request.transport.close();return web.Response()
        return web.json_response({'prompt_id':id,'node_errors':{}})
    def plan_result(self):
        return {'style':'realistic','assets_to_create':[], 'segments':[{'title':f'片段{i+1}','duration_seconds':2,'continuity':'continue' if i==1 else 'cut','depends_on_previous':i==1,'visual_zh':'女主说话。','camera_zh':'中景','image_prompt':'A woman in a room.','asset_ids':[self.asset['id']],'image_reference_ids':[self.asset['id']],'dialogue':[{'speaker':'女主','text':text}],'sound_zh':'轻微风声'} for i,text in enumerate(['你好。','再见。','明天见。'])]}
    def ai_result(self,instructions,prompt):
        self.ai_calls+=1
        if '分镜导演' in instructions:return self.plan_result()
        from test_core import compiler_result
        data=json.loads(prompt.split('\n修正上一次JSON',1)[0])
        if data.get('compiler_contract'):return compiler_result(data)
        count=sum(x['reference'].startswith('<Picture') for x in data['reference_map']);return rewrite(count,data['segment']['dialogue'][0]['text'])
    async def responses(self,request):
        data=await request.json()
        input_text=' '.join(part.get('text','') for message in data['input'] for part in message.get('content',[]) if part.get('type')=='input_text')
        if data.get('text',{}).get('format',{}).get('type')=='json_object' and 'json' not in input_text.lower():
            return web.json_response({'error':{'message':"Response input messages must contain the word 'json' in some form to use 'text.format' of type 'json_object'.",'param':'input'}},status=400)
        prompt=data['input'][0]['content'][0]['text'];result=self.ai_result(data['instructions'],prompt)
        return web.json_response({'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':json.dumps(result,ensure_ascii=False)}]}]})
    async def test_responses_json_mode_requires_keyword_inside_input(self):
        client_class=importlib.import_module('h3ad_test.providers').AIClient
        seen=[]
        self.ai_result=lambda instructions,prompt:seen.append(prompt) or {'ok':True}
        async with aiohttp.ClientSession() as session:
            old={'model':'mock','instructions':'只返回JSON对象','input':[{'role':'user','content':[{'type':'input_text','text':'请整理这份剧本。'}]}],'text':{'format':{'type':'json_object'}}}
            async with session.post(self.url+'/responses',json=old) as response:self.assertEqual(response.status,400)
            result=await client_class(self.store.settings(),session).text('请整理剧本。','请保留中文台词。')
        self.assertEqual(result,{'ok':True});self.assertEqual(seen,['请保留中文台词。'])
        self.assertFalse(self.graphs);self.assertEqual(self.image_calls,0)
    async def chat(self,request):
        data=await request.json();result=self.ai_result(data['messages'][0]['content'],data['messages'][1]['content'])
        return web.json_response({'choices':[{'finish_reason':'stop','message':{'content':json.dumps(result,ensure_ascii=False)}}]})
    async def image(self,request):
        self.image_calls+=1
        if request.content_type.startswith('multipart'):
            reader=await request.multipart()
            while (field:=await reader.next()) is not None:await field.read()
        else:await request.json()
        return web.json_response({'data':[{'b64_json':base64.b64encode(self.png).decode()}]})
    def project(self):return self.store.create_project({'title':'模拟短剧','script':'女主：你好。女主：再见。女主：明天见。','asset_ids':[self.asset['id']]})
    async def test_connection_checks_media_tools_without_ai_or_video_tasks(self):
        application=routes.Application(self.dir/'web_data',self.files.input,self.files.output,self.url)
        application.store.save_settings({'comfy_url':self.url})
        host=web.Application();host.router.add_route('*','/h3_autodrama_v1/{path:.*}',application.handle)
        runner=web.AppRunner(host);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
        port=site._server.sockets[0].getsockname()[1]
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(f'http://127.0.0.1:{port}/h3_autodrama_v1/api/connection',json={}) as response:
                    result=await response.json()
                    self.assertEqual(response.status,200,result)
            self.assertTrue(result['ok'])
            self.assertEqual(set(result['media_tools']),{'ffmpeg','ffprobe'})
            self.assertEqual(self.ai_calls,0);self.assertEqual(self.image_calls,0);self.assertFalse(self.graphs)
        finally:await runner.cleanup()
    async def finish(self,id):
        self.engine.start(id);await asyncio.wait_for(self.engine.tasks[id],30);return self.store.get('project',id)
    async def test_complete_pipeline_and_independent_graph(self):
        p=await self.finish(self.project()['id']);self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),3);self.assertEqual(self.image_calls,3)
        self.assertTrue(5.8<p['final']['duration']<6.4);self.assertEqual(p['final']['merge_mode'],'copy')
        self.assertTrue(self.files.output_path(p['final']).exists());self.assertGreater(self.history_polls,3)
        self.assertTrue(self.graphs[1]['34']['inputs']['value']);self.assertIn('[output]',self.graphs[1]['40']['inputs']['previous_video_name'])
        self.assertFalse(self.graphs[2]['34']['inputs']['value']);self.assertFalse(any(n['class_type'].startswith('H3Continue') for g in self.graphs for n in g.values()))
        self.assertEqual(p['clips'][0]['seed'],636323908608123)
    async def test_episodes_wait_for_previous_final_before_any_next_ai(self):
        from unittest.mock import patch
        first=self.project();second=self.project()
        merge_started=asyncio.Event();release_merge=asyncio.Event();original_merge=media.merge;merges=0
        async def gated_merge(*args,**kwargs):
            nonlocal merges
            merges+=1
            result=await original_merge(*args,**kwargs)
            if merges==1:
                merge_started.set();await release_merge.wait()
            return result
        engine_module=importlib.import_module('h3ad_test.engine')
        with patch.object(engine_module,'merge',gated_merge):
            self.engine.start(first['id']);self.engine.start(second['id'])
            second_task=self.engine.tasks[second['id']]
            self.engine.start(second['id']);self.assertIs(self.engine.tasks[second['id']],second_task)
            try:
                await asyncio.wait_for(merge_started.wait(),15)
                self.assertEqual(self.store.get('project',second['id'])['status'],'queued')
                self.assertIsNone(self.store.get('project',second['id'])['plan'])
                self.assertEqual(self.ai_calls,4);self.assertEqual(self.image_calls,3)
                self.assertEqual(len(self.graphs),3)
            finally:release_merge.set()
            await asyncio.wait_for(asyncio.gather(self.engine.tasks[first['id']],second_task),20)
        self.assertTrue(all(self.store.get('project',p['id'])['status']=='complete' for p in (first,second)))
        prefixes=[g['20']['inputs']['filename_prefix'] for g in self.graphs]
        self.assertTrue(all(first['id'] in p for p in prefixes[:3]))
        self.assertTrue(all(second['id'] in p for p in prefixes[3:]))
    async def test_pause_queued_episode_does_not_affect_running_episode(self):
        first=self.project();second=self.project()
        self.engine.start(first['id']);self.engine.start(second['id'])
        self.engine.pause(second['id'])
        await asyncio.wait_for(asyncio.gather(*self.engine.tasks.values(),return_exceptions=True),20)
        self.assertEqual(self.store.get('project',first['id'])['status'],'complete')
        self.assertEqual(self.store.get('project',second['id'])['status'],'paused')
        self.assertIsNone(self.store.get('project',second['id'])['plan'])
        self.assertEqual(len(self.graphs),3);self.assertEqual(self.image_calls,3)
    async def test_failed_episode_does_not_cancel_later_queued_episodes(self):
        first=self.project();second=self.project();self.fail_job=True
        self.engine.start(first['id']);self.engine.start(second['id'])
        await asyncio.wait_for(asyncio.gather(*self.engine.tasks.values(),return_exceptions=True),40)
        for p in (first,second):
            failed=self.store.get('project',p['id'])
            self.assertEqual(failed['status'],'deferred');self.assertIsNotNone(failed['plan'])
            self.assertTrue(all(c.get('task_failure') for c in failed['clips']))
        self.assertEqual(len(self.graphs),6)
        self.fail_job=False
        self.engine.start(first['id']);self.engine.start(second['id'])
        await asyncio.wait_for(asyncio.gather(*self.engine.tasks.values()),40)
        self.assertTrue(all(self.store.get('project',p['id'])['status']=='complete' for p in (first,second)))

    async def test_no_existing_assets_creates_shared_characters_and_scene(self):
        base=self.plan_result()
        base['assets_to_create']=[{'id':'new_woman','label':'女主','description':'黑发白衣','role':'character','image_prompt':'Woman with black hair wearing white.'},
                                 {'id':'new_room','label':'房间','description':'朴素房间','role':'scene','image_prompt':'Simple room.'}]
        for c in base['segments']:c['asset_ids']=['new_woman','new_room'];c['image_reference_ids']=['new_woman','new_room']
        self.plan_result=lambda:copy.deepcopy(base)
        p=await self.finish(self.store.create_project({'script':'女主：你好。女主：再见。女主：明天见。'})['id'])
        self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(self.image_calls,5);self.assertEqual(set(p['generated_assets']),{'new_woman','new_room'})
        shared=self.store.get('asset',p['generated_assets']['new_woman'])['relative_path']
        self.assertTrue(all(shared in json.loads(g['38']['inputs']['batch_media_json'])['images'] for g in self.graphs))
    async def test_slow_ai_waits_for_next_clip_without_ending_project(self):
        # GPU output 1 is ready while the AI is still preparing frame 2.
        provider=importlib.import_module('h3ad_test.providers');original_client=provider.AIClient.image
        async def delayed(client,prompt,reference_paths=()):
            if self.image_calls==1:await asyncio.sleep(1.3)
            return await original_client(client,prompt,reference_paths)
        from unittest.mock import patch
        with patch.object(provider.AIClient,'image',delayed):
            p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),3)
    async def test_render_wait_timeout_keeps_task_and_does_not_submit(self):
        cfg={**self.store.settings(),'render_timeout_minutes':0.0004,'poll_seconds':0.01}
        async with aiohttp.ClientSession() as session:
            with self.assertRaises(TimeoutError):await ComfyClient(cfg,session).wait('still_running')
        self.assertEqual(len(self.graphs),0)
    async def test_different_video_formats_merge_and_silent_clip_gets_audio(self):
        other=self.dir/'different.mp4'
        await media.command(['ffmpeg','-y','-v','error','-f','lavfi','-i','color=c=red:s=128x96:r=30:d=1','-c:v','libx264','-pix_fmt','yuv420p',other])
        output=self.files.project_dir('merge_test')/'final.mp4';result=await media.merge([self.fixture,other],output,self.store.settings());meta=await media.probe(output,self.store.settings())
        self.assertEqual(result['merge_mode'],'normalized');self.assertIsNotNone(meta['audio']);self.assertEqual(meta['video']['width'],64);self.assertTrue(2.8<meta['duration']<3.4)
    async def test_redo_continuation_only_and_keep_old_files(self):
        p=await self.finish(self.project()['id']);old=[self.files.output_path(c['output']) for c in p['clips']];third=copy.deepcopy(p['clips'][2]['output']);seed=p['clips'][0]['seed']
        affected=self.engine.redo(p['id'],[0],new_seed=True);self.assertEqual(affected,[0,1]);await asyncio.wait_for(self.engine.tasks[p['id']],30)
        p=self.store.get('project',p['id']);self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),5);self.assertEqual(p['clips'][2]['output'],third)
        self.assertNotEqual(p['clips'][0]['seed'],seed);self.assertEqual(self.image_calls,4);self.assertTrue(all(x.exists() for x in old));self.assertEqual(len(p['final_versions']),1)
    async def test_lost_post_response_is_reconciled_without_duplicate(self):
        self.lose_response=True;p=await self.finish(self.project()['id']);self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),3)
    async def test_render_error_records_every_shot_and_does_not_claim_success(self):
        self.fail_job=True;p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'deferred');self.assertIsNone(p['final'])
        self.assertFalse(any(c.get('output') for c in p['clips']))
        self.assertTrue(all('mock VRAM failure' in c['task_failure']['message'] for c in p['clips']))
        self.assertEqual(len(self.graphs),3)

    async def test_known_failure_retries_are_bounded_per_shot_and_resumable(self):
        self.store.save_settings({'retry_limit':1});self.fail_job=True
        p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'deferred');self.assertEqual(len(self.graphs),6)
        self.assertTrue(all(len(c['failed_attempts'])==2 for c in p['clips']))
        self.assertNotEqual(p['clips'][0]['failed_attempts'][0]['job_id'],p['clips'][0]['failed_attempts'][1]['job_id'])
        self.fail_job=False
        p=await self.finish(p['id']);self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),9)

    async def test_durable_generated_image_is_reused_after_link_checkpoint_loss(self):
        p=await self.finish(self.project()['id']);calls=self.image_calls
        c=p['clips'][0];frame=c['frame_asset_id'];c.pop('frame_asset_id');c.pop('prompt_en');c.pop('prompt_zh');p['status']='paused';self.store.put('project',p['id'],p)
        async with aiohttp.ClientSession() as session:
            ai=importlib.import_module('h3ad_test.providers').AIClient(self.engine.config(p),session)
            await self.engine.prepare_clip(p['id'],0,ai,self.engine.config(p))
        self.assertEqual(self.image_calls,calls);self.assertEqual(self.store.get('project',p['id'])['clips'][0]['frame_asset_id'],frame)
    async def test_resume_after_restart_does_not_resubmit(self):
        p=await self.finish(self.project()['id']);saved=copy.deepcopy(p['clips'][1]);p['clips'][1].pop('output');p['clips'][1].pop('meta');p['clips'][2].pop('output');p['final']=None;p['status']='running';self.store.put('project',p['id'],p)
        self.engine=Engine(self.store,self.files,ROOT,self.url);self.assertEqual(self.store.get('project',p['id'])['status'],'paused')
        p=await self.finish(p['id']);self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),3);self.assertEqual(p['clips'][1]['output'],saved['output'])
    async def test_deepseek_switch_uses_independent_image_service(self):
        self.store.save_settings({'provider':'deepseek'});p=await self.finish(self.project()['id']);self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(self.image_calls,3)
    async def test_ambiguous_intent_is_deferred_without_duplicate_post(self):
        p=self.project();plan=self.plan_result();p['plan']=plan
        p['clips']=[{**s,'status':'ready','seed':1,'generation':1,'prompt_en':rewrite(1)['prompt_en'],'prompt_zh':'对照','job_id':'unknown_job','submission_unknown':True,'output_prefix':'h3_autodrama_v1/no_such_file'} for s in plan['segments']]
        self.store.put('project',p['id'],p)
        p=await self.finish(p['id']);self.assertEqual(p['status'],'deferred');self.assertEqual(len(self.graphs),0)
        self.assertTrue(all(c.get('job_id')=='unknown_job' for c in p['clips']))
        self.assertTrue(all(c.get('task_failure') for c in p['clips']))
        self.assertIn('不能确定',p['clips'][0]['task_failure']['message'])

    async def test_pause_finishes_current_comfy_job(self):
        p=self.project();self.engine.start(p['id'])
        for _ in range(200):
            if self.graphs:break
            await asyncio.sleep(0.01)
        self.assertTrue(self.graphs);self.engine.pause(p['id']);await asyncio.wait_for(self.engine.tasks[p['id']],10)
        p=self.store.get('project',p['id']);self.assertEqual(p['status'],'paused');self.assertEqual(len(self.graphs),1);self.assertTrue(p['clips'][0].get('output'))
        p=await self.finish(p['id']);self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),3)
    async def test_api_does_not_return_keys_and_serves_files(self):
        app=routes.Application(self.dir/'web_data',self.files.input,self.files.output,self.url);app.store.save_settings({'openai_api_key':'secret-key'})
        fake=web.Application();fake.router.add_get('/h3_autodrama_v1/',app.handle);fake.router.add_get('/h3_autodrama_v1/{path:.*}',app.handle);fake.router.add_post('/h3_autodrama_v1/{path:.*}',app.handle)
        runner=web.AppRunner(fake);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();port=site._server.sockets[0].getsockname()[1]
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f'http://127.0.0.1:{port}/h3_autodrama_v1/api/settings') as r:body=await r.json();self.assertEqual(body['openai_api_key'],'');self.assertTrue(body['openai_api_key_configured'])
                async with session.get(f'http://127.0.0.1:{port}/h3_autodrama_v1/') as r:self.assertEqual(r.status,200);self.assertIn('输入剧本',await r.text())
                async with session.post(f'http://127.0.0.1:{port}/h3_autodrama_v1/api/projects',json={'title':'API测试','script':'你好'}) as r:self.assertEqual(r.status,400);self.assertIn('工作流',(await r.json())['error'])
        finally:await runner.cleanup()

    async def test_imported_workflow_runs_dynamic_ids_and_keeps_parameters(self):
        from test_workflows import fixture,w
        record=w.save(self.store,fixture());base=self.plan_result()
        for c in base['segments']:c.update(duration_seconds=2,continuity='cut')
        self.plan_result=lambda:copy.deepcopy(base)
        p=self.store.create_project({'script':'女主：你好。女主：再见。女主：明天见。','asset_ids':[self.asset['id']],'workflow_id':record['id']})
        self.store.save_settings({'width':1792,'height':672,'steps':4,'seed':1})
        p=await self.finish(p['id']);self.assertEqual(p['status'],'complete',p['error']);self.assertEqual(len(self.graphs),3)
        for graph in self.graphs:
            self.assertIn('node_20',graph);self.assertNotIn('20',graph)
            self.assertEqual(graph['node_38']['inputs']['width'],1024);self.assertEqual(graph['node_38']['inputs']['height'],384)
            self.assertEqual(graph['node_12']['inputs']['value'],23);self.assertEqual(graph['node_18']['inputs']['noise_seed'],2**63+17)
            self.assertEqual(graph['node_10']['inputs']['value'],domain.h3_frames(2))
        self.assertTrue(all(c['output_node_id']=='node_20' for c in p['clips']))
        self.assertEqual(p['workflow_snapshot']['version'],1)

    async def test_imported_workflow_rejects_plan_exceeding_h3_limits_before_images(self):
        from test_workflows import fixture,w
        record=w.save(self.store,fixture())
        base=self.plan_result()
        base['segments'][0]['duration_seconds']=16
        self.plan_result=lambda:copy.deepcopy(base)
        p=await self.finish(self.store.create_project({'script':'女主：你好。女主：再见。女主：明天见。','asset_ids':[self.asset['id']],'workflow_id':record['id']})['id'])
        self.assertEqual(p['status'],'deferred');self.assertIn('15秒',p['error'])
        self.assertFalse(self.graphs);self.assertEqual(self.image_calls,0)

    async def test_workflow_http_import_attach_and_start_without_gpu_submission(self):
        from test_workflows import fixture
        app=routes.Application(self.dir/'http_workflows',self.files.input,self.files.output,self.url);app.store.save_settings({'comfy_url':self.url})
        legacy=app.store.create_project({'script':'你好。'})
        host=web.Application();host.router.add_route('*','/h3_autodrama_v1/{path:.*}',app.handle)
        runner=web.AppRunner(host);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();port=site._server.sockets[0].getsockname()[1]
        base=f'http://127.0.0.1:{port}/h3_autodrama_v1/api/'
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(base+'projects/'+legacy['id']+'/start',json={}) as response:self.assertEqual(response.status,400)
                async with session.post(base+'workflows/preview',json={'graph':fixture()['graph']}) as response:
                    self.assertEqual(response.status,200);self.assertTrue((await response.json())['fields'])
                async with session.post(base+'workflows',json=fixture()) as response:
                    result=await response.json();self.assertEqual(response.status,200,result);wid=result['id']
                async with session.post(base+'projects/'+legacy['id']+'/workflow',json={'workflow_id':wid}) as response:
                    self.assertEqual(response.status,200);self.assertEqual((await response.json())['workflow_snapshot']['id'],wid)
                async with session.post(base+'projects',json={'script':'新剧本','workflow_id':wid,'settings':{'width':256}}) as response:
                    self.assertEqual(response.status,200);created=await response.json();self.assertEqual(created['settings'],{})
                async with session.get(base+'projects/'+created['id']+'/workflow') as response:
                    self.assertEqual(response.status,200);self.assertEqual((await response.json())['graph']['node_38']['inputs']['width'],1024)
            self.assertFalse(self.graphs);self.assertEqual(self.ai_calls,0);self.assertEqual(self.image_calls,0)
        finally:await runner.cleanup()

if __name__=='__main__':unittest.main()
