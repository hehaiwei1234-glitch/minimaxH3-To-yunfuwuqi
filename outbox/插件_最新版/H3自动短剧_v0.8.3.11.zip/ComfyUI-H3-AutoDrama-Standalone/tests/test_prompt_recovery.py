"""Malformed provider responses and interrupted old-cache recovery, no GPU/API."""
import copy
import importlib
import json
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import AsyncMock
from test_core import Store, Files, ROOT, domain, compiler_result

content = importlib.import_module('h3ad_test.prompt_content')
compiler = importlib.import_module('h3ad_test.prompt_compiler')
validation = importlib.import_module('h3ad_test.prompt_validation')
Engine = importlib.import_module('h3ad_test.engine').Engine
providers = importlib.import_module('h3ad_test.providers')


class PromptRecoveryTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        self.store = Store(root/'data')
        self.files = Files(root/'input', root/'output')
        self.engine = Engine(self.store, self.files, ROOT, 'http://127.0.0.1:1')
        self.asset = self.files.write_asset(self.store, '主角 原图.png', b'fixture', {'label': '林川', 'role': 'character'})
        self.assets = [self.asset]
        self.media = domain.media_state([self.asset['relative_path']], [], [])
        self.axis = {'new_content_start_seconds': 0}
        self.project = self.store.create_project({'script': '林川：你好。\n林川：明天见。', 'asset_ids': [self.asset['id']]})
        self.setup_content()

    async def asyncTearDown(self):
        self.temp.cleanup()

    def setup_content(self, lines=None, duration=6, two=False):
        if lines is None:
            lines = [{'speaker': '林川', 'text': '你好。'}, {'speaker': '林川', 'text': '明天见。'}]
        self.clip = {'title': '交谈', 'duration_seconds': duration, 'continuity': 'cut', 'dialogue': lines}
        self.request = {'segment': self.clip, 'references': compiler.request_references(self.assets), 'time_axis': self.axis}
        self.result = compiler_result(self.request)
        if two:
            self.result['shots'] = [
                {'start_seconds': 0, 'end_seconds': 3, 'visual_en': 'A gentle push in toward the scientist.', 'visual_zh': '缓慢推向科学家。', 'dialogue_indices': [0]},
                {'start_seconds': 3, 'end_seconds': duration, 'visual_en': 'The camera pans toward the window as he speaks.', 'visual_zh': '镜头摇向窗边，他继续说话。', 'dialogue_indices': [1]},
            ]
        self.engine.set(self.project['id'], clips=[copy.deepcopy(self.clip)])

    def ai(self, *responses, limit=1):
        return types.SimpleNamespace(config={'retry_limit': limit}, text=AsyncMock(side_effect=list(responses)))

    async def run_content(self, ai):
        return await content.compile_saved(self.engine, self.project['id'], 0, ai, compiler.INSTRUCTIONS,
            json.dumps(self.request, ensure_ascii=False), self.assets, self.media, self.axis)

    def saved(self):
        return self.store.get('project', self.project['id'])['clips'][0]['prompt_content']

    def indices_patch(self):
        return {'patches': [{'path': '/shots/0/dialogue_indices', 'value': [0]}, {'path': '/shots/1/dialogue_indices', 'value': [1]}]}

    async def test_silent_shots_never_depend_on_ai_dialogue_numbering(self):
        for wrong in ([0], [1, 99], None, '0', True):
            with self.subTest(wrong=wrong):
                self.setup_content([], two=False)
                self.request['segment']['title'] = repr(wrong)
                self.result['shots'][0]['dialogue_indices'] = wrong
                before = self.result['shots'][0]['visual_en']
                ai = self.ai(self.result)
                out = await self.run_content(ai)
                self.assertEqual(ai.text.await_count, 1)
                self.assertNotIn('<d>', out['prompt_en'])
                self.assertEqual(self.saved()['result']['shots'][0]['dialogue_indices'], [])
                self.assertEqual(self.saved()['result']['shots'][0]['visual_en'], before)

    async def test_single_shot_all_source_lines_are_program_owned(self):
        self.result['shots'][0].update(dialogue_indices=[99, False], start_seconds=None, end_seconds={'wrong': 99})
        ai = self.ai(self.result)
        out = await self.run_content(ai)
        self.assertEqual(ai.text.await_count, 1)
        for text in ('你好。', '明天见。'):
            self.assertEqual(out['prompt_en'].count('<d>[Chinese] '+text+'</d>'), 1)
        self.assertLess(out['prompt_en'].find('你好。'), out['prompt_en'].find('明天见。'))
        shot = self.saved()['result']['shots'][0]
        self.assertEqual((shot['start_seconds'], shot['end_seconds'], shot['dialogue_indices']), (0, 6, [0, 1]))

    async def test_multishot_lossless_number_and_one_based_conversion(self):
        self.setup_content(two=True)
        self.result['shots'][0]['dialogue_indices'] = '1'
        self.result['shots'][1]['dialogue_indices'] = ['2.0']
        self.result['shots'][0]['end_seconds'] = '3.0'
        ai = self.ai(self.result)
        await self.run_content(ai)
        self.assertEqual(ai.text.await_count, 1)
        shots = self.saved()['result']['shots']
        self.assertEqual([s['dialogue_indices'] for s in shots], [[0], [1]])
        self.assertEqual([s['visual_en'] for s in shots], [s['visual_en'] for s in self.result['shots']])

    async def test_multishot_bool_out_of_range_duplicates_and_missing_are_field_repaired(self):
        for wrong in ([True], [99], [0], [], ['garbage']):
            with self.subTest(wrong=wrong):
                self.setup_content(two=True)
                self.request['segment']['title'] = repr(wrong)
                self.result['shots'][1]['dialogue_indices'] = wrong
                before = copy.deepcopy(self.result)
                ai = self.ai(self.result, self.indices_patch())
                out = await self.run_content(ai)
                self.assertEqual(ai.text.await_count, 2)
                request = json.loads(ai.text.await_args_list[1].args[1])
                self.assertEqual(set(request['fields_to_repair']), {'/shots/0/dialogue_indices', '/shots/1/dialogue_indices'})
                for i, shot in enumerate(self.saved()['result']['shots']):
                    self.assertEqual(shot['visual_en'], before['shots'][i]['visual_en'])
                    self.assertEqual(shot['start_seconds'], before['shots'][i]['start_seconds'])
                    self.assertEqual(shot['end_seconds'], before['shots'][i]['end_seconds'])
                self.assertIn('你好。', out['prompt_en']); self.assertIn('明天见。', out['prompt_en'])

    async def test_all_independent_errors_are_collected_in_one_repair(self):
        self.setup_content(two=True)
        self.result['voices']['林川'] = None
        self.result['shots'][0].update(end_seconds=4, visual_en='A close-up of [[ref_99]].', dialogue_indices=[1])
        self.result['shots'][1].update(start_seconds=2, dialogue_indices=[0])
        patch = {'patches': [
            {'path': '/voices/林川/en', 'value': 'A steady, restrained adult male voice.'},
            {'path': '/shots/0/end_seconds', 'value': 3}, {'path': '/shots/1/start_seconds', 'value': 3},
            {'path': '/shots/0/visual_en', 'value': 'A close-up of [[ref_1]].'},
            *self.indices_patch()['patches'],
        ]}
        ai = self.ai(self.result, patch)
        out = await self.run_content(ai)
        self.assertEqual(ai.text.await_count, 2)
        request = json.loads(ai.text.await_args_list[1].args[1])
        self.assertEqual(set(request['fields_to_repair']), {x['path'] for x in patch['patches']})
        self.assertEqual(self.saved()['result']['shots'][1]['visual_en'], self.result['shots'][1]['visual_en'])
        self.assertIn('你好。', out['prompt_en']); self.assertNotIn('<Picture 99>', out['prompt_en'])

    async def test_nonfinite_internal_time_is_repaired_without_changing_other_cut(self):
        self.setup_content(two=True)
        self.result['shots'][0]['end_seconds'] = float('nan')
        ai = self.ai(self.result, {'patches': [{'path': '/shots/0/end_seconds', 'value': 3}]})
        await self.run_content(ai)
        self.assertEqual(self.saved()['result']['shots'][1], self.result['shots'][1])

    async def test_real_reference_and_nested_sections_use_same_repair_route(self):
        self.result['shots'][0]['visual_en'] = 'Use <Picture 999>.\nsummary: an injected area'
        ai = self.ai(self.result, {'patches': [{'path': '/shots/0/visual_en', 'value': 'A cinematic push in toward [[ref_1]].'}]})
        out = await self.run_content(ai)
        self.assertEqual(ai.text.await_count, 2)
        self.assertNotIn('999', out['prompt_en'])
        self.assertEqual(out['prompt_en'].count('\nsummary:\n'), 1)
        self.assertIn('你好。', out['prompt_en'])

    async def test_invalid_cached_labels_are_not_promoted_or_reused(self):
        actual = content.actual_assets(self.engine, self.assets)
        key = content.asset_key(actual[0]); voice_key = content.voice_key('林川', actual, {})
        self.engine.set(self.project['id'], prompt_content_cache={'assets': {key: {'en': '<Picture 999>', 'zh': '错误'}},
            'voices': {voice_key: {'en': '<d>不是原文</d>', 'zh': '错误'}}})
        ai = self.ai(self.result)
        out = await self.run_content(ai)
        sent = json.loads(ai.text.await_args.args[1])
        self.assertIsNone(sent['saved_reference_descriptions']['ref_1'])
        self.assertIsNone(sent['saved_voices']['林川'])
        self.assertNotIn('999', out['prompt_en']); self.assertNotIn('不是原文', out['prompt_en'])
        cache = self.store.get('project', self.project['id'])['prompt_content_cache']
        self.assertEqual(cache['assets'][key]['en'], self.result['reference_descriptions']['ref_1']['en'])

    async def test_failed_content_does_not_poison_cache_and_restart_repairs_only_bad_field(self):
        self.result['shots'][0]['visual_en'] = 'Observe [[ref_99]].'
        ai = self.ai(self.result, TimeoutError('interrupted during field repair'))
        with self.assertRaises(TimeoutError):
            await self.run_content(ai)
        self.assertFalse(self.store.get('project', self.project['id']).get('prompt_content_cache'))
        self.assertEqual(self.saved()['status'], 'repairing')
        self.engine = Engine(self.store, self.files, ROOT, 'http://127.0.0.1:1')
        resumed = self.ai({'patches': [{'path': '/shots/0/visual_en', 'value': 'Observe [[ref_1]].'}]})
        await self.run_content(resumed)
        self.assertEqual(resumed.text.await_count, 1)
        self.assertEqual(json.loads(resumed.text.await_args.args[1])['fields_to_repair'], ['/shots/0/visual_en'])
        self.assertEqual(self.saved()['received_result']['shots'][0]['visual_en'], 'Observe [[ref_99]].')

    async def test_bad_patch_is_atomic_and_retry_is_bounded(self):
        self.setup_content(two=True)
        self.result['shots'][1]['dialogue_indices'] = [99]
        invalid = {'patches': [
            {'path': '/shots/0/dialogue_indices', 'value': [1]},
            {'path': '/sound_en', 'value': 'Unauthorized replacement'},
        ]}
        ai = self.ai(self.result, invalid, self.indices_patch(), limit=2)
        out = await self.run_content(ai)
        self.assertEqual(ai.text.await_count, 3)
        last_request = json.loads(ai.text.await_args_list[2].args[1])
        self.assertTrue(last_request['last_repair_error'])
        self.assertEqual(last_request['saved_result']['shots'][0]['dialogue_indices'], [0])
        self.assertEqual(self.saved()['result']['sound_en'], self.result['sound_en'])
        self.assertIn('你好。', out['prompt_en'])

    async def test_exhausted_bad_patch_can_resume_saved_fields_instead_of_repeating_exception(self):
        self.setup_content(two=True)
        self.result['shots'][1]['dialogue_indices'] = [99]
        ai = self.ai(self.result, {'patches': []})
        with self.assertRaises(validation.InvalidContent):
            await self.run_content(ai)
        self.assertEqual(ai.text.await_count, 2)
        self.assertEqual(self.saved()['status'], 'needs_fields')
        self.engine = Engine(self.store, self.files, ROOT, 'http://127.0.0.1:1')
        resumed = self.ai(self.indices_patch())
        await self.run_content(resumed)
        self.assertEqual(resumed.text.await_count, 1)
        self.assertEqual(self.saved()['status'], 'compiled_content')

    async def test_broken_container_cache_and_nonobject_response_are_recoverable(self):
        self.engine.set(self.project['id'], prompt_content_cache={'assets': [], 'voices': None})
        ai = self.ai(None, {'patches': [
            {'path': '/shots', 'value': self.result['shots']},
            {'path': '/sound_en', 'value': self.result['sound_en']},
            {'path': '/voices/林川/en', 'value': 'A calm natural adult voice.'},
        ]})
        out = await self.run_content(ai)
        self.assertEqual(ai.text.await_count, 2); self.assertIn('明天见。', out['prompt_en'])

    async def test_unreadable_json_response_recovers_required_fields_instead_of_stopping(self):
        ai = self.ai(providers.ContentFormatError('AI返回的JSON无法读取'), {'patches': [
            {'path': '/shots', 'value': self.result['shots']}, {'path': '/sound_en', 'value': self.result['sound_en']},
            {'path': '/voices/林川/en', 'value': 'A calm natural adult voice.'},
        ]})
        out = await self.run_content(ai)
        self.assertEqual(ai.text.await_count, 2)
        self.assertTrue(self.saved()['received_format_error'])
        self.assertIn('你好。', out['prompt_en']); self.assertIn('明天见。', out['prompt_en'])

    async def test_patch_json_failure_is_bounded_and_keeps_good_content(self):
        self.setup_content(two=True); self.result['shots'][1]['dialogue_indices'] = [99]
        ai = self.ai(self.result, providers.ContentFormatError('AI必须返回JSON对象'), self.indices_patch(), limit=2)
        await self.run_content(ai)
        self.assertEqual(ai.text.await_count, 3)
        request = json.loads(ai.text.await_args_list[2].args[1])
        self.assertIn('JSON对象', request['last_repair_error'])
        self.assertEqual(self.saved()['result']['shots'][0]['visual_en'], self.result['shots'][0]['visual_en'])

    async def test_real_api_failure_is_not_disguised_as_content_or_retried_by_normalizer(self):
        ai = self.ai(providers.APIError('HTTP 401'))
        with self.assertRaisesRegex(providers.APIError, '401'):
            await self.run_content(ai)
        self.assertEqual(ai.text.await_count, 1)

    async def test_submitted_job_and_completed_output_are_never_recompiled(self):
        self.clip.update(job_id='committed', generation=1, output={'filename': 'completed.mp4'}, prompt_en='bad cached text', prompt_compiler_version=compiler.VERSION)
        self.engine.set(self.project['id'], clips=[self.clip])
        ai = self.ai()
        await self.engine.prepare_clip(self.project['id'], 0, ai, self.engine.config(self.store.get('project', self.project['id'])))
        self.assertEqual(ai.text.await_count, 0)
        self.assertEqual(self.store.get('project', self.project['id'])['clips'][0]['output']['filename'], 'completed.mp4')

    async def test_invalid_compiled_cache_rebuilds_from_saved_content_without_api_or_new_image(self):
        self.clip.update(asset_ids=[self.asset['id']], frame_asset_id=self.asset['id'], image_reference_ids=[], seed=123,
            generation=1, timing_version=1, generation_seconds=6, status='ready')
        self.engine.set(self.project['id'], clips=[self.clip], plan={'style': 'cinematic'}, settings={'generate_shot_images': False})
        cfg = self.engine.config(self.store.get('project', self.project['id']))
        async def initial(instructions, request, images):
            return compiler_result(json.loads(request))
        ai = types.SimpleNamespace(config={'retry_limit': 1}, text=AsyncMock(side_effect=initial))
        await self.engine.prepare_clip(self.project['id'], 0, ai, cfg)
        self.engine.clip_set(self.project['id'], 0, prompt_en='broken cached text', compiled_media_bindings=[{}])
        again = self.ai()
        await self.engine.prepare_clip(self.project['id'], 0, again, cfg)
        self.assertEqual(again.text.await_count, 0)
        clip = self.store.get('project', self.project['id'])['clips'][0]
        self.assertIn('你好。', clip['prompt_en']); self.assertEqual(clip['frame_asset_id'], self.asset['id'])
        self.assertEqual((clip['seed'], clip['generation']), (123, 1))
        self.assertEqual(len(self.store.list('asset')), 1)
        # The fast path also recovers text-only corruption with valid metadata.
        self.engine.clip_set(self.project['id'], 0, prompt_en='broken cached text again')
        await self.engine.prepare_clip(self.project['id'], 0, again, cfg)
        self.assertEqual(again.text.await_count, 0)
        self.assertIn('明天见。', self.store.get('project', self.project['id'])['clips'][0]['prompt_en'])


class StrictContractTests(unittest.TestCase):
    def test_real_provider_json_parser_exposes_typed_content_errors(self):
        for value in ('[]', 'null', 'not json'):
            with self.subTest(value=value), self.assertRaises(providers.ContentFormatError):
                providers.json_object(value)
        self.assertEqual(providers.json_object('```json\n{"ok":true}\n```'), {'ok': True})
    def test_direct_compiler_rejects_ambiguous_coverage_instead_of_dropping_words(self):
        assets = [{'id': 'hero', 'kind': 'image', 'role': 'character', 'label': '林川'}]
        clip = {'duration_seconds': 6, 'dialogue': [{'speaker': '林川', 'text': '你好。'}]}
        request = {'segment': clip, 'references': compiler.request_references(assets)}
        result = compiler_result(request); result['shots'][0]['dialogue_indices'] = []
        with self.assertRaises(validation.InvalidContent):
            compiler.compile_prompt(result, assets, domain.media_state(['hero.png'], [], []), clip, {'new_content_start_seconds': 0})

    def test_absolute_continuation_time_is_converted_without_moving_cuts(self):
        clip = {'duration_seconds': 6, 'dialogue': []}
        original = {'shots': [
            {'start_seconds': .917, 'end_seconds': 3.917, 'dialogue_indices': []},
            {'start_seconds': 3.917, 'end_seconds': 6.917, 'dialogue_indices': []},
        ]}
        recovered = validation.recover_structure(original, clip, {'new_content_start_seconds': .917})
        self.assertAlmostEqual(recovered['shots'][0]['end_seconds'], 3)
        self.assertAlmostEqual(recovered['shots'][1]['start_seconds'], 3)
        self.assertEqual(original['shots'][0]['start_seconds'], .917)


import test_production_draft as draft_tests


class DraftCacheRecoveryTests(draft_tests.Fixture):
    asyncSetUp = draft_tests.DraftExecutionTests.asyncSetUp
    create = draft_tests.DraftExecutionTests.create

    async def test_draft_rebuilds_corrupt_compiled_cache_locally_and_keeps_authored_timing(self):
        draft = draft_tests.draft()
        draft['episodes'][0]['segments'][0]['opening_frame_key'] = 'hero'
        series = self.create(draft)
        self.manager.create_children(series['id'])
        pid = self.store.get('series', series['id'])['project_ids'][0]
        cfg = self.engine.config(self.store.get('project', pid))
        ai = types.SimpleNamespace(text=AsyncMock(side_effect=AssertionError('Draft must not call creative API')))
        await self.engine.prepare_clip(pid, 0, ai, cfg)
        before = self.store.get('project', pid)['clips'][0]
        self.engine.clip_set(pid, 0, prompt_en='bad cached text', prompt_zh=None)
        await self.engine.prepare_clip(pid, 0, ai, cfg)
        after = self.store.get('project', pid)['clips'][0]
        self.assertEqual(after['dialogue'], before['dialogue'])
        self.assertEqual(after['frame_asset_id'], before['frame_asset_id'])
        self.assertEqual(after['seed'], before['seed'])
        self.assertIn('0.100s to 1.250s', after['prompt_en'])
        self.assertIn('你好。', after['prompt_en'])
        self.assertEqual(ai.text.await_count, 0)
        self.assertFalse(self.graphs)


if __name__ == '__main__':
    unittest.main()
