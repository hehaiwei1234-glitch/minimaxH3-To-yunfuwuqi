"""Focused P0 checks for both compilers and durable, field-only recovery."""
import asyncio
import copy
import importlib
import json
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import AsyncMock
from test_core import Store,Files,ROOT,domain,compiler_result

content=importlib.import_module('h3ad_test.prompt_content')
compiler=importlib.import_module('h3ad_test.prompt_compiler')
draft_compiler=importlib.import_module('h3ad_test.production_draft.compiler')
Engine=importlib.import_module('h3ad_test.engine').Engine

def inputs():
    assets=[{'id':'hero','kind':'image','role':'character','label':'林川','description':''}]
    clip={'title':'交谈','duration_seconds':3,'continuity':'cut','dialogue':[{'speaker':'林川','text':'你好。','start_seconds':.1,'end_seconds':1.5}]}
    axis={'new_content_start_seconds':0};media=domain.media_state(['hero.png'],[],[])
    request={'segment':clip,'references':[{'key':'ref_1','role':'character'}],'time_axis':axis}
    return assets,clip,axis,media,request,compiler_result(request)

class CompilerNormalizationTests(unittest.TestCase):
    def test_strings_empty_ref_and_missing_zh_work_in_both_compilers(self):
        for comp in (compiler,draft_compiler):
            for ref in ('The same scientist.',None,{}, {'en':'The same scientist.'}):
                with self.subTest(compiler=comp.__name__,ref=ref):
                    assets,clip,axis,media,req,result=inputs()
                    result['reference_descriptions']['ref_1']=ref
                    result['voices']['林川']='A restrained adult voice.'
                    result['shots'][0]['visual_en']={'en':'He quietly greets the person off camera.'}
                    result['shots'][0]['visual_zh']=None;result['sound_zh']=None
                    out=comp.compile_prompt(result,assets,media,clip,axis)
                    self.assertIn('你好。',out['prompt_en']);self.assertNotIn('<Audio 1>',out['prompt_en'])
                    self.assertIn(content.ZH_PENDING,out['prompt_zh']);self.assertTrue(out['compiler_warnings'])
    def test_null_voice_reuses_actual_audio_and_does_not_guess_audio_number(self):
        assets,clip,axis,media,req,result=inputs()
        assets.append({'id':'voice','kind':'audio','role':'voice','speaker':'林川','label':'林川声音','description':''})
        media=domain.media_state(['hero.png'],[],['voice.wav']);result['voices']['林川']=None
        out=compiler.compile_prompt(result,assets,media,clip,axis,{'林川':{'image_ids':['hero'],'voice_id':'voice'}})
        self.assertIn('<Audio 1>',out['prompt_en']);self.assertNotIn('<Audio 2>',out['prompt_en'])
    def test_essential_voice_without_audio_is_missing_not_invented(self):
        assets,clip,axis,media,req,result=inputs();result['voices']['林川']=None
        with self.assertRaises(content.MissingContent) as error:compiler.compile_prompt(result,assets,media,clip,axis)
        self.assertEqual(error.exception.paths,['/voices/林川/en'])
    def test_chinese_only_description_does_not_become_fake_english(self):
        assets,clip,axis,media,req,result=inputs();result['shots'][0]['visual_en']='男主凝视窗外。'
        with self.assertRaises(content.MissingContent):compiler.compile_prompt(result,assets,media,clip,axis)
    def test_dialogue_coverage_bad_time_and_nonexistent_reference_still_fail(self):
        for change in (lambda r:r['shots'][0].update(dialogue_indices=[]),lambda r:r['shots'][0].update(end_seconds=9),lambda r:r['shots'][0].update(visual_en='[[ref_9]] stands outside.')):
            assets,clip,axis,media,req,result=inputs();change(result)
            with self.assertRaises(ValueError):compiler.compile_prompt(result,assets,media,clip,axis)
    def test_patch_cannot_overwrite_valid_content(self):
        _,_,_,_,_,result=inputs();before=copy.deepcopy(result)
        with self.assertRaisesRegex(ValueError,'非缺失'):content.merge_patch(result,{'patches':[{'path':'/shots/0/end_seconds','value':9}]},['/sound_en'])
        self.assertEqual(result,before)
    def test_pointer_name_escape(self):
        result={'voices':{'甲/乙~':{}}};path='/voices/'+content.pointer('甲/乙~')+'/en'
        result=content.merge_patch(result,{'patches':[{'path':path,'value':'Natural voice.'}]},[path])
        self.assertEqual(result['voices']['甲/乙~']['en'],'Natural voice.')

class DurableRepairTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();root=Path(self.temp.name)
        self.store=Store(root/'data');self.files=Files(root/'input',root/'output');self.engine=Engine(self.store,self.files,ROOT,'http://127.0.0.1:1')
        self.asset=self.files.write_asset(self.store,'hero.png',b'fixture',{'label':'林川','role':'character'})
        _,self.clip,self.axis,_,_,_=inputs();self.assets=[self.asset];self.media=domain.media_state([self.asset['relative_path']],[],[])
        self.request={'segment':self.clip,'references':compiler.request_references(self.assets),'time_axis':self.axis}
        self.result=compiler_result(self.request)
        self.project=self.store.create_project({'script':'林川：你好。','asset_ids':[self.asset['id']]})
        self.engine.set(self.project['id'],clips=[copy.deepcopy(self.clip)])
    async def asyncTearDown(self):self.temp.cleanup()
    async def run_content(self,ai):
        return await content.compile_saved(self.engine,self.project['id'],0,ai,compiler.INSTRUCTIONS,json.dumps(self.request,ensure_ascii=False),self.assets,self.media,self.axis)
    def ai(self,*values):
        return types.SimpleNamespace(config={'retry_limit':1},text=AsyncMock(side_effect=list(values)))
    async def test_missing_translation_costs_zero_extra_calls(self):
        result=copy.deepcopy(self.result);result['reference_descriptions']['ref_1']={'en':'Preserve this scientist.'};result['voices']['林川']='A calm male voice.'
        ai=self.ai(result);out=await self.run_content(ai)
        self.assertEqual(ai.text.await_count,1);self.assertIn(content.ZH_PENDING,out['prompt_zh'])
    async def test_only_missing_field_requested_and_good_shots_unchanged(self):
        result=copy.deepcopy(self.result);result['voices']['林川']=None
        ai=self.ai(result,{'patches':[{'path':'/voices/林川/en','value':'A steady low adult voice.'}]})
        out=await self.run_content(ai)
        self.assertEqual(ai.text.await_count,2)
        request=json.loads(ai.text.await_args_list[1].args[1]);self.assertEqual(request['fields_to_fill'],['/voices/林川/en'])
        saved=self.store.get('project',self.project['id'])['clips'][0]['prompt_content']['result']
        self.assertEqual(saved['shots'],result['shots']);self.assertEqual(saved['sound_en'],result['sound_en']);self.assertIn('你好。',out['prompt_en'])
    async def test_transport_failure_then_restart_reuses_partial_and_only_fills_missing(self):
        result=copy.deepcopy(self.result);result['sound_en']=None
        ai=self.ai(result,TimeoutError('mock interruption'))
        with self.assertRaises(TimeoutError):await self.run_content(ai)
        self.engine=Engine(self.store,self.files,ROOT,'http://127.0.0.1:1')
        resumed=self.ai({'patches':[{'path':'/sound_en','value':'Quiet room ambience.'}]})
        out=await self.run_content(resumed);self.assertEqual(resumed.text.await_count,1)
        self.assertIn('fields_to_fill',json.loads(resumed.text.await_args.args[1]));self.assertIn('你好。',out['prompt_en'])
    async def test_cached_fixed_descriptions_and_voice_recover_null_without_repair(self):
        await self.run_content(self.ai(self.result))
        # Different task context forces a new shot request, but fixed identity
        # and voice remain cached against actual asset identity/version.
        self.request['segment']['title']='另一个镜头'
        result=copy.deepcopy(self.result);result['reference_descriptions']=None;result['voices']=None
        ai=self.ai(result);await self.run_content(ai);self.assertEqual(ai.text.await_count,1)
    async def test_missing_file_and_changed_binding_are_never_reused(self):
        out=await self.run_content(self.ai(self.result));self.assertTrue(content.can_reuse(self.engine,out,self.assets))
        other=self.files.write_asset(self.store,'other.png',b'other',{'label':'其他人'})
        self.assertFalse(content.can_reuse(self.engine,out,[other]))
        self.files.asset_path(self.asset).unlink()
        with self.assertRaisesRegex(ValueError,'不存在'):content.can_reuse(self.engine,out,self.assets)
        with self.assertRaises(ValueError):await self.run_content(self.ai(self.result))
    async def test_single_shot_outer_time_is_owned_by_task_without_full_retry(self):
        result=copy.deepcopy(self.result);result['shots'][0]['end_seconds']=99;ai=self.ai(result)
        out=await self.run_content(ai)
        self.assertEqual(ai.text.await_count,1);self.assertIn('你好。',out['prompt_en'])
        saved=self.store.get('project',self.project['id'])['clips'][0]['prompt_content']
        self.assertEqual(saved['result']['shots'][0]['end_seconds'],3)
        self.assertEqual(saved['received_result']['shots'][0]['end_seconds'],99)

if __name__=='__main__':unittest.main()
