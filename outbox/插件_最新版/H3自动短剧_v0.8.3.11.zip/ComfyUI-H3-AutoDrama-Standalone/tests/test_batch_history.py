from __future__ import annotations
import json
import unittest
import test_batches_management as batch_tests


class BatchHistoryTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):batch_tests.BatchAndDeletionTests.setUp(self)
    def tearDown(self):batch_tests.BatchAndDeletionTests.tearDown(self)
    finished=batch_tests.BatchAndDeletionTests.finished
    append_body=batch_tests.BatchAndDeletionTests.append_body

    async def test_new_asset_ids_are_namespaced_while_existing_references_stay_exact(self):
        s=self.finished();s['generated_assets']={'room':self.actor['id']}
        s['plan']['shared_assets']=[{'id':'room','label':'林悦','role':'character','description':'黑发白衣','image_prompt':'woman'}]
        self.store.put('series',s['id'],s);appended=self.series.append(s['id'],self.append_body(s))
        actor=self.actor['id']
        class AI:
            config={'retry_limit':0}
            async def text(inner,instructions,prompt,images=()):
                if '连续剧情记录员' in instructions:return {'summary':'女主已经回家，人物保持白衣。'}
                return {'episodes':[{'title':'庭院','end_unit':1}],'shared_assets':[
                    {'id':'room','label':'庭院','role':'scene','description':'石质庭院','image_prompt':'stone courtyard','reference_asset_ids':[actor]},
                    {'id':'book','label':'古书','role':'prop','description':'一本古书','image_prompt':'old book','reference_asset_ids':['room']}]}
        await self.series.plan(s['id'],AI(),{})
        result=self.series.record(s['id']);new=result['plan']['shared_assets'][1:]
        self.assertNotEqual(new[0]['id'],'room');self.assertEqual(new[0]['reference_asset_ids'],[actor])
        self.assertEqual(new[1]['reference_asset_ids'],[new[0]['id']])
        self.assertEqual(result['generated_assets']['room'],actor)
        self.assertEqual(result['plan']['style'],'冷灰写实')
        self.assertEqual(result['plan']['episodes'][-1]['batch_id'],appended['batches'][-1]['id'])

    async def test_long_memory_is_chunked_and_successful_chunks_survive_a_later_failure(self):
        s=self.finished()
        for pid in s['project_ids']:self.engine.set(pid,script='林悦记得已经发生的事情。'*2600)
        class AI:
            config={'retry_limit':0}
            def __init__(inner,fail=False):inner.requests=[];inner.fail=fail
            async def text(inner,instructions,prompt,images=()):
                data=json.loads(prompt);inner.requests.append(data)
                if inner.fail and len(inner.requests)==2:raise RuntimeError('network interrupted')
                return {'summary':'已完成的剧情记录。'}
        failed=AI(True)
        with self.assertRaisesRegex(RuntimeError,'interrupted'):await self.series.remember_previous(s['id'],failed)
        checkpoint=self.series.record(s['id'])['memory_progress']
        self.assertEqual(checkpoint['offset'],24000)
        resumed=AI();await self.series.remember_previous(s['id'],resumed)
        self.assertEqual(resumed.requests[0]['previous_summary'],checkpoint['summary'])
        self.assertNotEqual(resumed.requests[0]['completed_script_excerpt'],failed.requests[0]['completed_script_excerpt'])
        self.assertTrue(all(len(r['completed_script_excerpt'])<=24000 for r in failed.requests+resumed.requests))
        record=self.series.record(s['id']);self.assertEqual(record['memory_through'],2);self.assertIsNone(record['memory_progress'])

    async def test_progress_response_is_small_but_export_keeps_exact_original_and_scripts(self):
        s=self.finished();long='原始剧本。'*50000
        s['text']=long;s['batches'][0]['text']=long;s['plan']['episodes'][0]['script']=long
        self.store.put('series',s['id'],s)
        self.assertLess(len(json.dumps(self.series.public(s['id']),ensure_ascii=False)),20000)
        exported=self.series.public(s['id'],export=True)
        self.assertEqual(exported['text'],long);self.assertEqual(exported['batches'][0]['text'],long)
        self.assertEqual(exported['plan']['episodes'][0]['script'],long)
