"""Acceptance regressions for the three independently reproduced v0.8.3 bugs."""
import copy
import importlib
import json
import types
import unittest
from unittest.mock import AsyncMock,patch
import test_production_draft as draft_tests
from test_image_series import image_fixture,iw

service=draft_tests.service
schema=draft_tests.schema

class DraftDialogueTests(unittest.TestCase):
    def named_draft(self,name):
        d=draft_tests.draft();d['characters']={name:d['characters']['女主']}
        e=d['episodes'][0];e['script']=name+'：你好。';s=e['segments'][0]
        s['characters']=[name];s['dialogue'][0]['speaker']=name
        return d

    def test_declared_metadata_names_and_long_names_are_real_speakers(self):
        for name in ('声音','时间','动作','避难所中央控制系统广播员'):
            with self.subTest(name=name):
                d=self.named_draft(name)
                self.assertEqual(schema.loads(d)['episodes'][0]['segments'][0]['dialogue'][0]['speaker'],name)

    def test_missing_dialogue_for_metadata_named_character_is_rejected(self):
        for name in ('声音','时间','动作'):
            with self.subTest(name=name):
                d=self.named_draft(name);s=d['episodes'][0]['segments'][0]
                s['dialogue']=[];s['shots'][0]['dialogue_indices']=[]
                with self.assertRaisesRegex(ValueError,'逐字、逐句'):schema.loads(d)

    def test_unknown_prefix_and_unclosed_quotes_are_not_silently_accepted(self):
        for script in ('女主甲：你好。','陌生角色：你好。','女主：“你好。'):
            with self.subTest(script=script):
                d=draft_tests.draft();d['episodes'][0]['script']=script
                with self.assertRaises(ValueError):schema.loads(d)

    def test_metadata_and_annotated_quoted_dialogue_keep_original_words(self):
        d=draft_tests.draft();d['episodes'][0]['script']='【场景：地下室】\n动作：女主坐下。\n女主（画外）：“你好。”'
        parsed=schema.loads(d)
        self.assertEqual(parsed['episodes'][0]['segments'][0]['dialogue'][0]['text'],'你好。')

class DraftExecutionTests(draft_tests.Fixture):
    asyncSetUp=draft_tests.DraftExecutionTests.asyncSetUp
    create=draft_tests.DraftExecutionTests.create

    def voice_draft(self):
        d=draft_tests.draft()
        old=self.files.write_asset(self.store,'old_voice.wav',b'old voice',{'role':'voice','label':'原声音','speaker':'女主'})
        new=self.files.write_asset(self.store,'new_voice.wav',b'new voice',{'role':'voice','label':'新声音','speaker':'女主'})
        d['assets'].append({'key':'voice','kind':'audio','role':'voice','label':'原声音','source':{'id':old['id']},'description':{'en':'The supplied voice reference.','zh':'提供的音色参考。'}})
        d['characters']['女主']['voice_key']='voice';d['episodes'][0]['segments'][0]['opening_frame_key']='hero'
        return d,old,new

    def replace_voice(self,record,new):
        return service.save_bindings(self.store,'series',record['id'],{'expected_revision':1,
            'character_bindings':{'女主':{'image_ids':[self.asset['id']],'voice_id':new['id']}}})

    async def test_unstarted_authored_opening_updates_voice_and_recompiles_real_audio(self):
        d,old,new=self.voice_draft();r=self.create(d);self.manager.create_children(r['id'])
        pid=self.store.get('series',r['id'])['project_ids'][0]
        ai=types.SimpleNamespace(text=AsyncMock(side_effect=AssertionError('No creative API')))
        await self.engine.prepare_clip(pid,0,ai,self.engine.config(self.store.get('project',pid)))
        self.assertFalse(self.graphs)
        result=self.replace_voice(r,new);self.assertEqual(result['updated_episodes'],1);self.assertEqual(result['retained_episodes'],0)
        p=self.store.get('project',pid);self.assertEqual(p['character_bindings']['女主']['voice_id'],new['id'])
        self.assertNotIn('compiled_media_bindings',p['clips'][0])
        with patch.object(draft_tests.providers.AIClient,'text',AsyncMock(side_effect=AssertionError('No creative API'))):
            result=await self.finish_series(r['id'])
        self.assertEqual(result['status'],'complete',result['error']);c=self.store.get('project',pid)['clips'][0]
        self.assertEqual([b['asset_id'] for b in c['compiled_media_bindings'] if b['reference'].startswith('<Audio')],[new['id']])
        self.assertEqual(c['frame_asset_id'],self.asset['id']);self.assertEqual(c['dialogue'][0]['text'],'你好。')

    async def test_completed_episode_keeps_previous_voice_and_output(self):
        d,old,new=self.voice_draft();r=await self.finish_series(self.create(d)['id'])
        self.assertEqual(r['status'],'complete',r['error']);pid=r['project_ids'][0];before=self.store.get('project',pid)
        result=self.replace_voice(r,new);self.assertEqual(result['retained_episodes'],1)
        after=self.store.get('project',pid);self.assertEqual(after['character_bindings']['女主']['voice_id'],old['id'])
        self.assertEqual(after['final'],before['final']);self.assertEqual(after['clips'][0]['output'],before['clips'][0]['output'])

    async def test_committed_video_or_image_intent_keeps_binding_but_future_episode_updates(self):
        for key in ('job_id','image_asset_id'):
            with self.subTest(intent=key):
                d,old,new=self.voice_draft();d['episodes'].append(copy.deepcopy(d['episodes'][0]))
                r=self.create(d);self.manager.create_children(r['id']);pids=self.store.get('series',r['id'])['project_ids']
                self.engine.clip_set(pids[0],0,**{key:'committed-original-intent'})
                result=self.replace_voice(r,new);self.assertEqual(result['retained_episodes'],1);self.assertEqual(result['updated_episodes'],1)
                self.assertEqual(self.store.get('project',pids[0])['character_bindings']['女主']['voice_id'],old['id'])
                self.assertEqual(self.store.get('project',pids[0])['clips'][0][key],'committed-original-intent')
                self.assertEqual(self.store.get('project',pids[1])['character_bindings']['女主']['voice_id'],new['id'])
        self.assertFalse(self.graphs)

    def shared_draft(self):
        d=draft_tests.draft();d['episodes'][0]['segments'][0]['opening_frame_key']='hero'
        for key,refs in [('room',[]),('door',[]),('shelf',[]),('combined',['room','door','shelf'])]:
            d['assets'].append({'key':key,'kind':'image','role':'scene','label':key,'description':{'en':'The '+key+' scene.','zh':'场景参考。'},
                'generate':{'image_prompt':'A realistic '+key+' in an underground shelter.','reference_keys':refs}})
        return d

    async def test_shared_capacity_overflow_rejected_before_records_and_submissions(self):
        two=iw.save(self.store,image_fixture('slots',slots=2));self.store.save_settings({'image_reference_workflow_id':two['id']})
        with self.assertRaisesRegex(ValueError,'共用素材 combined.*需要3张参考图'):self.create(self.shared_draft())
        for kind in ('series','project','image_job','quality_asset','api_request'):self.assertFalse(self.store.list(kind),kind)
        self.assertFalse(self.graphs);self.assertEqual(self.ai_calls,0);self.assertEqual(self.image_calls,0)

    async def test_matching_capacity_completes_and_reused_shared_assets_need_no_regeneration(self):
        three=iw.save(self.store,image_fixture('slots',slots=3));self.store.save_settings({'image_reference_workflow_id':three['id']})
        d=self.shared_draft()
        with patch.object(draft_tests.providers.AIClient,'text',AsyncMock(side_effect=AssertionError('No creative API'))):
            r=await self.finish_series(self.create(d)['id']);self.assertEqual(r['status'],'complete',r['error'])
            self.assertEqual(sum('out' in g for g in self.graphs),4)
            two=iw.save(self.store,image_fixture('slots',slots=2));self.store.save_settings({'image_reference_workflow_id':two['id']})
            current=self.manager.record(r['id'])
            self.manager.append(r['id'],{'input_type':'production_draft','text':json.dumps(d,ensure_ascii=False),
                'expected_revision':current['revision'],'request_id':'reuse-after-capacity-change'})
            r=await self.finish_series(r['id']);self.assertEqual(r['status'],'complete',r['error'])
            self.assertEqual(sum('out' in g for g in self.graphs),4)
        self.assertEqual(self.ai_calls,0);self.assertEqual(self.image_calls,0)

if __name__=='__main__':unittest.main()
