const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..','static');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const field=html.match(/<select name="dialogue_language">([\s\S]*?)<\/select>/);
assert(field,'spoken language selector must be visible');
assert.deepEqual([...field[1].matchAll(/value="([^"]+)"/g)].map(x=>x[1]),['auto','zh','en','ja']);
const source=fs.readFileSync(path.join(root,'app.js'),'utf8');
const snippet=source.slice(source.indexOf('async function loadSettings()'),source.indexOf('async function saveSettings()'));
const language={name:'dialogue_language',type:'select-one',value:'auto'};
const elements=[language];elements.namedItem=name=>elements.find(e=>e.name===name);
const saved={dialogue_language:'auto'};
const ctx={api:async()=>saved,imageProviderView(){},$:selector=>{
 assert.equal(selector,'#settings-form');return {elements};
}};
vm.createContext(ctx);vm.runInContext(snippet,ctx);
(async()=>{
 for(const value of ['auto','en','ja','zh']){
  saved.dialogue_language=value;await ctx.loadSettings();
  assert.equal(language.value,value);
  assert.equal(ctx.formSettings().dialogue_language,value);
 }
 assert(html.includes('页面 v0.8.3.11'));
 assert(source.includes('FRONTEND_VERSION="0.8.3.11"'));
 console.log('PASS: Chinese/English/Japanese/auto selector loads and serializes saved settings; frontend version matches.');
})().catch(error=>{console.error(error);process.exitCode=1;});
