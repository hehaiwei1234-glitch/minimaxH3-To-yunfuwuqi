"""Reproduce impossible extra-hold repairs without paying another API call."""
import copy
import importlib
import json
import math
import random
import types
import unittest
from unittest.mock import AsyncMock
from test_core import compiler_result, domain
import test_prompt_recovery as host

validation = importlib.import_module('h3ad_test.prompt_validation')
retention = importlib.import_module('h3ad_test.dialogue_retention')
planning = importlib.import_module('h3ad_test.dialogue_plan')
content = importlib.import_module('h3ad_test.prompt_content')
compiler = importlib.import_module('h3ad_test.prompt_compiler')
fingerprint = importlib.import_module('h3ad_test.production').fingerprint


def fixture(duration=9.5, cut=5.5):
    c = {'duration_seconds':duration, 'generation_seconds':duration, 'timing_version':1,
         'dialogue':[{'speaker':'林川','text':'先把门关好。'},
                     {'speaker':'林川','text':'能睡暖觉，能吃热饭。'}],
         'dialogue_timing':{'extra_seconds':1.5},
         'dialogue_retention':{'version':1, 'policy':'preserve_tail'}}
    c['dialogue_budget'] = planning.budget(c['dialogue'])
    r = compiler_result({'segment':c,'references':[]})
    r['shots'] = [{'start_seconds':a,'end_seconds':b,'dialogue_indices':[i],
                   'visual_en':'A close-up as the scientist speaks.' if i==0 else 'The camera moves toward the warm room.',
                   'visual_zh':'科学家说话的近景。' if i==0 else '镜头移向温暖的房间。'}
                  for i,(a,b) in enumerate(((0,cut),(cut,duration)))]
    return c,r


class SpeechTimingRecoveryTests(unittest.TestCase):
    def assert_preserved(self, before, after, c):
        self.assertEqual(len(before['shots']), len(after['shots']))
        for old,new in zip(before['shots'],after['shots']):
            for key in ('visual_en','visual_zh','dialogue_indices'):
                self.assertEqual(old[key],new[key])
        self.assertEqual(after['shots'][0]['start_seconds'],0)
        self.assertAlmostEqual(after['shots'][-1]['end_seconds'],c['duration_seconds'])
        for a,b in zip(after['shots'],after['shots'][1:]):
            self.assertAlmostEqual(a['end_seconds'],b['start_seconds'])
        validation.validate(after,[],c)

    def test_reproduced_two_shot_failure_is_fixed_without_rewriting(self):
        c,r=fixture();before=copy.deepcopy(r);oldclip=copy.deepcopy(c)
        self.assertTrue(any('单独留出句尾余量' in reason for _,reason in validation.issues(r,[],c)))
        fixed=validation.recover_structure(r,c,{})
        self.assert_preserved(before,fixed,c)
        self.assertEqual(c,oldclip);self.assertEqual(r,before)
        self.assertEqual(retention.extra_hold(c,fixed['shots'],2),1.5)

    def test_total_budget_cannot_fit_all_extra_silence_but_speech_is_preserved(self):
        c,r=fixture()
        required=[planning.budget([line])['minimum_seconds'] for line in c['dialogue']]
        total=sum(required)+.5
        c.update(duration_seconds=total,generation_seconds=total)
        r['shots'][0]['end_seconds']=required[0]
        r['shots'][1].update(start_seconds=required[0],end_seconds=total)
        self.assertTrue(validation.issues(r,[],c))
        fixed=validation.recover_structure(r,c,{})
        self.assert_preserved(r,fixed,c)
        self.assertAlmostEqual(retention.extra_hold(c,fixed['shots'],2),.5)
        self.assertTrue(any('0.500秒' in note for note in fixed['_content_warnings']))

    def test_silent_time_is_borrowed_before_other_speech_time(self):
        c,r=fixture(12,2)
        first,last=r['shots']
        r['shots']=[{**first,'end_seconds':1},
                    {'start_seconds':1,'end_seconds':7,'dialogue_indices':[],
                     'visual_en':'Steam rises from soup.','visual_zh':'汤碗升起热气。'},
                    {**last,'start_seconds':7,'end_seconds':12}]
        fixed=validation.recover_structure(r,c,{})
        self.assert_preserved(r,fixed,c)
        self.assertEqual(fixed['shots'][2]['start_seconds'],7)
        self.assertLess(fixed['shots'][1]['end_seconds']-fixed['shots'][1]['start_seconds'],6)

    def test_valid_cuts_and_original_speech_deadline_are_unchanged(self):
        c,r=fixture(12,5)
        self.assertFalse(validation.issues(r,[],c))
        fixed=validation.recover_structure(r,c,{})
        self.assertEqual(fixed['shots'],r['shots'])

    def test_truly_insufficient_base_speech_budget_remains_invalid(self):
        c,r=fixture(3,1)
        fixed=validation.recover_structure(r,c,{})
        self.assertEqual(fixed['shots'],r['shots'])
        self.assertTrue(validation.issues(fixed,[],c))
        self.assertFalse(any('_speech_timing_contract' in s for s in fixed['shots']))

    def test_duplicate_or_invalid_line_ownership_is_not_guessed(self):
        for indices in ([0],[99],[True],[],['garbage']):
            c,r=fixture();r['shots'][1]['dialogue_indices']=indices
            fixed=validation.recover_structure(r,c,{})
            self.assertEqual(fixed['shots'],r['shots'])
            self.assertTrue(validation.issues(fixed,[],c))

    def test_internal_gaps_and_nonfinite_cuts_are_not_silently_repaired(self):
        for value in (4.,float('nan'),float('inf'),None):
            c,r=fixture();r['shots'][0]['end_seconds']=value
            fixed=validation.recover_structure(r,c,{})
            self.assertTrue(validation.issues(fixed,[],c))
            self.assertFalse(any('_speech_timing_contract' in s for s in fixed['shots']))

    def test_recovery_is_idempotent_and_does_not_accept_injected_reserve(self):
        c,r=fixture()
        r['shots'][1].update(_speech_timing_contract=1,_speech_reserved_extra_seconds=-100)
        fixed=validation.recover_structure(r,c,{})
        for _ in range(6):
            again=validation.recover_structure(fixed,c,{})
            self.assertEqual(again,fixed)
        self.assertEqual(retention.extra_hold(c,fixed['shots'],2),1.5)

    def test_committed_and_legacy_tasks_do_not_gain_time_recovery(self):
        c,r=fixture()
        for key in ('job_id','prompt_id','api_graph','submission_unknown','raw_output','output'):
            committed={**c,key:'existing'};shots=copy.deepcopy(r['shots'])
            self.assertEqual(validation.recover_speech_timing(shots,committed),[])
            self.assertEqual(shots,r['shots'])
        c.pop('dialogue_retention');shots=copy.deepcopy(r['shots'])
        self.assertEqual(validation.recover_speech_timing(shots,c),[])
        self.assertEqual(shots,r['shots'])

    def test_fixed_duration_is_never_extended_and_direct_compiler_remains_strict(self):
        c,r=fixture();c['dialogue_retention']['policy']='fixed'
        with self.assertRaises(validation.InvalidContent):
            validation.validate(r,[],c)
        fixed=validation.recover_structure(r,c,{})
        self.assert_preserved(r,fixed,c)
        self.assertEqual(c['generation_seconds'],9.5)

    def test_guide_offset_and_compiled_dialogue_are_preserved(self):
        c,r=fixture();guide=22/24
        for shot in r['shots']:
            for key in ('start_seconds','end_seconds'):shot[key]+=guide
        axis={'new_content_start_seconds':guide}
        fixed=validation.recover_structure(r,c,axis)
        out=compiler.compile_prompt(fixed,[],domain.media_state([],[],[]),c,axis)
        for line,window in zip(c['dialogue'],out['dialogue_windows']):
            self.assertEqual(out['prompt_en'].count('<d>[Chinese] '+line['text']+'</d>'),1)
            self.assertAlmostEqual(window['generated_start_seconds']-window['start_seconds'],guide)
            self.assertGreaterEqual(window['end_seconds'],window['start_seconds'])
            self.assertLessEqual(window['end_seconds']+window['reserved_tail_seconds'],window['shot_end_seconds']+1e-6)

    def test_many_feasible_distributions_keep_words_bounds_and_full_base_budget(self):
        rng=random.Random(20261007)
        for count in (1,2,3,5):
            for _ in range(35):
                lines=[{'speaker':'林川','text':'先关好门。'+'暖'*rng.randrange(5)+'。'} for _ in range(count)]
                base=[planning.budget([line])['minimum_seconds'] for line in lines]
                duration=sum(base)+rng.random()*2
                if duration>15:continue
                c={'duration_seconds':duration,'generation_seconds':duration,'dialogue':lines,
                   'dialogue_budget':planning.budget(lines),'dialogue_retention':{'version':1},
                   'dialogue_timing':{'extra_seconds':1.5}}
                raw=[rng.random()+.001 for _ in lines]
                cursor=0.;r=compiler_result({'segment':c,'references':[]});r['shots']=[]
                for i,value in enumerate(raw):
                    end=duration if i==count-1 else cursor+duration*value/sum(raw)
                    r['shots'].append({'start_seconds':cursor,'end_seconds':end,'dialogue_indices':[i],
                                       'visual_en':f'Camera movement {i}.','visual_zh':f'镜头动作{i}。'})
                    cursor=end
                fixed=validation.recover_structure(r,c,{})
                self.assert_preserved(r,fixed,c)
                self.assertEqual(validation.recover_structure(fixed,c,{}),fixed)


class SavedTimingRecoveryTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=host.PromptRecoveryTests.asyncSetUp
    asyncTearDown=host.PromptRecoveryTests.asyncTearDown
    setup_content=host.PromptRecoveryTests.setup_content

    def prepare_old_failure(self):
        c,r=fixture();self.clip={**c,'title':'保暖','continuity':'cut'}
        r['reference_descriptions']={'ref_1':{'en':'The young scientist.','zh':'年轻科学家。'}}
        self.result=r
        self.request={'compiler_contract':compiler.VERSION,'segment':copy.deepcopy(self.clip),
                      'references':compiler.request_references(self.assets),'time_axis':self.axis}
        previous={**self.request,'compiler_contract':4}
        assets=content.actual_assets(self.engine,self.assets)
        bindings=self.store.get('project',self.project['id']).get('character_bindings',{})
        ctx=fingerprint({'request':json.dumps(previous,ensure_ascii=False),
                         'assets':[content.asset_key(a) for a in assets],'bindings':bindings})
        self.clip['prompt_content']={'version':2,'context':ctx,'status':'needs_fields',
             'result':copy.deepcopy(r),'received_result':copy.deepcopy(r),'repair_attempts':2,
             'invalid_fields':validation.issues(r,self.assets,self.clip)}
        self.engine.set(self.project['id'],clips=[copy.deepcopy(self.clip)])

    async def run_saved(self,ai):
        return await content.compile_saved(self.engine,self.project['id'],0,ai,compiler.INSTRUCTIONS,
            json.dumps(self.request,ensure_ascii=False),self.assets,self.media,self.axis)

    async def test_stopped_v4_content_resumes_with_zero_paid_calls(self):
        self.prepare_old_failure()
        ai=types.SimpleNamespace(config={'retry_limit':1},text=AsyncMock(side_effect=AssertionError('Must not call API')))
        out=await self.run_saved(ai)
        self.assertEqual(ai.text.await_count,0)
        self.assertEqual(out['prompt_compiler_version'],compiler.VERSION)
        saved=self.store.get('project',self.project['id'])['clips'][0]['prompt_content']
        self.assertEqual(saved['status'],'compiled_content');self.assertEqual(saved['repair_attempts'],0)
        self.assertEqual(saved['received_result'],self.result)

    async def test_changed_real_asset_requires_new_content(self):
        self.prepare_old_failure()
        self.files.asset_path(self.asset).write_bytes(b'changed-real-reference')
        ai=types.SimpleNamespace(config={'retry_limit':1},text=AsyncMock(return_value=self.result))
        await self.run_saved(ai)
        self.assertEqual(ai.text.await_count,1)

    async def test_changed_feedback_is_not_hidden_by_upgrade_reuse(self):
        self.prepare_old_failure()
        self.clip['redo_feedback']='改成清晰的林川近景。'
        self.request['segment']['redo_feedback']=self.clip['redo_feedback']
        self.engine.set(self.project['id'],clips=[self.clip])
        ai=types.SimpleNamespace(config={'retry_limit':1},text=AsyncMock(return_value=self.result))
        await self.run_saved(ai)
        self.assertEqual(ai.text.await_count,1)

    async def test_engine_resumes_stopped_clip_without_api_or_duplicate_padding(self):
        self.prepare_old_failure()
        self.clip.update(asset_ids=[self.asset['id']],generation=1,seed=123,
                         generation_exact=False)
        self.clip['dialogue_timing'].update(initial_applied=True,version=1,
             base_duration_seconds=8.,base_generation_seconds=8.,
             initial_padding_seconds=1.5,retry_padding_seconds=0.)
        cfg=domain.validate_settings({'generate_shot_images':False})
        self.engine.set(self.project['id'],clips=[copy.deepcopy(self.clip)],plan={'style':'realistic'})
        p=self.store.get('project',self.project['id'])
        axis=domain.video_timing(self.clip,cfg)
        request={'compiler_contract':4,
                 'segment':{k:self.clip.get(k) for k in ('title','duration_seconds','continuity',
                     'visual_zh','camera_zh','dialogue','sound_zh','redo_feedback','dialogue_budget','dialogue_timing')},
                 'style':'realistic','user_instructions':p['instructions'],
                 'references':compiler.request_references(self.assets),
                 'previous_segment':None,'time_axis':axis}
        actual=content.actual_assets(self.engine,self.assets)
        ctx=fingerprint({'request':json.dumps(request,ensure_ascii=False),
                         'assets':[content.asset_key(a) for a in actual],
                         'bindings':p.get('character_bindings',{})})
        self.clip['prompt_content']['context']=ctx
        timing=copy.deepcopy(self.clip['dialogue_timing'])
        self.engine.set(self.project['id'],clips=[copy.deepcopy(self.clip)])
        ai=types.SimpleNamespace(config={'retry_limit':1},text=AsyncMock(side_effect=AssertionError('No paid call')))
        await self.engine.prepare_clip(self.project['id'],0,ai,cfg)
        saved=self.store.get('project',self.project['id'])['clips'][0]
        self.assertEqual(ai.text.await_count,0)
        self.assertEqual(saved['status'],'ready')
        self.assertEqual(saved['duration_seconds'],9.5)
        self.assertEqual(saved['dialogue_timing'],timing)
        self.assertEqual(saved['prompt_compiler_version'],compiler.VERSION)


if __name__=='__main__':unittest.main()
