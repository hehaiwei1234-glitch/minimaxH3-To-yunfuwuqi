from __future__ import annotations
import copy
import importlib
import json
import tempfile
import unittest
from pathlib import Path
from test_core import ROOT, Store, domain, ComfyClient
w=importlib.import_module('h3ad_test.workflows')

def fixture():
    original=json.loads((ROOT/'templates/h3_api.json').read_text())
    graph=domain.build_graph(original,{'prompt_en':'original','duration_seconds':4,'seed':2**63+17,'continuity':'cut'},
                             {**domain.DEFAULTS,'steps':23,'width':1024,'height':384},domain.media_state(['原图 中文.png'],[],[]),None,'original/video')
    ids={nid:'node_'+nid for nid in graph}
    for node in graph.values():
        for key,value in node['inputs'].items():
            if w.is_link(value) and value[0] in ids:node['inputs'][key]=[ids[value[0]],value[1]]
        if node['class_type']=='UNETLoader':node['inputs']['unet_name']='local_bf16.safetensors'
        if node['class_type']=='CLIPLoader':node['inputs']['clip_name']='local_clip_fp16.safetensors'
    graph={ids[nid]:node for nid,node in graph.items()}
    refs={'prompt':('39','value'),'media':('38','batch_media_json'),'duration':('10','value'),'prefix':('20','filename_prefix'),
          'seed':('18','noise_seed'),'fps':('30','fps'),'width':('38','width'),'height':('38','height')}
    return {'name':'本地工作流','graph':graph,'bindings':{role:{'node':'node_'+nid,'input':field} for role,(nid,field) in refs.items()},
            'output_node_id':'node_20','media_mode':'batch','duration_mode':'frames','seed_mode':'original','tested_by_user':True}

class WorkflowTests(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.store=Store(Path(self.temp.name));self.body=fixture()
    def tearDown(self):self.temp.cleanup()
    def test_only_whitelisted_fields_change_and_source_stays_exact(self):
        saved=w.save(self.store,self.body);before=copy.deepcopy(saved['graph'])
        clip={'prompt_en':'new prompt','seed':2**63+29,'continuity':'cut','duration_seconds':12}
        graph=w.instantiate(saved,clip,domain.media_state(['新图 中文.png'],[],[]),None,'new/project')
        changes={(nid,key) for nid in before for key,value in before[nid]['inputs'].items() if value!=graph[nid]['inputs'][key]}
        self.assertEqual(changes,{('node_39','value'),('node_38','batch_media_json'),('node_20','filename_prefix'),('node_18','noise_seed')})
        self.assertEqual(before,saved['graph']);self.assertEqual(before,self.body['graph'])
        self.assertEqual(graph['node_12']['inputs']['value'],23)
        self.assertEqual(graph['node_38']['inputs']['width'],1024)
        self.assertEqual(graph['node_10']['inputs']['value'],107)
        self.assertEqual(graph['node_30']['inputs']['bit_depth'],10)
        self.assertTrue(any(n['inputs'].get('unet_name')=='local_bf16.safetensors' for n in graph.values()))
    def test_exact_large_seed_is_preserved_from_raw_json_string(self):
        self.body['graph']=json.dumps(self.body['graph']);saved=w.save(self.store,self.body)
        self.assertEqual(saved['graph']['node_18']['inputs']['noise_seed'],2**63+17)
        self.assertEqual(w.summary(saved)['metadata']['seed'],str(2**63+17))
    def test_downloaded_record_can_be_reimported_without_large_integer_rounding(self):
        saved=w.save(self.store,self.body);source=json.dumps(saved)
        again=w.save(self.store,{**self.body,'graph':source,'name':'项目副本'})
        self.assertEqual(again['graph'],saved['graph']);self.assertNotEqual(again['id'],saved['id'])
    def test_node_ids_named_output_or_graph_are_not_mistaken_for_wrappers(self):
        for name in ('output','graph','prompt'):
            graph=copy.deepcopy(self.body['graph']);graph[name]={'class_type':'PrimitiveString','inputs':{'value':'test'}}
            self.assertEqual(w.api_graph(graph),graph)
    def test_project_keeps_old_template_after_new_version_and_restart(self):
        first=w.save(self.store,self.body);p=self.store.create_project({'script':'你好','workflow_id':first['id']})
        revised={**self.body,'id':first['id'],'expected_version':1};revised['graph']=copy.deepcopy(self.body['graph']);revised['graph']['node_12']['inputs']['value']=9
        second=w.save(self.store,revised);self.assertEqual(second['version'],2)
        again=Store(self.store.root);self.assertEqual(again.get('project',p['id'])['workflow_snapshot']['graph']['node_12']['inputs']['value'],23)
        self.assertEqual(again.get('workflow',first['id'])['graph']['node_12']['inputs']['value'],9)
        self.assertNotIn('graph',again.public_project(p['id'])['workflow_snapshot'])
    def test_version_conflict_does_not_overwrite(self):
        first=w.save(self.store,self.body)
        with self.assertRaises(ValueError):w.save(self.store,{**self.body,'id':first['id'],'expected_version':0})
        self.assertEqual(self.store.get('workflow',first['id'])['version'],1)
    def test_reject_unverified_import(self):
        with self.assertRaises(ValueError):w.save(self.store,{**self.body,'tested_by_user':False})
    def test_reject_canvas_instead_of_guessing_widget_order(self):
        with self.assertRaisesRegex(ValueError,'普通画布'):w.preview({'nodes':[{'id':1,'widgets_values':['x']}]})
    def test_reject_dangling_connection(self):
        self.body['graph']['node_30']['inputs']['images']=['missing',0]
        with self.assertRaisesRegex(ValueError,'不存在'):w.save(self.store,self.body)
    def test_reject_cycle(self):
        self.body['graph']['node_39']['inputs']['bad']=['node_20',0]
        with self.assertRaisesRegex(ValueError,'循环'):w.save(self.store,self.body)
    def test_reject_connected_input_binding(self):
        self.body['bindings']['duration']={'node':'node_38','input':'length'}
        with self.assertRaisesRegex(ValueError,'上游'):w.save(self.store,self.body)
    def test_reject_duplicate_roles(self):
        self.body['bindings']['prefix']=self.body['bindings']['prompt']
        with self.assertRaisesRegex(ValueError,'同时'):w.save(self.store,self.body)
    def test_reject_disconnected_prompt_binding(self):
        self.body['graph']['unused']={'class_type':'PrimitiveString','inputs':{'value':'unused'}}
        self.body['bindings']['prompt']={'node':'unused','input':'value'}
        with self.assertRaisesRegex(ValueError,'没有连接'):w.save(self.store,self.body)
    def test_encoding_fps_does_not_extend_h3_dialogue_budget(self):
        self.body['graph']['node_30']['inputs']['fps']=16
        saved=w.save(self.store,self.body);self.assertAlmostEqual(saved['metadata']['duration_seconds'],107/24)
        self.assertAlmostEqual(w.timing(saved,{'continuity':'cut'})['new_content_end_seconds'],107/24)
        self.assertEqual(saved['graph']['node_30']['inputs']['fps'],16)
        del self.body['bindings']['fps']
        self.assertAlmostEqual(w.save(self.store,self.body)['metadata']['duration_seconds'],107/24)
    def test_unknown_batch_interface_needs_adaptation(self):
        self.body['graph']['node_38']['inputs']['unknown_media']=''
        self.body['bindings']['media']['input']='unknown_media'
        with self.assertRaisesRegex(ValueError,'需适配'):w.save(self.store,self.body)
    def test_continue_needs_all_three_bindings(self):
        self.body['bindings']['previous_video']=self.body['bindings']['prompt'];del self.body['bindings']['prompt']
        with self.assertRaises(ValueError):w.save(self.store,self.body)
    def test_output_disabled_is_rejected_before_paid_calls(self):
        self.body['graph']['node_20']['inputs']['save_output']=False
        with self.assertRaisesRegex(ValueError,'启用保存'):w.save(self.store,self.body)
    def test_dynamic_output_selects_only_bound_node(self):
        entry={'status':{'completed':True},'outputs':{'20':{'images':[{'filename':'wrong.mp4'}]},'node_20':{'videos':[{'filename':'correct.mp4'}]}}}
        self.assertEqual(ComfyClient.output(entry,'node_20')['filename'],'correct.mp4')
        with self.assertRaises(Exception):ComfyClient.output(entry,'missing_output')
    def test_unbound_seed_is_not_changed(self):
        del self.body['bindings']['seed'];saved=w.save(self.store,self.body)
        graph=w.instantiate(saved,{'prompt_en':'new','seed':5,'continuity':'cut'},domain.media_state(['a.png'],[],[]),None,'p')
        self.assertEqual(graph['node_18']['inputs']['noise_seed'],2**63+17)
        with self.assertRaises(ValueError):w.save(self.store,{**self.body,'seed_mode':'random'})
    def test_single_image_contract_replaces_one_load_image_and_rejects_extra_refs(self):
        self.body['graph']['load_image']={'class_type':'LoadImage','inputs':{'image':'原图 中文.png'}}
        self.body['graph']['node_38']['inputs']['image_reference']=['load_image',0]
        self.body['bindings']['media']={'node':'load_image','input':'image'};self.body['media_mode']='single_image'
        saved=w.save(self.store,self.body)
        clip={'prompt_en':'new','seed':None,'continuity':'cut'}
        graph=w.instantiate(saved,clip,domain.media_state(['自动开场图.png'],[],[]),None,'p')
        self.assertEqual(graph['load_image']['inputs']['image'],'自动开场图.png')
        self.assertEqual(saved['graph']['load_image']['inputs']['image'],'原图 中文.png')
        with self.assertRaisesRegex(ValueError,'一张'):w.instantiate(saved,clip,domain.media_state(['a.png','b.png'],[],[]),None,'p')

if __name__=='__main__':unittest.main()
