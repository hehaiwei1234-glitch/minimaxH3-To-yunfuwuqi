// 完成提醒声测试：真浏览器 + 假后端 + 假的 AudioContext（只记录“响了什么”），不调用任何付费接口。
// 运行：node tests/test_finish_alert_browser.cjs   需要 playwright 和 Chromium。
const assert = require('node:assert/strict');
const F = require('./fake_backend.cjs');

// 假声音设备：记录每个振荡器的音高和波形；state 可以设成 suspended 模拟“浏览器还没允许出声”。
const FAKE_AUDIO = `
window.__beeps = [];
window.__audioState = window.__audioState || 'running';
class FakeParam { constructor(){ this.value = 0; } setValueAtTime(){} exponentialRampToValueAtTime(){} }
class FakeAudioContext {
  constructor(){ if (window.__audioThrows) throw new Error('no audio device'); this.currentTime = 0; this.destination = {}; this.state = window.__audioState; window.__contexts = (window.__contexts || 0) + 1; }
  resume(){ if (window.__audioState === 'running') this.state = 'running'; return Promise.resolve(); }
  createGain(){ return {gain: new FakeParam(), connect(){}}; }
  createOscillator(){ const o = {frequency: new FakeParam(), type: '', connect(){}, stop(){}, start(){ window.__beeps.push({hz: o.frequency.value, type: o.type}); }}; return o; }
}
window.AudioContext = FakeAudioContext;
`;

async function open(browser, url, {init = '', gesture = true} = {}) {
  const context = await browser.newContext({viewport: {width: 1280, height: 800}});
  const page = await context.newPage();
  page.pageErrors = [];
  page.on('pageerror', e => page.pageErrors.push(e.message));
  await page.addInitScript(FAKE_AUDIO + init);
  await page.goto(url);
  await F.waitReady(page);
  if (gesture) await page.click('#finish-alert-test'); // 用户点一下页面：浏览器允许出声（同时试听，计一次三声）
  if (gesture) await page.evaluate(() => { window.__beeps.length = 0; });
  return page;
}
const beeps = page => page.evaluate(() => window.__beeps.map(b => Math.round(b.hz)));
const DONE = [523, 659, 784], ATTENTION = [330, 330];
const waitBeeps = (page, n) => page.waitForFunction(count => window.__beeps.length >= count, n, {timeout: 9000});
const noticeText = page => page.textContent('#notice');

async function scenario(browser, name, project, fn) {
  const state = {series: {ser1: F.seriesRecord({status: 'running', phase: '制作中'})}, assets: [], projects: []};
  const {server, url} = await F.startServer(state);
  try { await fn(state, url); } finally { server.close(); }
  console.log('  ok', name);
}

(async () => {
  const browser = await F.launch();
  try {
    await scenario(browser, '打开页面时已经是完成状态：不响', null, async (state, url) => {
      state.series.ser1.status = 'complete';
      const page = await open(browser, url);
      await F.sleep(7000); // 两次以上刷新
      assert.deepEqual(await beeps(page), []);
      assert.deepEqual(page.pageErrors, []);
      await page.context().close();
    });

    await scenario(browser, '整剧制作中→已完成：响一次三声由低到高，并写明是哪一部', null, async (state, url) => {
      const page = await open(browser, url);
      await F.sleep(3500); // 先看到“制作中”
      state.series.ser1.status = 'complete';
      await waitBeeps(page, 3);
      await F.sleep(4000); // 之后继续刷新也不会再响
      assert.deepEqual(await beeps(page), DONE);
      assert.match(await noticeText(page), /整剧已全部完成：测试剧/);
      assert.deepEqual(page.pageErrors, []);
      await page.context().close();
    });

    await scenario(browser, '制作中→部分完成：两声低而短（需要处理）', null, async (state, url) => {
      const page = await open(browser, url);
      await F.sleep(3500);
      state.series.ser1.status = 'partial';
      await waitBeeps(page, 2);
      await F.sleep(3500);
      assert.deepEqual(await beeps(page), ATTENTION);
      assert.match(await noticeText(page), /需要处理：测试剧/);
      await page.context().close();
    });

    await scenario(browser, '自己点“暂停”后停下：不响；其后再继续又完成：响', null, async (state, url) => {
      const page = await open(browser, url);
      await F.sleep(3500);
      state.series.ser1.status = 'pausing';
      await F.sleep(3500);
      state.series.ser1.status = 'paused';
      await F.sleep(4000);
      assert.deepEqual(await beeps(page), []);
      state.series.ser1.status = 'running';
      await F.sleep(3500);
      state.series.ser1.status = 'complete';
      await waitBeeps(page, 3);
      assert.deepEqual(await beeps(page), DONE);
      await page.context().close();
    });

    await scenario(browser, '制作中直接变成已暂停（不是自己点的）：算需要处理', null, async (state, url) => {
      const page = await open(browser, url);
      await F.sleep(3500);
      state.series.ser1.status = 'paused';
      await waitBeeps(page, 2);
      assert.deepEqual(await beeps(page), ATTENTION);
      await page.context().close();
    });

    await scenario(browser, '整剧里的每一集完成不响；单独制作的一集完成才响', null, async (state, url) => {
      state.series.ser1.status = 'complete';
      state.projects = [
        {id: 'e1', title: '第1集', status: 'running', series_id: 'ser1'},
        {id: 'solo', title: '单独一集', status: 'running', series_id: null}];
      const page = await open(browser, url);
      await F.sleep(3500);
      state.projects[0].status = 'complete';
      await F.sleep(4000);
      assert.deepEqual(await beeps(page), [], '整剧里的集不应单独响');
      state.projects[1].status = 'complete';
      await waitBeeps(page, 3);
      assert.deepEqual(await beeps(page), DONE);
      assert.match(await noticeText(page), /单集已全部完成：单独一集/);
      await page.context().close();
    });

    await scenario(browser, '关闭提醒声：不响，但状态栏仍说明；设置记住；重新打开又响', null, async (state, url) => {
      const page = await open(browser, url);
      assert.equal((await page.textContent('#finish-alert-toggle')).trim(), '提醒声：开');
      await page.click('#finish-alert-toggle');
      assert.equal((await page.textContent('#finish-alert-toggle')).trim(), '提醒声：关');
      assert.equal(await page.evaluate(() => localStorage.getItem('h3ad_finish_alert')), 'off');
      assert.deepEqual(await beeps(page), [], '关闭时点按钮不应响');
      await F.sleep(3500);
      state.series.ser1.status = 'complete';
      await page.waitForFunction(() => /整剧已全部完成/.test(document.querySelector('#notice').textContent), null, {timeout: 9000});
      assert.deepEqual(await beeps(page), []);
      // 刷新页面后设置仍是“关”
      await page.reload(); await F.waitReady(page);
      assert.equal((await page.textContent('#finish-alert-toggle')).trim(), '提醒声：关');
      await page.click('#finish-alert-toggle'); // 打开时试听一次
      assert.deepEqual(await beeps(page), DONE);
      assert.equal(await page.evaluate(() => localStorage.getItem('h3ad_finish_alert')), 'on');
      await page.context().close();
    });

    await scenario(browser, '浏览器还没允许出声：状态栏说清楚原因，页面不报错', null, async (state, url) => {
      const page = await open(browser, url, {init: "window.__audioState='suspended';", gesture: false});
      await F.sleep(3500);
      state.series.ser1.status = 'complete';
      await page.waitForFunction(() => /没响：浏览器还没允许出声/.test(document.querySelector('#notice').textContent), null, {timeout: 9000});
      assert.deepEqual(await beeps(page), []);
      await page.click('#finish-alert-test');
      assert.match(await noticeText(page), /没有响：浏览器还没允许出声/);
      assert.deepEqual(page.pageErrors, []);
      await page.context().close();
    });

    await scenario(browser, '没有声音设备（AudioContext 不存在或创建失败）：照常使用，不报错', null, async (state, url) => {
      for (const init of ['window.AudioContext=undefined;window.webkitAudioContext=undefined;', 'window.__audioThrows=true;']) {
        state.series.ser1.status = 'running';
        const page = await open(browser, url, {init, gesture: false});
        await F.sleep(3500);
        state.series.ser1.status = 'complete';
        await page.waitForFunction(() => /整剧已全部完成/.test(document.querySelector('#notice').textContent), null, {timeout: 9000});
        await page.click('#finish-alert-test');
        // 页面其他功能照常：能打开整剧详情
        await page.click('[data-series]');
        await page.waitForSelector('#series-detail:not(.hidden)');
        assert.deepEqual(page.pageErrors, [], init);
        await page.context().close();
      }
    });

    await scenario(browser, '已归档的剧状态变化：不响', null, async (state, url) => {
      const page = await open(browser, url);
      await F.sleep(3500);
      state.series.ser1.archived = true; state.series.ser1.status = 'complete';
      await F.sleep(4500);
      assert.deepEqual(await beeps(page), []);
      await page.context().close();
    });

    console.log('finish alert browser: all scenarios passed');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });
