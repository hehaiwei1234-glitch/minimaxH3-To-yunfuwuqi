"""Real media regression: an audio tail must not move a visual state seek."""
import copy
import importlib
import tempfile
import unittest
from pathlib import Path
from test_core import ROOT, Store, Files, domain

Engine=importlib.import_module('h3ad_test.engine').Engine
media=importlib.import_module('h3ad_test.media_tools')


class StateFrameAudioTailTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.store=Store(self.root/'data');self.files=Files(self.root/'input',self.root/'output')
        self.engine=Engine(self.store,self.files,ROOT,'http://127.0.0.1:1')
        self.cfg=domain.validate_settings({})
        self.source=self.files.output/'短画面_长音频.mp4'
        await media.command(['ffmpeg','-y','-v','error','-f','lavfi','-i',
            'testsrc2=s=64x64:r=24:d=0.5','-f','lavfi','-i','sine=frequency=440:duration=1.5',
            '-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac',self.source])
        self.meta=await media.probe(self.source,self.cfg)
        self.project=self.store.create_project({'script':'继续观察。'})

    async def asyncTearDown(self):self.temp.cleanup()

    def set_clips(self,meta):
        clips=[{'duration_seconds':.5,'generation':1,'seed':123,'dialogue':[],
                'output':self.files.descriptor(self.source),'meta':meta,'quality_accepted':True},
               {'duration_seconds':2,'generation':1,'seed':456,'continuity':'continue',
                'depends_on_previous':True,'dialogue':[]}]
        self.engine.set(self.project['id'],clips=clips)

    async def test_stream_duration_extracts_last_picture_despite_longer_audio(self):
        self.assertGreater(self.meta['duration'],float(self.meta['video']['duration'])+.8)
        # Reproduce the old successful FFmpeg command that creates no file.
        bad=self.root/'old_seek.png'
        await media.command(['ffmpeg','-y','-v','error','-ss',str(self.meta['duration']-.08),
                             '-i',self.source,'-frames:v','1',bad])
        self.assertFalse(bad.exists())
        self.set_clips(self.meta)
        saved=await self.engine.state_reference(self.project['id'],1,self.cfg)
        self.assertTrue(saved.is_file());self.assertGreater(saved.stat().st_size,0)
        self.assertEqual(self.store.get('project',self.project['id'])['clips'][0]['output'],self.files.descriptor(self.source))
        again=await self.engine.state_reference(self.project['id'],1,self.cfg)
        self.assertEqual(again,saved)

    async def test_missing_stream_duration_uses_actual_last_frame_index(self):
        meta=copy.deepcopy(self.meta);meta['video'].pop('duration',None)
        self.set_clips(meta)
        saved=await self.engine.state_reference(self.project['id'],1,self.cfg)
        expected=self.root/'actual_last.png'
        await media.command(['ffmpeg','-y','-v','error','-i',self.source,'-an',
            '-vf',f"select=eq(n\\,{int(meta['video']['nb_frames'])-1})",'-frames:v','1',expected])
        self.assertEqual(saved.read_bytes(),expected.read_bytes())


if __name__=='__main__':unittest.main()
