const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.join(__dirname,'../static'),html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]);
assert.equal(new Set(ids).size,ids.length);
assert(html.includes('name="format_retry_limit"'));assert(html.includes('name="series_continue_on_error"'));
const elements=Object.fromEntries(ids.map(id=>[id,{id,disabled:false,innerHTML:'',textContent:'',dataset:{},classList:{toggle(){},add(){},remove(){}}}]));
const buttons=[],calls=[];
const c={console,$:s=>{assert(elements[s.slice(1)],s);return elements[s.slice(1)]},
 $$:s=>s==='[data-retry-episode]'?buttons:[],esc:s=>String(s??'').replace(/[<>&"']/g,x=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&#39;'}[x])),
 statuses:{complete:'已完成',partial:'有集待补做',deferred:'待补做',running:'运行中'},
 guarded:f=>f,managementButtons:()=>'',bindManagement(){},notice(){},BASE:'/',api:async(route,body)=>{calls.push({route,body});return {}},openProject(){}};
vm.createContext(c);vm.runInContext(fs.readFileSync(path.join(root,'series.js'),'utf8'),c);
const series={id:'s',title:'测试',status:'partial',active:false,phase:'待补做',error:'',can_append:true,batches:[{}],shared_asset_count:2,next_episode_number:19,
 episodes:[{id:'failed',title:'第17集',status:'deferred',phase:'格式失败',error:'<script>bad</script>',editable:true},{id:'done',title:'第18集',status:'complete',phase:'已完成'}],events:[]};
vm.runInContext('currentSeries='+JSON.stringify(series),c);c.renderSeries();
assert.match(elements['series-summary'].textContent,/1集待补做/);
assert.equal(elements['resume-series'].disabled,true);assert.equal(elements['append-series'].disabled,false);
assert(elements['series-episodes'].innerHTML.includes('data-retry-episode="failed"'));
assert(!elements['series-episodes'].innerHTML.includes('data-retry-episode="done"'));
assert(elements['series-episodes'].innerHTML.includes('&lt;script&gt;'));
assert(!elements['series-episodes'].innerHTML.includes('<script>'));
const b={disabled:false,dataset:{retryEpisode:'failed'}};buttons.push(b);c.renderSeries();
vm.runInContext('openSeries=async()=>{currentSeries.active=true}',c);
let finish;c.api=async(route,body)=>{calls.push({route,body});await new Promise(resolve=>finish=resolve);return {}};
(async()=>{
 const first=b.onclick();await b.onclick();assert.equal(calls.length,1);assert.equal(b.disabled,true);
 assert.equal(calls[0].route,'series/s/episodes/failed/retry');finish();await first;assert.equal(b.disabled,true);
 vm.runInContext('currentSeries.active=true',c);c.renderSeries();assert.equal(elements['append-series'].disabled,true);
assert(elements['series-episodes'].innerHTML.includes('data-retry-episode="failed" disabled'));
 vm.runInContext('currentSeries.active=false;currentSeries.can_resume=true',c);c.renderSeries();
 assert.equal(elements['resume-series'].disabled,false,'failed initial/pending batch can resume');
 vm.runInContext('currentSeries.episodes[0].final={partial:true,duration:4,missing_clips:[1]}',c);c.renderSeries();
 assert(elements['series-episodes'].innerHTML.includes('下载已有素材合辑'));
 console.log('Episode recovery UI passed: truthful completion counts, isolated retry, double-click guard, escaped failure text, settings controls and unique DOM IDs.');
})().catch(error=>{console.error(error);process.exitCode=1});
