"""v0.8.3.9：追加后续制作稿的校验说明、沿用本剧原声明、不能追加时的原因。离线，不调用付费接口。"""
import asyncio
import copy
import importlib
import json
import unittest

from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer
import test_production_draft as draft_tests
from test_core import ROOT

draft=draft_tests.draft
service=draft_tests.service
production=importlib.import_module('h3ad_test.production')
routes=importlib.import_module('h3ad_test.routes')
MODE='production_draft'


class AppendDraftTests(draft_tests.Fixture):
    asyncSetUp=draft_tests.DraftExecutionTests.asyncSetUp
    create=draft_tests.DraftExecutionTests.create

    async def first(self,d=None,**options):
        s=await self.finish_series(self.create(d or draft(),**options)['id'])
        self.assertEqual(s['status'],'complete',s['error'])
        return s

    def body(self,s,d,rid='batch-two',**extra):
        return {'input_type':MODE,'text':json.dumps(d,ensure_ascii=False),'expected_revision':s['revision'],'request_id':rid,**extra}

    def assert_untouched(self,before):
        after=self.store.get('series',before['id'])
        self.assertEqual(after['revision'],before['revision'])
        self.assertEqual(len(after['batches']),len(before['batches']))
        self.assertEqual(len(after['plan']['episodes']),len(before['plan']['episodes']))

    async def test_style_mismatch_says_what_differs_and_changes_nothing(self):
        s=await self.first()
        other=draft();other['style']='Cold blue light, handheld.'
        with self.assertRaises(ValueError) as caught:self.manager.append(s['id'],self.body(s,other))
        message=str(caught.exception)
        self.assertIn('风格 style',message);self.assertIn('Natural cinematic light.',message);self.assertIn('Cold blue light',message)
        self.assertIn('沿用本剧原声明',message)
        self.assert_untouched(s)

    async def test_all_differences_are_listed_in_one_message(self):
        s=await self.first()
        other=draft();other['style']='Another style.'
        other['assets'][0]['description']={'en':'The same woman in a red coat.','zh':'同一名穿红衣的女子。'}
        other['characters']['女主']['voice_description']={'en':'A bright young voice.','zh':'明亮的年轻声线。'}
        with self.assertRaises(ValueError) as caught:self.manager.append(s['id'],self.body(s,other))
        message=str(caught.exception)
        for label in ('风格 style','素材 hero','角色 女主'):self.assertIn(label,message)
        self.assert_untouched(s)

    async def test_adopt_flag_keeps_the_series_original_wording(self):
        s=await self.first()
        other=draft();other['style']='Another style.'
        other['assets'][0]['description']={'en':'The same woman in a red coat.','zh':'同一名穿红衣的女子。'}
        other['episodes'][0]['title']='第二批'
        appended=self.manager.append(s['id'],self.body(s,other,adopt_series_declarations=True))
        self.assertEqual(appended['production_draft']['style'],'Natural cinematic light.')
        self.assertEqual(appended['batches'][-1]['production_draft']['style'],'Natural cinematic light.')
        self.assertEqual(appended['batches'][-1]['production_draft']['assets'][0]['description']['en'],'The same woman wearing a white coat.')
        notes=[e['message'] for e in self.store.get('series',s['id'])['events'] if '已沿用本剧原声明' in e['message']]
        self.assertEqual(len(notes),1);self.assertIn('风格 style',notes[0]);self.assertIn('素材 hero',notes[0])
        # 追加后能正常做完，不调用创作接口。
        done=await self.finish_series(s['id'])
        self.assertEqual(done['status'],'complete',done['error']);self.assertEqual(len(done['project_ids']),2)

    async def test_adopt_flag_never_rebinds_an_existing_asset_key(self):
        s=await self.first()
        other=draft();other['assets'][0]['source']={'id':self.asset['id']}
        for adopt in (False,True):
            with self.assertRaisesRegex(ValueError,'素材身份'):
                self.manager.append(s['id'],self.body(s,other,rid='r%d'%adopt,adopt_series_declarations=adopt))
        self.assert_untouched(s)

    async def test_adopt_flag_must_be_a_switch(self):
        s=await self.first()
        with self.assertRaisesRegex(ValueError,'沿用本剧原声明须为开关'):
            self.manager.append(s['id'],self.body(s,draft(),adopt_series_declarations='yes'))

    async def test_append_inherits_image_api_choice_of_the_series(self):
        s=await self.first(allow_image_api=True)
        self.assertTrue(s['allow_image_api'])
        d=draft();d['episodes'][0]['title']='第二批'
        appended=self.manager.append(s['id'],self.body(s,d))   # 没有 allow_image_api：沿用上一批
        self.assertTrue(appended['allow_image_api']);self.assertTrue(appended['batches'][-1]['allow_image_api'])

    async def test_explicit_image_api_choice_still_wins(self):
        s=await self.first(allow_image_api=True)
        d=draft();d['episodes'][0]['title']='第二批'
        appended=self.manager.append(s['id'],self.body(s,d,allow_image_api=False))
        self.assertFalse(appended['allow_image_api'])

    async def test_second_append_waits_until_first_new_batch_started(self):
        s=await self.first()
        d=draft();d['episodes'][0]['title']='第二批'
        first=self.manager.append(s['id'],self.body(s,d))
        d2=draft();d2['episodes'][0]['title']='第三批'
        with self.assertRaisesRegex(ValueError,'还没有开始制作'):
            self.manager.append(s['id'],self.body(first,d2,rid='batch-three'))
        # 开始并做完后可以继续追加。
        done=await self.finish_series(s['id']);self.assertEqual(done['status'],'complete',done['error'])
        third=self.manager.append(s['id'],self.body(done,d2,rid='batch-three'))
        self.assertEqual(len(third['batches']),3)

    async def test_ambiguous_label_message_matches_the_append_dialog(self):
        s=await self.first()
        d=draft()
        d['assets'].append({'key':'case','kind':'image','role':'scene','label':'手提箱','source':{'label':'手提箱'},
                            'description':{'en':'A leather suitcase.','zh':'皮质手提箱。'}})
        made=[self.files.write_asset(self.store,'case%d.png'%n,self.png,{'role':'scene','label':'手提箱'}) for n in range(2)]
        d['episodes'][0]['title']='第二批'
        with self.assertRaises(ValueError) as caught:self.manager.append(s['id'],self.body(s,d))
        message=str(caught.exception)
        self.assertIn('有多个候选',message);self.assertNotIn('在下方',message);self.assertIn('按 id 绑定',message);self.assertIn('本批要用的素材',message)
        self.assert_untouched(s)
        # 追加窗口的素材清单只勾选一份：同一份制作稿即可通过，并且绑定到被勾选的那份。
        appended=self.manager.append(s['id'],self.body(s,d,asset_ids=[made[1]['id']]))
        self.assertEqual(appended['batches'][-1]['draft_asset_bindings']['case'],made[1]['id'])

    async def test_public_explains_why_append_is_unavailable(self):
        s=await self.first()
        public=self.manager.public(s['id'])
        self.assertTrue(public['can_append']);self.assertEqual(public['append_block_reason'],'')
        d=draft();d['episodes'][0]['title']='第二批'
        self.manager.append(s['id'],self.body(s,d))
        public=self.manager.public(s['id'])
        self.assertFalse(public['can_append']);self.assertIn('继续整剧',public['append_block_reason'])
        # 做完以后恢复可追加；归档时说明是归档。
        done=await self.finish_series(s['id'])
        self.assertTrue(self.manager.public(done['id'])['can_append'])
        self.store.update('series',s['id'],lambda r:r.update(archived=True))
        self.assertIn('归档',self.manager.public(s['id'])['append_block_reason'])

    async def test_unfinished_episode_is_named_in_the_reason(self):
        s=await self.first()
        self.store.update('project',s['project_ids'][0],lambda p:p.update(status='error'))
        public=self.manager.public(s['id'])
        self.assertFalse(public['can_append'])
        self.assertIn('第1集',public['append_block_reason']);self.assertIn('需要处理',public['append_block_reason'])


    async def test_series_stuck_by_a_failed_start_can_be_resumed(self):
        """追加的批次在创建各集之前失败（素材被归档）：整剧不能被误判为“全部完成”而永远无法继续。"""
        s=await self.first()
        d=draft();d['episodes'][0]['title']='第二批'
        self.manager.append(s['id'],self.body(s,d))
        self.store.update('asset',self.asset['id'],lambda a:a.update(archived=True))
        self.manager.start(s['id']);await asyncio.wait_for(self.manager.tasks[s['id']],35)
        public=self.manager.public(s['id'])
        self.assertNotEqual(public['status'],'complete');self.assertTrue(public['can_resume']);self.assertFalse(public['can_append'])
        self.store.update('asset',self.asset['id'],lambda a:a.pop('archived',None))
        done=await self.finish_series(s['id'])
        self.assertEqual(done['status'],'complete',done['error']);self.assertEqual(len(done['project_ids']),2)
        self.assertTrue(self.manager.public(s['id'])['can_append'])

    async def test_reason_names_the_button_that_actually_works(self):
        s=await self.first()
        self.store.update('project',s['project_ids'][0],lambda p:p.update(status='error'))
        reason=self.manager.public(s['id'])['append_block_reason']
        self.assertEqual(self.manager.public(s['id'])['status'],'complete')
        self.assertIn('打开该集',reason);self.assertNotIn('请先点“继续整剧”',reason)
        self.store.update('series',s['id'],lambda r:r.update(status='partial'))
        self.assertIn('继续整剧',self.manager.public(s['id'])['append_block_reason'])
        self.store.update('project',s['project_ids'][0],lambda p:p.update(status='running'))
        reason=self.manager.public(s['id'])['append_block_reason']
        self.assertIn('正在单独制作',reason);self.assertNotIn('整剧本身已完成',reason)

    async def test_complete_series_with_uncreated_episodes_is_healed(self):
        """旧版本（或补做本集）留下的“已完成但有集根本没创建”：改回可继续，而不是永远卡死。"""
        s=await self.first()
        d=draft();d['episodes'][0]['title']='第二批'
        self.manager.append(s['id'],self.body(s,d))
        self.store.update('series',s['id'],lambda r:r.update(status='complete'))
        public=self.manager.public(s['id'])
        self.assertEqual(public['status'],'partial');self.assertTrue(public['can_resume']);self.assertFalse(public['can_append'])
        done=await self.finish_series(s['id'])
        self.assertEqual(done['status'],'complete',done['error']);self.assertEqual(len(done['project_ids']),2)


class DeleteThenAppendTests(draft_tests.Fixture):
    asyncSetUp=draft_tests.DraftExecutionTests.asyncSetUp
    create=draft_tests.DraftExecutionTests.create

    async def test_episode_after_a_deleted_one_is_not_deferred_with_a_raw_id(self):
        """删除了一集再追加：新的一集不能因为“上一集找不到”而被判成待补做，提示里也不能出现一串内部编号。"""
        s=await self.finish_series(self.create()['id'])
        self.assertEqual(s['status'],'complete',s['error'])
        pid=s['project_ids'][0]
        manage=importlib.import_module('h3ad_test.management').RecordsManager(self.engine,self.manager)
        review=manage.preview('project',pid)
        manage.delete('project',pid,{'review_token':review['review_token'],'delete_files':False})
        d=draft();d['episodes'][0]['title']='第二批'
        current=self.store.get('series',s['id'])
        self.manager.append(s['id'],{'input_type':MODE,'text':json.dumps(d,ensure_ascii=False),'expected_revision':current['revision'],'request_id':'after-delete'})
        done=await self.finish_series(s['id'])
        self.assertEqual(done['status'],'complete',done['error'])
        self.assertEqual(len(done['project_ids']),1);self.assertIn(pid,done['removed_episodes'])
        self.assertEqual([e['status'] for e in self.manager.public(s['id'])['episodes']],['deleted','complete'])


class AutoRetryPromptTests(draft_tests.Fixture):
    asyncSetUp=draft_tests.DraftExecutionTests.asyncSetUp
    create=draft_tests.DraftExecutionTests.create

    async def test_automatic_retry_keeps_chinese_diagnosis_out_of_the_prompt(self):
        """F3：自动重抽时，应用自己写的中文诊断不能进视频提示词（H3 会把它念成乱码）。"""
        from unittest.mock import AsyncMock,patch
        self.store.save_settings({'review_video_enabled':True,'review_model':'mock','review_api_key':'mock','review_base_url':self.url,'review_video_attempts':2})
        check=AsyncMock(side_effect=[{'passed':False,'reasons':['wrong pose'],'summary':'NG'},{'passed':True,'reasons':[],'summary':'OK'}])
        with patch.object(draft_tests.review.Reviewer,'video',check):
            s=await self.finish_series(self.create()['id'])
        self.assertEqual(s['status'],'complete',s['error']);self.assertEqual(check.await_count,2)
        clip=self.store.get('project',s['project_ids'][0])['clips'][0]
        self.assertEqual(clip['quality_attempt'],2);self.assertTrue(clip.get('redo_feedback_auto'))
        self.assertIn('wrong pose',clip['redo_feedback'])            # 仍然记录在项目里，界面能看到
        for key in ('prompt_en','prompt_zh'):
            self.assertNotIn('wrong pose',clip[key]);self.assertNotIn('修正视频',clip[key])

    def test_only_text_typed_by_the_user_reaches_prompts(self):
        runtime=draft_tests.runtime
        self.assertEqual(runtime.human_feedback({'redo_feedback':'修正视频/对白核对发现的问题：[]','redo_feedback_auto':True}),'')
        self.assertEqual(runtime.human_feedback({'redo_feedback':'改成近景','redo_feedback_auto':False}),'改成近景')
        self.assertEqual(runtime.human_feedback({'redo_feedback':'改成近景'}),'改成近景')


class MessageShapeTests(unittest.TestCase):
    def asset(self,n,text):
        return {'key':'a%d'%n,'kind':'image','role':'scene','label':'场景%d'%n,'source':{'label':'场景%d'%n},'description':{'en':text,'zh':text}}

    def test_fix_is_first_and_long_lists_are_capped(self):
        old={'style':'S','assets':[self.asset(n,'old %d'%n) for n in range(9)],'characters':{}}
        new={'style':'S','assets':[self.asset(n,'new %d'%n) for n in range(9)],'characters':{}}
        with self.assertRaises(ValueError) as caught:service.reconcile_declarations(new,old,False)
        message=str(caught.exception);lines=message.split('\n')
        self.assertTrue(lines[1].startswith('处理办法'),message)
        self.assertEqual(sum(1 for l in lines if l.startswith('- 素材')),6)
        self.assertIn('另有 3 项不同',message)

    def test_identity_changes_that_adopt_cannot_fix_are_listed_first(self):
        old={'style':'S','assets':[self.asset(n,'same') for n in range(3)],'characters':{}}
        new=copy.deepcopy(old);new['assets'][0]['description']={'en':'x','zh':'x'}
        new['assets'][2]['source']={'label':'别的素材'}
        with self.assertRaises(ValueError) as caught:service.reconcile_declarations(new,old,True)
        rows=[l for l in str(caught.exception).split('\n') if l.startswith('- ')]
        self.assertEqual(len(rows),1);self.assertIn('素材 a2',rows[0]);self.assertIn('不能沿用',rows[0])

    def test_tick_advice_only_when_ticking_can_help(self):
        old={'style':'S','assets':[self.asset(n,'same') for n in range(2)],'characters':{}}
        identity=copy.deepcopy(old);identity['assets'][1]['source']={'label':'别的素材'}
        for adopt in (False,True):
            with self.assertRaises(ValueError) as caught:service.reconcile_declarations(copy.deepcopy(identity),old,adopt)
            self.assertNotIn('勾选“沿用本剧原声明”',str(caught.exception))
        text=copy.deepcopy(old);text['assets'][0]['description']={'en':'x','zh':'x'}
        with self.assertRaises(ValueError) as caught:service.reconcile_declarations(text,old,False)
        self.assertIn('勾选“沿用本剧原声明”',str(caught.exception))

    def test_character_image_limit_names_the_character(self):
        with self.assertRaisesRegex(ValueError,'基利安已选5张图片'):
            production.validate_bindings({'基利安':{'image_ids':['a','b','c','d','e']}},None)


class HttpErrorTextTests(draft_tests.Fixture):
    asyncSetUp=draft_tests.DraftExecutionTests.asyncSetUp
    create=draft_tests.DraftExecutionTests.create

    async def test_missing_record_is_reported_without_python_quotes(self):
        application=routes.Application(self.store.root,self.files.input,self.files.output,self.url)
        app=web.Application();app.router.add_route('*','/{path:.*}',application.handle)
        client=TestClient(TestServer(app));await client.start_server()
        try:
            response=await client.post('/api/series/doesnotexist/append',json={'request_id':'x'})
            data=await response.json()
            self.assertEqual(response.status,400)
            self.assertNotRegex(data['error'],r"^['\"]");self.assertIn('doesnotexist',data['error'])
        finally:await client.close()


if __name__=='__main__':unittest.main()
