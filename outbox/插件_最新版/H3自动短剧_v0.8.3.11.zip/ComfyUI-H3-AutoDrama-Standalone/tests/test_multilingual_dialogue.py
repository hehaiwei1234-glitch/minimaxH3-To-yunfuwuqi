"""Real regressions for title parsing, language binding and uncropped audio.

These use synthetic media and mock endpoints; no paid API or H3 inference.
"""
import copy
import importlib
import json
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch
from test_core import ROOT, Store, domain, compiler_result
import test_production_draft as drafts

lang=importlib.import_module('h3ad_test.dialogue_language')
plan=importlib.import_module('h3ad_test.dialogue_plan')
compiler=importlib.import_module('h3ad_test.prompt_compiler')
speech=importlib.import_module('h3ad_test.dialogue_check')
recognition=importlib.import_module('h3ad_test.speech_recognition')
retention=importlib.import_module('h3ad_test.dialogue_retention')
padding=importlib.import_module('h3ad_test.dialogue_timing')
validation=importlib.import_module('h3ad_test.prompt_validation')
production=importlib.import_module('h3ad_test.production')
media=importlib.import_module('h3ad_test.media_tools')
schema=drafts.schema

SOURCE='''《地下春天》续集：第17—24集
第17集：仓库还不算家
林川：粮食堆得再高，睡觉的地方也得先暖起来。
老陈：墙都包过了，就剩入口。这门以前只管挡雨。
林川：在这儿再加一道门。两扇门之间，留个小间。
老陈：再隔一道，搬货就没那么方便了。
林川：货快搬完了。以后进来一个人，别把整屋的热气放走。
老陈：这里。避开这根柱子，推车也能转过去。
林川：行。今晚先把这间屋封好。
老陈：试试。总算不像睡工地了。
林川：明早把其他床也铺上。别等人到了再收拾。
老陈：外面这条线路，昨天也闪过。'''


class DialogueLanguageTests(unittest.TestCase):
    def test_reported_episode_and_series_titles_are_not_dialogue(self):
        lines=plan.script_lines(SOURCE,['林川','老陈'])
        self.assertEqual(len(lines),10)
        self.assertEqual({x['speaker'] for x in lines},{'林川','老陈'})
        result={'segments':[{'dialogue':lines}]}
        self.assertEqual(plan.check_coverage(result,SOURCE)['explicit_lines'],10)

    def test_missing_or_modified_real_dialogue_still_fails(self):
        lines=plan.script_lines(SOURCE,['林川','老陈'])
        for actual in (lines[:-1],lines+[lines[-1]],list(reversed(lines)),
                       [{**x,'text':x['text'][:-2]} if i==9 else x for i,x in enumerate(lines)]):
            with self.assertRaisesRegex(ValueError,'对白遗漏'):
                plan.check_coverage({'segments':[{'dialogue':actual}]},SOURCE)

    def test_english_and_japanese_metadata_is_not_a_character(self):
        source='Title: Safe Haven\nEpisode 17: A Warm Room\nScene 2: Basement\nNora: Come inside.\n美咲：ここは安全です。'
        self.assertEqual([x['speaker'] for x in plan.script_lines(source,['Nora','美咲'])],['Nora','美咲'])

    def test_declared_long_english_name_is_not_silently_omitted(self):
        source='Dr. Rafael Montgomery: Stay inside.'
        line={'speaker':'Dr. Rafael Montgomery','text':'Stay inside.'}
        self.assertEqual(plan.script_lines(source,[line['speaker']]),[line])
        self.assertEqual(plan.check_coverage({'segments':[{'dialogue':[line]}]},source)['explicit_lines'],1)

    def test_heading_filter_does_not_hide_an_omitted_second_speaker(self):
        with self.assertRaisesRegex(ValueError,'对白遗漏'):
            plan.check_coverage({'segments':[{'dialogue':[{'speaker':'林川','text':'先关门。'}]}]},
                                '第17集：入口\n林川：先关门。\n老陈：好。')

    def test_draft_script_accepts_headings_but_rejects_unknown_speakers(self):
        self.assertEqual(schema.script_lines(SOURCE,{'林川':{},'老陈':{}},'script'),plan.script_lines(SOURCE))
        with self.assertRaisesRegex(ValueError,'未声明'):
            schema.script_lines('Nora: Come inside.\nUnknown: Hello.',{'Nora':{}},'script')

    def test_language_detection_and_explicit_kanji_only_choice(self):
        self.assertEqual(lang.detect('Come inside.'),'en')
        self.assertEqual(lang.detect('这里安全。'),'zh')
        self.assertEqual(lang.detect('ここは安全です。'),'ja')
        self.assertEqual(lang.tag({'text':'安全第一。'},{'dialogue_language':'ja'}),'Japanese')
        self.assertEqual(lang.tag({'text':'Hello.','language':'en'},{'dialogue_language':'ja'}),'English')

    def test_settings_default_aliases_and_invalid_language(self):
        self.assertEqual(domain.validate_settings({})['dialogue_language'],'auto')
        self.assertEqual(domain.validate_settings({'dialogue_language':'en-US'})['dialogue_language'],'en')
        for invalid in (None,False,'French'):
            with self.assertRaises(ValueError):domain.validate_settings({'dialogue_language':invalid})

    def compile(self,lines):
        clip={'duration_seconds':15,'dialogue':lines}
        data=compiler_result({'segment':clip,'references':[]})
        return compiler.compile_prompt(data,[],domain.media_state([],[],[]),clip,{'new_content_start_seconds':0})

    def test_normal_compiler_uses_each_original_language_and_exact_words(self):
        lines=[{'speaker':'Nora','text':'An engagement dinner. Or a confession?'},
               {'speaker':'美咲','text':'ここは安全です。'},{'speaker':'林川','text':'把门关好。'}]
        result=self.compile(lines)
        for line,tag in zip(lines,['English','Japanese','Chinese']):
            self.assertIn('<d>['+tag+'] '+line['text']+'</d>',result['prompt_en'])
            self.assertIn('<d>['+tag+'] '+line['text']+'</d>',result['prompt_zh'])
        self.assertEqual([x['language'] for x in result['dialogue_windows']],['en','ja','zh'])

    def test_english_comparison_preserves_real_word_boundaries(self):
        self.assertFalse(speech.compare('the rapist','therapist')['passed'])
        self.assertFalse(speech.compare('a part','apart')['passed'])
        self.assertTrue(speech.compare("Don't go outside.","dont go outside")['passed'])
        self.assertTrue(speech.compare('Come inside.','COME INSIDE!')['passed'])
        self.assertFalse(speech.compare('Come inside now.','Come inside')['passed'])

    def test_all_three_languages_require_the_final_word(self):
        for expected,actual in [('先把门关好。','先把门关'),('Please come inside.','Please come'),('ここは安全です。','ここは安全で')]:
            self.assertFalse(speech.compare(expected,actual)['passed'])
            self.assertTrue(speech.compare(expected,expected)['passed'])

    def test_mixed_languages_do_not_force_one_asr_language(self):
        self.assertIsNone(lang.asr_hint([{'text':'你好。'},{'text':'Hello.'}]))
        self.assertIsNone(lang.asr_hint([{'text':'Hello，林川。'}]))
        self.assertEqual(lang.asr_hint([{'text':'ここは安全です。'}]),'ja')

    def test_nullable_optional_references_do_not_discard_real_pins(self):
        assets=[{'id':'hero','kind':'image','role':'character','label':'林川'},
                {'id':'voice','kind':'audio','role':'voice','speaker':'林川'}]
        result=production.bind_plan({'assets_to_create':None,'segments':[{'characters':['林川'],
            'dialogue':[{'speaker':'林川','text':'先关门。'}],'asset_ids':None,'image_reference_ids':None}]},
            {'林川':{'image_ids':['hero'],'voice_id':'voice'}},assets)
        self.assertEqual(result['segments'][0]['asset_ids'],['hero','voice'])
        self.assertEqual(result['segments'][0]['image_reference_ids'],['hero'])
        with self.assertRaisesRegex(ValueError,'真实素材编号'):
            production.bind_plan({'segments':[{'asset_ids':[None]}]}, {},assets)

    def test_draft_tail_policy_distinguishes_authored_time_and_manual_caps(self):
        clip={'duration_seconds':2,'generation_exact':True,'timing_version':1,'dialogue':[{'speaker':'Nora','text':'Welcome.'}]}
        project={'production_draft':{'version':1},'episode_target_seconds':2}
        cfg=domain.validate_settings({'dialogue_padding_seconds':0})
        retention.prepare(project,clip,cfg)
        self.assertEqual(clip['dialogue_retention']['policy'],'preserve_tail')
        for name in ('episode','total','task'):
            c=copy.deepcopy(clip)
            retention.prepare({**project,'timing_policy':{name:{'enabled':True,'seconds':2}}},c,cfg)
            self.assertEqual(c['dialogue_retention']['policy'],'fixed')
        c={**copy.deepcopy(clip),'job_id':'sent'};before=copy.deepcopy(c)
        self.assertFalse(retention.prepare(project,c,cfg));self.assertEqual(c,before)

    def test_subframe_rounding_does_not_bypass_timing_recovery(self):
        c={'duration_seconds':5,'timing_version':1,'dialogue_budget':True,
           'dialogue':[{'speaker':'林川','text':'先关门。'}]}
        retention.prepare({},c,domain.DEFAULTS)
        data=compiler_result({'segment':c,'references':[]})
        data['shots']=[{**data['shots'][0],'end_seconds':1.0},
                       {**data['shots'][0],'start_seconds':1.01,'end_seconds':5,'dialogue_indices':[]}]
        fixed=validation.recover_structure(data,c,{'new_content_start_seconds':0})
        self.assertFalse(validation.issues(fixed,[],c))
        self.assertEqual(fixed['shots'][0]['end_seconds'],fixed['shots'][1]['start_seconds'])
        self.assertEqual(fixed['shots'][0]['visual_en'],data['shots'][0]['visual_en'])

    def test_legacy_trim_uses_owned_full_audio_node_in_submission_copy(self):
        graph={'prepare':{'class_type':'H3ContinuePrepare','inputs':{}},
               'frames':{'class_type':'Frames','inputs':{}},'audio':{'class_type':'Audio','inputs':{}},
               'trim':{'class_type':'H3ContinueTrim','inputs':{'images':['frames',0],'audio':['audio',0],
                    'trim_start_frames':['prepare',3],'trim_output_frames':['prepare',4],'enable_continue':True}},
               'save':{'class_type':'SaveVideo','inputs':{'video':['trim',0]}},
               'unrelated':{'class_type':'H3ContinueTrim','inputs':{'trim_output_frames':999}}}
        original=copy.deepcopy(graph)
        clip={'duration_seconds':2,'timing_version':1,'continuity':'continue','dialogue':[{'speaker':'Nora','text':'Welcome.'}]}
        retention.prepare({},clip,domain.DEFAULTS)
        result,audit=retention.protect_graph(graph,'save',clip)
        self.assertEqual(graph,original)
        self.assertEqual(result['trim']['class_type'],'H3ADv1Trim')
        self.assertEqual(result['trim']['inputs']['trim_output_frames'],0)
        self.assertEqual(result['trim']['inputs']['trim_start_frames'],['prepare',3])
        self.assertEqual(result['unrelated'],original['unrelated'])
        self.assertEqual(len(audit['tail_limit_changes']),2)


class RecognitionLanguageTests(unittest.IsolatedAsyncioTestCase):
    async def test_qwen_hints_all_supported_languages_without_reference_text(self):
        for language in ('en','ja','zh',None):
            cfg={**domain.DEFAULTS,'asr_provider':'qwen','asr_model':'qwen3-asr-flash',
                 'asr_base_url':'https://dashscope.aliyuncs.com/compatible-mode/v1','asr_language':language}
            client=types.SimpleNamespace(config=cfg,_request=AsyncMock(return_value={
                'choices':[{'message':{'content':'Welcome.'}}]}))
            result,provider=await recognition.recognize(client,b'actual audio bytes')
            payload=client._request.call_args.args[2]
            self.assertEqual(payload['asr_options'].get('language'),language)
            self.assertFalse(payload['asr_options']['enable_itn'])
            self.assertEqual(len(payload['messages'][0]['content']),1)
            self.assertEqual(result['text'],'Welcome.');self.assertEqual(provider,'qwen')

    async def test_openai_hints_language_and_still_sends_audio_multipart(self):
        for language in ('en','ja','zh',None):
            cfg={**domain.DEFAULTS,'asr_provider':'openai','asr_model':'gpt-4o-mini-transcribe','asr_language':language}
            client=types.SimpleNamespace(config=cfg,_request=AsyncMock(return_value={'text':'Welcome.'}))
            await recognition.recognize(client,b'actual audio bytes')
            form=client._request.call_args.kwargs['form_factory']()
            fields={str(h['name']):v for h,_,v in form._fields}
            self.assertEqual(fields.get('language'),language)
            self.assertEqual(fields['file'],b'actual audio bytes')
            self.assertNotIn('prompt',fields)


class DraftLanguageExecutionTests(drafts.Fixture):
    create=drafts.DraftExecutionTests.create
    async def asyncSetUp(self):
        await drafts.DraftExecutionTests.asyncSetUp(self)
        self.store.save_settings({'dialogue_padding_seconds':0,'review_audio':True,
            'asr_provider':'compatible','asr_model':'mock','asr_base_url':self.url})

    async def execute_language(self,name,text,language):
        d=drafts.draft();d['dialogue_language']=language
        d['characters']={name:d['characters'].pop('女主')}
        e=d['episodes'][0];e['script']=name+': '+text
        s=e['segments'][0];s['characters']=[name]
        s['dialogue'][0].update(speaker=name,text=text)
        hints=[]
        async def recognize(client,blob):
            hints.append(client.config.get('asr_language'))
            return {'text':text},'compatible'
        with patch.object(drafts.providers.AIClient,'text',AsyncMock(side_effect=AssertionError('creative API forbidden'))),patch.object(speech,'recognize',recognize):
            series=await self.finish_series(self.create(d)['id'])
        self.assertEqual(series['status'],'complete',series['error'])
        p=self.store.get('project',series['project_ids'][0]);clip=p['clips'][0]
        self.assertIn('<d>['+lang.LABELS[language]+'] '+text+'</d>',clip['prompt_en'])
        self.assertTrue(clip['dialogue_check']['passed'])
        self.assertEqual(hints,[language]);self.assertEqual(self.ai_calls,0)
        self.assertEqual(clip['dialogue'][0]['end_seconds'],1.25)
        self.assertEqual(clip['retention_audit']['application_removed_tail_seconds'],0)
        return p

    async def test_english_mode3_reaches_final_with_zero_creative_api(self):
        await self.execute_language('Nora','Welcome.','en')

    async def test_japanese_mode3_reaches_final_and_keeps_authored_timestamps(self):
        await self.execute_language('美咲','安全。','ja')

    async def test_settings_language_is_validated_before_paying_for_images(self):
        self.store.save_settings({'dialogue_language':'ja'})
        d=drafts.draft();d['episodes'][0]['script']='女主：明日会議'
        d['episodes'][0]['segments'][0]['dialogue'][0]['text']='明日会議'
        # Its all-kanji text fits the old Chinese estimate, but not Japanese.
        schema.loads(d)
        with self.assertRaisesRegex(ValueError,'自然语速预算不足'):
            self.create(d)
        self.assertFalse(self.graphs);self.assertEqual(self.ai_calls,0)

    async def test_normal_planning_with_reported_titles_succeeds_on_first_response(self):
        self.store.save_settings({'review_audio':False})
        p=self.store.create_project({'title':'第17集测试','script':SOURCE,'asset_ids':[self.asset['id']],
                                     'timing_policy':{}})
        self.engine.assign_workflow(p['id'],self.video['id'])
        lines=plan.script_lines(SOURCE,['林川','老陈'])
        result={'style':'Natural cinematic lighting.','assets_to_create':[],
                'segments':[{'title':f'镜头{i+1}','duration_seconds':12,'continuity':'cut',
                    'visual_zh':line['speaker']+'在室内说话。','camera_zh':'近景',
                    'image_prompt':'Close-up inside the supplied shelter.',
                    'asset_ids':[self.asset['id']],'image_reference_ids':[self.asset['id']],
                    'dialogue':[line],'sound_zh':'微弱室内环境声。'} for i,line in enumerate(lines)]}
        cfg=self.engine.config(self.store.get('project',p['id']))
        ai=types.SimpleNamespace(config=cfg,text=AsyncMock(return_value=result))
        await self.engine.plan(p['id'],ai,cfg)
        saved=self.store.get('project',p['id'])
        self.assertEqual(saved['script'],SOURCE)
        self.assertEqual([line for c in saved['clips'] for line in c['dialogue']],lines)
        self.assertEqual(ai.text.call_count,1)


class ContinuationAudioNodeTests(unittest.TestCase):
    # Reuse the real host-schema shim; no installed ComfyUI or GPU required.
    from test_render_contract import HostContractTests as _host
    setUp=_host.setUp
    tearDown=_host.tearDown

    def test_count_zero_keeps_audio_beyond_last_frame_but_still_removes_guide(self):
        import numpy as np
        frames=np.arange(158).reshape(158,1,1,1)
        waveform=np.arange(200000).reshape(1,1,-1)
        audio={'waveform':waveform,'sample_rate':24000}
        full=self.render.H3ADv1Trim.execute(frames,audio,22,0,True)
        limited=self.render.H3ADv1Trim.execute(frames,audio,22,124,True)
        self.assertEqual(full[0].shape[0],136)
        self.assertEqual(full[1]['waveform'][0,0,0],22000)
        self.assertEqual(full[1]['waveform'][0,0,-1],199999)
        self.assertEqual(limited[1]['waveform'][0,0,-1],145999)


class AudioOverhangTests(unittest.IsolatedAsyncioTestCase):
    async def test_full_retention_preserves_every_audio_packet_and_extends_last_frame(self):
        with tempfile.TemporaryDirectory() as folder:
            source=Path(folder)/'raw.mp4';cfg=domain.DEFAULTS
            await media.command(['ffmpeg','-y','-v','error','-f','lavfi','-i','color=c=blue:s=64x64:r=24:d=2',
                '-f','lavfi','-i','sine=frequency=660:duration=3',
                '-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac',source])
            raw=await media.probe(source,cfg);target,kept=await media.keep_full(source,2,cfg,raw)
            self.assertGreater(float(raw['audio']['duration']),float(raw['video']['duration'])+.8)
            self.assertGreaterEqual(float(kept['video']['duration'])+1/24,float(kept['audio']['duration']))
            async def audio_hash(path):
                return await media.command(['ffmpeg','-v','error','-i',path,'-map','0:a:0','-c','copy','-f','hash','-hash','sha256','-'])
            self.assertEqual(await audio_hash(source),await audio_hash(target))
            self.assertTrue(source.exists())
            final=await media.merge([target,target],Path(folder)/'final.mp4',cfg)
            self.assertGreaterEqual(final['duration'],6-1/24)

    async def test_normal_audio_tail_does_not_reencode_and_short_picture_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            source=Path(folder)/'raw.mp4'
            await media.command(['ffmpeg','-y','-v','error','-f','lavfi','-i','color=c=blue:s=64x64:r=24:d=2',
                '-f','lavfi','-i','sine=frequency=660:duration=2','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',source])
            target,_=await media.keep_full(source,2,domain.DEFAULTS)
            self.assertEqual(target,source)
            with self.assertRaisesRegex(RuntimeError,'短于'):
                await media.keep_full(source,3,domain.DEFAULTS)
