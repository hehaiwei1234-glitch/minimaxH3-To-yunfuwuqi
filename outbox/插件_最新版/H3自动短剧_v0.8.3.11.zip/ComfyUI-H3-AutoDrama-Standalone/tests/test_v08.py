"""No model/GPU calls: compiler contracts and recoverable speech gates."""
import asyncio
import copy
import importlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch
import aiohttp
from aiohttp import web
from test_core import Store, Files, domain, compiler_result
import test_integration as integration

providers=importlib.import_module('h3ad_test.providers')
planning=importlib.import_module('h3ad_test.dialogue_plan')
compiler=importlib.import_module('h3ad_test.prompt_compiler')
speech=importlib.import_module('h3ad_test.dialogue_check')
timing=importlib.import_module('h3ad_test.timing_policy')
telemetry=importlib.import_module('h3ad_test.telemetry')
diagnostics=importlib.import_module('h3ad_test.api_diagnostics')
review=importlib.import_module('h3ad_test.review')


class ParserAndPlanTests(unittest.TestCase):
    def test_null_auxiliary_responses_content_is_ignored(self):
        data={'output':[None,{'type':'reasoning','content':None},{'type':'function_call'},
                        {'type':'message','content':[None,{'type':'output_text','text':'{"ok":true}'}]}]}
        self.assertEqual(providers.json_object(providers.responses_text(data)),{'ok':True})
    def test_missing_body_refusal_and_incomplete_are_explicit_errors(self):
        for data in ({'output':None},{'output':[{'content':None}]},
                     {'output':[{'content':[{'type':'refusal','refusal':'no'}]}]},
                     {'status':'incomplete','output':[]}):
            with self.subTest(data=data),self.assertRaises(providers.APIError):providers.responses_text(data)
        for data in ({'choices':None},{'choices':[None]},{'choices':[{'message':None}]},
                     {'choices':[{'message':{'content':None,'reasoning_content':'not a body'}}]},
                     {'choices':[{'finish_reason':'length','message':{'content':'{}'}}]}):
            with self.subTest(data=data),self.assertRaises(providers.APIError):providers.chat_text(data)
        self.assertEqual(providers.chat_text({'choices':[{'message':{'content':[None,{'type':'text','text':'{}'}]}}]}),'{}')
    def example(self):
        return {'segments':[{'duration_seconds':5,'dialogue':[{'speaker':'林川','text':'今天能付全款，价格我再让一成。车也一起卖。'}]}]}
    def test_budget_extends_auto_but_preserves_manual_caps(self):
        original=self.example();result=planning.prepare(original,timing.normalize())
        self.assertGreater(result['segments'][0]['duration_seconds'],5)
        self.assertEqual(original['segments'][0]['duration_seconds'],5)
        for policy in ({'task':{'enabled':True,'seconds':5}},{'episode':{'enabled':True,'seconds':5}}):
            with self.assertRaisesRegex(ValueError,'自然|预算'):planning.prepare(original,timing.normalize(policy))
    def test_source_coverage_allows_natural_split_but_not_loss_duplicate_or_wrong_speaker(self):
        script='林川：今天能付全款，价格我再让一成。车也一起卖。\n梁经理：好。'
        plan={'segments':[{'dialogue':[{'speaker':'林川','text':'今天能付全款，'},
                                     {'speaker':'林川','text':'价格我再让一成。车也一起卖。'},
                                     {'speaker':'梁经理','text':'好。'}]}]}
        self.assertEqual(planning.check_coverage(plan,script)['explicit_lines'],2)
        for mutation in ('missing','duplicate','speaker','order'):
            bad=copy.deepcopy(plan);lines=bad['segments'][0]['dialogue']
            if mutation=='missing':lines.pop(1)
            elif mutation=='duplicate':lines.insert(0,copy.deepcopy(lines[0]))
            elif mutation=='speaker':lines[1]['speaker']='梁经理'
            else:lines.reverse()
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):planning.check_coverage(bad,script)
    def test_inline_and_quoted_dialogue_extraction(self):
        self.assertEqual([x['text'] for x in planning.script_lines('女主：你好。女主：再见。',['女主'])],['你好。','再见。'])
        text='场景：室内\n林川低声说：“车也一起卖。”\n画面：他握住杯子。'
        self.assertEqual(planning.script_lines(text,['林川']),[{'speaker':'林川','text':'车也一起卖。'}])
    def test_transcript_differences_never_silently_pass(self):
        self.assertTrue(speech.compare('车也一起卖。','车也一起卖')['passed'])
        self.assertEqual(speech.compare('车也一起卖。','车也一起')['status'],'incomplete')
        self.assertEqual(speech.compare('车也一起卖。','车也一起买')['status'],'needs_review')
        self.assertFalse(speech.compare('车也一起卖。','')['passed'])


class CompilerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'data')
        self.assets=[{'id':'lin','kind':'image','role':'character','label':'林川','relative_path':'lin.png'},
                     {'id':'liang','kind':'image','role':'character','label':'梁经理','relative_path':'liang.png'},
                     {'id':'voice','kind':'audio','role':'voice','speaker':'林川','label':'林川','relative_path':'lin.wav'}]
        for a in self.assets:self.store.put('asset',a['id'],a)
        self.bindings={'林川':{'image_ids':['lin'],'voice_id':'voice'},'梁经理':{'image_ids':['liang'],'voice_id':''}}
    def tearDown(self):self.tmp.cleanup()
    def make(self,speaker='梁经理',text='可以。',duration=3,source=None):
        lines=[{'speaker':speaker,'text':text}]
        assets=compiler.authoritative_audio(self.assets if source is None else source,lines,self.bindings,self.store)
        media=domain.media_state([a['relative_path'] for a in assets if a['kind']=='image'],[],[a['relative_path'] for a in assets if a['kind']=='audio'])
        clip={'duration_seconds':duration,'dialogue':lines,'dialogue_budget':planning.budget(lines)}
        request={'segment':clip,'references':compiler.request_references(assets)}
        return compiler_result(request),assets,media,clip
    def compile(self,data):return compiler.compile_prompt(*data,{'new_content_start_seconds':.92},self.bindings)
    def test_unvoiced_speaker_has_no_fabricated_audio_reference(self):
        data=self.make();data[0]['voices']['梁经理']['en']='Use <Audio 1> for a warm voice.'
        result=self.compile(data)
        self.assertEqual(data[2]['audios'],[]);self.assertNotIn('<Audio',result['prompt_en'])
        self.assertIn('梁经理',result['prompt_en']);self.assertIn('(S1)',result['prompt_en'])
        self.assertTrue(result['compiler_warnings'])
    def test_pin_is_injected_only_for_speaking_character(self):
        data=self.make('林川',source=self.assets[:2]);result=self.compile(data)
        self.assertEqual(data[2]['audios'],['lin.wav']);self.assertIn('<Audio 1>',result['prompt_en'])
        self.assertNotIn('<Audio 2>',result['prompt_en'])
        self.assertEqual(result['prompt_en'].count('<d>[Chinese] 可以。</d>'),1)
    def test_wrong_visual_key_and_wrong_dialogue_coverage_are_rejected(self):
        for mutation in ('key','duplicate','missing','raw','tight'):
            data=self.make();shot=data[0]['shots'][0]
            if mutation=='key':shot['visual_en']='Use [[ref_99]].'
            elif mutation=='duplicate':shot['dialogue_indices']=[0,0]
            elif mutation=='missing':shot['dialogue_indices']=[]
            elif mutation=='raw':shot['visual_en']='Use <Picture 99>.'
            else:
                shot['end_seconds']=.5
                data[0]['shots'].append({'start_seconds':.5,'end_seconds':3,'visual_en':'Hold.','visual_zh':'停留。','dialogue_indices':[]})
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):self.compile(data)
    def test_original_words_and_timing_are_program_inserted(self):
        text='今天能付全款，价格我再让一成。车也一起卖。';result=self.compile(self.make('林川',text,8))
        prompt=result['prompt_en']
        self.assertEqual(prompt.count('<d>[Chinese] '+text+'</d>'),1)
        self.assertIn('From 1.020s',prompt);self.assertIn('through 8.920s',prompt)
        self.assertIn('no new dialogue',prompt);self.assertIn('non_diegetic_music:\nN/A',prompt)
        self.assertIn('从1.020秒',result['prompt_zh']);self.assertEqual(result['compiled_media_bindings'][0]['name'],'lin.png')
    def test_same_explicit_voice_pin_can_be_used_by_either_named_role(self):
        self.bindings['梁经理']['voice_id']='voice'
        for name in ('林川','梁经理'):
            result=self.compile(self.make(name))
            self.assertIn('<Audio 1>',result['prompt_en']);self.assertIn('(S1)',result['prompt_en'])


class DiagnosticLifecycleTests(unittest.TestCase):
    def test_urls_and_request_records_do_not_reveal_credentials(self):
        record=diagnostics.begin('https://user:password@example.com/v1/responses?api_key=private',{'model':'test'})
        self.assertEqual(record['endpoint'],'https://example.com/v1/responses')
        value=diagnostics.redact({'nested':{'Authorization':'Bearer private','b64_json':'image'},'error':'private failed'}, {'asr_api_key':'private'})
        self.assertNotIn('private',json.dumps(value));self.assertNotIn('image',json.dumps(value))
    def test_deleting_project_also_deletes_only_its_diagnostics(self):
        with tempfile.TemporaryDirectory() as folder:
            store=Store(Path(folder)/'data');files=Files(Path(folder)/'input',Path(folder)/'output')
            engine=integration.Engine(store,files,integration.ROOT,'http://127.0.0.1:8188')
            manager=importlib.import_module('h3ad_test.management').RecordsManager(engine,importlib.import_module('h3ad_test.series').SeriesManager(engine))
            a=store.create_project({'script':'甲：你好。'});b=store.create_project({'script':'乙：你好。'})
            for p in (a,b):store.put('api_request',p['id'],{'id':p['id'],'owner_kind':'project','owner_id':p['id']})
            preview=manager.preview('project',a['id']);manager.delete('project',a['id'],{'review_token':preview['review_token'],'delete_files':False})
            self.assertEqual([r['id'] for r in store.list('api_request')],[b['id']])


# Reuse the local API/ComfyUI fixture without inheriting its test cases.
class Fixture(unittest.IsolatedAsyncioTestCase):pass
for _name,_method in vars(integration.IntegrationTests).items():
    if callable(_method) and not _name.startswith('test_'):setattr(Fixture,_name,_method)


class SpeechPipelineTests(Fixture):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.asr_calls=0;self.asr_status=200;self.transcripts=['你好。','再见。','明天见。'];self.asr_seen=[]
        app=web.Application();app.router.add_post('/audio/transcriptions',self.transcribe)
        self.asr_runner=web.AppRunner(app);await self.asr_runner.setup();site=web.TCPSite(self.asr_runner,'127.0.0.1',0);await site.start()
        self.asr_url=f'http://127.0.0.1:{site._server.sockets[0].getsockname()[1]}'
        self.store.save_settings({'review_audio':True,'asr_base_url':self.asr_url,'asr_model':'mock-asr',
                                  'review_image_enabled':False,'review_video_enabled':False,'review_video_attempts':1,
                                  'review_video_exhausted':'pause'})
    async def asyncTearDown(self):
        await self.asr_runner.cleanup();await super().asyncTearDown()
    async def transcribe(self,request):
        self.asr_calls+=1;reader=await request.multipart();names=[]
        while (field:=await reader.next()) is not None:names.append(field.name);await field.read()
        self.asr_seen.append(names)
        if self.asr_status!=200:return web.json_response({'error':'ASR unavailable'},status=self.asr_status,headers={'x-request-id':'asr-failed'})
        text=self.transcripts[min(self.asr_calls-1,len(self.transcripts)-1)]
        return web.json_response({'text':text},headers={'x-request-id':f'asr-{self.asr_calls}'})
    async def test_asr_runs_without_visual_review_and_no_script_leak_to_recognizer(self):
        with patch.object(review.Reviewer,'video',AsyncMock(side_effect=AssertionError('visual review disabled'))):
            p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertEqual(self.asr_calls,3)
        self.assertTrue(all(c['dialogue_check']['passed'] for c in p['clips']))
        self.assertTrue(all(names==['model','file'] for names in self.asr_seen))
    async def test_missing_tail_is_adopted_and_manual_confirm_does_not_rerender(self):
        self.transcripts=['你','明天见。','再见。']
        p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertTrue(p.get('final'))
        self.assertEqual(len(self.graphs),3);self.assertTrue(p['clips'][1].get('output'))
        first=p['clips'][0];self.assertTrue(first['quality_accepted']);self.assertTrue(first['adopted_ng'])
        self.assertTrue(self.files.output_path(first['raw_output']).exists())
        self.assertTrue(speech.current_report(self.files,first),'NG archive preserves report signature')
        self.engine.resolve_dialogue(p['id'],{'index':0,'action':'confirm','signature':first['dialogue_check']['signature']})
        p=await self.finish(p['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertEqual(len(self.graphs),3);self.assertEqual(self.asr_calls,3)
        self.assertEqual(p['clips'][0]['dialogue_check']['status'],'manual_confirmed')

    async def test_asr_transport_error_keeps_all_videos_and_recheck_never_rerenders(self):
        self.asr_status=503;p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'complete');self.assertEqual(len(self.graphs),3)
        self.assertTrue(all(c.get('output') and c.get('recovery_unchecked') for c in p['clips']))
        rows=diagnostics.export(self.store,'project',p['id'])['requests']
        self.assertTrue(any(x.get('request_id')=='asr-failed' and x['status']=='error' for x in rows))
        self.asr_status=200;self.asr_calls=0
        for i,c in enumerate(p['clips']):self.engine.resolve_dialogue(p['id'],{'index':i,'action':'recheck','signature':c['dialogue_check']['signature']})
        p=await self.finish(p['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertEqual(len(self.graphs),3)
        self.assertEqual(p['timings']['video_generation']['calls'],3)
        self.assertTrue(all(c['dialogue_check']['passed'] for c in p['clips']))

    async def test_old_visual_acceptance_does_not_skip_independent_audio_gate(self):
        self.store.save_settings({'review_audio':False});p=await self.finish(self.project()['id'])
        for c in p['clips']:
            c['quality_verdict']={'passed':True,'reasons':[]};c['video_reviewed']=True
        p['final']=None;p['status']='paused';self.store.put('project',p['id'],p)
        self.store.save_settings({'review_audio':True});self.transcripts=['你','明天见。','明天见。']
        p=await self.finish(p['id'])
        self.assertEqual(p['status'],'complete');self.assertEqual(len(self.graphs),3)
        self.assertGreater(self.asr_calls,0);self.assertTrue(p['clips'][0]['adopted_ng']);self.assertFalse(p['clips'][0]['dialogue_check']['passed'])
    async def test_manual_recheck_in_explicit_pause_mode_does_not_rerender_and_is_stale_safe(self):
        self.transcripts=['错词','明天见。']
        p=await self.finish(self.project()['id']);first=p['clips'][0]
        self.assertEqual(p['status'],'complete');self.assertEqual(len(self.graphs),3)
        with self.assertRaisesRegex(ValueError,'变化'):
            self.engine.resolve_dialogue(p['id'],{'index':0,'action':'confirm','signature':'stale'})
        self.engine.resolve_dialogue(p['id'],{'index':0,'action':'recheck','signature':first['dialogue_check']['signature']})
        self.transcripts+=['你好。','再见。'];p=await self.finish(p['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertEqual(len(self.graphs),3)
    async def test_missing_tail_retries_only_within_existing_video_budget(self):
        self.store.save_settings({'review_video_attempts':2});self.transcripts=['你','你好。','再见。','明天见。']
        p=await self.finish(self.project()['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertEqual(len(self.graphs),4)
        c=p['clips'][0];self.assertEqual(c['quality_attempt'],2)
        self.assertNotEqual(str(c['seed']),str(c['quality_history'][0]['seed']))
    async def test_explicitly_disabling_audio_gate_can_resume_but_does_not_mark_it_passed(self):
        self.transcripts=['你','明天见。'];p=await self.finish(self.project()['id'])
        self.store.save_settings({'review_audio':False});p=self.store.get('project',p['id'])
        self.assertEqual(p['status'],'complete',p.get('error'));self.assertFalse(p['clips'][0]['dialogue_check']['passed'])
    async def test_api_validation_failure_retains_redacted_raw_response(self):
        original=self.ai_result
        self.ai_result=lambda *args:{'unexpected':'mock secret-private-value'}
        self.store.save_settings({'openai_api_key':'secret-private-value'})
        p=self.project()
        async with aiohttp.ClientSession() as session:
            ai=providers.AIClient(self.store.settings(),session)
            with telemetry.scope(self.store,'project',p['id']):
                with self.assertRaises(ValueError):
                    await self.engine.checked_text(ai,'task','JSON request',lambda result:(_ for _ in ()).throw(ValueError('bad contract')))
        self.ai_result=original
        record=diagnostics.export(self.store,'project',p['id']);encoded=json.dumps(record)
        self.assertIn('unexpected',encoded);self.assertNotIn('secret-private-value',encoded)
        self.assertIn('redacted',encoded);self.assertEqual(record['requests'][0]['status'],'error')
    async def test_http_dialogue_resolution_and_diagnostics_download(self):
        # Use realistic distinct secrets; the old dummy key "mock" is also a
        # substring of our model name, and is correctly redacted from exports.
        self.store.save_settings({'openai_api_key':'test-secret-primary','deepseek_api_key':'test-secret-secondary'})
        self.transcripts=['你','明天见。'];p=await self.finish(self.project()['id'])
        application=integration.routes.Application(self.store.root,self.files.input,self.files.output,self.url)
        application.engine=self.engine;application.store=self.store
        host=web.Application();host.router.add_route('*','/h3_autodrama_v1/{path:.*}',application.handle)
        runner=web.AppRunner(host);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
        base=f'http://127.0.0.1:{site._server.sockets[0].getsockname()[1]}/h3_autodrama_v1/api/projects/{p["id"]}'
        try:
            async with aiohttp.ClientSession() as session:
                body={'index':0,'action':'confirm','signature':'stale'}
                async with session.post(base+'/dialogue',json=body) as response:self.assertEqual(response.status,400)
                body['signature']=p['clips'][0]['dialogue_check']['signature']
                async with session.post(base+'/dialogue',json=body) as response:self.assertEqual(response.status,200,await response.text())
                async with session.get(base+'/diagnostics') as response:
                    self.assertEqual(response.status,200);data=await response.json()
                    self.assertTrue(any(row['model']=='mock-asr' for row in data['requests']))
                    self.assertIn('attachment',response.headers['Content-Disposition'])
        finally:await runner.cleanup()


if __name__=='__main__':unittest.main()
