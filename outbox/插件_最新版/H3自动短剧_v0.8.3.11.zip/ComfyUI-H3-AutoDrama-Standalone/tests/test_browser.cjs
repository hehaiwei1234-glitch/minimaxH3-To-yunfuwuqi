// Optional development smoke test. No paid APIs or GPU inference are used.
const assert = require('node:assert/strict');
const path = require('node:path');
const {spawn} = require('node:child_process');
const {createRequire} = require('node:module');
const runtimeRequire = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES
  ? createRequire(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'package.json'))
  : require;
const {chromium} = runtimeRequire('playwright');

async function main() {
  const server = spawn(process.env.PYTHON || 'python', ['tests/mock_server.py'], {cwd:path.resolve(__dirname,'..'), stdio:['ignore','pipe','pipe']});
  let browser, logs=''; server.stderr.on('data',chunk=>logs+=chunk);
  try {
    const url = await new Promise((resolve,reject)=>{
      let output='';const timer=setTimeout(()=>reject(Error('Mock server did not start: '+logs)),15000);
      server.stdout.on('data',chunk=>{output+=chunk;const match=output.match(/http:\/\/127\.0\.0\.1:\d+\/h3_autodrama_v1\//);if(match){clearTimeout(timer);resolve(match[0]);}});
      server.once('exit',code=>{clearTimeout(timer);reject(Error('Mock server exited '+code+': '+logs));});
    });
    const launch={headless:true};
    if(process.env.H3_QA_CHROMIUM){launch.executablePath=process.env.H3_QA_CHROMIUM;launch.args=(process.env.H3_QA_ARGS?JSON.parse(process.env.H3_QA_ARGS):['--no-sandbox']);}
    browser=await chromium.launch(launch);
    const page=await browser.newPage();const errors=[];page.on('pageerror',error=>errors.push(error.message));
    await page.goto(url);await page.waitForFunction(()=>document.querySelector('#notice').textContent.includes('就绪：'));
    assert.equal(await page.locator('[data-timing-fields] input[type="checkbox"]:checked').count(),0);
    assert.equal(await page.locator('[data-timing-fields] input[type="number"]:disabled').count(),9);
    await page.locator('[data-tab="image-workflows"]').click();await page.locator('#install-qwen-templates').click();
    await page.waitForFunction(()=>document.querySelector('#notice').textContent.includes('两份千问生图模板已保存并启用'));
    const api=async route=>{const response=await page.request.get(url+'api/'+route);assert.equal(response.status(),200);return response.json();};
    let cfg=await api('settings');assert.equal(cfg.image_provider,'local');assert(cfg.image_workflow_id);assert(cfg.image_reference_workflow_id);
    const reference=await api('image-workflows/'+cfg.image_reference_workflow_id);assert.equal(reference.reference_bindings.length,8);
    await page.evaluate(async graph=>await openImageWorkflowDraft(JSON.stringify(graph),'重新识别的参考图'),reference.graph);
    for(const name of ['image_binding_prompt','image_binding_prefix','image_binding_seed',...Array.from({length:8},(_,i)=>'reference_'+i)])assert(await page.locator(`#image-workflow-form [name="${name}"]`).inputValue(),name);
    await page.locator('#image-workflow-form [name="tested_by_user"]').check();await page.locator('#image-workflow-form button[type="submit"]').click();
    await page.waitForFunction(()=>document.querySelector('#notice').textContent.includes('本地生图模板已保存'));
    await page.locator('[data-tab="settings"]').click();
    await page.locator('#image-reference-workflow').selectOption('');await page.waitForFunction(()=>!document.querySelector('#image-reference-workflow').disabled);
    assert.equal((await api('settings')).image_reference_workflow_id,'');
    await page.locator('#image-reference-workflow').selectOption(cfg.image_reference_workflow_id);await page.waitForFunction(()=>!document.querySelector('#image-reference-workflow').disabled);
    await page.locator('#settings-form button[type="submit"]').click();await page.waitForFunction(()=>document.querySelector('#notice').textContent==='设置已保存并核对');
    await page.reload();await page.waitForFunction(()=>document.querySelector('#notice').textContent.includes('就绪：'));
    cfg=await api('settings');assert.equal(cfg.image_reference_workflow_id,reference.id);
    assert.equal(await page.locator('#image-reference-workflow').inputValue(),reference.id);
    await page.locator('[data-tab="series"]').click();
    const form=page.locator('#series-form');await form.locator('[name="title"]').fill('安全屋浏览器回归');
    await form.locator('[name="text"]').fill('女主：你好。\n女主：再见。\n女主：明天见。\n女主：晚安。');
    assert.equal(await form.locator('[name="episode_count"]').inputValue(),'0');
    for(const [key,value]of [['episode','4'],['total','8'],['task','3']]){await form.locator(`[name="${key}_time_enabled"]`).check();await form.locator(`[name="${key}_time_seconds"]`).fill(value);}
    await form.locator('[name="task_time_enabled"]').uncheck();
    assert.deepEqual(await page.evaluate(()=>timingFromForm(document.querySelector('#series-form')).task),{enabled:false,seconds:null});
    await form.locator('[name="task_time_enabled"]').check();
    const submitted=page.waitForRequest(request=>request.method()==='POST'&&request.url()===url+'api/series');
    await form.locator('button[type="submit"]').click();const body=(await submitted).postDataJSON();
    assert.equal(body.timing_policy.task.seconds,3);assert.equal(body.timing_policy.episode.seconds,4);assert.equal(body.timing_policy.total.seconds,8);
    await page.locator('#series-detail').waitFor({state:'visible'});
    let result;const deadline=Date.now()+50000;
    while(Date.now()<deadline){const list=await api('series');const item=list.find(s=>s.title==='安全屋浏览器回归');if(item){result=await api('series/'+item.id);if(['complete','error','paused'].includes(result.status))break;}await new Promise(resolve=>setTimeout(resolve,200));}
    assert.equal(result?.status,'complete',JSON.stringify(result?.error||logs));assert.equal(result.episodes.length,2);
    assert(Math.abs(result.episodes.reduce((sum,e)=>sum+e.final.duration,0)-8)<.15);
    assert.deepEqual(errors,[]);
    console.log('Chromium passed: default AI timings; 3 independent overrides; 8-slot import; persistent second image template; two episodes rendered and merged with real FFmpeg.');
  } finally {if(browser)await browser.close();server.kill('SIGTERM');await new Promise(resolve=>{if(server.exitCode!==null)resolve();else server.once('exit',resolve);});}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
