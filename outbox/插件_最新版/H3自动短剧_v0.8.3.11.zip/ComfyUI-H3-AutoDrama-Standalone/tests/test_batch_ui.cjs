const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.join(__dirname,'../static'),html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]);assert.equal(new Set(ids).size,ids.length,'duplicate DOM ids');
function context(){
 const elements=Object.fromEntries(ids.map(id=>[id,{id,value:'',disabled:false,checked:false,innerHTML:'',textContent:'',dataset:{},classList:{toggle(){},add(){},remove(){}},showModal(){this.open=true},close(){this.open=false}}]));
 for(const name of ['append-form','script-edit-form','delete-form']){
   const fields=['text','input_type','target_episode_seconds','episode_count','workflow_id','instructions','script','delete_files'].map(name=>({name,value:'',disabled:false,checked:false}));
   for(const f of fields)fields[f.name]=f;
   const submit={disabled:false};fields.push(submit);elements[name].elements=fields;elements[name].reset=()=>{};elements[name].querySelector=()=>submit;
 }
 const calls=[],notices=[];
 const ctx={timingFromForm:()=>({version:1}),restoreTiming:()=>{},console,globalThis:null,$:selector=>{assert.ok(selector.startsWith('#'));const el=elements[selector.slice(1)];assert.ok(el,'missing DOM selector '+selector);return el},$$:()=>[],
   guarded:fn=>fn,esc:s=>String(s??'').replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&#39;'}[c])),notice:s=>notices.push(s),
   FormData:class{constructor(form){return form.elements.filter(f=>f.name).map(f=>[f.name,f.value])}},
   current:null,currentSeries:{id:'original',revision:1,title:'夜归人',can_append:true,next_episode_number:3,batches:[{input_type:'script',target_episode_seconds:8}]},workflowTemplates:[],settings:{},BASE:'/',
   loadSeries:async()=>{},loadProjects:async()=>{},loadAssets:async()=>{},loadWorkflows:async()=>{},loadImageWorkflows:async()=>{},loadSettings:async()=>{},
   api:async(route,body)=>{calls.push({route,body});return route==='manage/cleanup'?{pending:0}:{}},
   openSeries:async id=>calls.push({route:'open:'+id}),renderProject:()=>{},renderSeries:()=>{}};
 ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(root,'management.js'),'utf8'),ctx);
 return {ctx,elements,calls,notices};
}
async function appendTest(failStart){
 const {ctx,elements,calls}=context();await ctx.initManagement();ctx.openAppendDialog();
 const form=elements['append-form'];form.elements.text.value='新的后续剧本';let complete;
 ctx.currentSeries.revision=2; // a poll must not silently update the dialog's revision
 ctx.api=async(route,body)=>{calls.push({route,body});if(route.endsWith('/append'))return new Promise(r=>complete=r);if(failStart&&route.endsWith('/start'))throw Error('start failed');return {}};
 const event={target:form,preventDefault(){}};const pending=form.onsubmit(event);await form.onsubmit(event);
 assert.equal(calls.filter(c=>c.route.endsWith('/append')).length,1);
 const request=calls.find(c=>c.route.endsWith('/append')).body;assert.equal(request.expected_revision,1);assert.ok(request.request_id);assert.equal(form.elements.text.disabled,true);
 complete({});if(failStart)await assert.rejects(pending,/start failed/);else await pending;
 assert.ok(calls.findIndex(c=>c.route==='open:original')<calls.findIndex(c=>c.route==='series/original/start'));
 assert.equal(form.elements.text.disabled,false);assert.equal(elements['append-dialog'].open,false);
}
async function deleteTest(){
 const {ctx,elements,calls}=context();await ctx.initManagement();vm.runInContext('refreshManagement=async()=>{}',ctx);
 vm.runInContext('deleteReview={kind:"project",id:"p",title:"测试",review_token:"reviewed",files:2,bytes:1048576,projects:1,shared_assets_kept:1,episode_number_kept:true}',ctx);
 ctx.renderDeleteReview();assert.match(elements['delete-scope'].textContent,/共享素材会保留/);assert.match(elements['delete-scope'].textContent,/本集编号保留/);
 elements['delete-form'].elements.delete_files.checked=false;
 await elements['delete-form'].onsubmit({target:elements['delete-form'],preventDefault(){}});
 const request=calls.find(c=>c.route==='manage/project/p/delete').body;assert.equal(request.review_token,'reviewed');assert.equal(request.delete_files,false);
}
async function archiveVisibility(){
 const {ctx,elements}=context();vm.runInContext(fs.readFileSync(path.join(root,'workflows.js'),'utf8'),ctx);
 elements['show-archived-workflow'].checked=true;let route;
 ctx.api=async r=>{route=r;return [{id:'visible',name:'使用中',version:1,metadata:{duration_seconds:4,media_mode:'batch'}},{id:'old',name:'旧模板',archived:true,version:1,metadata:{duration_seconds:4,media_mode:'batch'}}]};
 await ctx.loadWorkflows();assert.equal(route,'workflows?include_archived=1');
 assert.ok(elements['workflow-list'].innerHTML.includes('旧模板'));assert.ok(elements['workflow-list'].innerHTML.includes('data-manage="delete-preview"'));
 assert.ok(elements['workflow-list'].innerHTML.includes('data-manage="restore"'));
 assert.ok(!elements['project-workflow'].innerHTML.includes('旧模板'));assert.equal(elements['project-workflow'].value,'visible');
}
async function scriptEditTest(){
 const {ctx,elements,calls}=context();await ctx.initManagement();vm.runInContext('refreshManagement=async()=>{}',ctx);
 ctx.api=async(route,body)=>{calls.push({route,body});if(!body)return {id:'p',series_id:'s',title:'第2集',script:'原台词',script_revision:3,status:'draft',clips:[],generated_assets:{}};return {}};
 await ctx.openScriptEditor('p');elements['script-edit-form'].elements.script.value='改好的台词';
 await elements['script-edit-form'].onsubmit({target:elements['script-edit-form'],preventDefault(){}});
 const request=calls.find(c=>c.route==='series/s/episodes/p/script').body;assert.equal(request.script,'改好的台词');assert.equal(request.expected_revision,3);
}
(async()=>{await appendTest(false);await appendTest(true);await deleteTest();await archiveVisibility();await scriptEditTest();console.log('5 UI checks passed: append double click and frozen revision; saved batch on start failure; reviewed file deletion; archive dropdown filtering; series script editing. DOM selectors and unique IDs checked against delivered HTML.')})().catch(e=>{console.error(e);process.exitCode=1});
