const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..','static');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const code=fs.readFileSync(path.join(root,'app.js'),'utf8');
const formMarkup=html.slice(html.indexOf('<form id="settings-form"'),html.indexOf('</form>',html.indexOf('<form id="settings-form"')));
assert.match(formMarkup,/<input name="dialogue_padding_seconds" type="number" min="0" max="5" step="0.1">/);
assert.equal((html.match(/name="dialogue_padding_seconds"/g)||[]).length,1);
const backend=fs.readFileSync(path.join(__dirname,'..','version.py'),'utf8').match(/VERSION\s*=\s*['"]([^'"]+)/)[1];
assert.ok(code.includes(`FRONTEND_VERSION="${backend}"`),'frontend and backend release versions must match');
assert.match(code,/c\.dialogue_timing\?\.extra_seconds/);
const input={name:'dialogue_padding_seconds',type:'number',value:''};
const audio={name:'review_audio',type:'checkbox',checked:false};
const elements=[input,audio];elements.namedItem=name=>elements.find(x=>x.name===name);
const form={elements};
const context={$:selector=>{assert.equal(selector,'#settings-form');return form;},
  settings:{},api:async()=>({dialogue_padding_seconds:1.5,review_audio:false}),imageProviderView:()=>{}};
vm.createContext(context);
vm.runInContext(code.slice(code.indexOf('async function loadSettings()'),code.indexOf('async function saveSettings()')),context);
(async()=>{
  await context.loadSettings();assert.equal(input.value,'1.5');assert.equal(context.formSettings().dialogue_padding_seconds,1.5);
  input.value='0';assert.equal(context.formSettings().dialogue_padding_seconds,0);
  audio.checked=true;input.value='2.5';const body=context.formSettings();assert.equal(body.dialogue_padding_seconds,2.5);assert.equal(body.review_audio,true);
  console.log('4 dialogue timing UI checks passed: entry/range, default load, zero disable, numeric persistence and independent audio switch.');
})().catch(error=>{console.error(error);process.exitCode=1;});
