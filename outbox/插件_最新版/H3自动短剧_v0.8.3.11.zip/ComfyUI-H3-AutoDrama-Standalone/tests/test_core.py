from __future__ import annotations
import ast
import copy
import importlib
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if 'h3ad_test' not in sys.modules:
    package=types.ModuleType('h3ad_test');package.__path__=[str(ROOT)];sys.modules['h3ad_test']=package
domain=importlib.import_module('h3ad_test.domain')
Store=importlib.import_module('h3ad_test.storage').Store
Files=importlib.import_module('h3ad_test.files').Files
ComfyClient=importlib.import_module('h3ad_test.comfy_client').ComfyClient
RenderFailed=importlib.import_module('h3ad_test.comfy_client').RenderFailed

def rewrite(count=1,text='你好。'):
    tokens=' '.join(f'<Picture {i+1}>' for i in range(count))
    return {'prompt_en':f'subject_definitions: {tokens}\nsummary: A conversation.\nretention_analysis: Preserve identities.\ndetailed_description: [Shot 1] A woman says <d>{text}</d>.\noverall_soundscape: Quiet wind.\nnon_diegetic_music: N/A', 'prompt_zh':'人物参考；交谈；保留外观；女人说“'+text+'”；风声；无背景音乐。'}

def compiler_result(data):
    segment=data['segment'];lines=segment.get('dialogue',[])
    return {'reference_descriptions':{r['key']:{'en':'The same '+(r.get('role') or 'reference')+'.','zh':'保留同一参考。'} for r in data['references']},
            'voices':{line['speaker']:{'en':'A calm, natural adult voice.','zh':'平静自然的成年声线。'} for line in lines},
            'shots':[{'start_seconds':0,'end_seconds':segment['duration_seconds'],
                      'visual_en':'A cinematic medium shot of the conversation.', 'visual_zh':'有电影感的中景交谈。',
                      'dialogue_indices':list(range(len(lines)))}],
            'sound_en':'Quiet wind and room ambience.','sound_zh':'微风和室内环境音。'}

def assert_state_references(case,actual,expected):
    """Pinned assets stay ordered; v0.7 also includes one adopted state frame."""
    case.assertEqual([p for p in actual if p in expected],expected)
    extra=[p for p in actual if p not in expected]
    case.assertLessEqual(len(extra),1)
    for path in extra:
        case.assertIn('/assets/state_',path)
        case.assertTrue((case.files.input/path).is_file())

class DomainTests(unittest.TestCase):
    def setUp(self):self.template=json.loads((ROOT/'templates/h3_api.json').read_text());self.clip={'prompt_en':'test','duration_seconds':8,'seed':636323908608123,'continuity':'cut'}
    def graph(self,**config):return domain.build_graph(self.template,self.clip,{**domain.DEFAULTS,**config},domain.media_state(['中文 带 空格.png'],[],[]),None,'test/project/clip1')
    def test_original_names_and_order(self):
        state=domain.media_state(['中文 带 空格.png','阎2_前侧全身.png'],[],['癸司_御姐版.mp3'])
        self.assertEqual(state['images'][0],'中文 带 空格.png');self.assertEqual(state['audios'][0],'癸司_御姐版.mp3')
    def test_total_reference_limit(self):
        with self.assertRaises(ValueError):domain.media_state(['x']*9,['x']*2,['x']*2)
    def test_normal_branch_has_no_optional_dependencies(self):
        g=self.graph();types_={x['class_type'] for x in g.values()}
        for node in ('LoraLoaderModelOnly','MinimaxH3LatentUpscaler3D','ComfySwitchNode','ComfyMathExpression'):self.assertNotIn(node,types_)
        self.assertEqual(g['38']['inputs']['length'],['10',0]);self.assertEqual(g['10']['inputs']['value'],192)
    def test_enabled_optional_branches(self):
        g=self.graph(turbo=True,upscale=True);types_={x['class_type'] for x in g.values()}
        self.assertIn('LoraLoaderModelOnly',types_);self.assertIn('MinimaxH3LatentUpscaler3D',types_)
        self.assertIn('H3ADv1RefitGuide',types_);self.assertEqual(g['6']['inputs']['steps'],['16',0])
    def test_original_graph_is_not_mutated(self):
        before=copy.deepcopy(self.template);self.graph(upscale=True);self.assertEqual(before,self.template)
    def test_continuation_requires_previous(self):
        self.clip['continuity']='continue'
        with self.assertRaises(ValueError):self.graph()
        g=domain.build_graph(self.template,self.clip,domain.DEFAULTS,domain.media_state(['a.png'],[],[]),'prev.mp4 [output]','clip')
        self.assertTrue(g['34']['inputs']['value']);self.assertEqual(g['40']['inputs']['previous_video_name'],'prev.mp4 [output]')
    def test_actual_frame_alignment(self):
        for duration in (2,8,15):
            self.clip['duration_seconds']=duration;frames=self.graph()['10']['inputs']['value'];self.assertEqual(frames%17,5);self.assertGreaterEqual(frames,round(duration*24))
    def test_continuation_dialogue_window_excludes_trimmed_prefix(self):
        clip={'duration_seconds':8,'continuity':'continue'}
        t=domain.video_timing(clip,domain.DEFAULTS,{'duration_seconds':8})
        self.assertEqual(t['guide_frames'],22);self.assertEqual(t['output_frames'],192);self.assertAlmostEqual(t['new_content_start_seconds'],22/24)
        self.assertAlmostEqual(t['new_content_end_seconds']-t['new_content_start_seconds'],8)
        self.assertGreater(t['generated_total_seconds'],t['new_content_end_seconds'])
    def test_prompt_references_and_dialogue(self):
        domain.validate_rewrite(rewrite(),{'images':['x']},[{'text':'你好。'}])
        with self.assertRaises(ValueError):domain.validate_rewrite(rewrite(2),{'images':['x']})
        with self.assertRaises(ValueError):domain.validate_rewrite(rewrite(),{'images':['x']},[{'text':'被改掉的台词'}])
    def test_requires_translation_and_no_music(self):
        r=rewrite();r['prompt_zh']=''
        with self.assertRaises(ValueError):domain.validate_rewrite(r,{'images':['x']})
        r=rewrite();r['prompt_en']=r['prompt_en'].replace('N/A','Loud dramatic score')
        with self.assertRaises(ValueError):domain.validate_rewrite(r,{'images':['x']})
    def test_reject_path_traversal(self):
        for s in ('../x','a/b.png','a\\b.png','..'):
            with self.assertRaises(ValueError):domain.safe_name(s)
        domain.safe_name('中文 (声音) .mp3')
    def test_redo_closure_stops_at_cut(self):
        clips=[{'continuity':x} for x in ['cut','continue','continue','cut','continue']]
        self.assertEqual(domain.dependent_indices(clips,[0]),[0,1,2]);self.assertEqual(domain.dependent_indices(clips,[1,3]),[1,2,3,4])
    def test_only_real_saved_outputs_count_as_success(self):
        self.assertIsNone(ComfyClient.output({'status':{'completed':False},'outputs':{}}))
        with self.assertRaises(RenderFailed):ComfyClient.output({'status':{'completed':True,'status_str':'error','messages':[['execution_error',{'node_id':'4'}]]}})
        with self.assertRaises(RenderFailed):ComfyClient.output({'status':{'completed':True},'outputs':{}})
    def test_queue_marker(self):
        extra={'h3_autodrama_v1':{'job_id':'job'}};item=[3,'pid',{},extra,['20']]
        self.assertEqual(ComfyClient.marker(item),'job');self.assertEqual(ComfyClient.marker({'prompt':item}),'job')
    def test_settings_validate_and_redact(self):
        cfg={**domain.DEFAULTS,'comfy_url':'https://host.example:1234','openai_api_key':'secret','seed':2**63+7}
        cfg=domain.validate_settings(cfg);out=domain.public_settings(cfg)
        self.assertEqual(out['openai_api_key'],'');self.assertTrue(out['openai_api_key_configured']);self.assertEqual(out['seed'],str(2**63+7))
        with self.assertRaises(ValueError):domain.validate_settings({**cfg,'width':1001})
        with self.assertRaises(ValueError):domain.validate_settings({**cfg,'comfy_url':'javascript:x'})
    def test_nodes_namespace_no_global_handler(self):
        source=(ROOT/'render_nodes.py').read_text();tree=ast.parse(source)
        classes=[n.name for n in tree.body if isinstance(n,ast.ClassDef)]
        self.assertTrue(classes);self.assertTrue(all(n.startswith('H3ADv1') for n in classes))
        self.assertNotIn('H3Continue',source);self.assertNotIn('add_on_prompt_handler',(ROOT/'__init__.py').read_text())
        self.assertNotIn('register_extension',(ROOT/'render_nodes.py').read_text())
    def test_no_personal_prompt_or_asset_in_template(self):
        self.assertEqual(self.template['39']['inputs']['value'],'');self.assertEqual(self.template['40']['inputs']['previous_video_name'],'')
        self.assertFalse(json.loads(self.template['38']['inputs']['batch_media_json'])['images'])

class StoreTests(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.store=Store(Path(self.temp.name)/'data');self.files=Files(Path(self.temp.name)/'input',Path(self.temp.name)/'output')
    def tearDown(self):self.temp.cleanup()
    def test_secrets_preserved_when_blank(self):
        self.store.save_settings({'openai_api_key':'abc'});self.store.save_settings({'openai_api_key':''})
        self.assertEqual(self.store.settings()['openai_api_key'],'abc');self.store.save_settings({'clear_keys':['openai_api_key']});self.assertEqual(self.store.settings()['openai_api_key'],'')
    def test_restart_keeps_work_and_secrets(self):
        p=self.store.create_project({'script':'剧本','title':'第一集'});self.store.save_settings({'openai_api_key':'abc'})
        again=Store(self.store.root);self.assertEqual(again.get('project',p['id'])['script'],'剧本');self.assertEqual(again.settings()['openai_api_key'],'abc')
    def test_import_keeps_old_file(self):
        original=self.files.input/'中文 (原声).mp3';original.write_bytes(b'audio')
        a=self.files.import_asset(self.store,original.name,{'speaker':'人物甲'})
        self.assertEqual(a['name'],original.name);self.assertEqual(original.read_bytes(),b'audio');self.assertEqual(self.files.asset_path(a).read_bytes(),b'audio')
        with self.assertRaises(ValueError):self.files.import_asset(self.store,'../../secret.mp3')
    def test_project_does_not_accept_keys_or_urls(self):
        p=self.store.create_project({'script':'test','settings':{'openai_api_key':'oops','comfy_url':'http://other','width':1024}})
        self.assertEqual(p['settings'],{'width':1024})

if __name__=='__main__':unittest.main()
