"""Keep generated speech tails until the independent transcript gate runs.

The old pipeline cropped twice *before* listening. Neither an H3 alignment
frame nor a planned shot boundary is evidence that the soundtrack is silent.
This contract is saved before submission; resuming a committed job never
retroactively changes its graph or retention policy.
"""
import copy
from .dialogue_timing import COMMITTED

VERSION = 1
TRIM_TYPES = {'H3ContinueTrim', 'H3ADv1Trim'}


def fixed_reason(project, clip, cfg):
    policy = project.get('timing_policy') or {}
    for name in ('episode', 'total', 'task'):
        if (policy.get(name) or {}).get('enabled'):
            return 'manual_' + name
    if clip.get('generation_exact') and not project.get('production_draft'):
        return 'exact_task'
    if cfg.get('_dialogue_fixed_total') or (project.get('episode_target_seconds') and not project.get('production_draft')):
        return 'fixed_episode'
    return ''


def prepare(project, clip, cfg):
    if (not clip.get('dialogue') or not clip.get('timing_version')
            or any(clip.get(key) for key in COMMITTED)):
        return False
    reason = fixed_reason(project, clip, cfg)
    value = {'version': VERSION, 'policy': 'fixed' if reason else 'preserve_tail',
             'fixed_reason': reason}
    if clip.get('dialogue_retention') == value:
        return False
    clip['dialogue_retention'] = value
    # A saved structured description is reusable; compiled timing text is not.
    # Leave it in place with its old compiler version so upgrade reuse can run.
    return True


def active(clip):
    return (clip.get('dialogue_retention') or {}).get('version') == VERSION


def actual_guide_frames(previous_clip):
    """Match Prepare's floor(duration * 24), using the adopted file duration."""
    if not previous_clip or not previous_clip.get('meta'):
        return None
    meta=previous_clip['meta']
    value=float((meta.get('video') or {}).get('duration') or meta.get('duration') or 0)
    if value<=0:
        return None
    available=int(value*24+1e-6)
    return max(0,5+17*((available-5)//17))


def protect_graph(graph, output_node, clip):
    """Change only the submitted copy, never the user's saved workflow.

    Both supported Trim implementations define count=0 as all remaining
    frames. Keep the prefix removal (guide), and disable only the tail limit.
    Fixed-duration projects also save this fuller raw result for diagnosis;
    their requested output boundary is still enforced in accept_output.
    """
    if not active(clip):
        return graph, None
    from .workflows import upstream, is_link, PREPARE_NODES
    result = copy.deepcopy(graph)
    nodes = upstream(result, output_node)
    trims = [nid for nid in nodes if result[nid]['class_type'] in TRIM_TYPES]
    changes = []
    if clip.get('continuity') == 'continue':
        if len(trims) != 1:
            raise ValueError('对白尾部保护需要所选视频输出包含一个受支持的续接裁剪节点。')
        nid = trims[0]
        inputs = result[nid]['inputs']
        start = inputs.get('trim_start_frames')
        if (not is_link(start) or start[1] != 3
                or result[start[0]]['class_type'] not in PREPARE_NODES):
            raise ValueError('对白尾部保护无法核实续接引导裁剪来源；请检查 trim_start_frames 接线。')
        before = copy.deepcopy(inputs.get('trim_output_frames'))
        inputs['trim_output_frames'] = 0
        changes.append({'node': nid, 'class_type': result[nid]['class_type'],
                        'input': 'trim_output_frames', 'before': before, 'after': 0})
        # The legacy node can still truncate audio at the last video frame
        # even with count=0. Use our compatible implementation only when its
        # exact supported interface is present; saved templates stay intact.
        if (result[nid]['class_type']=='H3ContinueTrim'
                and set(inputs)=={'images','audio','trim_start_frames','trim_output_frames','enable_continue'}):
            result[nid]['class_type']='H3ADv1Trim'
            changes.append({'node':nid,'input':'class_type','before':'H3ContinueTrim','after':'H3ADv1Trim',
                            'reason':'保留全部音轨尾部，仍按原接线移除续接引导'})
    return result, {'version': VERSION, 'policy': clip['dialogue_retention']['policy'],
                    'prefix_guide_removed': clip.get('continuity') == 'continue',
                    'tail_limit_changes': changes}


def audit(clip, raw_meta, kept_meta):
    def duration(meta):
        return float((meta.get('video') or {}).get('duration') or meta['duration'])
    raw, kept = duration(raw_meta), duration(kept_meta)
    return {'version': VERSION, **clip['dialogue_retention'],
            'planned_seconds': float(clip['duration_seconds']),
            'raw_seconds': raw, 'retained_seconds': kept,
            'application_removed_tail_seconds': round(max(0., raw-kept), 6),
            'raw_video_frames': (raw_meta.get('video') or {}).get('nb_frames'),
            'retained_video_frames': (kept_meta.get('video') or {}).get('nb_frames'),
            'note': ('保留生成结果的全部新内容尾部；对白是否完整由实际语音核对判断。'
                     if clip['dialogue_retention']['policy'] == 'preserve_tail' else
                     '遵守固定时长；另存裁剪前结果，核对缺尾时区分生成缺词与裁剪损失。')}


def extra_hold(clip, shots, shot_number):
    """Padding must not lengthen the intended spoken window again.

    v0.8.3.3 inserts padding in the last speaking shot. Subtract that padding
    from its speaking window, while keeping the longer visual shot and output.
    No change to the heuristic speech budget or to the original words.
    """
    if not active(clip):
        return 0.
    speaking = [i for i, shot in enumerate(shots, 1)
                if isinstance(shot, dict) and shot.get('dialogue_indices')]
    if not speaking or shot_number != speaking[-1]:
        return 0.
    requested = max(0., float((clip.get('dialogue_timing') or {}).get('extra_seconds', 0)))
    shot = shots[shot_number - 1]
    # Only the generated-content recovery boundary calculates this value.
    # Direct compiler callers keep the strict, full-padding contract.
    if shot.get('_speech_timing_contract') == 1:
        return min(requested, max(0., float(shot['_speech_reserved_extra_seconds'])))
    return requested
