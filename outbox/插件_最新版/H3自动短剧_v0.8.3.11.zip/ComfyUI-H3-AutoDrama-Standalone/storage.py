from __future__ import annotations
import copy
import json
import os
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from .domain import DEFAULTS, SECRET_KEYS, public_settings, validate_settings

class Store:
    def __init__(self, root):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.db=self.root/'projects.sqlite3';self.lock=threading.RLock()
        with self.connect() as c:
            c.execute('PRAGMA journal_mode=WAL')
            c.execute('CREATE TABLE IF NOT EXISTS records(kind TEXT,id TEXT,body TEXT,PRIMARY KEY(kind,id))')
        try:os.chmod(self.root,0o700);os.chmod(self.db,0o600)
        except OSError:pass
    def connect(self):return sqlite3.connect(self.db,timeout=30)
    def get(self,kind,id):
        with self.connect() as c:r=c.execute('SELECT body FROM records WHERE kind=? AND id=?',(kind,id)).fetchone()
        if not r:raise KeyError('找不到记录：'+id)
        return json.loads(r[0])
    def put(self,kind,id,body):
        with self.lock,self.connect() as c:c.execute('INSERT OR REPLACE INTO records VALUES(?,?,?)',(kind,id,json.dumps(body,ensure_ascii=False)))
        return body
    def update(self,kind,id,fn):
        with self.lock:
            body=self.get(kind,id);fn(body);body['updated_at']=time.time();self.put(kind,id,body);return body
    def apply_changes(self,writes=(),deletes=()):
        """Commit related record changes together; callers may hold the RLock."""
        with self.lock,self.connect() as c:
            c.executemany('INSERT OR REPLACE INTO records VALUES(?,?,?)',
                [(kind,id,json.dumps(body,ensure_ascii=False)) for kind,id,body in writes])
            c.executemany('DELETE FROM records WHERE kind=? AND id=?',list(deletes))
    def list(self,kind):
        with self.connect() as c:rows=c.execute('SELECT body FROM records WHERE kind=?',(kind,)).fetchall()
        return sorted([json.loads(r[0]) for r in rows],key=lambda x:x.get('created_at',0),reverse=True)
    def settings(self):
        try:stored=self.get('config','main')
        except KeyError:stored={}
        return {**copy.deepcopy(DEFAULTS),**stored}
    def save_settings(self,body):
        current=self.settings()
        if 'review_enabled' in body and not any(k in body for k in ('review_image_enabled','review_video_enabled')):
            current.update(review_image_enabled=None,review_video_enabled=None)
        for key,value in body.items():
            if key in DEFAULTS:
                if key in SECRET_KEYS and not value:continue
                current[key]=value
        for key in body.get('clear_keys',[]):
            if key in SECRET_KEYS:current[key]=''
        current=validate_settings(current)
        for key,reference in (('image_workflow_id',False),('image_reference_workflow_id',True)):
            if current[key]:
                try:template=self.get('image_workflow',current[key])
                except KeyError:raise ValueError('所选生图模板不存在，请重新选择。')
                if template.get('archived') or (template['reference_mode']!='none')!=reference:
                    raise ValueError('基础图须使用文生图模板，镜头图须使用带参考图模板；模板不能已归档。')
        self.put('config','main',current)
        return public_settings(current)
    def create_project(self,body,project_id=None):
        # Deterministic IDs are used internally for series children, so a
        # restart between child creation and series update cannot duplicate it.
        from .domain import safe_id
        from . import timing_policy
        id=safe_id(project_id) if project_id else uuid.uuid4().hex
        if project_id:
            try:return self.get('project',id)
            except KeyError:pass
        script=str(body.get('script','')).strip()
        if not script:raise ValueError('请填写剧本。')
        if len(script)>500000:raise ValueError('剧本过长，请按集建立项目。')
        asset_ids=list(dict.fromkeys(body.get('asset_ids',[])))
        for aid in asset_ids:self.get('asset',aid)
        from .production import inferred_bindings, validate_bindings, binding_ids
        bindings=validate_bindings(body['character_bindings'] if 'character_bindings' in body else inferred_bindings([self.get('asset',a) for a in asset_ids]),self)
        asset_ids=list(dict.fromkeys(asset_ids+binding_ids(bindings)))
        render_fields={'width','height','steps','duration_seconds','seed','seed_mode','upscale','upscale_factor','turbo','turbo_steps','refine_steps','refine_start_step','refine_save_vram','bit_depth','color_space','overlap_seconds','continue_audio','generate_shot_images'}
        overrides={k:v for k,v in body.get('settings',{}).items() if k in render_fields}
        validate_settings({**self.settings(),**overrides})
        snapshot=copy.deepcopy(self.get('workflow',str(body['workflow_id']))) if body.get('workflow_id') else None
        if snapshot and snapshot.get('archived'):raise ValueError('请选择未归档的工作流。')
        if snapshot and snapshot.get('media_mode')=='single_image' and any(b.get('voice_id') for b in bindings.values()):raise ValueError('固定声音参考需要批量素材视频工作流。')
        timing=timing_policy.from_body(body)
        timing_policy.check_workflow(timing,snapshot)
        ep=timing_policy.seconds(timing,'episode');total=timing_policy.seconds(timing,'total')
        if ep and total and timing_policy.frames(ep)!=timing_policy.frames(total):raise ValueError('单集项目的每集时长与总时长须一致，或只勾选一项。')
        return self.put('project',id,{
            'id':id,'title':str(body.get('title') or '未命名短剧'),'script':script,'instructions':str(body.get('instructions','')),
            'asset_ids':asset_ids,'character_bindings':bindings,'settings':overrides,'workflow_snapshot':snapshot,'series_id':body.get('series_id'),
            'timing_policy':timing,
            'status':'draft','phase':'等待开始','plan':None,'clips':[],'generated_assets':{},'events':[],'script_revision':1,
            'pause_requested':False,'error':'','final':None,'created_at':time.time(),'updated_at':time.time(),
        })
    def event(self,id,message):
        def change(p):
            p.setdefault('events',[]).append({'time':time.time(),'message':str(message)})
            p['events']=p['events'][-200:]
        return self.update('project',id,change)
    def public_project(self,id):
        p=self.get('project',id)
        p.setdefault('script_revision',1)
        if p.get('workflow_snapshot'):
            from .workflows import summary
            p['workflow_snapshot']=summary(p['workflow_snapshot'])
        if p.get('image_workflow_snapshots'):
            from .image_workflows import summary as image_summary
            p['image_workflow_snapshots']={key:image_summary(value) if value else None for key,value in p['image_workflow_snapshots'].items()}
        for clip in p.get('clips',[]):
            clip.pop('api_graph',None)
            if clip.get('seed') is not None:clip['seed']=str(clip['seed'])
        return p
