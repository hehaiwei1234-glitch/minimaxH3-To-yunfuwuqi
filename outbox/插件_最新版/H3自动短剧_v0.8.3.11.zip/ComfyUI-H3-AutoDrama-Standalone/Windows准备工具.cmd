@echo off
setlocal
title H3 AutoDrama - Prepare Windows Tools
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_windows_tools.ps1"
set "h3ad_exit_code=%ERRORLEVEL%"
echo.
pause
exit /b %h3ad_exit_code%
