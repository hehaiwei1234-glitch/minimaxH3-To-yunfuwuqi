"""Spoken language belongs to original dialogue, not translated UI prose."""
import re
import unicodedata

LABELS = {'zh': 'Chinese', 'en': 'English', 'ja': 'Japanese'}
ALIASES = {
    'auto': 'auto', 'automatic': 'auto', '自动': 'auto',
    'zh': 'zh', 'zh-cn': 'zh', 'zh-tw': 'zh', 'chinese': 'zh', '中文': 'zh',
    'en': 'en', 'en-us': 'en', 'en-gb': 'en', 'english': 'en', '英语': 'en', '英文': 'en',
    'ja': 'ja', 'ja-jp': 'ja', 'jp': 'ja', 'japanese': 'ja', '日语': 'ja', '日文': 'ja',
}


def canonical(value='auto'):
    if not isinstance(value, str) or value.strip().lower() not in ALIASES:
        raise ValueError('对白语言请选择自动、中文、英语或日语。')
    return ALIASES[value.strip().lower()]


def detect(text):
    text = unicodedata.normalize('NFKC', str(text))
    if re.search(r'[\u3040-\u30ff\uff66-\uff9f]', text):
        return 'ja'
    if re.search(r'[\u3400-\u9fff]', text):
        return 'zh'
    return 'en' if re.search(r'[A-Za-z]', text) else 'zh'


def resolve(line, *contexts):
    for value in [line.get('language', 'auto')] + [c.get('dialogue_language', 'auto') for c in contexts if isinstance(c, dict)]:
        language = canonical(value)
        if language != 'auto':
            return language
    return detect(line.get('text', ''))


def tag(line, *contexts):
    return LABELS[resolve(line, *contexts)]


def apply(segment, *contexts):
    """Annotate only an explicit choice; automatic legacy Chinese stays equal."""
    choice = next((canonical(c.get('dialogue_language', 'auto')) for c in (segment, *contexts)
                   if isinstance(c, dict) and canonical(c.get('dialogue_language', 'auto')) != 'auto'), 'auto')
    if choice != 'auto':
        segment['dialogue_language'] = choice
        for line in segment.get('dialogue', []):
            if canonical(line.get('language', 'auto')) == 'auto':
                line['language'] = choice
    return segment


def asr_hint(lines, *contexts):
    languages = {resolve(line, *contexts) for line in lines if str(line.get('text', '')).strip()}
    # Do not force a single ASR language for a multilingual clip or line.
    for line in lines:
        text = str(line.get('text', ''))
        if re.search(r'[A-Za-z]{2,}', text) and re.search(r'[\u3040-\u30ff\u3400-\u9fff]', text):
            return None
    return next(iter(languages)) if len(languages) == 1 else None


def comparison_text(text, language=None):
    text = unicodedata.normalize('NFKC', str(text)).lower()
    if (language or detect(text)) == 'en':
        # Preserve word boundaries: "the rapist" cannot pass as "therapist".
        text = re.sub(r"['’]", '', text)
        return ' '.join(re.findall(r'[^\W_]+', text, re.UNICODE))
    return ''.join(c for c in text if c.isalnum())


def instruction(config):
    language = canonical(config.get('dialogue_language', 'auto'))
    chosen = LABELS.get(language)
    return ('\n对白语言：' + (chosen if chosen else '跟随用户要求及原始对白；未指定的新故事默认中文')
            + '。已有剧本的台词不得翻译、删改或换语言。对白可逐句指定中文、英语或日语；镜头说明的语言不代表对白语言。')
