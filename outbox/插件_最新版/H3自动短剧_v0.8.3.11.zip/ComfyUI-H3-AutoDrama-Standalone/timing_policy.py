"""Story pacing and render requests are separate, frame-based quantities."""
from __future__ import annotations
import copy
import math

FPS=24
KINDS={'episode':('每集时长',.25,86400),'total':('全剧总时长',.25,8640000),'task':('每次任务时长',2,15)}

def normalize(value=None):
    if value is None:value={}
    if not isinstance(value,dict):raise ValueError('时长设置格式不正确。')
    result={'version':1}
    for key,(label,minimum,maximum) in KINDS.items():
        item=value.get(key,{})
        if not isinstance(item,dict) or not isinstance(item.get('enabled',False),bool):raise ValueError(label+'开关无效。')
        enabled=item.get('enabled',False);seconds=None
        if enabled:
            raw=item.get('seconds')
            if raw is None or raw=='' or isinstance(raw,bool):raise ValueError('勾选'+label+'后，请填写秒数。')
            try:seconds=float(raw)
            except (ValueError,TypeError):raise ValueError(label+'必须是有效秒数。')
            if not math.isfinite(seconds) or not minimum<=seconds<=maximum:raise ValueError(f'{label}须为{minimum:g}至{maximum:g}秒。')
        result[key]={'enabled':enabled,'seconds':seconds}
    return result

def from_body(body):
    if 'timing_policy' in body:return normalize(body['timing_policy'])
    target=body.get('target_episode_seconds',0)
    return normalize({'episode':{'enabled':bool(float(target or 0)), 'seconds':target}})

def seconds(policy,key):
    item=(policy or {}).get(key,{})
    return float(item['seconds']) if item.get('enabled') else 0

def frames(value):return max(1,round(float(value)*FPS))

def series_count(policy,count):
    episode=seconds(policy,'episode');total=seconds(policy,'total')
    if episode and total:
        n=frames(total)/frames(episode)
        if abs(n-round(n))>1e-6 or not 1<=round(n)<=100:
            raise ValueError('每集时长与全剧总时长冲突：总时长须为每集时长的整数倍；可关闭其中一项交给AI。')
        if count and count!=round(n):raise ValueError('指定集数与每集时长、全剧总时长不一致。')
        return round(n)
    return count

def assign_episodes(plan,policy):
    episode=seconds(policy,'episode');total=seconds(policy,'total')
    for e in plan['episodes']:
        if episode:e['target_seconds']=frames(episode)/FPS
        elif total:
            try:d=float(e['duration_seconds'])
            except (KeyError,ValueError,TypeError):raise ValueError('指定全剧总时长后，AI须为每集返回duration_seconds，且合计等于总时长。')
            if not math.isfinite(d) or not .25<=d<=86400:raise ValueError('AI分配的每集秒数无效。')
            e['target_seconds']=frames(d)/FPS
        else:e['target_seconds']=0
    if total and sum(frames(e['target_seconds']) for e in plan['episodes'])!=frames(total):
        raise ValueError('AI分配的各集时长合计不等于指定全剧总时长，请重新分配，不能忽略用户时长。')
    return plan

def prepare_segments(plan,policy,target=0):
    result=copy.deepcopy(plan);task=seconds(policy,'task')
    for i,s in enumerate(result['segments']):
        duration=frames(s['duration_seconds'])/FPS
        if task and duration>task+1/FPS:
            raise ValueError(f'第{i+1}段超过用户每次任务{task:g}秒，请按动作和台词拆成多个任务；同一长镜头用continue续接，不能直接截掉内容。')
        s['duration_seconds']=duration
        s['generation_seconds']=task or max(2,duration)
        s['generation_exact']=bool(task)
        s['timing_version']=1
    target=target or seconds(policy,'episode') or seconds(policy,'total')
    if target and sum(frames(s['duration_seconds']) for s in result['segments'])!=frames(target):
        raise ValueError(f'分镜保留时长合计须为{target:g}秒（按24FPS对齐），不能用模板默认秒数代替。请重新安排镜头和台词，不能删改台词或加速声音。')
    return result

def check_workflow(policy,record):
    if not record or not seconds(policy,'task'):return
    from . import workflows
    record=workflows.resolved(record);value=seconds(policy,'task')
    if record['duration_mode']=='seconds' and isinstance(workflows.read(record['graph'],record['bindings']['duration']),int) and not value.is_integer():
        raise ValueError('这份工作流的任务时长输入只接收整数秒，请将每次任务时长填写为整数。')

def instructions(policy,target=0):
    task=seconds(policy,'task')
    return ('\n时长优先级：用户勾选并填写的值 > AI安排 > 工作流示例值。未勾选时按剧本对白、动作和节奏决定，禁止套用模板默认秒数。'
            '\nsegments是生成任务，不是镜头时长上限：一个长镜头可拆成多个continuity=continue的任务，剧情转场用cut。每段duration_seconds为实际保留内容时长，最短0.25秒，最长15秒。'
            '\nduration_seconds按1/24秒对齐。生成帧数可能向上对齐。对白和动作按计划时长安排；自动时长的对白任务另保留实际生成尾部以保护句尾，不把额外对齐帧用于新剧情。固定时长和无对白任务仍按计划裁剪。'
            +(f'\n用户每次ComfyUI任务请求固定{task:g}秒；每段保留时长不得超过它；尾段可少保留。长对白在自然停顿处分配，不得机械截断。' if task else '\n每次任务的秒数也由你决定，H3单次生成范围2至15秒，更短的剪辑用最少2秒生成后保留所需部分。')
            +(f'\n本集保留时长合计必须为{target:g}秒，不删台词、不倍速。' if target else '\n本集没有人工指定时长，剧情走到哪里算哪里，不填充空镜凑秒数。'))
