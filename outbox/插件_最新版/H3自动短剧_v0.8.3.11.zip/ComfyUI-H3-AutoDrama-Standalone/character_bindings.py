"""Update pins for future work without silently remaking completed episodes."""
from .production import validate_bindings, binding_ids, bind_plan


def save_bindings(store,kind,identity,body):
    with store.lock:
        record=store.get(kind,identity)
        if record.get('archived') or record['status'] in {'running','queued','pausing'}:
            raise ValueError('请等当前制作完成或暂停，再调整角色与声音。')
        if kind=='project' and record.get('series_id'):
            raise ValueError('请在所属整剧的“固定角色与声音”中修改。')
        if body.get('expected_revision')!=record.get('bindings_revision',1):
            raise ValueError('角色绑定已更新，请重新打开后保存。')
        bindings=validate_bindings(body.get('character_bindings',{}),store)
        ids=binding_ids(bindings)
        snapshot=record.get('workflow_snapshot') or {}
        if snapshot.get('media_mode')=='single_image' and any(b.get('voice_id') for b in bindings.values()):
            raise ValueError('此视频工作流只接收单张图；固定音色需要支持音频的批量素材工作流。')
        targets=[store.get('project',p) for p in record.get('project_ids',[])] if kind=='series' else [record]
        writes=[];updated=0;retained=0
        for project in targets:
            begun=any(c.get('frame_asset_id') or c.get('job_id') or c.get('output') for c in project.get('clips',[]))
            if begun or project.get('final'):
                if kind=='project':raise ValueError('本集已经准备或生成镜头；请为新项目指定角色，避免混入两套人物。')
                retained+=1;continue
            project['character_bindings']=bindings
            project['asset_ids']=list(dict.fromkeys(project['asset_ids']+ids))
            if project.get('plan'):
                assets=[store.get('asset',a) for a in project['asset_ids']]
                plan=bind_plan(project['plan'],bindings,assets)
                project['plan']=plan
                for clip,segment in zip(project['clips'],plan['segments']):
                    for k in ('asset_ids','image_reference_ids','characters'):
                        clip[k]=segment.get(k,[])
                    for k in ('prompt_en','prompt_zh'):clip.pop(k,None)
            if kind=='series':writes.append(('project',project['id'],project))
            updated+=1
        record['character_bindings']=bindings
        record['asset_ids']=list(dict.fromkeys(record['asset_ids']+ids))
        record['bindings_revision']=record.get('bindings_revision',1)+1
        writes.append((kind,identity,record));store.apply_changes(writes)
        return {'updated_episodes':updated,'retained_episodes':retained,'bindings_revision':record['bindings_revision']}
