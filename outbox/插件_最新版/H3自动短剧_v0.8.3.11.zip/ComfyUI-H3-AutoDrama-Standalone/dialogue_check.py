"""Independent audio transcript gate; never claim to hear from video frames."""
import copy
import hashlib
import json
import time
import unicodedata
from pathlib import Path
import re
from .media_tools import command
from .providers import AIClient, APIError
from .review import ReviewPaused
from .telemetry import measure
from .dialogue_plan import normalized
from .dialogue_language import comparison_text, asr_hint
from .speech_recognition import recognize
from .dialogue_timing import missing_tail
from . import dialogue_retention

VERSION=1


def enabled(cfg):return bool(cfg.get('review_audio'))


def signature(files,clip):
    if not clip.get('output'):return ''
    stat=files.output_path(clip['output']).stat()
    value={'version':VERSION,'generation':clip.get('generation'),'job':clip.get('job_id'),
           'raw':clip.get('raw_output'),'size':stat.st_size,'mtime_ns':stat.st_mtime_ns,
           'duration':clip.get('duration_seconds'),'dialogue':clip.get('dialogue',[])}
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True).encode()).hexdigest()


def current_report(files,clip):
    report=clip.get('dialogue_check') or {}
    try:valid=report.get('signature')==signature(files,clip)
    except (OSError,KeyError):valid=False
    return report if valid else None


def approved(files,clip,cfg):
    if not enabled(cfg) or not clip.get('dialogue'):return True
    report=current_report(files,clip)
    return bool(report and report.get('passed'))


def resolved(files,clip,cfg):
    """Ready for continuation after a pass or an explicit NG adoption.

    Adoption never changes the recognition result to a pass. Its signature
    binds the decision to this exact video and dialogue, not an older take.
    """
    # An unavailable checker is not evidence of complete speech. Production
    # may explicitly retain this exact saved video as unchecked NG and proceed.
    from .task_recovery import adopted_unchecked
    if adopted_unchecked(files, clip):return True
    if approved(files,clip,cfg):return True
    report=current_report(files,clip);decision=clip.get('dialogue_adoption') or {}
    return bool(report and clip.get('quality_accepted') and clip.get('adopted_ng')
                and decision.get('status')=='adopted_ng'
                and decision.get('signature')==report.get('signature'))


def compare(expected,actual,language=None):
    a=comparison_text(expected,language);b=comparison_text(actual,language)
    if a==b and a:return {'passed':True,'status':'passed','reason':'识别文字与原文一致（忽略标点和空白）。'}
    if b and a.startswith(b):return {'passed':False,'status':'incomplete','missing_tail_chars':len(a)-len(b),'missing_tail_text':a[len(b):],'reason':'识别结果缺少原句末尾：'+expected[-min(60,len(expected)): ]}
    missing=missing_tail(expected,actual)
    if missing:return {'passed':False,'status':'needs_review','suspected_missing_tail_chars':missing,'reason':'识别有少量差异且疑似缺少末尾'+str(missing)+'字；按视频/对白共用次数修正并增加时间余量。'}
    return {'passed':False,'status':'needs_review','reason':'识别文字与原文不一致，可能漏词、错词或识别误差；按视频/对白共用次数处理，并保留识别结果。'}


class DialogueCheckMixin:
    async def check_dialogue(self,identity,index,cfg,session):
        clip=self.store.get('project',identity)['clips'][index]
        if not clip.get('dialogue'):
            return {'passed':True,'status':'not_required'}
        if not enabled(cfg):return {'passed':True,'status':'disabled'}
        cached=current_report(self.files,clip)
        if cached:return cached
        self.paused(identity)
        language=asr_hint(clip['dialogue'],clip)
        expected=(' ' if language in {'en',None} else '').join(line['text'] for line in clip['dialogue'])
        fingerprint=signature(self.files,clip)
        report={'version':VERSION,'signature':fingerprint,'expected':expected,'created_at':time.time(),
                'model':cfg['asr_model'],'passed':False,'status':'pending'}
        if not clip.get('meta',{}).get('audio'):
            report.update(status='incomplete',transcript='',reason='片段包含对白，但最终视频没有音轨。')
        else:
            self.set(identity,phase=f'核对第{index+1}段实际对白')
            folder=self.files.project_dir(identity)/'自检记录'/f'dialogue_{index+1:03d}_{fingerprint[:12]}'
            folder.mkdir(parents=True,exist_ok=True);wav=folder/'speech.wav'
            client=AIClient({**cfg,'asr_language':language},session)
            cached_asr=clip.get('dialogue_retained_recognition') or {}
            if cached_asr.get('signature')==fingerprint:
                response=cached_asr['response'];asr_protocol=cached_asr['provider']
            else:
                await command([cfg['ffmpeg'],'-y','-v','error','-i',self.files.output_path(clip['output']),'-vn','-ac','1','-ar','16000',wav])
                with measure('dialogue_asr',str(index+1)):
                    response,asr_protocol=await recognize(client,wav.read_bytes())
                cached_asr={'signature':fingerprint,'response':response,'provider':asr_protocol,
                            'request_id':(client.last_request or {}).get('request_id')}
                self.clip_set(identity,index,dialogue_retained_recognition=cached_asr)
            transcript=response['text'];report['provider']=asr_protocol
            report.update(compare(expected,transcript,language));report['transcript']=transcript
            report['language']=language or 'auto'
            # Only word timestamps provide endpoint evidence. Waveform energy
            # can be wind/music and is deliberately not used as speech proof.
            words=response.get('words')
            if isinstance(words,list):
                ends=[w.get('end') for w in words if isinstance(w,dict) and isinstance(w.get('end'),(int,float))]
                if ends:
                    report['last_word_end']=max(ends)
                    duration=float(clip.get('meta',{}).get('duration') or clip['duration_seconds'])
                    report['tail_seconds']=round(duration-max(ends),3)
                    if report['passed'] and report['tail_seconds']<.08:
                        report.update(passed=False,status='needs_review',reason='文字识别完整，但最后一个词贴近视频结束；请试听确认没有截断。')
            report['request_id']=cached_asr.get('request_id')
            retention=clip.get('retention_audit') or {}
            report['retention']=copy.deepcopy(retention)
            # Only diagnose an actual crop after the retained transcript fails.
            # Unconstrained full-tail outputs need no additional ASR request.
            # Persist the first recognition before an optional diagnostic call;
            # a network error on that call must not trigger another paid render.
            if (not report['passed'] and clip.get('raw_output')
                    and retention.get('application_removed_tail_seconds',0)>1/24):
                prior=clip.get('dialogue_raw_diagnostic') or {}
                raw_path=self.files.output_path(clip['raw_output'])
                raw_stat=raw_path.stat()
                raw_key=f'{fingerprint}:{raw_stat.st_size}:{raw_stat.st_mtime_ns}'
                if prior.get('signature')==raw_key:
                    raw_report=prior
                else:
                    raw_wav=folder/'speech_before_crop.wav'
                    await command([cfg['ffmpeg'],'-y','-v','error','-i',raw_path,'-vn','-ac','1','-ar','16000',raw_wav])
                    with measure('dialogue_asr_before_crop',str(index+1)):
                        raw_response,protocol=await recognize(client,raw_wav.read_bytes())
                    raw_report={'signature':raw_key,'transcript':raw_response['text'],
                                **compare(expected,raw_response['text'],language),'provider':protocol,
                                'request_id':(client.last_request or {}).get('request_id')}
                    self.clip_set(identity,index,dialogue_raw_diagnostic=raw_report)
                report['before_crop']=raw_report
                if raw_report['passed']:
                    report['cause']='complete_before_application_crop'
                    report['reason']='裁剪前识别完整，固定时长裁剪后缺词；原片已保留。须调整镜头/时长约束后重做，不能靠同一切点继续删除句尾。'
                else:
                    report['cause']='incomplete_before_application_crop'
                    report['reason']+='；软件裁剪前的识别也未通过，不能只归因于最后一次保留裁剪。'
            elif dialogue_retention.active(clip) and not report['passed']:
                report['cause']='incomplete_in_retained_generation'
                report['reason']+='；本次已保留生成结果的全部新内容尾部，缺词仍需由生成/语音识别核实。'
            (folder/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        self.clip_set(identity,index,dialogue_check=report)
        self.store.event(identity,f'第{index+1}段对白：'+report['reason'])
        return report

    def resolve_dialogue(self,identity,body):
        with self.store.lock:
            p=self.store.get('project',identity)
            if p['status'] in {'running','queued','pausing'} or identity in self.preparing_projects:
                raise ValueError('请先暂停项目，再处理对白核对。')
            index=body.get('index')
            if type(index) is not int or not 0<=index<len(p['clips']):raise ValueError('镜头编号无效。')
            clip=p['clips'][index];report=current_report(self.files,clip)
            if not report or report.get('signature')!=body.get('signature'):raise ValueError('视频或对白核对结果已变化，请刷新。')
            if report.get('passed'):raise ValueError('该段对白已经确认。')
            if body.get('action')=='confirm':
                clip['dialogue_check']={**report,'passed':True,'status':'manual_confirmed','confirmed_at':time.time(),'reason':'用户试听后确认对白完整。'}
            elif body.get('action')=='recheck':
                clip.setdefault('dialogue_check_history',[]).append(report)
                clip['dialogue_check_history']=clip['dialogue_check_history'][-10:]
                clip.pop('dialogue_check',None)
                clip.pop('dialogue_retained_recognition',None)
                clip.pop('dialogue_raw_diagnostic',None)
            else:raise ValueError('对白处理操作无效。')
            if (clip.get('quality_verdict') or {}).get('dialogue_failed'):clip.pop('quality_verdict',None)
            clip.pop('dialogue_adoption',None)
            clip.pop('recovery_adoption',None);clip.pop('recovery_unchecked',None)
            clip.pop('quality_accepted',None);clip.pop('quality_error',None);clip['status']='generated'
            p.update(status='paused',error='',phase='对白处理已保存，点击继续完成核对与合成。')
            self.store.put('project',identity,p)
        return {'ok':True}
