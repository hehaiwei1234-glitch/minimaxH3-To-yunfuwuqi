"""Versioned, idempotent speech headroom; never resize a committed job."""
import copy
import math
from difflib import SequenceMatcher
from .dialogue_plan import normalized
from . import timing_policy

VERSION = 1
FPS = 24
MAX_SECONDS = 15.0
DEFAULT_PADDING = 1.5
COMMITTED = ('job_id', 'prompt_id', 'api_graph', 'submission_unknown', 'raw_output', 'output')


def blocked_reason(project, clip, cfg):
    if any(clip.get(key) for key in COMMITTED):
        return '任务已提交或已有输出'
    if not clip.get('dialogue'):
        return '没有对白'
    if float(cfg.get('dialogue_padding_seconds', DEFAULT_PADDING)) <= 0:
        return '对白余量已关闭'
    if not clip.get('timing_version'):
        return '旧版固定工作流时长'
    policy = project.get('timing_policy') or {}
    if any(timing_policy.seconds(policy, key) for key in ('episode', 'total', 'task')):
        return '用户指定时长优先'
    if cfg.get('_dialogue_fixed_total'):
        return '用户指定全剧时长优先'
    # Draft target_seconds is derived from the authored tasks, not a manual cap.
    if not project.get('production_draft') and project.get('episode_target_seconds'):
        return '本集已有固定时长目标'
    return ''


def extend_shots(shots, lines, before, after, authored=False):
    """Insert time in the final speaking shot, shifting any following inserts.

    Keep every word, shot description and preceding authored timestamp intact.
    Invalid partial API content is left to the existing bounded repair layer.
    """
    if not isinstance(shots, list) or not shots or after <= before:
        return False
    work = copy.deepcopy(shots)
    try:
        cursor = 0.0
        for shot in work:
            start, end = float(shot['start_seconds']), float(shot['end_seconds'])
            if not all(math.isfinite(v) for v in (start, end)) or abs(start-cursor) > 1/FPS+.001 or end <= start:
                return False
            cursor = end
        if abs(cursor-before) > 1/FPS+.001:
            return False
        speaking = [i for i, shot in enumerate(work) if shot.get('dialogue_indices')]
        chosen = speaking[-1] if speaking else len(work)-1
        delta = after-before
        work[chosen]['end_seconds'] = float(work[chosen]['end_seconds'])+delta
        for shot in work[chosen+1:]:
            for key in ('start_seconds', 'end_seconds'):
                shot[key] = float(shot[key])+delta
        new_lines = copy.deepcopy(lines)
        if authored and speaking:
            indices = work[chosen]['dialogue_indices']
            last = indices[-1]
            if type(last) is not int or not 0 <= last < len(new_lines):
                return False
            for line in new_lines[last+1:]:
                for key in ('start_seconds', 'end_seconds'):
                    line[key] = float(line[key])+delta
    except (KeyError, TypeError, ValueError, IndexError):
        return False
    shots[:] = work
    if authored:
        lines[:] = new_lines
    return True


def _grow(clip, seconds, source):
    old = float(clip['duration_seconds'])
    request = max(2.0, float(clip.get('generation_seconds', old)))
    available = max(0, math.floor((MAX_SECONDS-max(old, request))*FPS+1e-6))
    frames = min(available, max(0, math.ceil(float(seconds)*FPS-1e-6)))
    state = copy.deepcopy(clip.get('dialogue_timing') or {
        'version': VERSION, 'base_duration_seconds': old,
        'base_generation_seconds': request, 'extra_seconds': 0.0,
        'initial_padding_seconds': 0.0, 'retry_padding_seconds': 0.0,
    })
    delta = frames/FPS
    state['last_reason'] = source if frames else '已到H3单次15秒上限'
    if frames:
        duration = (round(old*FPS)+frames)/FPS
        generated = min(MAX_SECONDS, (round(request*FPS)+frames)/FPS)
        if clip.get('shots') and not extend_shots(clip['shots'], clip['dialogue'], old, duration, authored=True):
            raise ValueError('制作稿时间结构无法安全增加对白余量；保留原任务，请检查shots。')
        saved = clip.get('prompt_content')
        if isinstance(saved, dict) and saved.get('status') == 'compiled_content':
            result = copy.deepcopy(saved.get('result'))
            if isinstance(result, dict) and extend_shots(result.get('shots'), clip['dialogue'], old, duration):
                # Only timing changed. Real asset versions and feedback must
                # still match before this content can be reused without an API.
                saved.update(result=result, context=None, timing_reuse=True,
                             timing_redo_feedback=clip.get('redo_feedback', ''))
        clip.update(duration_seconds=duration, generation_seconds=generated, generation_exact=False)
        for key in ('prompt_en', 'prompt_zh', 'prompt_compiler_version', 'compiler_warnings'):
            clip.pop(key, None)
        state['extra_seconds'] = round(float(state['extra_seconds'])+delta, 6)
        key = 'initial_padding_seconds' if source == '首次对白余量' else 'retry_padding_seconds'
        state[key] = round(float(state[key])+delta, 6)
    clip['dialogue_timing'] = state
    return delta


def prepare(project, clip, cfg):
    if blocked_reason(project, clip, cfg) or (clip.get('dialogue_timing') or {}).get('initial_applied'):
        return False
    _grow(clip, cfg.get('dialogue_padding_seconds', DEFAULT_PADDING), '首次对白余量')
    clip['dialogue_timing']['initial_applied'] = True
    return True


def missing_tail(expected, actual):
    """Conservative endpoint alignment; this never turns an ASR mismatch into a pass."""
    a, b = normalized(expected), normalized(actual)
    if not b or len(b) >= len(a):
        return 0
    if a.startswith(b):
        return len(a)-len(b)
    if len(b) < 10:
        return 0
    matches = SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks()
    last = matches[-2] if len(matches) > 1 else None
    if last is None or last.b+last.size != len(b) or last.size < 3:
        return 0
    stop = last.a+last.size
    missing = len(a)-stop
    if not 1 <= missing <= 6:
        return 0
    aligned = SequenceMatcher(None, a[:stop], b, autojunk=False)
    # Few internal substitutions are allowed only to diagnose missing time.
    if aligned.ratio() < .9 or sum(m.size for m in aligned.get_matching_blocks())/max(stop,len(b)) < .85:
        return 0
    return missing


def retry(project, clip, cfg, report):
    """Use the existing shared retry, adding time only for endpoint evidence."""
    if blocked_reason(project, clip, cfg) or not isinstance(report, dict):
        return 0.0
    expected = normalized(report.get('expected') or ''.join(x['text'] for x in clip['dialogue']))
    actual = normalized(report.get('transcript') or '')
    missing = missing_tail(expected, actual)
    tail = report.get('tail_seconds')
    at_end = (report.get('status') == 'needs_review' and expected and actual == expected
              and isinstance(tail, (int, float)) and tail < .08)
    if not (report.get('status') in {'incomplete','needs_review'} and missing > 0) and not at_end:
        return 0.0
    return _grow(clip, max(1.0, .5+.45*missing), '缺尾重试余量')


def shot_label(number, start):
    """Canonical H3 shot markers; the first shot has no timestamp."""
    if number == 1:
        return '[Shot 1]'
    millis = max(0, round(float(start)*1000))
    minutes, millis = divmod(millis, 60000)
    seconds, millis = divmod(millis, 1000)
    return f'[Shot {number}] At {minutes:02d}:{seconds:02d}.{millis:03d}'
