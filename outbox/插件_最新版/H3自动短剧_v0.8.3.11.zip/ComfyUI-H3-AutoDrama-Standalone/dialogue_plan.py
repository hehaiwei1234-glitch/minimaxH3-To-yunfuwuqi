"""Deterministic dialogue coverage and conservative planning budgets."""
import copy
import math
import re
import unicodedata
from . import timing_policy, dialogue_language

VERSION=1
LEAD=.10
TAIL=.65
CPS=4.0
HEADER={'人物','场景','声音','时间','时长','画面','镜头','动作','说明','风格','标题','地点','台词','对白','声音要求'}


SCRIPT_HEADERS=HEADER|{'剧名','片名','本集标题','本集时长','剧本标题','总标题','中文标题','英文标题','故事梗概','剧情梗概','出场人物','主要角色','角色','总剧本','续集','集数','语言','字幕','背景音乐'}
HEADING=re.compile(r'^(?:第\s*[0-9０-９零〇一二三四五六七八九十百千万两]+\s*(?:集|章|幕|场|节|回)(?:\b|[^A-Za-z])|(?:episode|ep\.?|chapter|scene|act|part|season)\s*\d+\b|(?:场景|镜头|分镜|任务)\s*\d+)',re.I)


def is_script_heading(label):
    value=re.sub(r'[（(].*?[）)]','',str(label)).strip()
    if value in SCRIPT_HEADERS or HEADING.search(value):return True
    if value.startswith(('《','〈')):return True
    return value.lower() in {'title','subtitle','scene','setting','location','time','duration','characters','cast','episode','chapter','summary','action','camera','dialogue','language','sound','music','int.','ext.','int','ext'}


def normalized(text):
    value=unicodedata.normalize('NFKC',str(text)).lower()
    return ''.join(c for c in value if c.isalnum())


def spoken_units(text):
    text=str(text)
    han=len(re.findall(r'[\u3400-\u9fff]',text))
    words=len(re.findall(r'[A-Za-z0-9]+',text))
    other=sum(c.isalpha() and not ('\u3400'<=c<='\u9fff') and not c.isascii() for c in text)
    return han+words*2.0+other*.5


def line_seconds(text, language=None):
    text=str(text)
    language=dialogue_language.canonical(language or dialogue_language.detect(text))
    if language=='auto':language=dialogue_language.detect(text)
    if language=='en':
        words=len(re.findall(r"[A-Za-z0-9]+(?:['’][A-Za-z0-9]+)*",text))
        pauses=len(re.findall(r'[,;:]',text))*.12+len(re.findall(r'[!?]',text))*.18
        return max(.35,words/2.0+min(pauses,1.5))
    if language=='ja':
        # Kana are closer to morae than half a Chinese character. Kanji
        # readings are unknown; this remains an estimate, not a speech clock.
        kana=len(re.findall(r'[\u3040-\u30ff]',unicodedata.normalize('NFKC',text)))
        han=len(re.findall(r'[\u3400-\u9fff]',text))
        words=len(re.findall(r"[A-Za-z0-9]+(?:['’][A-Za-z0-9]+)*",text))
        pauses=len(re.findall(r'[、，,；;：:]',text))*.12+len(re.findall(r'[。！？!?]',text))*.18
        return max(.35,kana/5.0+han*.5+words*.5+min(pauses,1.5))
    pauses=len(re.findall(r'[，,；;：:]',text))*.12+len(re.findall(r'[。！？!?]',text))*.18
    return max(.35,spoken_units(text)/CPS+min(pauses,1.5))


def budget(lines):
    valid=[line for line in lines if normalized(line.get('text',''))]
    if not valid:return {'version':VERSION,'minimum_seconds':0,'lead_seconds':0,'tail_seconds':0,'line_seconds':[]}
    durations=[line_seconds(line['text'],dialogue_language.resolve(line)) for line in valid]
    minimum=math.ceil((LEAD+sum(durations)+.12*(len(durations)-1)+TAIL)*24)/24
    return {'version':VERSION,'minimum_seconds':minimum,'lead_seconds':LEAD,'tail_seconds':TAIL,'line_seconds':durations,'estimated_units_per_second':CPS}


def script_lines(script,known_names=()):
    """Read explicit speaker:dialogue or speaker says:'dialogue' notation.

    Ambiguous prose is not silently reclassified as dialogue. This function
    returns only explicit anchors, which the plan must cover in order.
    """
    names=sorted({str(x).strip() for x in known_names if x},key=len,reverse=True)
    pattern=re.compile(r'(?m)(?:^|(?<=[。！？!?]))\s*([^\n：:“”「」『』\[\]【】]{1,100})[：:]\s*')
    matches=list(pattern.finditer(script))
    # Quoted speech in prose may follow an action rather than a line boundary.
    for name in names:
        rx=re.compile(re.escape(name)+r'(?:[（(][^\n）)]{0,20}[）)])?(?:轻声|低声|说道|说|问道|问|回答|喊道|喊|喃喃|平静地说|轻声说|低声说)?[：:]\s*[“「『"]')
        matches.extend(rx.finditer(script))
    matches.sort(key=lambda x:x.start())
    found={}
    for match in matches:
        prefix=match.group(0).lstrip()
        raw=prefix.rsplit('：',1)[0].rsplit(':',1)[0].strip()
        name=next((n for n in names if raw.startswith(n)),None)
        if not name:
            name=re.sub(r'[（(].*?[）)]','',raw).strip()
            name=re.sub(r'(?:轻声说|低声说|轻声|低声|说道|问道|喊道|回答|喃喃|说|问)$','',name)
        heading=is_script_heading(raw) and (raw not in names or bool(HEADING.search(raw)) or raw.startswith(('《','〈')))
        if not name or heading or (len(name)>12 and name not in names):continue
        start=match.end()
        if prefix[-1:] in '“「『"':start-=1
        tail=script[start:]
        if tail[:1] in {'“','「','『','"'}:
            endchar={'“':'”','「':'」','『':'』','"':'"'}[tail[0]]
            end=tail.find(endchar,1)
            if end<0:continue
            text=tail[1:end]
        else:
            end=tail.find('\n')
            text=tail[:end] if end>=0 else tail
            # Multiple explicitly labelled lines on one physical line.
            for other in matches:
                if other.start()>=start:
                    text=text[:other.start()-start];break
            text=text.strip().strip('“”「」『』"')
        if text.strip():found[start]={'speaker':name,'text':text.strip()}
    return [found[key] for key in sorted(found)]


def check_coverage(plan,script):
    lines=[line for s in plan['segments'] for line in s.get('dialogue',[])]
    expected=script_lines(script,[line['speaker'] for line in lines])
    if not expected:return {'mode':'source_substrings','explicit_lines':0}
    # Only judge the explicit source anchors. Unlabelled prose remains subject
    # to the existing source-substring check rather than a guessed transcript.
    names={line['speaker'] for line in expected}
    actual=[line for line in lines if line['speaker'] in names]
    a=[(line['speaker'],c) for line in actual for c in normalized(line['text'])]
    b=[(line['speaker'],c) for line in expected for c in normalized(line['text'])]
    if a!=b:
        raise ValueError('分镜对白遗漏、重复、改写、说话人或顺序不符。必须完整按顺序覆盖以下原文；长句可在自然停顿处分段：'+str(expected))
    return {'mode':'explicit_speaker_lines','explicit_lines':len(expected)}


def prepare(plan,policy,target=0):
    result=copy.deepcopy(plan)
    fixed_total=target or timing_policy.seconds(policy,'episode') or timing_policy.seconds(policy,'total')
    task=timing_policy.seconds(policy,'task') or 15
    problems=[]
    for i,segment in enumerate(result['segments']):
        info=budget(segment.get('dialogue',[]));segment['dialogue_budget']=info
        needed=info['minimum_seconds'];current=float(segment['duration_seconds'])
        if needed>task+1/24:
            problems.append(f'第{i+1}段对白自然表达预计至少{needed:.2f}秒，超过任务上限{task:g}秒；按完整句子或自然停顿重分任务，不能加快语速或删除台词。')
        elif current+1/24<needed:
            if fixed_total:
                problems.append(f'第{i+1}段对白预计至少{needed:.2f}秒，当前仅{current:g}秒；在总预算{fixed_total:g}秒内重新分配或自然拆分，不删改对白，不裁句尾。')
            else:
                segment['duration_seconds']=max(2,needed)
    if problems:raise ValueError(' '.join(problems))
    return result


PLANNING_RULES='''\n对白规划：先安排完整原句及自然停顿，再安排镜头动作。对白新内容尽早开口，不把观察、转头、拿手机等动作全部堆在说话之前；允许动作与说话并行。按正常语速估计，中文可先以约4字/秒、英语约2词/秒、日语按假名及汉字读音预留，并留出句末自然收尾；这是保守估算，不是加速播放指令。长对白若超出任务上限，按完整句子或自然停顿分配，不能把单词或残字硬接到下一段。每句原文按顺序完整出现一次。禁止将对白安排在引导段或待裁尾帧中。\n'''
