"""Pinned character assets and production-wide generation requirements."""
import copy
import hashlib
import json
import re

NO_SUBTITLES = 'No subtitles, captions, or on-screen dialogue text. Dialogue is spoken audio only.'
PRODUCTION_RULES = ('画面禁止生成字幕、台词文字和字幕条；台词仅作为声音呈现。无背景音乐，仅对白和环境音。'
                    '固定角色图片只定义身份，不能把参考图的姿势和背景强加到当前镜头。')

def enforce_subtitles(result):
    result = dict(result)
    prompt = result['prompt_en']
    if NO_SUBTITLES not in prompt:
        prompt = re.sub(r'(?m)^(\s*detailed_description\s*:)', lambda m: m[1]+'\n'+NO_SUBTITLES, prompt, count=1)
    result['prompt_en'] = prompt
    zh = result.get('prompt_zh', '')
    if '对白仅作为声音' not in zh:
        result['prompt_zh'] = zh+'\n画面不生成字幕；对白仅作为声音。'
    return result

def inferred_bindings(assets):
    result = {}
    for asset in assets:
        role = asset.get('role')
        if role not in {'character', 'voice'}:
            continue
        name = (asset.get('speaker') or asset.get('label', '')).strip()
        if not name:
            continue
        item = result.setdefault(name, {'image_ids': [], 'voice_id': ''})
        if role == 'character' and asset['kind'] == 'image':
            item['image_ids'].append(asset['id'])
        elif role == 'voice' and asset['kind'] == 'audio':
            if item['voice_id'] and item['voice_id'] != asset['id']:
                raise ValueError(name+'选择了多份音色，请只保留一份固定声音参考。')
            item['voice_id'] = asset['id']
    return result

def validate_bindings(bindings, store):
    if not isinstance(bindings, dict) or len(bindings) > 100:
        raise ValueError('角色绑定格式无效。')
    result = {}
    for name, item in bindings.items():
        if not isinstance(name, str) or not name.strip() or len(name) > 100 or not isinstance(item, dict):
            raise ValueError('请填写与剧本一致的角色姓名。')
        name = name.strip()
        if name in result:
            raise ValueError('角色姓名重复。')
        ids = item.get('image_ids', [])
        if not isinstance(ids, list) or any(not isinstance(x, str) for x in ids):
            raise ValueError('每名角色最多绑定4张图片。')
        if len(ids) > 4:
            raise ValueError(name + '已选' + str(len(ids)) + '张图片，每名角色最多绑定4张，请取消多余的勾选。')
        ids = list(dict.fromkeys(ids))
        voice = item.get('voice_id', '')
        for identity in ids + ([voice] if voice else []):
            asset = store.get('asset', identity)
            if asset.get('archived') or asset['kind'] != ('audio' if identity == voice else 'image'):
                raise ValueError('角色图片和声音的素材类型不符，或素材已归档。')
        if ids or voice:
            result[name] = {'image_ids': ids, 'voice_id': voice}
    return result

def binding_ids(bindings):
    return list(dict.fromkeys(a for b in bindings.values() for a in b['image_ids']+([b['voice_id']] if b.get('voice_id') else [])))

def bind_plan(plan, bindings, assets):
    """Make references mandatory before the ordinary capacity validator runs."""
    result = copy.deepcopy(plan)
    if not isinstance(result,dict):raise ValueError('分镜结果须为JSON对象。')
    for key in ('assets_to_create','shared_assets'):
        if key in result and result[key] is None:result[key]=[]
    for segment in result.get('segments',[]) or []:
        if not isinstance(segment,dict):raise ValueError('分镜项须为对象。')
        for key in ('asset_ids','image_reference_ids','characters','dialogue'):
            if segment.get(key) is None:segment[key]=[]
        for key in ('asset_ids','image_reference_ids'):
            if not isinstance(segment[key],list) or any(not isinstance(x,str) for x in segment[key]):
                raise ValueError('分镜素材引用须为真实素材编号列表：'+key)
    for key in ('assets_to_create','shared_assets'):
        for item in result.get(key,[]) or []:
            if not isinstance(item,dict):raise ValueError('新增素材项须为对象。')
            if item.get('reference_asset_ids') is None:item['reference_asset_ids']=[]
    if not bindings:
        return result
    catalog = {a['id']: a for a in assets}
    replacements = {}
    for key in ('assets_to_create', 'shared_assets'):
        keep = []
        for item in result.get(key, []):
            name = item.get('label', '').strip()
            if item.get('role') == 'character' and name in bindings and bindings[name]['image_ids']:
                replacements[item['id']] = bindings[name]['image_ids'][0]
            else:
                keep.append(item)
        if key in result:
            result[key] = keep
    for key in ('assets_to_create', 'shared_assets'):
        for item in result.get(key, []):
            item['reference_asset_ids'] = list(dict.fromkeys(replacements.get(a,a) for a in item.get('reference_asset_ids', [])))
    for segment in result.get('segments', []):
        declared = segment.get('characters', [])
        if not isinstance(declared, list) or any(not isinstance(n, str) for n in declared):
            raise ValueError('分镜中的characters须为出镜角色姓名列表。')
        people = set(declared)
        visual = segment.get('visual_zh', '')
        people.update(name for name in bindings if name in visual)
        speakers = {d.get('speaker') for d in segment.get('dialogue', [])}
        for field in ('asset_ids', 'image_reference_ids'):
            segment[field] = list(dict.fromkeys(replacements.get(a,a) for a in segment.get(field, [])))
        for aid in segment['asset_ids']+segment['image_reference_ids']:
            asset = catalog.get(aid, {})
            if asset.get('role') == 'character':
                people.add(asset.get('speaker') or asset.get('label'))
        for name, bound in bindings.items():
            if name in people:
                for field in ('asset_ids', 'image_reference_ids'):
                    remaining=[a for a in segment[field] if not (catalog.get(a,{}).get('role')=='character' and
                        (catalog.get(a,{}).get('speaker') or catalog.get(a,{}).get('label'))==name and a not in bound['image_ids'])]
                    segment[field] = list(dict.fromkeys(bound['image_ids']+remaining))
            if name in speakers and bound.get('voice_id'):
                # Do not let an AI-selected alternate voice compete with the pin.
                segment['asset_ids'] = [a for a in segment['asset_ids'] if not (
                    catalog.get(a, {}).get('kind') == 'audio' and catalog.get(a, {}).get('speaker') == name)]
                segment['asset_ids'].append(bound['voice_id'])
        segment['characters'] = sorted(n for n in people if n)
    return result

def fingerprint(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()

def preparation_dependency(clip, index):
    if not index:
        return None
    if clip.get('continuity') == 'continue' or clip.get('depends_on_previous', True):
        return index-1
    return None
