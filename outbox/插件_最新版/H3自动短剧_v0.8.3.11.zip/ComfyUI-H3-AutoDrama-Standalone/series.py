"""One submitted text creates a restartable series with ordered episode projects."""
from __future__ import annotations
from .review import ReviewPaused, validate_review, enabled as review_enabled
import asyncio
import copy
import hashlib
import json
import re
import time
import uuid
import aiohttp
from .domain import validate_plan, safe_id
from .asset_plans import normalize_asset_plan
from .engine import Paused
from .providers import AIClient
from .image_generator import ImageGenerator
from . import image_workflows, workflows
from . import timing_policy
from . import episode_recovery
from .comfy_client import ComfyClient
from .media_tools import command
from .production import PRODUCTION_RULES, bind_plan, inferred_bindings, validate_bindings, binding_ids
from .telemetry import scope, measure
from .series_batches import SeriesBatchesMixin, initial_batch, batch_values

SERIES_INSTRUCTIONS='''你是整剧策划。默认按剧情节奏、自然停顿决定分集和时长，不套用固定秒数。不需要人工确认。若指定集数，严格遵守；0表示自行决定，最多100集。timing_policy中enabled=true的秒数为用户最高优先级约束，未启用的全部由AI决定。全剧总时长指定时，各集须返回duration_seconds（秒），合计等于指定总时长。每集时长也指定时，每集必须等于该值。保持原文对白，不通过删台词或倍速凑时长。
target_episode_seconds=0表示自动时长，绝不是零秒或默认120秒。根据原文对白、动作、场景转换和剧情节奏自然分集。完整剧本已有明确集数标题时优先保留分集，不能只为凑时间截断一句对白或删减剧情；没有集数标题时按合理剧情段落分集。大纲输入时按剧情内容合理确定各集篇幅，不为填满固定时间添加无用内容。
先确定全剧共同风格、人物、场景、道具，一次建立shared_assets，后面各集复用，不能每集换脸。只在缺少已有素材时新增。生图描述英文，其余说明中文。角色和场景的固定外观写清楚。已有文本若是完整剧本，禁止改写原文台词；仅以给定文本单元边界分集，每集end_unit表示包含的最后一个单元编号，从1开始。所有单元必须按顺序覆盖且不能遗漏，不把一句台词拆进两集。若是故事大纲，给出每集详细剧情提纲outline，稍后由程序逐集写剧本。
返回JSON：{"style":"全剧风格","shared_assets":[{"id":"character_1","role":"character|scene|prop|style","label":"人物/场景名","description":"固定外观说明","image_prompt":"英文生图描述","reference_asset_ids":[]}],"episodes":[{"title":"本集标题","end_unit":5,"outline":"大纲输入时提供本集详细剧情提纲"}]}。完整剧本使用end_unit，大纲使用outline。shared_assets只列本批确实缺少的新素材；若已有素材足够，返回空数组[]。不得把已有目录复制到shared_assets；引用已有素材时使用assets给出的实际id。新增素材不超过40个，参考编号只能来自已有或先前列出的素材。JSON。'''

WRITER_INSTRUCTIONS='''你是短剧编剧。依据全剧设定、本集提纲和此前剧本，写本集可拍摄的完整剧本，保持情节顺序、角色名称、性格、外观和场景一致，不能重演此前剧情。写出场景、动作、说话人和逐句原语言台词，不写技术接口或工作流参数。台词按目标时长与正常说话速度安排。target_seconds=0表示按剧情与正常语速自然安排篇幅，不表示零秒，也不套用默认120秒。禁止人工审核等待。只返回JSON {"script":"完整剧本"}。'''

def source_units(text):
    lines=text.splitlines(keepends=True)
    if len(lines)>1:return lines
    # A paragraph without line breaks still has exact, reconstructible units.
    parts=re.split(r'(?<=[。！？!?])',text)
    return [s for s in parts if s]

def validate_series_plan(result,record,assets,*,namespace=None,aliases=None):
    if not isinstance(result,dict) or not isinstance(result.get('episodes'),list) or not 1<=len(result['episodes'])<=100:
        raise ValueError('AI必须返回1至100集的分集清单。')
    if record['episode_count'] and len(result['episodes'])!=record['episode_count']:raise ValueError('AI分集数量与指定集数不符。')
    generated=result.get('shared_assets',[])
    if not isinstance(generated,list) or len(generated)>40:raise ValueError('整剧共用素材最多40个。')
    result=normalize_asset_plan(result,assets,'shared_assets',namespace=namespace,aliases=aliases)
    generated=result['shared_assets']
    dummy={'duration_seconds':8,'continuity':'cut','visual_zh':'校验素材','image_prompt':'validation','asset_ids':[],'image_reference_ids':[]}
    validate_plan({'assets_to_create':generated,'segments':[dummy]},assets,1)
    known={(a.get('role'),a.get('label','').strip()) for a in assets}
    for item in generated:
        label=(item['role'],item['label'].strip())
        if label in known:raise ValueError('共用素材名称重复，已有'+item['label']+'时请复用，不能另建。')
        known.add(label)
    result=copy.deepcopy(result);units=source_units(record['text']);previous=0
    for episode in result['episodes']:
        title=episode.get('title')
        if not isinstance(title,str) or not title.strip() or len(title)>160:raise ValueError('分集标题无效。')
        if record['input_type']=='script':
            end=episode.get('end_unit')
            if isinstance(end,bool) or not isinstance(end,int) or not previous<end<=len(units):raise ValueError('分集边界必须按文本单元顺序递增。')
            episode['script']=''.join(units[previous:end]);previous=end
        elif not isinstance(episode.get('outline'),str) or not episode['outline'].strip():raise ValueError('大纲分集缺少本集剧情提纲。')
    if record['input_type']=='script' and previous!=len(units):raise ValueError('AI分集遗漏了原文末尾，请覆盖全部文本单元。')
    result.setdefault('style','');result.setdefault('shared_assets',[])
    if not isinstance(result['style'],str) or len(result['style'])>8000:raise ValueError('全剧风格应为最多8000字的文字。')
    return timing_policy.assign_episodes(result,record['timing_policy']) if record.get('timing_policy') else result

class SeriesManager(SeriesBatchesMixin):
    def __init__(self,engine):
        self.engine=engine;self.store=engine.store;self.files=engine.files;self.tasks={}
        for item in self.store.list('series'):
            if item['status'] in {'running','queued','pausing'}:
                self.set(item['id'],status='paused',phase='服务已重启，点击继续接着制作',pause_requested=False)
    def set(self,id,**values):return self.store.update('series',id,lambda x:x.update(**values))
    def event(self,id,message):
        def change(x):
            x['events'].append({'time':time.time(),'message':str(message)});x['events']=x['events'][-200:]
        self.store.update('series',id,change)
    def paused(self,id):
        if self.store.get('series',id)['pause_requested']:raise Paused('整剧已暂停，点击继续从保存的进度接着制作。')
    def create(self,body):
        text=str(body.get('text','')).strip()
        if not text or len(text)>500000:raise ValueError('请填写整篇文本，最多50万字。')
        mode=body.get('input_type','script')
        if mode not in {'script','outline'}:raise ValueError('请选择完整剧本或故事大纲。')
        values=batch_values(body)
        count=values['episode_count'];duration=values['target_episode_seconds']
        workflow=workflows.resolved(self.store.get('workflow',safe_id(body.get('workflow_id',''))))
        if workflow.get('archived'):raise ValueError('请选择未归档的视频工作流。')
        timing_policy.check_workflow(values['timing_policy'],workflow)
        # Verify configuration now, before creating any record or paying AI.
        cfg=self.engine.config({'settings':{},'workflow_snapshot':workflow})
        snapshot=image_workflows.snapshots(self.store,cfg)
        assets=list(dict.fromkeys(body.get('asset_ids',[])))
        for aid in assets:self.store.get('asset',aid)
        bindings=validate_bindings(body['character_bindings'] if 'character_bindings' in body else inferred_bindings([self.store.get('asset',a) for a in assets]),self.store)
        assets=list(dict.fromkeys(assets+binding_ids(bindings)))
        if workflow.get('media_mode')=='single_image' and any(b.get('voice_id') for b in bindings.values()):raise ValueError('固定声音参考需要批量素材视频工作流。')
        now=time.time();id=uuid.uuid4().hex
        record={'id':id,'title':str(body.get('title') or '未命名整剧')[:160],
            'text':text,'input_type':mode,'episode_count':count,'target_episode_seconds':duration,'instructions':str(body.get('instructions','')),
            'timing_policy':values['timing_policy'],
            'workflow_snapshot':workflow,'image_workflow_snapshots':snapshot,'asset_ids':assets,'character_bindings':bindings,'generated_assets':{},
            'plan':None,'project_ids':[],'events':[],'status':'draft','phase':'等待开始','error':'','pause_requested':False,
            'created_at':now,'updated_at':now,'revision':1,'continuity_summary':'','memory_through':0,'removed_episodes':{}}
        record['batches']=[initial_batch(record)]
        return self.store.put('series',id,record)
    def append_block_reason(self,record,active):
        """Why '追加后续剧本' is unavailable, in words the user can act on. Empty when appending is allowed."""
        if record.get('archived'):return '本剧已归档，请先恢复。'
        if active:
            if record.get('status') in {'queued','running'}:return '整剧正在制作。请等待完成，或先点“当前任务完成后暂停”。'
            if record.get('status')=='pausing':return '整剧正在暂停。请等当前任务结束。'
            return '有一集正在单独制作。请等该集结束，或在该集页面暂停它。'
        plan=record.get('plan')
        if not plan:return '还没有分集清单。请先点“继续整剧”完成分集。'
        if self.pending_batch(record):return '上一批文本已保存但还没开始制作。请先点“继续整剧”。'
        if len(record['episodes'])!=len(plan['episodes']):return '有些集的记录还没有创建。请先点“继续整剧”。'
        names={'draft':'等待开始','paused':'已暂停','error':'需要处理','partial':'有集待补做','pending':'待准备','ready':'待生成视频','blocked':'等待前段处理'}
        open_items=[f"第{i+1}集（{names.get(e['status'],e['status'])}）" for i,e in enumerate(record['episodes']) if e['status'] not in {'complete','deferred','deleted'}]
        if open_items:
            head='这些集还没有完成：'+'、'.join(open_items[:6])+('等' if len(open_items)>6 else '')+'。'
            # 已完成的整剧不接受“继续整剧”（按钮灰色，start() 会拒绝）：要在该集页面里继续或重做。
            if record.get('status')=='complete':return head+'整剧已完成，请打开该集，点“开始 / 继续”或重做镜头。'
            return head+'请先点“继续整剧”，或对该集使用补做／重做。'
        return ''
    def public(self,id,export=False):
        record=self.record(id)
        if export:return record
        for batch in record['batches']:
            batch['workflow_snapshot']=workflows.summary(batch['workflow_snapshot'])
            if batch.get('image_workflow_snapshots'):
                batch['image_workflow_snapshots']={k:image_workflows.summary(w) if w else None for k,w in batch['image_workflow_snapshots'].items()}
        record['workflow_snapshot']=workflows.summary(record['workflow_snapshot'])
        if record.get('image_workflow_snapshots'):
            record['image_workflow_snapshots']={k:image_workflows.summary(w) if w else None for k,w in record['image_workflow_snapshots'].items()}
        record['episodes']=[]
        active=record['status'] in {'running','queued','pausing'}
        for i,episode in enumerate((record.get('plan') or {}).get('episodes',[])):
            pid=self.episode_id(id,i)
            if pid in record['removed_episodes']:
                record['episodes'].append({'id':pid,'title':f'第{i+1}集：'+episode['title'],'status':'deleted','phase':'已删除，集数编号保留','editable':False})
                continue
            if pid not in record['project_ids']:continue
            project=self.store.get('project',pid)
            item={k:project.get(k) for k in ('id','title','status','phase','error','final','archived','script_revision','planned_duration_seconds')}
            item['editable']=not active and self.engine.script_editable(project)
            record['episodes'].append(item)
        active=active or any(e['status'] in {'running','queued','pausing'} for e in record['episodes'])
        record['active']=active
        record['deferred_count']=sum(e['status']=='deferred' for e in record['episodes'])
        record['can_resume']=not active and not record.get('archived') and bool(self.pending_batch(record) or any(e['status'] not in {'complete','deferred','deleted'} for e in record['episodes']) or not record.get('plan') or len(record['episodes'])!=len(record['plan']['episodes']))
        record['append_block_reason']=self.append_block_reason(record,active)
        record['can_append']=not record['append_block_reason']
        record['next_episode_number']=len((record.get('plan') or {}).get('episodes',[]))+1
        record['shared_asset_count']=len(record['asset_ids'])
        # A long series must not resend every script on each progress poll.
        # Exact scripts remain in the project and complete export endpoints.
        record.pop('text',None)
        for batch in record['batches']:
            batch.pop('text',None);batch.pop('request_sha256',None)
        if record.get('plan'):record['plan']={'style':record['plan']['style'],'episode_count':len(record['plan']['episodes'])}
        return record
    def start(self,id):
        record=self.record(id)
        if record.get('archived'):raise ValueError('请先恢复已归档的整剧。')
        if id in self.tasks and not self.tasks[id].done():return
        if record['status']=='complete':raise ValueError('整剧已经完成，修改镜头请打开对应集使用重做。')
        self.set(id,status='queued',phase='整剧已排队；自动分集并顺序制作',pause_requested=False,error='')
        self.tasks[id]=asyncio.create_task(self.run(id),name='h3ad_series_'+id)
    def pause(self,id):
        record=self.store.get('series',id)
        if record['status'] not in {'queued','running','pausing'}:return
        self.set(id,status='pausing',pause_requested=True,phase='当前任务完成后暂停整剧')
        for pid in record['project_ids']:
            if self.store.get('project',pid)['status'] in {'queued','running','pausing'}:self.engine.pause(pid)
    def retry_episode(self,id,project_id):
        record=self.ensure_idle(id)
        if record.get('archived'):raise ValueError('请先恢复已归档的整剧。')
        project=self.store.get('project',safe_id(project_id))
        if project.get('series_id')!=id or project_id not in record['project_ids']:
            raise ValueError('本集不属于这个整剧。')
        if project['status']!='deferred':raise ValueError('请选择待补做的集；其他集请打开本集继续或重做。')
        if project.get('archived'):raise ValueError('请先恢复已归档的单集。')
        self.set(id,pause_requested=False)
        self.set(id,status='running',phase=f'单独补做第{project.get("episode_number","?")}集',error='')
        self.tasks[id]=asyncio.create_task(self._retry_episode(id,project_id),name='h3ad_retry_'+id)
        self.event(id,f'单独补做第{project.get("episode_number","?")}集；后续已有成片保留。')
    async def _retry_episode(self,id,project_id):
        try:
            project=self.store.get('project',project_id)
            if project.get('script_pending'):
                async with self.engine.episode_lock:
                    cfg=self.engine.config(project)
                    async with aiohttp.ClientSession() as session:
                        await self.write_scripts(id,AIClient(cfg,session),only={project['episode_number']-1})
                    self.create_children(id)
                if self.store.get('project',project_id).get('script_pending'):
                    raise RuntimeError('原剧本步骤仍失败，未用大纲冒充完整剧本；本集继续待补做。')
            self.paused(id)
            self.engine.start(project_id,require_workflow=True)
            await asyncio.shield(self.engine.tasks[project_id])
            self.paused(id)
            project=self.store.get('project',project_id)
            if project['status']=='paused':raise Paused('本集补做已暂停，点击整剧继续可接着制作。')
            if episode_recovery.can_defer(project,self.engine.config(project),self.store):
                self.engine.set(project_id,status='deferred',phase='补做已有成果已保留；仍失败的任务继续留待补做',
                                deferred_reason=project.get('error',''),deferred_at=time.time())
            elif project['status']!='complete':
                raise RuntimeError('本集补做停止：'+project.get('error','请打开本集查看原因。'))
            record=self.record(id)
            projects=[self.store.get('project',pid) for pid in record['project_ids']]
            deferred=[str(p.get('episode_number','?')) for p in projects if p['status']=='deferred']
            # 追加的批次已划分但还有集没创建时，也不能算“全部完成”，否则“继续整剧”灰掉，整剧无法再继续。
            pending=self.pending_batch(record) or self.uncreated(id,record) or any(not episode_recovery.terminal(p) for p in projects)
            self.set(id,status='draft' if pending else 'partial' if deferred else 'complete',
                     phase='补做已保存；仍有未处理内容，点击整剧继续' if pending else
                           '本批已处理完；第'+'、'.join(deferred)+'集待补做' if deferred else '全部成片已完成，待补做的集已补齐',
                     error='',pause_requested=False)
        except (Paused,ReviewPaused) as error:
            self.set(id,status='paused',phase=str(error),pause_requested=False)
        except asyncio.CancelledError:
            self.set(id,status='paused',phase='补做等待已暂停，任务与进度保留',pause_requested=False)
            raise
        except Exception as error:
            from .task_recovery import project_deferred
            project_deferred(self.engine,project_id,error)
            self.set(id,status='partial',phase='补做失败，原文与已有成果保留，可单独补做或追加后续剧本',error=str(error),pause_requested=False)
    def defer_episode(self,id,pid,number,project,cfg):
        if not episode_recovery.can_defer(project,cfg,self.store):return False
        self.engine.set(pid,status='deferred',phase='本集部分或全部任务待补做；已有素材保留，后续集继续制作',
                        deferred_reason=project.get('error',''),deferred_at=time.time())
        generated=list(project.get('generated_assets',{}).values())
        self.store.update('series',id,lambda x:x.update(asset_ids=list(dict.fromkeys(x['asset_ids']+generated))))
        self.event(id,f'第{number}集待补做：'+project.get('error','')+'；继续后续集，原剧本与已有素材保留。')
        return True
    async def plan(self,id,ai,cfg):
        record=self.record(id);batch=self.pending_batch(record)
        if not batch:return
        if record.get('plan'):
            await self.remember_previous(id,ai);record=self.record(id);batch=self.pending_batch(record)
        start=len((record.get('plan') or {}).get('episodes',[]))
        self.set(id,phase=f'AI划分本批各集，从第{start+1}集开始')
        assets=[self.store.get('asset',aid) for aid in record['asset_ids']]
        request={k:batch[k] for k in ('input_type','episode_count','target_episode_seconds','instructions')}
        request['duration_mode']='auto' if batch['target_episode_seconds']==0 else 'target'
        request['timing_policy']=batch.get('timing_policy')
        request['video_segment_seconds']=timing_policy.seconds(batch.get('timing_policy'),'task') if batch.get('timing_policy') else batch['workflow_snapshot']['metadata']['duration_seconds']
        request['assets']=self.engine.asset_summary(assets)
        request['character_bindings']=record.get('character_bindings',{})
        request.update(previous_story_summary=record.get('continuity_summary',''),next_episode_number=start+1,
                       fixed_style=(record.get('plan') or {}).get('style',''),global_instructions=record['instructions'])
        if batch['input_type']=='script':request['text_units']=[{'unit':i+1,'text':t} for i,t in enumerate(source_units(batch['text']))]
        else:request['text']=batch['text']
        instructions=SERIES_INSTRUCTIONS+'\n'+PRODUCTION_RULES+'\n固定角色绑定优先，不能重新设计已绑定的人物。'+'\n输入只属于本批，不重写此前各集。已有素材的编号、角色身份、服装、场景和固定风格必须沿用；结合previous_story_summary承接剧情。'
        plan=await self.engine.checked_text(ai,instructions,json.dumps(request,ensure_ascii=False),lambda r:validate_series_plan(bind_plan(r,record.get('character_bindings',{}),assets),batch,assets,namespace=batch['id'] if start else None,aliases=record['generated_assets']),self.engine.images(assets))
        if start:
            plan['style']=record['plan']['style']
        for episode in plan['episodes']:episode['batch_id']=batch['id']
        def save(x):
            current=next(b for b in x['batches'] if b['id']==batch['id'])
            current.update(status='planned',start_index=start,episode_total=len(plan['episodes']))
            if x.get('plan'):
                x['plan']['episodes'].extend(plan['episodes']);x['plan']['shared_assets'].extend(plan['shared_assets'])
            else:x['plan']=plan
        self.store.update('series',id,save)
        self.set(id,batch_error='')
        self.event(id,f'本批已划分{len(plan["episodes"])}集：第{start+1}至第{start+len(plan["episodes"])}集。')
        if start:self.event(id,f'已有共用素材{len(assets)}个继续保留；本批新增{len(plan["shared_assets"])}个。')
    async def write_scripts(self,id,ai,only=None):
        record=self.record(id)
        for i,episode in enumerate(record['plan']['episodes']):
            self.paused(id)
            if only is not None and i not in only:continue
            if episode.get('script'):continue
            batch=self.batch_for(record,episode)
            self.set(id,phase=f'AI撰写第{i+1}集剧本')
            catalog=[self.store.get('asset',aid) for aid in record['asset_ids']]
            request={'series_outline':batch['text'],'production_style':record['plan']['style'],'characters_and_scenes':self.engine.asset_summary(catalog),
                     'new_assets':record['plan']['shared_assets'],'previous_story_summary':record.get('continuity_summary',''),
                     'previous_scripts':[e.get('script','') for e in record['plan']['episodes'][max(batch['start_index'],i-2):i]],
                     'episodes':[{'title':e['title'],'outline':e.get('outline','')} for e in record['plan']['episodes'] if e.get('batch_id','initial')==batch['id']],
                     'current_episode':i+1,'batch_episode':i-batch['start_index']+1,'current_outline':episode.get('outline',''),
                     'target_seconds':episode.get('target_seconds',batch['target_episode_seconds']),'instructions':record['instructions']+'\n'+batch['instructions']}
            def check(result):
                if not isinstance(result,dict) or not isinstance(result.get('script'),str) or not result['script'].strip() or len(result['script'])>500000:raise ValueError('AI未返回本集完整剧本。')
                return result['script'].strip()
            from .dialogue_language import instruction
            try:script=await self.engine.checked_text(ai,WRITER_INSTRUCTIONS+instruction(ai.config),json.dumps(request,ensure_ascii=False),check)
            except Paused:raise
            except Exception as error:
                self.paused(id)
                self.store.update('series',id,lambda x:x['plan']['episodes'][i].update(script_error=str(error)))
                self.event(id,f'第{i+1}集剧本步骤失败，保留待补做；继续准备后续集：{error}')
                continue
            def save_script(x):
                x['plan']['episodes'][i].update(script=script)
                x['plan']['episodes'][i].pop('script_error',None)
            self.store.update('series',id,save_script)
            record=self.store.get('series',id)
    async def shared_assets(self,id,ai,cfg,images):
        record=self.store.get('series',id)
        for item in record['plan']['shared_assets']:
            try:
                self.paused(id);record=self.store.get('series',id)
                if item['id'] in record['generated_assets']:continue
                aid=hashlib.sha256((id+':shared:'+item['id']).encode()).hexdigest()[:40]
                try:asset=self.store.get('asset',aid)
                except KeyError:
                    self.set(id,phase='建立整剧共用素材：'+item['label'])
                    refs=[self.files.asset_path(self.store.get('asset',record['generated_assets'].get(ref,ref))) for ref in item.get('reference_asset_ids',[])]
                    prompt=item['image_prompt']+'\nProduction style: '+record['plan']['style']+'\nNo captions, no watermarks.'
                    blob=await images.image(ai,aid,id,prompt,refs)
                    asset=self.files.write_asset(self.store,'共用_'+aid[:12]+'.png',blob,{**item,'generated':True},id=aid)
                def save(x):
                    x['generated_assets'][item['id']]=aid
                    if aid not in x['asset_ids']:x['asset_ids'].append(aid)
                    if item.get('role')=='character':x.setdefault('character_bindings',{}).setdefault(item['label'],{'image_ids':[aid],'voice_id':''})
                self.store.update('series',id,save);self.event(id,'已保存共用素材：'+asset['label'])
            except Paused:raise
            except Exception as error:
                self.paused(id)
                self.store.update('series',id,lambda x:x.setdefault('asset_failures',{}).update({item['id']:str(error)}))
                self.event(id,'共用素材失败，仅依赖此素材的镜头待补做，其他任务继续：'+item['label']+'：'+str(error))
    def create_children(self,id):
        record=self.record(id)
        for i,episode in enumerate(record['plan']['episodes']):
            pid=self.episode_id(id,i)
            if pid in record['removed_episodes']:continue
            batch=self.batch_for(record,episode)
            catalog=[self.store.get('asset',aid) for aid in record['asset_ids']]
            instructions=record['instructions']+'\n本批补充要求：'+batch['instructions']+'\n此前剧情记录：'+record.get('continuity_summary','')+'\n全剧共同风格：'+record['plan']['style']+'\n必须优先复用全剧共用人物和场景，禁止为已有角色另建外观。共用素材：'+json.dumps(self.engine.asset_summary(catalog),ensure_ascii=False)
            p=self.store.create_project({'title':f'{record["title"]}·第{i+1}集：{episode["title"]}','script':episode.get('script') or episode.get('outline') or episode['title'],
                'instructions':instructions,'asset_ids':record['asset_ids'],'series_id':id,'character_bindings':record.get('character_bindings',{})},project_id=pid)
            if p.get('script_pending') and episode.get('script'):
                def restore_script(project):
                    project.update(script=episode['script'],status='draft',error='',error_kind='')
                    project.pop('script_pending',None)
                p=self.store.update('project',pid,restore_script)
            if not p.get('workflow_snapshot'):
                self.engine.set(pid,workflow_snapshot=workflows.resolved(batch['workflow_snapshot']),image_workflow_snapshots=copy.deepcopy(batch.get('image_workflow_snapshots')),episode_number=i+1,series_batch_id=batch['id'])
            if i and not p.get('final'):
                previous={'previous_episode_id':self.episode_id(id,i-1),'previous_episode_script':record['plan']['episodes'][i-1].get('script') or record['plan']['episodes'][i-1].get('outline','')}
                if any(p.get(k)!=v for k,v in previous.items()):self.engine.set(pid,**previous)
            # Older queued children also inherit their own batch's pacing setting.
            if not p.get('plan') and p['status']!='complete':
                policy=copy.deepcopy(batch.get('timing_policy'))
                if policy:policy['total']={'enabled':False,'seconds':None}
                self.engine.set(pid,episode_target_seconds=episode.get('target_seconds',batch['target_episode_seconds']),timing_policy=policy)
            self.store.update('series',id,lambda x:x['project_ids'].append(pid) if pid not in x['project_ids'] else None)
            if not episode.get('script') and episode.get('script_error'):
                from .task_recovery import project_deferred
                self.engine.set(pid,script_pending=True)
                project_deferred(self.engine,pid,episode['script_error'])
    async def run(self,id):
        with scope(self.store,'series',id),measure('series_active'):
            await self._run(id)

    async def _run(self,id):
        draft_task=None;prepare_task=None;ready_task=None
        try:
            async with self.engine.episode_lock:
                self.paused(id);self.set(id,status='running',phase='准备整剧自动流程')
                record=self.record(id);batch=self.pending_batch(record) or record['batches'][-1]
                normalized=workflows.resolved(batch['workflow_snapshot'])
                if normalized!=batch['workflow_snapshot']:
                    self.store.update('series',id,lambda x:next(b for b in x['batches'] if b['id']==batch['id']).update(workflow_snapshot=normalized))
                    if batch['id']=='initial':self.set(id,workflow_snapshot=normalized)
                    batch={**batch,'workflow_snapshot':normalized}
                cfg=self.engine.config({'settings':{},'workflow_snapshot':batch['workflow_snapshot']})
                try:validate_review(cfg)
                except Exception as error:self.event(id,'审核配置异常，逐个任务记录；已有素材保留，其他生成继续：'+str(error))
                async with aiohttp.ClientSession() as session:
                    ai=AIClient(cfg,session);images=ImageGenerator(self.store,self.files,cfg,session,self.engine.render_lock,batch.get('image_workflow_snapshots'))
                    try:await ComfyClient(cfg,session).preflight(batch['workflow_snapshot']['graph'],batch['workflow_snapshot']['output_node_id'])
                    except Exception as error:self.event(id,'ComfyUI预检查异常，将逐集/逐镜头记录，不停止整剧：'+str(error))
                    try:await images.preflight()
                    except Exception as error:self.event(id,'生图预检查异常，将逐个任务记录：'+str(error))
                    if cfg['image_provider']=='local' and not batch.get('image_workflow_snapshots'):
                        self.store.update('series',id,lambda x:next(b for b in x['batches'] if b['id']==batch['id']).update(image_workflow_snapshots=images.snapshots))
                        if batch['id']=='initial':self.set(id,image_workflow_snapshots=images.snapshots)
                    try:
                        await command([cfg['ffmpeg'],'-version']);await command([cfg['ffprobe'],'-version'])
                    except Exception as error:self.event(id,'视频工具异常；已生成素材保留，后处理单独记录：'+str(error))
                    try:await self.plan(id,ai,cfg)
                    except Paused:raise
                    except Exception as error:
                        self.event(id,'本批规划失败，已有任务继续；未取得分集清单的批次留待恢复：'+str(error))
                        self.set(id,batch_error=str(error))
                        if not self.store.get('series',id).get('plan'):
                            self.set(id,status='partial',phase='尚未取得可执行分集；原文已保留，继续可重新请求',error=str(error),pause_requested=False)
                            return
                    self.paused(id)
                    await self.write_scripts(id,ai);self.paused(id)
                    await self.shared_assets(id,ai,cfg,images);self.paused(id)
                    self.create_children(id)
            record=self.store.get('series',id)
            for pid in record['project_ids']:
                task=None
                try:
                    i=next(j for j in range(len(record['plan']['episodes'])) if self.episode_id(id,j)==pid)
                    self.paused(id);project=self.store.get('project',pid)
                    if episode_recovery.terminal(project):continue
                    run_cfg=self.engine.config(project)
                    # A legacy release may have stopped a whole episode at one
                    # shot. Preserve that shot and execute its saved successors;
                    # an available storyboard must not be thrown away wholesale.
                    if project['status']=='error' and project.get('plan') and project.get('clips'):
                        from .task_recovery import record_failure
                        candidates=[j for j,c in enumerate(project['clips'])
                                    if (c.get('quality_error') and not c.get('quality_accepted')) or not c.get('output') or
                                    ((run_cfg.get('review_audio') or review_enabled(run_cfg,'video'))
                                     and not c.get('quality_accepted'))]
                        if candidates:
                            await record_failure(self.engine,pid,candidates[0],RuntimeError(project.get('error') or '旧版停止的任务'),run_cfg)
                        self.engine.set(pid,status='draft',error='',error_kind='')
                        project=self.store.get('project',pid)
                    # Prefetched plans already exhausted this content budget.
                    if self.defer_episode(id,pid,i+1,project,run_cfg):continue
                    # Carry forward any genuinely new scenery from earlier episodes.
                    catalog=self.store.get('series',id)['asset_ids']
                    self.engine.set(pid,asset_ids=list(dict.fromkeys(project['asset_ids']+catalog)))
                    self.set(id,phase=f'自动制作第{i+1}集 / 共{len(record["project_ids"])}集')
                    self.engine.start(pid,require_workflow=True,retry_failed=False)
                    task=self.engine.tasks[pid]
                    next_pid=next((candidate for candidate in record['project_ids'][record['project_ids'].index(pid)+1:]
                                   if not episode_recovery.terminal(self.store.get('project',candidate))),None)
                    run_cfg=self.engine.config(project)
                    can_prefetch=next_pid and run_cfg.get('pipeline_enabled',True) and not run_cfg.get('gpu_handoff') and run_cfg.get('provider')!='local' and run_cfg.get('review_provider')!='local'
                    if can_prefetch:
                        prepared=asyncio.create_task(self.engine.preparation_events[pid].wait())
                        try:await asyncio.wait([task,prepared],return_when=asyncio.FIRST_COMPLETED)
                        finally:
                            if not prepared.done():prepared.cancel()
                            await asyncio.gather(prepared,return_exceptions=True)
                        can_prefetch=self.engine.preparation_events[pid].is_set() and not self.store.get('series',id).get('pause_requested')
                    if can_prefetch:
                        current_project=self.store.get('project',pid)
                        new_ids=list(current_project.get('generated_assets',{}).values())
                        following=self.store.get('project',next_pid)
                        self.engine.set(next_pid,asset_ids=list(dict.fromkeys(following['asset_ids']+new_ids)))
                        # Text only. Never create next-episode images from provisional output.
                        async def draft(target=next_pid):
                            try:await self.engine.prepare_episode(target)
                            except Paused:raise
                            except Exception as error:
                                self.paused(id)
                                saved=self.store.get('project',target)
                                self.engine.set(target,status='draft' if saved.get('plan') else 'error',
                                                phase='提前准备失败已记录；已有分镜的任务继续，无分镜的集待补做',
                                                error='' if saved.get('plan') else str(error),
                                                error_kind='' if saved.get('plan') else 'automatic',prefetch_error=str(error))
                        draft_task=asyncio.create_task(draft())
                        ready_task=asyncio.create_task(self.engine.ready_events[pid].wait())
                        await asyncio.wait([task,ready_task],return_when=asyncio.FIRST_COMPLETED)
                        if self.engine.ready_events[pid].is_set() and not self.store.get('series',id).get('pause_requested'):
                            await draft_task
                            async def prepare(target=next_pid,prior=pid):
                                try:await self.engine.prepare_episode(target,prior,images=True)
                                except Paused:raise
                                except Exception as error:
                                    self.paused(id)
                                    saved=self.store.get('project',target)
                                    if saved.get('clips'):
                                        from .task_recovery import record_failure
                                        await record_failure(self.engine,target,0,error,self.engine.config(saved))
                                        self.engine.set(target,status='draft',prefetch_error=str(error))
                                    else:
                                        self.engine.set(target,status='error',error=str(error),error_kind='automatic',prefetch_error=str(error))
                            if self.store.get('project',next_pid).get('status')!='error':
                                prepare_task=asyncio.create_task(prepare())
                    try:await asyncio.shield(task)
                    except asyncio.CancelledError:
                        if asyncio.current_task().cancelling():raise
                    if self.store.get('project',pid)['status']=='complete':
                        for pending in (draft_task,prepare_task):
                            if pending:await pending
                    else:
                        for pending in (draft_task,prepare_task):
                            if pending and not pending.done():pending.cancel()
                        await asyncio.gather(*(t for t in (draft_task,prepare_task) if t),return_exceptions=True)
                    if ready_task and not ready_task.done():ready_task.cancel()
                    if ready_task:await asyncio.gather(ready_task,return_exceptions=True)
                    draft_task=prepare_task=ready_task=None
                    self.paused(id);project=self.store.get('project',pid)
                    if project['status']!='complete':
                        if project['status']=='paused':
                            self.paused(id)
                            self.engine.set(pid,status='deferred',error='后台等待意外结束；原任务保留，后续继续',error_kind='automatic')
                            project=self.store.get('project',pid)
                        if self.defer_episode(id,pid,i+1,project,run_cfg):continue
                        raise RuntimeError(f'第{i+1}集停止：'+project.get('error','请打开本集查看原因。'))
                    generated=list(project['generated_assets'].values())
                    self.store.update('series',id,lambda x:x.update(asset_ids=list(dict.fromkeys(x['asset_ids']+generated))))
                    more=any(not episode_recovery.terminal(self.store.get('project',q)) for q in record['project_ids'][record['project_ids'].index(pid)+1:])
                    self.event(id,f'第{i+1}集已完成。'+('自动继续下一集。' if more else '本批全部完成，可追加后续剧本。'))
                except Paused:raise
                except asyncio.CancelledError:raise
                except Exception as error:
                    self.paused(id)
                    if task and not task.done():await asyncio.shield(task)
                    from .task_recovery import project_deferred
                    project_deferred(self.engine,pid,error)
                    self.event(id,f'本集自动异常已记录，继续后续集：{error}')
                    for pending in (draft_task,prepare_task,ready_task):
                        if pending and not pending.done():pending.cancel()
                    await asyncio.gather(*(t for t in (draft_task,prepare_task,ready_task) if t),return_exceptions=True)
                    draft_task=prepare_task=ready_task=None
                    continue
            deferred=[i+1 for i in range(len(record['plan']['episodes']))
                      if self.episode_id(id,i) in record['project_ids'] and self.store.get('project',self.episode_id(id,i))['status']=='deferred']
            pending=self.pending_batch(self.store.get('series',id))
            self.set(id,status='partial' if deferred or pending else 'complete',
                     phase=('已有任务已处理；尚有批次未取得分集清单，点击继续重试该批次' if pending else
                            '本批已处理完；第'+ '、'.join(map(str,deferred))+'集待补做，可追加后续剧本或单独补做' if deferred
                            else '全部成片已完成，打开各集查看或选择镜头重做'),
                     error=self.store.get('series',id).get('batch_error','') if pending else '',pause_requested=False)
        except Paused as e:self.set(id,status='paused',phase=str(e),pause_requested=False)
        except asyncio.CancelledError:
            self.set(id,status='paused',phase='服务停止，进度已保存，点击继续恢复',pause_requested=False);raise
        except Exception as e:
            self.set(id,status='partial',phase='本批自动步骤异常已记录，已有成果保留；未完成内容可补做',error=str(e),pause_requested=False);self.event(id,'自动步骤异常记录：'+str(e))
        finally:
            for pending in (draft_task,prepare_task,ready_task):
                if pending and not pending.done():pending.cancel()
            await asyncio.gather(*(t for t in (draft_task,prepare_task,ready_task) if t),return_exceptions=True)
