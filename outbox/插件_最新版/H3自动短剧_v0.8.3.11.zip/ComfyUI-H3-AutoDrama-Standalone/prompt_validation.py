"""One field-addressed contract for generated prompt content.

Only the AI boundary performs lossless structural recovery. Authored drafts
and direct compiler callers continue to receive strict validation.
"""
import copy
import json
import math
import re

TOKEN = re.compile(r'\[\[(ref_\d+)\]\]')
RAW_REF = re.compile(r'<(Picture|Video|Audio|Subject)\s+\d+>', re.I)
HEADERS = re.compile(r'(?mi)^\s*(?:subject_definitions|summary|retention_analysis|detailed_description|integrated_multimodal_description|overall_soundscape|non_diegetic_music|asset_bindings)\s*:')
TOLERANCE = 1 / 24 + .001


class InvalidContent(ValueError):
    def __init__(self, issues):
        self.issues = list(dict.fromkeys((str(path), str(reason)) for path, reason in issues))
        self.paths = list(dict.fromkeys(path for path, _ in self.issues))
        super().__init__('提示词字段需要修正：' + '；'.join(f'{path}：{reason}' for path, reason in self.issues))


def number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        return None
    try:
        value = float(value)
    except (ValueError, TypeError, OverflowError):
        return None
    return value if math.isfinite(value) else None


def text_issues(value, path, keys=(), allow_refs=False):
    if not isinstance(value, str) or not value.strip():
        return [(path, '须为非空文字')]
    problems = []
    if re.search(r'</?d\b|\(S\d+\)', value, re.I):
        problems.append((path, '不要在描述内添加对白标签或说话人编号；原句由软件写入'))
    if HEADERS.search(value):
        problems.append((path, '不要在字段内嵌套H3区域或素材绑定表'))
    if any(m.group(1).lower() != 'audio' for m in RAW_REF.finditer(value)):
        problems.append((path, '视觉引用须使用本次真实输入的[[ref_编号]]，不能自行编造H3编号'))
    tokens = TOKEN.findall(value)
    if allow_refs:
        if any(key not in keys for key in tokens):
            problems.append((path, '描述引用了不存在的素材key；只可使用本次references中的key'))
        remaining = TOKEN.sub('', value)
    else:
        remaining = value
    if '[[' in remaining or ']]' in remaining:
        problems.append((path, '素材占位格式无效，或素材自身/声音描述嵌套了引用'))
    return problems


def recover_structure(result, clip, axis):
    """Recover derived bookkeeping without changing prose or source dialogue."""
    out = copy.deepcopy(result)
    shots = out.get('shots')
    if not isinstance(shots, list) or not shots:
        return out
    valid = [s for s in shots if isinstance(s, dict)]
    notes = []
    duration = float(clip['duration_seconds'])
    count = len(clip.get('dialogue', []))
    guide = float(axis.get('new_content_start_seconds', 0))
    # Some responses use generated-video time instead of retained-content time.
    # Subtract the guide only if the complete range identifies it unambiguously.
    if len(valid) == len(shots) and guide:
        first = number(shots[0].get('start_seconds'))
        last = number(shots[-1].get('end_seconds'))
        if first is not None and last is not None and abs(first-guide)<.001 and abs(last-guide-duration)<.001:
            if all(number(s.get(k)) is not None for s in shots for k in ('start_seconds', 'end_seconds')):
                for shot in shots:
                    for key in ('start_seconds', 'end_seconds'):
                        shot[key] = number(shot[key])-guide
                notes.append('已将续接引导时间换算为本任务保留内容时间')
    for shot in valid:
        for key in ('start_seconds', 'end_seconds'):
            converted = number(shot.get(key))
            if converted is not None:
                shot[key] = converted
        if not count:
            if shot.get('dialogue_indices') != []:
                notes.append('本任务没有原台词，已由软件固定空对白关联')
            shot['dialogue_indices'] = []
        elif len(shots) == 1:
            if shot.get('dialogue_indices') != list(range(count)):
                notes.append('单镜头对白关联已由软件按全部原句顺序生成')
            shot['dialogue_indices'] = list(range(count))
        else:
            indices = shot.get('dialogue_indices')
            if isinstance(indices, str):
                try:
                    indices = json.loads(indices)
                except (ValueError, TypeError):
                    pass
            if type(indices) in (int, float):
                indices = [indices]
            if isinstance(indices, list):
                converted = []
                for item in indices:
                    value = number(item)
                    converted.append(int(value) if value is not None and value.is_integer() else item)
                shot['dialogue_indices'] = converted
    if len(valid) == len(shots):
        # A task's outer bounds are already authoritative; AI chooses its cuts.
        if shots[0].get('start_seconds') != 0 or shots[-1].get('end_seconds') != duration:
            notes.append('任务首尾边界已与原定保留时长一致')
        shots[0]['start_seconds'] = 0.
        shots[-1]['end_seconds'] = duration
        flat = [i for s in shots for i in s.get('dialogue_indices', [])] if all(isinstance(s.get('dialogue_indices'), list) for s in shots) else None
        if count and flat == list(range(1, count+1)) and all(type(i) is int for i in flat):
            for shot in shots:
                shot['dialogue_indices'] = [i-1 for i in shot['dialogue_indices']]
            notes.append('已将完整且无歧义的1起始对白编号换算为0起始')
        notes.extend(recover_speech_timing(shots, clip))
    prior = out.get('_content_warnings')
    out['_content_warnings'] = list(dict.fromkeys([x for x in prior if isinstance(x, str)] if isinstance(prior, list) else []))
    out['_content_warnings'] = list(dict.fromkeys(out['_content_warnings'] + notes))
    return out


def recover_speech_timing(shots, clip):
    """Fit derived shot cuts locally; preserve every word and creative field.

    A task-wide budget reserves one lead/tail pair. Several speaking shots
    need additional pairs, so their full extra padding may no longer fit.
    Extra silence is subordinate to the existing speech budget. Do not resize
    the task, rewrite dialogue, repair broken ownership, or touch sent jobs.
    """
    from .dialogue_retention import active
    from .dialogue_timing import COMMITTED
    from .dialogue_plan import budget
    if not active(clip) or any(clip.get(key) for key in COMMITTED):
        return []
    for shot in shots:
        if isinstance(shot, dict):
            shot.pop('_speech_timing_contract', None)
            shot.pop('_speech_reserved_extra_seconds', None)
    lines = clip.get('dialogue', [])
    if not lines:
        return []
    duration = number(clip.get('duration_seconds'))
    if duration is None or duration <= 0:
        return []
    lengths, minimum, flat, speaking = [], [], [], []
    cursor = 0.
    for i, shot in enumerate(shots):
        if not isinstance(shot, dict):
            return []
        start, end = (number(shot.get(key)) for key in ('start_seconds', 'end_seconds'))
        indices = shot.get('dialogue_indices')
        if (start is None or end is None or end <= start or abs(start-cursor) > TOLERANCE
                or not isinstance(indices, list)
                or any(type(j) is not int or not 0 <= j < len(lines) for j in indices)):
            return []
        flat.extend(indices)
        span = end-cursor
        if span <= 0:return []
        lengths.append(span)
        if indices:
            speaking.append(i)
            minimum.append(budget([lines[j] for j in indices])['minimum_seconds']
                           if clip.get('dialogue_budget') else .75)
        else:
            minimum.append(min(span, 1/24))
        cursor = end
    if abs(cursor-duration) > TOLERANCE or flat != list(range(len(lines))) or not speaking:
        return []
    required = sum(minimum)
    if required > duration + 1e-8:
        # This is genuine insufficient speech time, not a padding failure.
        # Existing bounded field repair can regroup the authored lines.
        return []
    requested = number((clip.get('dialogue_timing') or {}).get('extra_seconds', 0))
    if requested is None:
        return []
    requested = max(0., requested)
    reserved = min(requested, max(0., duration-required))
    last = speaking[-1]
    minimum[last] += reserved
    fitted = [max(old, needed) for old, needed in zip(lengths, minimum)]
    deficit = max(0., sum(fitted)-duration)
    # Borrow silent time first, then only genuine surplus in speaking shots.
    donors = sorted(range(len(shots)),
                    key=lambda i: (bool(shots[i]['dialogue_indices']), -(fitted[i]-minimum[i]), i))
    for i in donors:
        take = min(deficit, max(0., fitted[i]-minimum[i]))
        fitted[i] -= take
        deficit -= take
    if deficit > 1e-7:
        return []
    notes = []
    if any(abs(a-b) > 1e-7 for a,b in zip(lengths,fitted)) or any(abs(float(s['start_seconds'])-(float(shots[i-1]['end_seconds']) if i else 0.))>1e-7 for i,s in enumerate(shots)):
        cursor = 0.
        for i, (shot, span) in enumerate(zip(shots, fitted)):
            shot['start_seconds'] = cursor
            cursor += span
            shot['end_seconds'] = duration if i == len(shots)-1 else cursor
        notes.append('软件已在原任务时长内校准镜头边界，保留镜头顺序、描述和全部原台词')
    if reserved < requested-1e-7:
        shots[last]['_speech_timing_contract'] = 1
        shots[last]['_speech_reserved_extra_seconds'] = reserved
        notes.append(f'完整对白及各镜头正常收尾优先；本段额外句尾停留可预留{reserved:.3f}秒')
    return notes


def issues(result, assets, clip):
    """Collect all repairable field errors before paying for another request."""
    problems = []
    keys = {f'ref_{i+1}' for i in range(len(assets))}
    for key, pair in result.get('reference_descriptions', {}).items():
        if isinstance(pair, dict):
            for language in ('en', 'zh'):
                problems.extend(text_issues(pair.get(language), f'/reference_descriptions/{key}/{language}'))
    for name, pair in result.get('voices', {}).items():
        if isinstance(pair, dict):
            escaped = name.replace('~', '~0').replace('/', '~1')
            for language in ('en', 'zh'):
                problems.extend(text_issues(pair.get(language), f'/voices/{escaped}/{language}'))
    for language in ('en', 'zh'):
        problems.extend(text_issues(result.get('sound_'+language), '/sound_'+language, keys, True))
    shots = result.get('shots')
    if not isinstance(shots, list) or not 1 <= len(shots) <= 12:
        problems.append(('/shots', 'shots须为1至12个镜头的列表'))
        return problems
    duration = float(clip['duration_seconds'])
    lines = clip.get('dialogue', [])
    flat = []
    valid_indices = True
    previous = None
    for i, shot in enumerate(shots):
        path = f'/shots/{i}'
        if not isinstance(shot, dict):
            problems.append((path, '镜头项须为对象'))
            valid_indices = False
            previous = None
            continue
        for language in ('en', 'zh'):
            problems.extend(text_issues(shot.get('visual_'+language), path+'/visual_'+language, keys, True))
        start, end = (number(shot.get(k)) for k in ('start_seconds', 'end_seconds'))
        for key, value in (('start_seconds', start), ('end_seconds', end)):
            if value is None:
                problems.append((path+'/'+key, '镜头须提供有效的开始和结束秒数，布尔值、空值和非有限数字无效'))
        if start is not None and i == 0 and abs(start) > TOLERANCE:
            problems.append((path+'/start_seconds', '首镜头须从保留内容0秒开始'))
        if start is not None and end is not None and end <= start:
            problems.extend((path+'/'+k, '镜头结束须晚于开始') for k in ('start_seconds', 'end_seconds'))
        if end is not None and end > duration + TOLERANCE:
            problems.append((path+'/end_seconds', '镜头不能超过本段保留时长'))
        if previous is not None and start is not None and abs(start-previous) > TOLERANCE:
            problems.extend([(f'/shots/{i-1}/end_seconds', '相邻镜头时间须连续，不能重叠或留空'), (path+'/start_seconds', '相邻镜头时间须连续，不能重叠或留空')])
        if i == len(shots)-1 and end is not None and abs(end-duration) > TOLERANCE:
            problems.append((path+'/end_seconds', '镜头时间须覆盖本段全部保留时长'))
        previous = end
        indices = shot.get('dialogue_indices')
        if not isinstance(indices, list) or any(type(j) is not int or not 0 <= j < len(lines) for j in indices):
            problems.append((path+'/dialogue_indices', 'dialogue_indices须使用原台词0起始索引'))
            valid_indices = False
        else:
            flat.extend(indices)
        if isinstance(indices, list) and all(type(j) is int and 0 <= j < len(lines) for j in indices) and start is not None and end is not None:
            from .dialogue_plan import budget
            from .dialogue_retention import extra_hold
            hold = extra_hold(clip, shots, i+1)
            required = budget([lines[j] for j in indices])['minimum_seconds'] if clip.get('dialogue_budget') else .75
            if indices and (clip.get('dialogue_budget') or hold) and end-start-hold+1/24 < required:
                problems.extend((f'/shots/{n}/{k}', '对白时间不足，须单独留出句尾余量并在既定任务时长内重新分配镜头/原句，不能删词或加速') for n in range(len(shots)) for k in ('start_seconds', 'end_seconds', 'dialogue_indices'))
    if not valid_indices or flat != list(range(len(lines))):
        problems.extend((f'/shots/{i}/dialogue_indices', '每句原文须按原顺序完整出现一次，不能遗漏、重复或交换；无台词时为空数组') for i, s in enumerate(shots) if isinstance(s, dict))
    return list(dict.fromkeys(problems))


def validate(result, assets, clip):
    problems = issues(result, assets, clip)
    if problems:
        raise InvalidContent(problems)
