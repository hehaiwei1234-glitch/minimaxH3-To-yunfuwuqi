"""Standalone MiniMax H3 continuation workflow helpers.

Goals:
- coexist with the user's mature batch-reference + upscale plugin;
- never modify ComfyUI core files on disk;
- backport the *runtime behavior* needed by H3 multi-frame/audio guides only on
  the MODEL branch that passes through H3ADv1ModelCompat;
- keep continuation and second-pass upscale independently switchable.

The compatibility behavior mirrors the official MiniMaxH3AddGuide change while
remaining isolated to a cloned ModelPatcher branch.
"""

from __future__ import annotations

import copy
import hashlib
import json
import logging
import math
import inspect
import os
import types
from typing import Any

import torch
import torchaudio

import folder_paths
import nodes
import node_helpers
import comfy.conds
import comfy.ldm.common_dit
import comfy.nested_tensor
import comfy.ops
import comfy.utils
import comfy.ldm.minimax.model as minimax_model
from comfy_api.latest import ComfyExtension, io
from comfy_api.latest._input_impl import VideoFromFile
from comfy_extras import nodes_audio
from comfy_extras import nodes_minimax_h3 as h3_nodes
from comfy_extras.nodes_minimax_h3 import MiniMaxH3ReferenceToVideo


BATCH_NODE_ID = "H3ADv1BatchReferenceToVideo"
BATCH_NODE_DISPLAY_NAME = "H3 自动短剧独立版 · 批量引用"
MEDIA_GROUP_IDS = {"ref_images", "ref_videos", "ref_video_audios", "ref_audios"}
MAX_IMAGES = 9
MAX_VIDEOS = 3
MAX_AUDIOS = 3
H3_FPS = 24


def _clean_name(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    value = value.strip()
    return "" if value in {"", "(none)"} else value


def _normalise_name_list(value: Any, label: str, maximum: int) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValueError(f"批量素材状态中的 {label} 必须是列表。")
    result: list[str] = []
    for entry in value:
        name = _clean_name(entry.get("name") if isinstance(entry, dict) else entry)
        if name:
            result.append(name)
    if len(result) > maximum:
        raise ValueError(f"{label} 最多支持 {maximum} 个，当前为 {len(result)} 个。")
    return result


def _normalise_videos(value: Any) -> list[dict[str, Any]]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValueError("批量素材状态中的 videos 必须是列表。")
    result: list[dict[str, Any]] = []
    for entry in value:
        if isinstance(entry, str):
            name = _clean_name(entry)
            include_audio = True
        elif isinstance(entry, dict):
            name = _clean_name(entry.get("name"))
            include_audio = bool(entry.get("include_audio", True))
        else:
            continue
        if name:
            result.append({"name": name, "include_audio": include_audio})
    if len(result) > MAX_VIDEOS:
        raise ValueError(f"videos 最多支持 {MAX_VIDEOS} 个，当前为 {len(result)} 个。")
    return result


def parse_media_state(value: Any) -> dict[str, Any]:
    if value is None or value == "" or value == "(none)":
        raw: dict[str, Any] = {}
    elif isinstance(value, dict):
        raw = value
    else:
        try:
            raw = json.loads(str(value))
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise ValueError("批量素材状态 JSON 已损坏；请在节点中重新添加素材。") from exc
        if not isinstance(raw, dict):
            raise ValueError("批量素材状态必须是 JSON 对象。")

    if "items" in raw and not any(key in raw for key in ("images", "videos", "audios")):
        images: list[Any] = []
        videos: list[Any] = []
        audios: list[Any] = []
        for item in raw.get("items", []):
            if not isinstance(item, dict):
                continue
            kind = item.get("kind")
            if kind == "image":
                images.append(item)
            elif kind == "video":
                videos.append({"name": item.get("name"), "include_audio": not bool(item.get("muted", False))})
            elif kind == "audio":
                audios.append(item)
        raw = {"images": images, "videos": videos, "audios": audios}

    result = {
        "version": 1,
        "images": _normalise_name_list(raw.get("images"), "images", MAX_IMAGES),
        "videos": _normalise_videos(raw.get("videos")),
        "audios": _normalise_name_list(raw.get("audios"), "audios", MAX_AUDIOS),
    }
    if sum(len(result[key]) for key in ("images", "videos", "audios")) > 12:
        raise ValueError("H3单段参考素材合计不能超过12个。")
    return result


def _resolve_input_file(name: str) -> str:
    try:
        path = folder_paths.get_annotated_filepath(name)
    except Exception as exc:
        raise RuntimeError(f"找不到素材：{name}") from exc
    if not path or not os.path.isfile(path):
        raise RuntimeError(f"找不到素材：{name}")
    return path


def _load_image(name: str):
    _resolve_input_file(name)
    try:
        return nodes.LoadImage().load_image(name)[0]
    except Exception as exc:
        raise RuntimeError(f"参考图片读取失败：{name}: {exc}") from exc


def _load_audio(name: str):
    _resolve_input_file(name)
    try:
        return nodes_audio.LoadAudio.load(name)[0]
    except Exception as exc:
        raise RuntimeError(f"参考音频读取失败：{name}: {exc}") from exc


def _load_video(name: str):
    path = _resolve_input_file(name)
    try:
        components = VideoFromFile(path).get_components()
    except Exception as exc:
        raise RuntimeError(f"参考视频读取失败：{name}: {exc}") from exc
    frames = getattr(components, "images", None)
    if frames is None:
        raise RuntimeError(f"参考视频没有可读取的画面：{name}")
    return frames, getattr(components, "audio", None)


def _file_signature(hasher: "hashlib._Hash", name: str) -> None:
    hasher.update(name.encode("utf-8", "surrogatepass"))
    hasher.update(b"\0")
    try:
        path = _resolve_input_file(name)
        stat = os.stat(path)
        hasher.update(str(stat.st_size).encode())
        hasher.update(b":")
        hasher.update(str(stat.st_mtime_ns).encode())
    except Exception:
        hasher.update(b"missing")
    hasher.update(b"\0")


class H3ADv1BatchReferenceToVideo(io.ComfyNode):
    """Independent copy of the user's mature batch-reference behavior."""

    DESCRIPTION = (
        "续接独立版自己的批量参考节点。最多 9 张图片、3 个视频、3 个音频；"
        "仍然原样调用当前 ComfyUI 的 MiniMaxH3ReferenceToVideo，不修改 Prompt。"
    )
    RETURN_TYPES = ("CONDITIONING", "LATENT")
    RETURN_NAMES = ("positive", "latent")
    FUNCTION = "EXECUTE_NORMALIZED"
    CATEGORY = "model/conditioning/minimax"

    @classmethod
    def define_schema(cls):
        schema = copy.deepcopy(MiniMaxH3ReferenceToVideo.define_schema())
        schema.node_id = BATCH_NODE_ID
        schema.display_name = BATCH_NODE_DISPLAY_NAME
        schema.description = cls.DESCRIPTION
        schema.inputs = [input_spec for input_spec in schema.inputs if input_spec.id not in MEDIA_GROUP_IDS]
        schema.inputs.append(
            io.String.Input(
                "batch_media_json",
                default="",
                optional=True,
                multiline=True,
                tooltip="由批量素材界面保存；由自动短剧软件管理。",
                extra_dict={"hidden": True},
            )
        )
        return schema

    @classmethod
    def INPUT_TYPES(cls):
        input_types = copy.deepcopy(MiniMaxH3ReferenceToVideo.INPUT_TYPES())
        for section_name in ("required", "optional", "hidden"):
            section = input_types.get(section_name)
            if isinstance(section, dict):
                for key in MEDIA_GROUP_IDS:
                    section.pop(key, None)
        input_types.setdefault("optional", {})["batch_media_json"] = (
            "STRING", {"default": "", "multiline": True, "hidden": True}
        )
        return input_types

    @classmethod
    def IS_CHANGED(cls, batch_media_json="", **_kwargs):
        state = parse_media_state(batch_media_json)
        hasher = hashlib.sha256()
        hasher.update(b"h3_autodrama_v1_batch_v1\0")
        hasher.update(json.dumps(state, ensure_ascii=False, sort_keys=True).encode("utf-8"))
        for name in state["images"]:
            _file_signature(hasher, name)
        for video in state["videos"]:
            _file_signature(hasher, video["name"])
        for name in state["audios"]:
            _file_signature(hasher, name)
        return hasher.hexdigest()

    @classmethod
    def execute(cls, clip, vae, audio_vae, prompt, width, height, length,
                ref_image_size="match", batch_media_json=""):
        state = parse_media_state(batch_media_json)
        ref_images = {f"ref_image_{i}": _load_image(name) for i, name in enumerate(state["images"])}
        ref_videos: dict[str, Any] = {}
        ref_video_audios: dict[str, Any] = {}
        for i, item in enumerate(state["videos"]):
            frames, audio = _load_video(item["name"])
            ref_videos[f"ref_video_{i}"] = frames
            if item["include_audio"] and audio is not None:
                ref_video_audios[f"ref_video_audio_{i}"] = audio
        ref_audios = {f"ref_audio_{i}": _load_audio(name) for i, name in enumerate(state["audios"])}
        return MiniMaxH3ReferenceToVideo.execute(
            clip=clip, vae=vae, audio_vae=audio_vae, prompt=prompt,
            width=width, height=height, length=length, ref_image_size=ref_image_size,
            ref_images=ref_images or None, ref_videos=ref_videos or None,
            ref_video_audios=ref_video_audios or None, ref_audios=ref_audios or None,
        )


def _frame_count_from_av_latent(latent) -> int:
    samples = latent.get("samples") if isinstance(latent, dict) else None
    if samples is None or not getattr(samples, "is_nested", False):
        raise ValueError("H3 续接需要 MiniMax H3 的 AV LATENT。")
    video = samples.tensors[0]
    return int(sum(minimax_model.FRAME_PER_TOKEN[k % 5] for k in range(video.shape[2])))


def _latent_canvas(latent) -> tuple[int, int]:
    samples = latent["samples"]
    video = samples.tensors[0]
    return int(video.shape[4] * 16), int(video.shape[3] * 16)


def _pad_guide_video_latent(latent: torch.Tensor) -> torch.Tensor:
    """Pad guide/video condition latent exactly like H3 pads its main stream.

    H3 patch_size is (1, 2, 2).  A VAE encode may return an odd latent H/W
    (for example 240px -> 15 latent rows).  The main H3 stream calls
    comfy.ldm.common_dit.pad_to_patch_size() before patchify; condition latents
    in the affected 0.33.x core do not.  Mirror the core's own padding here so
    guide rows and target PackedLayout use the same patch grid.
    """
    if not isinstance(latent, torch.Tensor) or latent.ndim != 5:
        return latent
    return comfy.ldm.common_dit.pad_to_patch_size(latent, (1, 2, 2))


def _core_supports_multiframe_guides() -> bool:
    """Detect the *model core* capability, not merely whether a UI node exists.

    ComfyUI 0.33.x PackedLayout still has ``frame_count`` and only accepts
    first/last keyframes.  The 0.34+ multi-frame-guide core removed that
    parameter and supports arbitrary clip guides.  Checking PackedLayout avoids
    false positives on partially updated installs where nodes_minimax_h3.py and
    comfy/ldm/minimax/model.py are from different releases.
    """
    try:
        params = inspect.signature(minimax_model.PackedLayout.__init__).parameters
        return "frame_count" not in params
    except Exception:
        return False


def _largest_valid_guide_frames(frame_count: int) -> int:
    frame_count = int(frame_count)
    if frame_count < 5:
        return 0
    return 5 + 17 * ((frame_count - 5) // 17)


def _requested_guide_frames(overlap_seconds: float) -> int:
    requested = max(5, int(round(float(overlap_seconds) * H3_FPS)))
    return _largest_valid_guide_frames(requested)


def _align_h3_frames(frame_count: int) -> int:
    n = max(5, int(frame_count))
    while n % 17 != 5:
        n += 1
    return n


def _crop_audio_duration(audio, seconds: float):
    if audio is None:
        return None
    waveform = audio.get("waveform") if hasattr(audio, "get") else None
    sample_rate = int(audio.get("sample_rate", 0)) if hasattr(audio, "get") else 0
    if waveform is None or sample_rate <= 0:
        return audio
    wanted = max(1, int(round(float(seconds) * sample_rate)))
    result = dict(audio)
    result["waveform"] = waveform[..., -wanted:].clone() if waveform.shape[-1] > wanted else waveform
    return result


def _encode_guide_audio(audio_vae, audio):
    waveform = audio["waveform"]
    sr = int(audio["sample_rate"])
    vae_sr = int(getattr(audio_vae, "audio_sample_rate", 32000))
    if sr != vae_sr:
        waveform = torchaudio.functional.resample(waveform, sr, vae_sr)
    z = audio_vae.encode(waveform[:1].movedim(1, -1))
    return z


def _prepare_tail_video(name: str, overlap_seconds: float, include_audio: bool):
    path = _resolve_input_file(name)
    source = VideoFromFile(path)
    duration = float(source.get_duration())
    if duration <= 0:
        raise ValueError("上一段视频时长无效。")
    requested = _requested_guide_frames(overlap_seconds)
    available = max(0, int(duration * H3_FPS + 1e-6))
    guide_frames = min(requested, _largest_valid_guide_frames(available))
    if guide_frames < 5:
        raise ValueError("上一段视频太短，至少需要约 0.21 秒才能做动态续接。")
    guide_seconds = guide_frames / H3_FPS
    trimmed = source.as_trimmed(
        start_time=max(0.0, duration - guide_seconds),
        duration=guide_seconds,
        strict_duration=False,
    )
    if trimmed is None:
        raise ValueError("无法截取上一段视频尾部。")
    components = trimmed.get_components()
    frames = getattr(components, "images", None)
    if frames is None or getattr(frames, "ndim", 0) != 4 or frames.shape[0] < 1:
        raise ValueError("上一段视频没有可读取的视频帧。")
    if frames.shape[0] != guide_frames:
        indices = torch.linspace(0, frames.shape[0] - 1, guide_frames, device=frames.device)
        indices = indices.round().long().clamp_(0, frames.shape[0] - 1)
        frames = frames.index_select(0, indices)
    audio = getattr(components, "audio", None) if bool(include_audio) else None
    if audio is not None:
        audio = _crop_audio_duration(audio, guide_seconds)
    return frames, audio, guide_frames, guide_seconds


class H3ADv1Prepare(io.ComfyNode):
    """Optionally add the previous clip tail as a multi-frame/audio H3 guide."""

    DESCRIPTION = (
        "开启时读取上一段 MP4 的真实尾部，作为下一段开头的动态+音频 Guide；"
        "同时把目标 latent 自动延长，生成后再裁掉重叠段。关闭时原样返回原 conditioning/latent，且不会读取上一段视频。"
    )
    FUNCTION = "EXECUTE_NORMALIZED"
    CATEGORY = "conditioning/video_models"

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3ADv1Prepare",
            display_name="H3 自动短剧 · 续接准备",
            category=cls.CATEGORY,
            description=cls.DESCRIPTION,
            inputs=[
                io.Conditioning.Input("positive"),
                io.Latent.Input("latent"),
                io.Vae.Input("vae"),
                io.Vae.Input("audio_vae"),
                io.Boolean.Input("enable_continue", default=False, tooltip="关闭时完全走原逻辑，不读取上一段视频。"),
                io.Float.Input("overlap_seconds", default=1.0, min=0.21, max=5.0, step=0.05,
                               tooltip="继承上一段结尾时长；内部吸附到 H3 合法 5/22/39/... 帧。"),
                io.Boolean.Input("include_audio", default=True, tooltip="上一段有声音时，同时继承对应尾部音频。"),
                io.String.Input("previous_video_name", default="", optional=True, multiline=False,
                                tooltip="由节点里的上一段视频选择器保存。", extra_dict={"hidden": True}),
            ],
            outputs=[
                io.Conditioning.Output(display_name="positive"),
                io.Latent.Output(display_name="latent"),
                io.Image.Output(display_name="guide_frames"),
                io.Int.Output(display_name="trim_start_frames"),
                io.Int.Output(display_name="trim_output_frames"),
                io.Int.Output(display_name="guide_frame_count"),
            ],
        )

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "positive": ("CONDITIONING",), "latent": ("LATENT",), "vae": ("VAE",), "audio_vae": ("VAE",),
                "enable_continue": ("BOOLEAN", {"default": False}),
                "overlap_seconds": ("FLOAT", {"default": 1.0, "min": 0.21, "max": 5.0, "step": 0.05}),
                "include_audio": ("BOOLEAN", {"default": True}),
            },
            "optional": {"previous_video_name": ("STRING", {"default": "", "hidden": True})},
        }

    @classmethod
    def IS_CHANGED(cls, enable_continue=False, previous_video_name="", overlap_seconds=1.0, include_audio=True, **_kwargs):
        if not enable_continue:
            return "h3_autodrama_v1_off"
        hasher = hashlib.sha256()
        hasher.update(f"{overlap_seconds}:{bool(include_audio)}:".encode())
        name = _clean_name(previous_video_name)
        if name:
            _file_signature(hasher, name)
        return hasher.hexdigest()

    @classmethod
    def execute(cls, positive, latent, vae, audio_vae, enable_continue=False,
                overlap_seconds=1.0, include_audio=True, previous_video_name=""):
        base_frames = _frame_count_from_av_latent(latent)
        if not bool(enable_continue):
            # Placeholder is never consumed when the downstream refit node is disabled.
            placeholder = torch.zeros((1, 1, 1, 3), dtype=torch.float32)
            return io.NodeOutput(positive, latent, placeholder, 0, base_frames, 0)

        name = _clean_name(previous_video_name)
        if not name:
            raise ValueError("已开启上一段续接，但还没有选择上一段 MP4。")
        guide_frames_tensor, guide_audio, guide_frames, _guide_seconds = _prepare_tail_video(
            name, overlap_seconds, include_audio
        )
        width, height = _latent_canvas(latent)
        target_frames = _align_h3_frames(base_frames + guide_frames)
        target_latent, _ = h3_nodes._empty_av_latent(width, height, target_frames)

        resized = h3_nodes._resize(guide_frames_tensor[:guide_frames], width, height, "center")
        guide_latent = _pad_guide_video_latent(vae.encode(resized))
        keyframe = {
            "resolved_frame_index": 0,
            "latent": guide_latent,
            "h3_autodrama_v1": True,
            "guide_frame_count": guide_frames,
        }
        if guide_audio is not None:
            audio_latent = _encode_guide_audio(audio_vae, guide_audio)
            # Mirror official AddGuide safety: never let a guide soundtrack extend
            # past the target audio timeline. Our guide is anchored at frame 0.
            target_audio_t = int(target_latent["samples"].tensors[1].shape[-1])
            if audio_latent.shape[-1] > target_audio_t:
                audio_latent = audio_latent[..., :target_audio_t].clone()
            keyframe["audio_latent"] = audio_latent

        keyframes = list(positive[0][1].get("minimax_keyframes", []))
        keyframes.append(keyframe)
        positive = node_helpers.conditioning_set_values(positive, {"minimax_keyframes": keyframes})
        return io.NodeOutput(positive, target_latent, guide_frames_tensor, guide_frames, base_frames, guide_frames)


class H3ADv1PackedLayout:
    """PackedLayout compatible with the user's older H3 core, extended for clip/audio guides.

    Audio guide rows intentionally use the already-supported ``ref_audio`` segment kind,
    so the old diffusion-model forward path does not need to be replaced globally.
    """

    def __init__(self, text_len, latent_t, latent_h, latent_w, audio_t,
                 keyframes=None, refs=None, frame_count=None):
        frame, w_grid = minimax_model._frame_grid(latent_h, latent_w)
        frame_rows = frame.shape[0]
        segments = [("text", text_len)]
        g = torch.zeros(text_len, 3, dtype=torch.float64)
        g[:, 0] = torch.arange(text_len, dtype=torch.float64)
        pos = [g]
        img_pos, img_update = [], []
        audio_pos, audio_update = [], []
        row = text_len
        target_audio_w = (float(w_grid[0]), float(w_grid[-1]))

        # Match the newer official H3 layout semantics: reference blocks occupy
        # time before the target stream, therefore keyframe/clip guide anchors
        # are measured from the *target* timeline origin, after all ref spans.
        target_cursor = float(text_len)
        for blk in refs or ():
            kind = blk.get("kind")
            if kind == "image":
                target_cursor += 1.0
            elif kind == "audio":
                target_cursor += float(blk.get("ref_audio_t", 0))
            elif kind in ("video", "video_audio"):
                rt = float(blk.get("ref_audio_t", 0))
                vt = int(blk.get("latent_t", 0))
                target_cursor += max(rt, sum(minimax_model._video_t_spans(vt)))

        if keyframes:
            for kf in keyframes:
                cond_t = target_cursor + minimax_model.FRAME_RESCALE * int(kf["resolved_frame_index"])
                video_latent = kf.get("latent")
                if video_latent is not None:
                    vt = int(video_latent.shape[2])
                    n = vt * frame_rows
                    segments.append(("cond", n))
                    pos.append(minimax_model._video_grid(vt, frame, cond_t))
                    img_pos.append(torch.arange(row, row + n))
                    img_update.append(torch.zeros(n, dtype=torch.bool))
                    row += n
                audio_latent = kf.get("audio_latent")
                if audio_latent is not None:
                    rt = int(audio_latent.shape[-1])
                    segments.append(("ref_audio", rt * 2))
                    pos.append(minimax_model._audio_grid(cond_t, rt, *target_audio_w))
                    audio_pos.append(torch.arange(row, row + rt * 2))
                    audio_update.append(torch.zeros(rt * 2, dtype=torch.bool))
                    row += rt * 2

        cursor = float(text_len)
        if refs:
            for blk in refs:
                kind = blk["kind"]
                if kind == "image":
                    r_frame, _ = minimax_model._frame_grid(blk["latent_h"], blk["latent_w"])
                    n = r_frame.shape[0]
                    g = torch.empty(n, 3, dtype=torch.float64)
                    g[:, 0] = cursor
                    g[:, 1:] = r_frame
                    segments.append(("ref_img", n))
                    pos.append(g)
                    img_pos.append(torch.arange(row, row + n))
                    img_update.append(torch.zeros(n, dtype=torch.bool))
                    row += n
                    cursor += 1.0
                elif kind == "audio":
                    rt = int(blk["ref_audio_t"])
                    if rt > 0:
                        segments.append(("ref_audio", rt * 2))
                        pos.append(minimax_model._audio_grid(cursor, rt, *target_audio_w))
                        audio_pos.append(torch.arange(row, row + rt * 2))
                        audio_update.append(torch.zeros(rt * 2, dtype=torch.bool))
                        row += rt * 2
                    cursor += float(rt)
                elif kind in ("video", "video_audio"):
                    rt = int(blk["ref_audio_t"])
                    vt = int(blk["latent_t"])
                    r_frame, r_w_grid = minimax_model._frame_grid(blk["latent_h"], blk["latent_w"])
                    if rt > 0:
                        segments.append(("ref_audio", rt * 2))
                        pos.append(minimax_model._audio_grid(cursor, rt, float(r_w_grid[0]), float(r_w_grid[-1])))
                        audio_pos.append(torch.arange(row, row + rt * 2))
                        audio_update.append(torch.zeros(rt * 2, dtype=torch.bool))
                        row += rt * 2
                    n = vt * r_frame.shape[0]
                    segments.append(("ref_img", n))
                    pos.append(minimax_model._video_grid(vt, r_frame, cursor))
                    img_pos.append(torch.arange(row, row + n))
                    img_update.append(torch.zeros(n, dtype=torch.bool))
                    row += n
                    cursor += max(float(rt), sum(minimax_model._video_t_spans(vt)))

        segments.append(("audio", audio_t * 2))
        pos.append(minimax_model._audio_grid(cursor, audio_t, *target_audio_w))
        audio_pos.append(torch.arange(row, row + audio_t * 2))
        audio_update.append(torch.ones(audio_t * 2, dtype=torch.bool))
        row += audio_t * 2

        n_video = latent_t * frame_rows
        segments.append(("video", n_video))
        pos.append(minimax_model._video_grid(latent_t, frame, cursor))
        img_pos.append(torch.arange(row, row + n_video))
        img_update.append(torch.ones(n_video, dtype=torch.bool))
        row += n_video

        self.seq_len = row
        self.position_ids = torch.cat(pos)
        self.img_pos = torch.cat(img_pos)
        self.img_update = torch.cat(img_update)
        self.audio_pos = torch.cat(audio_pos)
        self.audio_update = torch.cat(audio_update)
        self.signature = (text_len, latent_t, latent_h, latent_w, audio_t)
        seg_abs = []
        off = 0
        for kind, n in segments:
            seg_abs.append((off, off + n, kind))
            off += n
        self.segments = seg_abs


def _make_compat_extra_conds(base_model):
    original_extra = base_model.extra_conds

    def compat_extra(self_model, **kwargs):
        keyframes = kwargs.get("minimax_keyframes", None)
        if not keyframes:
            return original_extra(**kwargs)

        # Normalize every continuation/keyframe visual latent onto the same 2x2
        # patch grid as the target stream.  This is deliberately repeated here
        # even though H3ADv1Prepare already pads its own guide, so a stale
        # conditioning object or another keyframe source cannot reintroduce an
        # odd H/W latent at sampler time.
        safe_keyframes = []
        for kf in keyframes:
            item = dict(kf)
            if item.get("latent") is not None:
                item["latent"] = _pad_guide_video_latent(item["latent"])
            safe_keyframes.append(item)
        keyframes = safe_keyframes

        # Let the user's old H3 core build every normal/ref2va condition exactly as before,
        # but omit keyframes so its first/last-only PackedLayout cannot reject our clip guide.
        base_kwargs = dict(kwargs)
        base_kwargs["minimax_keyframes"] = None
        base_kwargs.pop("minimax_frame_count", None)
        out = original_extra(**base_kwargs)

        payload_cond = out.get("minimax_payload")
        if payload_cond is None:
            raise RuntimeError("当前 H3 核心没有生成 minimax_payload，无法启用上一段续接。")
        payload = dict(payload_cond.cond)
        refs = payload.get("refs")
        key_video = [kf["latent"] for kf in keyframes if kf.get("latent") is not None]
        key_audio = [kf["audio_latent"] for kf in keyframes if kf.get("audio_latent") is not None]
        payload["keyframes"] = keyframes
        payload["cond_video_latents"] = key_video + list(payload.get("cond_video_latents", []))
        payload["cond_audio_latents"] = key_audio + list(payload.get("cond_audio_latents", []))

        latent_shapes = kwargs.get("latent_shapes", None)
        cross = out.get("c_crossattn")
        if cross is not None and latent_shapes is not None and len(latent_shapes) > 1:
            vs = latent_shapes[0]
            payload["layout"] = H3ADv1PackedLayout(
                cross.cond.shape[1], vs[2], (vs[3] + 1) // 2 * 2, (vs[4] + 1) // 2 * 2,
                latent_shapes[1][-1], keyframes=keyframes, refs=refs,
            )
        out["minimax_payload"] = comfy.conds.CONDConstant(payload)
        return out

    return types.MethodType(compat_extra, base_model)


class H3ADv1ModelCompat(io.ComfyNode):
    """Clone and patch only this model branch for old-core dynamic H3 guides."""

    DESCRIPTION = (
        "仅当上一段续接开启时，对当前 MODEL 克隆分支补上新版 H3 Guide 所需的布局行为。"
        "不修改 ComfyUI 核心文件，也不修改其他工作流/其他 MODEL 分支。"
    )
    RETURN_TYPES = ("MODEL",)
    RETURN_NAMES = ("model",)
    FUNCTION = "EXECUTE_NORMALIZED"
    CATEGORY = "conditioning/video_models"

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3ADv1ModelCompat",
            display_name="H3 自动短剧 · 续接兼容层",
            category=cls.CATEGORY,
            description=cls.DESCRIPTION,
            inputs=[io.Model.Input("model"), io.Boolean.Input("enable_continue", default=False)],
            outputs=[io.Model.Output(display_name="model")],
        )

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"model": ("MODEL",), "enable_continue": ("BOOLEAN", {"default": False})}}

    @classmethod
    def execute(cls, model, enable_continue=False):
        if not bool(enable_continue):
            return io.NodeOutput(model)
        # Decide from the DiT/PackedLayout core itself, not from the presence of
        # MiniMaxH3AddGuide in the UI module.  A partially updated installation
        # can expose that node while still running the old 0.33.x model core.
        if _core_supports_multiframe_guides():
            return io.NodeOutput(model)
        patched = model.clone()
        base_model = getattr(patched, "model", None)
        if base_model is None or not hasattr(base_model, "extra_conds"):
            raise RuntimeError("当前 MODEL 不支持 H3 续接兼容补丁。")
        patched.add_object_patch("extra_conds", _make_compat_extra_conds(base_model))
        return io.NodeOutput(patched)


class H3ADv1RefitGuide(io.ComfyNode):
    """Re-encode continuation guide at the second-pass target spatial size."""

    FUNCTION = "EXECUTE_NORMALIZED"
    CATEGORY = "conditioning/video_models"

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3ADv1RefitGuide",
            display_name="H3 自动短剧 · 二采尺寸适配",
            category=cls.CATEGORY,
            description="二次超分开启时，把续接视频 Guide 按放大后的 latent 尺寸重新 VAE 编码。续接关闭时原样透传。",
            inputs=[
                io.Conditioning.Input("positive"), io.Latent.Input("latent"), io.Vae.Input("vae"),
                io.Image.Input("guide_frames"), io.Boolean.Input("enable_continue", default=False),
            ],
            outputs=[io.Conditioning.Output(display_name="positive")],
        )

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "positive": ("CONDITIONING",), "latent": ("LATENT",), "vae": ("VAE",),
            "guide_frames": ("IMAGE",), "enable_continue": ("BOOLEAN", {"default": False}),
        }}

    @classmethod
    def execute(cls, positive, latent, vae, guide_frames, enable_continue=False):
        if not bool(enable_continue):
            return io.NodeOutput(positive)
        keyframes = list(positive[0][1].get("minimax_keyframes", []))
        if not keyframes:
            return io.NodeOutput(positive)
        width, height = _latent_canvas(latent)
        changed = False
        new_keyframes = []
        for kf in keyframes:
            item = dict(kf)
            if item.get("h3_autodrama_v1"):
                count = int(item.get("guide_frame_count", guide_frames.shape[0]))
                frames = h3_nodes._resize(guide_frames[:count], width, height, "center")
                item["latent"] = _pad_guide_video_latent(vae.encode(frames))
                changed = True
            new_keyframes.append(item)
        if not changed:
            return io.NodeOutput(positive)
        return io.NodeOutput(node_helpers.conditioning_set_values(positive, {"minimax_keyframes": new_keyframes}))


class H3ADv1Trim(io.ComfyNode):
    """Trim the guide prefix; a zero frame limit preserves all remaining audio."""

    FUNCTION = "EXECUTE_NORMALIZED"
    CATEGORY = "video/postprocessing"

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3ADv1Trim",
            display_name="H3 自动短剧 · 裁掉重叠段",
            category=cls.CATEGORY,
            description="续接开启时裁掉开头重叠段；输出帧数为0时保留全部剩余画面和音轨，正数时限制保留时长；关闭时原样透传。",
            inputs=[
                io.Image.Input("images"), io.Audio.Input("audio"),
                io.Int.Input("trim_start_frames", default=0, min=0, max=100000),
                io.Int.Input("trim_output_frames", default=0, min=0, max=100000),
                io.Boolean.Input("enable_continue", default=False),
            ],
            outputs=[io.Image.Output(display_name="images"), io.Audio.Output(display_name="audio")],
        )

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",), "audio": ("AUDIO",),
            "trim_start_frames": ("INT", {"default": 0, "min": 0, "max": 100000}),
            "trim_output_frames": ("INT", {"default": 0, "min": 0, "max": 100000}),
            "enable_continue": ("BOOLEAN", {"default": False}),
        }}

    @classmethod
    def execute(cls, images, audio, trim_start_frames=0, trim_output_frames=0, enable_continue=False):
        if not bool(enable_continue):
            return io.NodeOutput(images, audio)
        start = max(0, int(trim_start_frames))
        count = max(0, int(trim_output_frames))
        end = min(images.shape[0], start + count) if count else images.shape[0]
        out_images = images[start:end]
        out_audio = audio
        if audio is not None and hasattr(audio, "get"):
            waveform = audio.get("waveform")
            sr = int(audio.get("sample_rate", 0))
            if waveform is not None and sr > 0:
                a0 = int(round(start / H3_FPS * sr))
                # count=0 means keep the entire remainder, including audio
                # beyond the final video frame. The adopter can freeze that
                # frame; trimming samples here would destroy the words first.
                a1 = int(round(end / H3_FPS * sr)) if count else waveform.shape[-1]
                result = dict(audio)
                result["waveform"] = waveform[..., a0:min(a1, waveform.shape[-1])]
                out_audio = result
        return io.NodeOutput(out_images, out_audio)


class H3ADv1RefineMemoryController(io.ComfyNode):
    """Standalone copy of the mature second-pass FFN chunk controller."""

    RETURN_TYPES = ("MODEL",)
    RETURN_NAMES = ("model",)
    FUNCTION = "EXECUTE_NORMALIZED"
    CATEGORY = "conditioning/video_models"

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3ADv1RefineMemoryController",
            display_name="H3 自动短剧独立版 · 二采显存控制",
            category=cls.CATEGORY,
            description="二次 Refine MLP 分块。开=省显存；关=高显存高速。只影响二采模型分支。",
            inputs=[
                io.Model.Input("model"), io.Boolean.Input("save_vram", default=True),
                io.Int.Input("chunks", default=8, min=1, max=64, step=1),
                io.Int.Input("seq_threshold", default=4096, min=256, max=262144, step=256),
            ],
            outputs=[io.Model.Output(display_name="model")],
        )

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "model": ("MODEL",), "save_vram": ("BOOLEAN", {"default": True}),
            "chunks": ("INT", {"default": 8, "min": 1, "max": 64, "step": 1}),
            "seq_threshold": ("INT", {"default": 4096, "min": 256, "max": 262144, "step": 256}),
        }}

    @staticmethod
    def _make_chunked_forward(chunks: int, seq_threshold: int):
        def chunked_forward(self_module, x):
            if x.shape[0] > seq_threshold and chunks > 1:
                out = x.new_empty(x.shape)
                offset = 0
                for part in x.chunk(chunks, dim=0):
                    value = comfy.ops.linear_input_act(self_module.fc2, self_module.fc1(part), "swiglu")
                    out[offset:offset + part.shape[0]] = value
                    offset += part.shape[0]
                return out
            return comfy.ops.linear_input_act(self_module.fc2, self_module.fc1(x), "swiglu")
        return chunked_forward

    @classmethod
    def execute(cls, model, save_vram=True, chunks=8, seq_threshold=4096):
        chunks = max(1, int(chunks)); seq_threshold = max(1, int(seq_threshold))
        if not bool(save_vram) or chunks == 1:
            return io.NodeOutput(model)
        patched = model.clone()
        diffusion_model = patched.get_model_object("diffusion_model")
        blocks = getattr(diffusion_model, "blocks", None)
        if not blocks:
            logging.warning("H3ADv1RefineMemoryController: diffusion_model.blocks not found")
            return io.NodeOutput(model)
        forward_impl = cls._make_chunked_forward(chunks, seq_threshold)
        for index, block in enumerate(blocks):
            mlp = getattr(block, "mlp", None)
            if mlp is None or not hasattr(mlp, "fc1") or not hasattr(mlp, "fc2"):
                logging.warning("H3ADv1RefineMemoryController: incompatible block %s", index)
                return io.NodeOutput(model)
            patched.add_object_patch(
                f"diffusion_model.blocks.{index}.mlp.forward",
                types.MethodType(forward_impl, mlp),
            )
        return io.NodeOutput(patched)


class H3ADv1ImageReferenceBatch(io.ComfyNode):
    """Optional image-workflow adapter; existing video nodes are untouched."""
    RETURN_TYPES=("IMAGE",)
    RETURN_NAMES=("images",)
    FUNCTION="EXECUTE_NORMALIZED"
    CATEGORY="H3自动短剧/生图"

    @classmethod
    def define_schema(cls):
        return io.Schema(node_id="H3ADv1ImageReferenceBatch",display_name="H3 自动短剧独立版 · 生图参考批量加载",
            category=cls.CATEGORY,
            description="将JSON图片路径列表加载成IMAGE批次；请连接到能使用多图参考的生图节点。宽高只控制参考批次的统一尺寸，不改变生成模型参数。",
            inputs=[io.String.Input("images_json",default='["参考图.png"]',multiline=True),
                    io.Int.Input("width",default=512,min=64,max=4096,step=8),io.Int.Input("height",default=512,min=64,max=4096,step=8)],
            outputs=[io.Image.Output(display_name="images")])

    @classmethod
    def INPUT_TYPES(cls):
        return {"required":{"images_json":("STRING",{"default":"[]","multiline":True}),
            "width":("INT",{"default":512,"min":64,"max":4096,"step":8}),
            "height":("INT",{"default":512,"min":64,"max":4096,"step":8})}}

    @classmethod
    def IS_CHANGED(cls,images_json,width=512,height=512):
        names=cls.names(images_json);hasher=hashlib.sha256()
        hasher.update((images_json+str(width)+str(height)).encode())
        for name in names:_file_signature(hasher,name)
        return hasher.hexdigest()

    @staticmethod
    def names(value):
        try:names=json.loads(value)
        except (ValueError,TypeError) as e:raise ValueError("参考图片路径列表不是有效JSON。") from e
        if not isinstance(names,list) or not 1<=len(names)<=8 or any(not isinstance(x,str) or not x.strip() for x in names):
            raise ValueError("生图参考列表必须含1至8个图片路径。")
        return names

    @classmethod
    def execute(cls,images_json,width=512,height=512):
        width=int(width);height=int(height)
        if not 64<=width<=4096 or not 64<=height<=4096:raise ValueError("参考批次尺寸超出范围。")
        images=[]
        for name in cls.names(images_json):
            image=_load_image(name)[:1]
            image=comfy.utils.common_upscale(image.movedim(-1,1),width,height,"lanczos","disabled").movedim(1,-1)
            images.append(image)
        return io.NodeOutput(torch.cat(images,dim=0))


class H3ADv1StandaloneExtension(ComfyExtension):
    async def get_node_list(self):
        return [
            H3ADv1BatchReferenceToVideo,
            H3ADv1Prepare,
            H3ADv1ModelCompat,
            H3ADv1RefitGuide,
            H3ADv1Trim,
            H3ADv1RefineMemoryController,
            H3ADv1ImageReferenceBatch,
        ]


def comfy_entrypoint():
    return H3ADv1StandaloneExtension()
