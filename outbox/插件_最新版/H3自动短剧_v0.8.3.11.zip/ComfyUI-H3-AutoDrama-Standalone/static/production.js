"use strict";
let bindingOwner=null;
const timingNames={episode_active:"本集运行",series_active:"整剧运行",planning_api:"分镜／规划API",prompt_api:"H3提示词API",image_generation:"图片生成",image_review:"图片审核API",video_generation:"视频生成与取回",video_review:"视频审核（含抽帧）",video_review_api:"其中：视频审核API",image_gpu_wait:"图片等待GPU",video_gpu_wait:"视频等待GPU",state_frame:"提取前段状态",merge:"合并成片"};
function elapsedText(seconds){const n=Math.round(Number(seconds)||0);return `${Math.floor(n/60)}分${n%60}秒`}
function renderProduction(record,prefix){
 const target=$("#"+prefix+"-timings"),bindings=record.character_bindings||{};
 $("#"+prefix+"-binding-summary").textContent=Object.entries(bindings).map(([name,b])=>`${name}：${b.image_ids.length}张固定图${b.voice_id?"＋固定音色":""}`).join("；")||"尚未指定固定角色；新建时可勾选自己上传的素材。";
 $("#"+prefix+"-bindings").disabled=!!record.archived||["running","queued","pausing"].includes(record.status);
 const entries=Object.entries(record.timings||{});
 target.innerHTML=entries.length?`<details><summary>耗时明细</summary><p class="muted">各阶段可能并行、相互包含，耗时不可直接相加；包含重试，暂停期间不计入运行时间。下一集提前准备记在下一集。</p><table><thead><tr><th>阶段</th><th>累计耗时</th><th>次数</th></tr></thead><tbody>${entries.map(([k,v])=>`<tr><td>${esc(timingNames[k]||k)}</td><td>${elapsedText(v.seconds)}</td><td>${v.calls}</td></tr>`).join("")}</tbody></table></details>`:"";
 target.innerHTML+=`<p><a class="link" href="${BASE}api/${prefix==="series"?"series":"projects"}/${encodeURIComponent(record.id)}/diagnostics" download>下载接口诊断记录</a></p>`;
}
timingNames.dialogue_asr="实际对白语音识别";
timingNames.dialogue_asr_before_crop="裁剪前对白诊断";
function renderDialogueCheck(clip,index,locked){
 if(!clip.dialogue?.length)return "";
 const a=clip.retention_audit;
 const retention=a?`<p class="muted">对白尾部：生成 ${Number(a.raw_seconds).toFixed(3)} 秒 · 实际保留 ${Number(a.retained_seconds).toFixed(3)} 秒 · 软件尾裁 ${Number(a.application_removed_tail_seconds).toFixed(3)} 秒${a.policy==="fixed"?"（遵守固定时长）":"（保留生成尾部）"}</p>`:"";
 const report=clip.dialogue_check;
 if(!report)return retention+`<p class="muted">实际对白未核对${clip.output?"（已有视频）":"（等待生成）"}</p>`;
 const labels={passed:"实际对白识别一致",manual_confirmed:"对白已由你试听确认",incomplete:"对白识别疑似缺尾",needs_review:"对白识别存在差异",pending:"对白正在核对",unavailable:"对白核对接口失败，视频已保留"};
 const adopted=!report.passed&&clip.quality_accepted&&clip.adopted_ng&&clip.dialogue_adoption?.status==="adopted_ng"&&clip.dialogue_adoption.signature===report.signature;
 const adoption=adopted?`<p class="badge">视频/对白共用次数已耗尽（${esc(clip.dialogue_adoption.attempt)}/${esc(clip.dialogue_adoption.limit)}），已采用最后结果继续。对白核对仍未通过。</p>`:"";
 const actions=!report.passed&&!locked?`<div class="row"><button data-dialogue-index="${index}" data-dialogue-action="recheck">重新核对</button><button data-dialogue-index="${index}" data-dialogue-action="confirm">我已试听，确认完整</button></div>`:"";
 return retention+`<details class="panel"><summary>${esc(adopted?"对白未通过，次数耗尽已采用":labels[report.status]||"对白核对结果")}</summary>${adoption}<p>${esc(report.reason)}</p><p><b>剧本原句：</b>${esc(report.expected)}</p><p><b>识别结果：</b>${esc(report.transcript||"未识别到文字")}</p>${report.before_crop?`<p><b>裁剪前识别：</b>${esc(report.before_crop.transcript||"未识别到文字")}</p>`:""}${actions}</details>`;
}
function bindDialogueActions(){
 $$("[data-dialogue-action]").forEach(button=>button.onclick=guarded(async()=>{
  const index=Number(button.dataset.dialogueIndex),action=button.dataset.dialogueAction,id=current.id;
  const report=current.clips[index].dialogue_check;
  if(action==="confirm"&&!confirm("请先完整试听该段视频，确认每句台词均已说完且没有错词。确认后程序将按你的判断采用对白。"))return;
  await api("projects/"+id+"/dialogue",{index,action,signature:report.signature});
  await openProject(id);notice(action==="confirm"?"试听确认已保存，点击继续制作。":"已清除本次识别结果，点击继续重新核对，不重新渲染视频。");
 }));
}
function addBindingRow(name="",bound={image_ids:[],voice_id:""}){
 const row=document.createElement("div");row.className="panel binding-row";
 const options=kind=>assets.filter(a=>!a.archived&&a.kind===kind).map(a=>`<option value="${esc(a.id)}" ${(kind==="image"?bound.image_ids.includes(a.id):bound.voice_id===a.id)?"selected":""}>${esc(a.label)} · ${esc(a.name)}</option>`).join("");
 row.innerHTML=`<label>剧本角色姓名<input class="binding-name" value="${esc(name)}" required maxlength="100" placeholder="例如：周宁"></label><label>固定人物图片（可按Ctrl多选，最多4张）<select class="binding-images" multiple size="4">${options("image")}</select></label><label>固定声音参考<select class="binding-voice"><option value="">暂不绑定声音</option>${options("audio")}</select></label><button type="button" class="binding-remove">删除这条绑定</button>`;
 row.querySelector(".binding-remove").onclick=()=>row.remove();$("#binding-rows").append(row);
}
async function openBindings(kind,record){
 if(kind==="project"&&record.series_id){notice("本集属于整剧，打开整剧的固定角色设置");await openSeries(record.series_id);return openBindings("series",currentSeries)}
 await loadAssets();bindingOwner={kind,id:record.id,revision:record.bindings_revision||1};$("#binding-rows").innerHTML="";
 for(const [name,b]of Object.entries(record.character_bindings||{}))addBindingRow(name,b);
 if(!Object.keys(record.character_bindings||{}).length)addBindingRow();$("#bindings-dialog").showModal();
}
function initProduction(){
 $("#series-bindings").onclick=guarded(()=>openBindings("series",currentSeries));$("#project-bindings").onclick=guarded(()=>openBindings("project",current));
 $("#binding-add").onclick=()=>addBindingRow();
 $("#bindings-form").onsubmit=guarded(async e=>{
  e.preventDefault();const bound={};for(const row of $$(".binding-row")){
   const name=row.querySelector(".binding-name").value.trim();if(Object.hasOwn(bound,name))throw Error("角色姓名重复");
   bound[name]={image_ids:[...row.querySelector(".binding-images").selectedOptions].map(o=>o.value),voice_id:row.querySelector(".binding-voice").value};
  }
  const owner=bindingOwner,route=(owner.kind==="series"?"series":"projects")+"/"+owner.id;
  const result=await api(route+"/bindings",{character_bindings:bound,expected_revision:owner.revision});$("#bindings-dialog").close();
  if(owner.kind==="series")await openSeries(owner.id);else await openProject(owner.id);
  notice(`角色绑定已保存；${result.retained_episodes}个已准备或完成的集保持原样。`);
 });
}
