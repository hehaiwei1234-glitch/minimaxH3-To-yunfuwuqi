"use strict";
let seriesItems=[],currentSeries=null,creatingSeries=false;
async function loadSeries(){
 seriesItems=await api("series"+managementQuery("series"));globalThis.h3FinishAlert?.observe("series",seriesItems);$("#series-list").innerHTML=seriesItems.map(s=>`<div class="record-item"><button class="project-item ${currentSeries?.id===s.id?"active":""}" data-series="${esc(s.id)}">${esc(s.title)}<small>${s.archived?"已归档 · ":""}${statuses[s.status]||esc(s.status)} · ${s.project_ids.length||"待分"}集 · ${esc(new Date(s.created_at*1000).toLocaleString())}</small></button>${managementButtons("series",s.id,s.archived)}</div>`).join("");
 $$("[data-series]").forEach(b=>b.onclick=guarded(()=>openSeries(b.dataset.series)));bindManagement();
}
async function openSeries(id){currentSeries=await api("series/"+id);tab("series");$("#series-form").classList.add("hidden");$("#series-detail").classList.remove("hidden");renderSeries();await renderImageJobs(id,$("#series-image-jobs"));await loadSeries()}
function renderSeries(){
 if(typeof renderProduction==="function")renderProduction(currentSeries,"series");
 const s=currentSeries,active=!!s.archived||!!s.active||["running","queued","pausing"].includes(s.status),count=s.episodes.filter(e=>e.status==="complete").length,deferred=s.episodes.filter(e=>e.status==="deferred").length;
 $("#series-title").textContent=s.title;$("#series-phase").textContent=s.phase;$("#series-summary").textContent=`已完成${count} / ${s.episodes.length||"待分集"}集${deferred?` · ${deferred}集待补做`:""} · ${statuses[s.status]||s.status}`;
 $("#series-error").textContent=s.error?"任务记录："+s.error:"";$("#series-error").classList.toggle("hidden",!s.error);$("#resume-series").disabled=active||s.status==="complete"||(s.status==="partial"&&!s.can_resume);$("#pause-series").disabled=!active||s.status==="pausing";
 $("#append-series").disabled=active||!s.can_append;{const hint=$("#append-hint"),why=s.can_append?"":(s.append_block_reason||"");hint.textContent=why?"暂时不能追加后续剧本："+why:"";hint.classList.toggle("hidden",!why)}$("#series-batches").textContent=`已保存${s.batches.length}批文本 · 共用素材${s.shared_asset_count}个 · 下一批从第${s.next_episode_number}集开始`;$("#series-memory").textContent=s.continuity_summary||"追加后续剧本时，程序会记录此前各集的既定剧情，待补做集也保留原剧情。";
 $("#export-series").href=BASE+"api/series/"+s.id+"/export";
 $("#series-episodes").innerHTML=s.episodes.length?s.episodes.map(e=>`<div class="panel"><div class="row spread"><b>${esc(e.title)}</b><span>${statuses[e.status]||esc(e.status)}</span></div><p class="muted">${esc(e.phase)}${e.final?.duration?` · ${e.final.partial?"已有素材合辑":"成片"}${Number(e.final.duration).toFixed(2)}秒`:e.planned_duration_seconds?` · 预计${Number(e.planned_duration_seconds).toFixed(2)}秒`:""}</p>${e.status==="deferred"?`<p class="muted">待补做原因：${esc(e.error)}</p>`:""}<div class="row">${e.status!=="deleted"?`<button data-episode="${esc(e.id)}">打开本集 / 查看镜头</button>${e.status==="deferred"?`<button data-retry-episode="${esc(e.id)}" ${active||e.archived?"disabled":""}>补做本集</button>`:""}${e.editable?`<button data-script-edit="${esc(e.id)}">修改剧本</button>`:""}${managementButtons("project",e.id,e.archived)}`:""}${e.final?`<a class="link" href="${BASE}api/projects/${e.id}/final" download="${esc(e.title)}.mp4">${e.final.partial?"下载已有素材合辑":"下载成片"}</a>`:""}</div></div>`).join(""):"正在自动准备各集，完成后会出现在这里。";
 $$("[data-episode]").forEach(b=>b.onclick=guarded(()=>openProject(b.dataset.episode)));$$("[data-script-edit]").forEach(b=>b.onclick=guarded(()=>openScriptEditor(b.dataset.scriptEdit)));bindManagement();
 $$("[data-retry-episode]").forEach(b=>b.onclick=guarded(async()=>{if(b.disabled)return;b.disabled=true;try{await api("series/"+s.id+"/episodes/"+b.dataset.retryEpisode+"/retry",{});await openSeries(s.id);notice("本集已加入补做队列，后续已有成片保留")}finally{b.disabled=!!currentSeries.active}}));
 $("#series-events").innerHTML=[...s.events].reverse().map(e=>`<div>${new Date(e.time*1000).toLocaleTimeString()} ${esc(e.message)}</div>`).join("");
}
// 只绑定按钮，不发任何请求；加载整剧列表在 initSeries 里，失败也不影响按钮。
function bindSeries(){
 $("#series-text-file").onchange=guarded(async e=>{const file=e.target.files[0];if(file){if(file.size>3*1024*1024)throw Error("TXT超过3MB，请缩短文本。");const value=await file.text();if(value.includes("\ufffd"))throw Error("TXT编码无法读取，请另存为UTF-8再导入。");$("#series-form").elements.text.value=value;notice("整篇文本已导入")}});
 $("#new-series").onclick=guarded(async()=>{if(creatingSeries)return;currentSeries=null;$("#series-form").classList.remove("hidden");$("#series-detail").classList.add("hidden");await Promise.all([loadSeries(),loadAssets(),loadWorkflows()])});
 $("#series-form").onsubmit=guarded(async e=>{
   e.preventDefault();if(creatingSeries)return;
   const form=e.target,body=Object.fromEntries(new FormData(form));body.asset_ids=$$("#series-asset-choices input:checked").map(x=>x.value);
   body.timing_policy=timingFromForm(form);
   if(!body.workflow_id)throw Error("请先选择各集使用的视频工作流。");
   creatingSeries=true;const controls=[...form.elements,$("#new-series")].map(el=>[el,el.disabled]);controls.forEach(([el])=>el.disabled=true);
   try{const s=await api("series",body);resetAssetPicker("#series-asset-choices");await openSeries(s.id);await api("series/"+s.id+"/start",{});await openSeries(s.id);notice("已开始整剧自动制作，程序会自动创建并顺序完成各集")}
   finally{creatingSeries=false;controls.forEach(([el,disabled])=>el.disabled=disabled)}
 });
 $("#resume-series").onclick=guarded(async()=>{await api("series/"+currentSeries.id+"/start",{});await openSeries(currentSeries.id);notice("整剧已继续，已有素材和成片会复用")});
 $("#pause-series").onclick=guarded(async()=>{await api("series/"+currentSeries.id+"/pause",{});await openSeries(currentSeries.id);notice("当前任务完成后暂停，不会终止ComfyUI任务")});
}
async function initSeries(){bindSeries();await loadSeries()}
