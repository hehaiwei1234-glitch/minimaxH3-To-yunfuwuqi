"use strict";
function timingFields(){
 for(const area of document.querySelectorAll('[data-timing-fields]')){
   const batch=area.dataset.timingFields==='batch';
   area.innerHTML='<fieldset><legend>时长：默认全部由 AI 按剧情决定</legend><p class="muted">什么都不勾选即可。只在你确实需要限定时勾选并填写；勾选的值优先。镜头长短和转场仍由 AI 安排，长镜头自动拆成续接任务。</p><div class="grid3">'+[
     ['episode','指定每集时长',.25,86400],['total',batch?'指定本批剧本总时长':'指定总剧本时长',.25,8640000],['task','指定每次 ComfyUI 任务时长',2,15]
   ].map(([key,label,min,max])=>`<div><label class="check"><input type="checkbox" name="${key}_time_enabled">${label}</label><label>秒数<input name="${key}_time_seconds" type="number" min="${min}" max="${max}" step="any" placeholder="AI 决定" disabled></label></div>`).join('')+'</div><p class="muted">勾选任务时长可控制单次负荷（H3 请求范围 2–15 秒）。多生成的尾部按剧情裁去，续接会使用保留后的片段。'+(batch?'本批总时长只约束这次追加的文本。':'')+'</p></fieldset>';
   const form=area.closest('form');
   for(const key of ['episode','total','task']){
     const toggle=form.elements.namedItem(key+'_time_enabled'),value=form.elements.namedItem(key+'_time_seconds');
     toggle.onchange=()=>{value.disabled=!toggle.checked;value.required=toggle.checked;if(toggle.checked)value.focus()};
   }
 }
}
function timingFromForm(form){
 const result={version:1};
 for(const key of ['episode','total','task']){
   const enabled=!!form.elements.namedItem(key+'_time_enabled')?.checked;
   const raw=form.elements.namedItem(key+'_time_seconds')?.value;
   if(enabled&&(!raw||!Number.isFinite(Number(raw))||Number(raw)<=0))throw Error('勾选时长后，请填写有效秒数。');
   result[key]={enabled,seconds:enabled?Number(raw):null};
 }
 return result;
}
function restoreTiming(form,policy={}){
 for(const key of ['episode','total','task']){
   const toggle=form.elements.namedItem(key+'_time_enabled'),value=form.elements.namedItem(key+'_time_seconds'),item=policy?.[key]||{};
   toggle.checked=!!item.enabled;value.value=item.enabled?item.seconds:'';value.disabled=!toggle.checked;value.required=toggle.checked;
 }
}
