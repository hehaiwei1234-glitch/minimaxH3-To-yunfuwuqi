"use strict";
// 素材勾选器：一键全选／全部取消／沿用最近一部剧（或最近一集）的全部素材。
// 所有素材始终保留在页面里（只是用 hidden 隐藏），所以原有的
// $$("#series-asset-choices input:checked") 读取方式不变，被隐藏但已勾选的素材也会提交。
const assetPickerConfigs={
 "#series-asset-choices":{kind:"series",empty:"没有素材可直接开始，程序会建立共用人物和场景。",recentLabel:"沿用最近一部剧的全部素材",recentNoun:"剧"},
 "#append-asset-choices":{kind:"series",current:true,empty:"素材库里还没有素材。",recentLabel:"选中本剧已用的全部素材",recentNoun:"剧"},
 "#asset-choices":{kind:"project",empty:"还没有素材，可直接开始，让AI自动建立。",recentLabel:"沿用最近一集的全部素材",recentNoun:"集"},
};
const assetPickerState={};
let assetPickerAssets=[];
// 软件自动产生、给单个镜头当参考用的图片：前段状态图、每个镜头的开场图。通常不需要手动勾选。
function isHelperAsset(a){return !!a.generated&&(a.name==="前段状态.png"||a.label==="前段最终采用状态"||/^片段_\d+_开场图/.test(a.name||""))}
function assetStamp(a){
 if(!a.created_at)return"";const d=new Date(a.created_at*1000),two=n=>String(n).padStart(2,"0");
 return `${d.getMonth()+1}/${d.getDate()} ${two(d.getHours())}:${two(d.getMinutes())}`;
}
function assetPickerRecordIds(record){
 const ids=new Set([...(record.asset_ids||[]),...Object.values(record.generated_assets||{})]);
 for(const b of Object.values(record.character_bindings||{})){for(const id of b.image_ids||[])ids.add(id);if(b.voice_id)ids.add(b.voice_id)}
 return ids;
}
// 固定角色与声音里改过绑定后，旧的声音／人物图仍留在该剧的素材列表里（只增不减）。沿用时如果两份都选，后端会拒绝
// （每名角色只能 1 份声音、最多 4 张人物图），所以只保留“现在绑定着”的那份。
function assetPickerBound(record){
 const images=new Set(),voices=new Set(),names=new Set(),withImages=new Set();
 for(const [name,b] of Object.entries(record.character_bindings||{})){names.add(name);if((b.image_ids||[]).length)withImages.add(name);for(const id of b.image_ids||[])images.add(id);if(b.voice_id)voices.add(b.voice_id)}
 return {images,voices,names,withImages};
}
function assetPickerSuperseded(a,bound){
 if(!bound.names.size)return false;
 const name=(a.speaker||a.label||"").trim();
 if(a.role==="voice"&&a.kind==="audio")return bound.names.has(name)&&!bound.voices.has(a.id);
 // 该角色绑定了人物图时，丢掉没绑定的旧图；只固定了声音的角色，保留自动生成的人物图、丢掉早先取消绑定的上传图。
 if(a.role==="character"&&a.kind==="image")return bound.names.has(name)&&!bound.images.has(a.id)&&(bound.withImages.has(name)||!a.generated);
 return false;
}
// 提交前就提醒后端一定会拒绝的组合：同一角色最多 4 张人物图、只能有 1 份声音。
function assetPickerConflicts(st){
 const by={};
 for(const a of assetPickerAssets){
   if(!st.selected.has(a.id)||(a.role!=="character"&&a.role!=="voice"))continue;
   const name=(a.speaker||a.label||"").trim();if(!name)continue;
   const item=by[name]||(by[name]={images:0,voices:0});
   if(a.role==="character"&&a.kind==="image")item.images++;else if(a.role==="voice"&&a.kind==="audio")item.voices++;
 }
 const out=[];
 for(const [name,item] of Object.entries(by)){
   if(item.images>4)out.push(`${name}：已选 ${item.images} 张人物图，最多 4 张`);
   if(item.voices>1)out.push(`${name}：已选 ${item.voices} 份声音，只能留 1 份`);
 }
 return out;
}
async function fetchRecentAssetSource(kind,cfg={}){
 const route=kind==="series"?"series":"projects";
 let latest;
 if(cfg.current){ // 追加窗口：来源就是正在追加的这部剧
  const id=(typeof appendContext!=="undefined"&&appendContext?.id)||(typeof currentSeries!=="undefined"&&currentSeries?.id);
  if(!id)return null;latest={id};
 }else{
  const list=(await api(route)).filter(r=>!r.archived);
  if(!list.length)return null;
  latest=list.reduce((a,b)=>(b.created_at||0)>(a.created_at||0)?b:a);
 }
 const record=await api(route+"/"+encodeURIComponent(latest.id));
 return {id:latest.id,title:record.title||latest.title||"未命名",ids:assetPickerRecordIds(record),bound:assetPickerBound(record)};
}
function ensureAssetPicker(selector){
 const cfg=assetPickerConfigs[selector],box=$(selector);
 if(!cfg||!box)return null;
 let st=assetPickerState[selector];
 if(st&&st.box===box)return st;
 st={cfg,box,selected:new Set(),scope:"all",reuse:false,before:null,recent:null,showHelpers:false,busy:false,epoch:0,calls:0};
 const tools=document.createElement("div");tools.className="asset-tools";
 tools.innerHTML=`<div class="row"><button type="button" data-asset-act="all">全选当前显示的素材</button><button type="button" data-asset-act="none">全部取消</button><label class="check"><input type="checkbox" data-asset-act="recent">${cfg.recentLabel}</label><button type="button" data-asset-act="scope" class="hidden"></button><label class="check"><input type="checkbox" data-asset-act="helpers">显示自动生成的参考图<small data-asset-helper-count></small></label></div><p class="muted" data-asset-status aria-live="polite"></p>`;
 box.before(tools);st.tools=tools;assetPickerState[selector]=st;
 tools.addEventListener("click",event=>{const button=event.target.closest?.("button[data-asset-act]");if(button)guarded(()=>assetPickerAction(selector,button.dataset.assetAct))()});
 tools.addEventListener("change",event=>{const input=event.target;if(input?.dataset?.assetAct==="recent")guarded(()=>assetPickerReuse(selector,input.checked))();else if(input?.dataset?.assetAct==="helpers"){st.showHelpers=input.checked;renderAssetPicker(selector)}});
 box.closest("form")?.elements?.input_type?.addEventListener("change",()=>refreshAssetPickerStatus(selector));
 box.addEventListener("change",event=>{const input=event.target;if(input?.type!=="checkbox")return;if(input.checked)st.selected.add(input.value);else st.selected.delete(input.value);refreshAssetPickerStatus(selector)});
 return st;
}
function assetPickerVisible(st,a){
 if(isHelperAsset(a)&&!st.showHelpers&&!st.selected.has(a.id))return false;
 if(st.scope==="recent"&&!st.recent?.ids.has(a.id))return false;
 return true;
}
function renderAssetPicker(selector){
 const st=ensureAssetPicker(selector);if(!st)return;
 const list=assetPickerAssets,known=new Set(list.map(a=>a.id));
 for(const id of [...st.selected])if(!known.has(id))st.selected.delete(id);
 if(st.recent)st.recent.ids=new Set([...st.recent.ids].filter(id=>known.has(id)));
 if(!list.length){st.box.innerHTML=`<span class="muted">${st.cfg.empty}</span>`;st.tools.classList.add("hidden");return}
 st.tools.classList.remove("hidden");
 st.box.innerHTML=list.map(a=>{
   const recent=st.recent?.ids.has(a.id),visible=assetPickerVisible(st,a),tags=[a.kind];
   if(a.generated)tags.push("自动生成");if(a.created_at)tags.push(assetStamp(a));
   return `<label class="check${recent?" recent-asset":""}${visible?"":" hidden"}" data-asset-id="${esc(a.id)}" title="${esc(a.name||"")}"><input type="checkbox" value="${esc(a.id)}" ${st.selected.has(a.id)?"checked":""}>${recent&&st.reuse?"★ ":""}${esc(a.label)} <small>${esc(tags.join(" · "))}</small></label>`;
 }).join("");
 refreshAssetPickerStatus(selector);
}
function refreshAssetPickerStatus(selector){
 const st=assetPickerState[selector];if(!st)return;
 const list=assetPickerAssets,visible=list.filter(a=>assetPickerVisible(st,a)),hiddenHelpers=list.filter(a=>isHelperAsset(a)&&!assetPickerVisible(st,a)&&st.scope!=="recent").length;
 const outside=[...st.selected].filter(id=>!visible.some(a=>a.id===id)).length;
 const recentBox=st.tools.querySelector('[data-asset-act="recent"]'),scopeButton=st.tools.querySelector('[data-asset-act="scope"]'),helperBox=st.tools.querySelector('[data-asset-act="helpers"]');
 recentBox.checked=st.reuse||st.busy;recentBox.disabled=st.busy;helperBox.checked=st.showHelpers;helperBox.disabled=st.scope==="recent";
 st.tools.querySelector("[data-asset-helper-count]").textContent=list.some(isHelperAsset)?`（${list.filter(isHelperAsset).length}个，通常不用选）`:"";
 scopeButton.classList.toggle("hidden",!st.reuse);scopeButton.textContent=st.scope==="recent"?"显示全部素材（另选其他）":"只显示这部分素材";
 const parts=[`已选 ${st.selected.size} 个素材，当前显示 ${visible.length} 个。`];
 if(st.reuse&&st.recent){
   parts.push(`已沿用《${st.recent.title}》的 ${st.recent.ids.size} 个素材${st.recent.missing?`（另有 ${st.recent.missing} 个已删除或归档，未计入）`:""}；`+(st.scope==="recent"?"只显示这些，取消勾选即可排除；要另选其他素材，点“显示全部素材”。":"正在显示全部素材，带★的是这部分用过的。"));
 }
 if(outside)parts.push(`另有 ${outside} 个已选素材不在当前显示范围内（切到“显示全部素材”可查看）。`);
 if(hiddenHelpers)parts.push(`已隐藏 ${hiddenHelpers} 个自动生成的参考图。`);
 // 制作稿模式下后端不按角色分组检查（勾选只用来区分同名素材），所以不提醒。
 const conflicts=st.box.closest("form")?.elements?.input_type?.value==="production_draft"?[]:assetPickerConflicts(st);if(conflicts.length)parts.push("这样选会被拒绝，请取消多余的勾选："+conflicts.join("；")+"。");
 st.tools.querySelector("[data-asset-status]").textContent=parts.join(" ");
}
async function assetPickerReuse(selector,on){
 const st=ensureAssetPicker(selector);if(!st||st.busy)return;
 if(!on){
   // 取消沿用：恢复勾选前的选择，回到显示全部。
   st.epoch++;st.selected=st.before||new Set();st.before=null;st.reuse=false;st.recent=null;st.scope="all";renderAssetPicker(selector);return;
 }
 st.busy=true;const epoch=st.epoch,call=++st.calls;refreshAssetPickerStatus(selector);
 try{
   const source=await fetchRecentAssetSource(st.cfg.kind,st.cfg);
   if(st.epoch!==epoch)return; // 等待期间用户已点了“全部取消”或开始了新表单，丢弃这次结果
   if(!source)throw Error(`还没有可以沿用的${st.cfg.kind==="series"?"整剧":"单集"}。`);
   const known=new Map(assetPickerAssets.map(a=>[a.id,a])),ids=[...source.ids].filter(id=>known.has(id)&&!isHelperAsset(known.get(id))&&!assetPickerSuperseded(known.get(id),source.bound));
   if(!ids.length)throw Error(`最近的《${source.title}》没有可沿用的素材，或素材已被删除、归档。`);
   st.before=new Set(st.selected);st.selected=new Set(ids);
   st.recent={id:source.id,title:source.title,ids:new Set(ids),missing:[...source.ids].filter(id=>!known.has(id)).length};
   st.reuse=true;st.scope="recent";
 }catch(error){if(st.epoch===epoch){st.reuse=false;st.recent=null;st.scope="all"}throw error}
 finally{if(st.calls===call)st.busy=false;renderAssetPicker(selector)}
}
function assetPickerAction(selector,action){
 const st=ensureAssetPicker(selector);if(!st)return;
 if(action==="all"){for(const a of assetPickerAssets)if(assetPickerVisible(st,a))st.selected.add(a.id)}
 else if(action==="none"){st.epoch++;st.selected.clear();st.reuse=false;st.recent=null;st.before=null;st.scope="all"}
 else if(action==="scope"&&st.reuse)st.scope=st.scope==="recent"?"all":"recent";
 renderAssetPicker(selector);
}
// 创建成功后清空勾选，避免上一部剧的人物绑定悄悄带进下一部（中途离开或创建失败时保留，方便继续填写）。
function resetAssetPicker(selector){
 const st=assetPickerState[selector];if(!st)return;
 st.epoch++;st.calls++;st.selected=new Set();st.before=null;st.recent=null;st.reuse=false;st.scope="all";st.busy=false;
 renderAssetPicker(selector);
}
function renderAssetChoices(available){
 assetPickerAssets=available;
 for(const selector of Object.keys(assetPickerConfigs))renderAssetPicker(selector);
}
