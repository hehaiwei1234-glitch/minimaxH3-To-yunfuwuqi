"""ASR transports; only actual audio is sent, never expected dialogue.

Qwen contract: https://help.aliyun.com/zh/model-studio/qwen-asr-api-reference
"""
import base64
import re
from urllib.parse import urlsplit
import aiohttp
from .providers import APIError

PROVIDERS = {'auto', 'qwen', 'openai', 'compatible'}
QWEN_MODEL = re.compile(r'qwen3-asr-flash(?:-\d{4}-\d{2}-\d{2})?')


def openai_model(model):
    return model=='whisper-1' or (model.startswith('gpt-') and '-transcribe' in model)


def qwen_host(base):
    host = (urlsplit(base).hostname or '').lower()
    return host in {'dashscope.aliyuncs.com', 'dashscope-intl.aliyuncs.com',
                    'dashscope-us.aliyuncs.com'} or host.endswith('.maas.aliyuncs.com')


def protocol(cfg):
    provider = cfg.get('asr_provider', 'auto')
    if not isinstance(provider, str) or provider not in PROVIDERS:
        raise ValueError('语音识别接口类型无效。')
    model = cfg.get('asr_model', '')
    base = cfg.get('asr_base_url', '')
    if not isinstance(model, str) or not model.strip():
        raise ValueError('请填写语音识别模型；百炼对白核对使用 qwen3-asr-flash。')
    model = model.strip()
    if not base:
        raise ValueError('请填写语音识别 API 地址。')
    direct_qwen = qwen_host(base)
    use_qwen = provider == 'qwen' or (provider == 'auto' and QWEN_MODEL.fullmatch(model))
    if use_qwen:
        if not QWEN_MODEL.fullmatch(model):
            raise ValueError('千问对白核对请使用 qwen3-asr-flash 或其日期快照；文本/视觉模型、realtime 和 filetrans 不能用于此接口。')
        if urlsplit(base).hostname == 'api.openai.com':
            raise ValueError('千问语音模型需要百炼地址；北京请填 https://dashscope.aliyuncs.com/compatible-mode/v1。')
        if direct_qwen and urlsplit(base).path.rstrip('/') not in {
                '/compatible-mode/v1', '/compatible-mode/v1/chat/completions'}:
            raise ValueError('百炼语音识别地址请使用以 /compatible-mode/v1 结尾的兼容地址；北京可填 https://dashscope.aliyuncs.com/compatible-mode/v1。')
        if urlsplit(base).hostname == 'dashscope-us.aliyuncs.com' or '.us-east-1.maas.aliyuncs.com' in base:
            raise ValueError('百炼美国地域不支持此语音兼容接口；请选择与 Key 同地域的北京或新加坡地址。')
        return 'qwen'
    if direct_qwen:
        raise ValueError('百炼对白核对不能使用通用 /audio/transcriptions；接口选千问或自动识别，模型填写 qwen3-asr-flash。')
    if provider == 'auto' and model.startswith('qwen3-asr-flash'):
        raise ValueError('本版千问语音接口支持 qwen3-asr-flash 及日期快照，不支持 realtime 或 filetrans。')
    if provider=='openai' or (provider=='auto' and openai_model(model)):
        if not openai_model(model):
            raise ValueError('GPT 语音识别请填写 gpt-4o-mini-transcribe、gpt-4o-transcribe 或其他 GPT 转录模型；普通聊天模型不能用于此接口。')
        return 'openai'
    if urlsplit(base).hostname=='api.openai.com' and not openai_model(model):
        raise ValueError('OpenAI 对白核对需要语音转录模型，例如 gpt-4o-mini-transcribe；不能填写普通聊天模型。')
    return 'compatible'


def endpoint(base, path):
    base = base.rstrip('/')
    return base if base.endswith(path) else base + path


def qwen_text(response):
    choices = response.get('choices')
    if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
        raise APIError('千问语音识别没有返回有效 choices。')
    choice = choices[0]
    if choice.get('finish_reason') in {'length', 'content_filter'}:
        raise APIError('千问语音识别未完整返回：' + str(choice['finish_reason']))
    message = choice.get('message')
    if not isinstance(message, dict) or message.get('refusal'):
        raise APIError('千问语音识别没有返回有效转录正文。')
    content = message.get('content')
    if isinstance(content, list):
        texts = [part['text'] for part in content if isinstance(part, dict)
                 and part.get('type') in {'text', 'output_text'} and isinstance(part.get('text'), str)]
        if content and not texts:
            raise APIError('千问语音识别正文没有文字。')
        content = ''.join(texts)
    if not isinstance(content, str):
        raise APIError('千问语音识别没有返回转录字符串。')
    # An empty transcript is valid silence, never evidence that dialogue passed.
    return content


async def recognize(client, blob):
    cfg = client.config
    try:
        kind = protocol(cfg)
    except ValueError as error:
        raise APIError(str(error)) from error
    model = cfg['asr_model'].strip()
    language=cfg.get('asr_language')
    if language not in {'zh','en','ja'}:language=None
    if kind == 'qwen':
        audio = 'data:audio/wav;base64,' + base64.b64encode(blob).decode('ascii')
        if len(audio.encode('ascii')) > 10_000_000:
            raise APIError('本段音频超过千问短音频接口的 10MB 限制；视频已保留，未提交付费识别。')
        payload = {'model': model, 'messages': [{'role': 'user', 'content': [
            {'type': 'input_audio', 'input_audio': {'data': audio}}]}],
            'stream': False, 'asr_options': {'enable_itn': False}}
        if language:payload['asr_options']['language']=language
        response = await client._request(endpoint(cfg['asr_base_url'], '/chat/completions'),
                                         cfg['asr_api_key'], payload)
        try:
            return {'text': qwen_text(response)}, kind
        except APIError as error:
            client.validation_failed(error, response)
            raise
    def form():
        body = aiohttp.FormData()
        body.add_field('model', model)
        if language and kind=='openai':body.add_field('language',language)
        if kind=='openai':body.add_field('response_format','json')
        body.add_field('file', blob, filename='speech.wav', content_type='audio/wav')
        return body
    response = await client._request(endpoint(cfg['asr_base_url'], '/audio/transcriptions'),
        cfg['asr_api_key'], payload={'model': model,**({'language':language} if language and kind=='openai' else {})}, form_factory=form, allow_empty_key=kind=='compatible')
    if not isinstance(response.get('text'), str):
        client.validation_failed('语音识别没有返回 text 字符串', response)
        raise APIError('语音识别没有返回 text 字符串；已有视频保留，继续时只重新核对，不重新渲染。')
    return response, kind
