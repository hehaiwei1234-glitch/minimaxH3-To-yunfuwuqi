"""Keep automatic failures local to a shot and preserve every saved candidate."""
import copy
import time
from . import dialogue_check
from .dialogue_timing import COMMITTED


def failed(clip):
    return clip.get('status') == 'deferred' and not clip.get('output')


def adopted_unchecked(files, clip):
    decision = clip.get('recovery_adoption') or {}
    if not (clip.get('output') and clip.get('quality_accepted') and clip.get('adopted_ng')):
        return False
    try:
        return decision.get('signature') == dialogue_check.signature(files, clip)
    except (OSError, KeyError):
        return False


def independent_after_gap(engine, identity, index):
    """Only unsubmitted successors may drop a missing continuation dependency."""
    p = engine.store.get('project', identity)
    clip = p['clips'][index]
    if not index or not failed(p['clips'][index-1]):
        return False
    if any(clip.get(key) for key in COMMITTED):
        return False
    if clip.get('continuity') != 'continue' and not clip.get('depends_on_previous'):
        return False
    def change(project):
        item = project['clips'][index]
        item.setdefault('recovery_original_continuity', item.get('continuity', 'cut'))
        if item.get('state_reference_id') or item.get('state_reference_source'):
            item.pop('frame_asset_id', None)
            item.pop('image_asset_id', None)
        for key in ('state_reference_id', 'state_reference_source', 'prompt_en',
                    'prompt_zh', 'prompt_compiler_version'):
            item.pop(key, None)
        item.update(continuity='cut', depends_on_previous=False,
                    recovery_gap={'previous_clip': index, 'mode': 'independent_fixed_assets'},
                    status='pending')
        if project.get('plan') and len(project['plan'].get('segments', [])) > index:
            project['plan']['segments'][index].update(continuity='cut', depends_on_previous=False)
    engine.store.update('project', identity, change)
    engine.store.event(identity, f'第{index+1}段：前段无可用视频，改用固定人物/场景独立生成；原台词保留，连续性降级已标记。')
    return True


async def record_failure(engine, identity, index, error, cfg):
    """Adopt a real saved video as unchecked NG, or leave a genuine empty gap.

    Submission IDs are deliberately retained: a missing acknowledgement is
    never permission to submit an expensive job twice.
    """
    p = engine.store.get('project', identity)
    clip = p['clips'][index]
    record = {'message': str(error), 'type': type(error).__name__,
              'time': time.time(), 'stage': clip.get('status', ''),
              'submission_unknown': bool(clip.get('submission_unknown'))}
    candidates = [(clip.get('output'), clip.get('meta')),
                  (clip.get('raw_output'), clip.get('meta'))]
    candidates += [(take.get('output') or take.get('raw_output'), take.get('meta'))
                   for take in reversed(clip.get('quality_history', []))]
    output = meta = None
    for candidate, candidate_meta in candidates:
        if not isinstance(candidate, dict):
            continue
        try:
            path = engine.files.output_path(candidate)
            if path.is_file() and path.stat().st_size:
                output, meta = copy.deepcopy(candidate), copy.deepcopy(candidate_meta)
                break
        except (OSError, ValueError, KeyError):
            continue
    if output:
        if not meta:
            from .media_tools import probe
            try:
                meta = await probe(engine.files.output_path(output), cfg)
            except Exception:
                meta = {'duration': clip.get('duration_seconds', 0), 'audio': False}
        engine.clip_set(identity, index, output=output, meta=meta, status='complete',
                        task_failure=record, adopted_ng=True, quality_accepted=True,
                        video_reviewed=False, recovery_unchecked=True,
                        quality_error=str(error))
        saved = engine.store.get('project', identity)['clips'][index]
        if cfg.get('review_audio') and saved.get('dialogue') and not dialogue_check.current_report(engine.files, saved):
            engine.clip_set(identity, index, dialogue_check={
                'signature': dialogue_check.signature(engine.files, saved),
                'passed': False, 'status': 'unavailable', 'transcript': '',
                'expected': ' '.join(line['text'] for line in saved['dialogue']),
                'reason': '自动核对未完成：'+str(error), 'created_at': time.time()})
        engine.clip_set(identity, index, recovery_adoption={
            'signature': dialogue_check.signature(engine.files, saved),
            'status': 'unchecked_ng', 'reason': str(error), 'time': time.time()})
        message = f'第{index+1}段：自动步骤失败，已有视频标记为NG/未核对并保留；继续后续任务。原因：{error}'
    else:
        if clip.get('output'):
            engine.clip_set(identity, index, missing_output=clip['output'])
        def clear_missing(project):
            for key in ('output', 'meta', 'recovery_adoption', 'recovery_unchecked'):
                project['clips'][index].pop(key, None)
        engine.store.update('project', identity, clear_missing)
        engine.clip_set(identity, index, status='deferred', task_failure=record,
                        quality_accepted=False, quality_error=str(error))
        message = f'第{index+1}段：生成失败，无视频可采用，标记待补做；继续后续任务。原因：{error}'
    engine.store.event(identity, message)
    engine.set(identity, phase=message)
    return bool(output)


def reset_missing_for_retry(project):
    for clip in project.get('clips', []):
        if not failed(clip):
            continue
        if clip.get('task_failure'):
            clip.setdefault('task_failure_history', []).append(clip.pop('task_failure'))
        clip.pop('quality_error', None)
        clip.update(status='ready' if clip.get('prompt_en') else 'pending')


def project_deferred(engine, identity, error):
    engine.set(identity, status='deferred', error=str(error), error_kind='automatic',
               phase='自动步骤失败，本集留待补做；整剧将继续后续集', pause_requested=False)
    engine.store.event(identity, '本集留待补做，已有成果保留：'+str(error))
