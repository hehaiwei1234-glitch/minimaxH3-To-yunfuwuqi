"""Local, redacted request records. Recording must never break production."""
import json
import time
import uuid
from urllib.parse import urlsplit
from .telemetry import _owner
from .version import VERSION


def redact(value, config):
    secrets=[str(v) for k,v in config.items() if k.endswith('_api_key') and v]
    def clean(x):
        if isinstance(x, dict):
            return {str(k):('[omitted]' if str(k).lower() in {'authorization','api_key','b64_json','image_url','waveform'} else clean(v)) for k,v in x.items()}
        if isinstance(x,list):return [clean(v) for v in x[:200]]
        if isinstance(x,str):
            if x.startswith('data:'):return '[media omitted]'
            for secret in secrets:x=x.replace(secret,'[redacted]')
            return x[:40000]
        return x
    return clean(value)


def begin(url, payload):
    parts=urlsplit(url)
    host=parts.hostname or ''
    if ':' in host:host='['+host+']'
    if parts.port:host+=':'+str(parts.port)
    return {'id':uuid.uuid4().hex,'started_at':time.time(),'endpoint':parts.scheme+'://'+host+parts.path,
            'model':(payload or {}).get('model',''),'status':'requesting'}


def save(record,config,response=None,error=None):
    owner=_owner.get()
    if not owner:return
    store,kind,identity=owner
    try:
        row={**record,'owner_kind':kind,'owner_id':identity,'updated_at':time.time()}
        if response is not None:
            safe=redact(response,config)
            encoded=json.dumps(safe,ensure_ascii=False)
            row['response']=safe if len(encoded)<=40000 else {'truncated_response':encoded[:40000]}
        if error:row.update(status='error',error=str(error))
        row=redact(row,config)
        store.put('api_request',record['id'],row)
        if error:
            def change(p):
                errors=[x for x in p.get('api_failures',[]) if x.get('id')!=row['id']]
                errors.append({k:row[k] for k in ('id','endpoint','model','status','error','started_at','request_id') if k in row})
                p['api_failures']=errors[-20:]
            store.update(kind,identity,change)
    except Exception:
        # Failure to write diagnostic metadata must not cause a paid retry.
        pass


def save_wait(record,config):
    """Record local queue/history waits separately from paid API requests."""
    owner=_owner.get()
    if not owner:return
    store,kind,identity=owner
    try:
        row={**record,'owner_kind':kind,'owner_id':identity,'updated_at':time.time()}
        store.put('comfy_wait',record['id'],redact(row,config))
    except Exception:
        pass


def export(store,kind,identity):
    record=store.get(kind,identity)
    owners={identity}
    if kind=='series':owners.update(record.get('project_ids',[]))
    rows=[row for row in store.list('api_request') if row.get('owner_id') in owners]
    rows.sort(key=lambda row:row.get('started_at',0))
    waits=[row for row in store.list('comfy_wait') if row.get('owner_id') in owners]
    waits.sort(key=lambda row:row.get('started_at',0))
    fields=('id','owner_id','status','job_id','prompt_id','missing_prompt_id','submission_unknown',
            'error','workflow_name','created_at','output')
    images=[{key:row[key] for key in fields if key in row}
            for row in store.list('image_job') if row.get('owner_id') in owners]
    cfg=store.settings()
    return redact({'software_version':VERSION,'runtime_module_file':__file__,'owner_kind':kind,'owner_id':identity,
                   'exported_at':time.time(),'requests':rows,
                   'comfy_waits':waits,'local_image_jobs':images,
                   'wait_policy':{key:cfg.get(key) for key in ('api_timeout_seconds','render_timeout_minutes','poll_seconds','retry_limit')},
                   'note':'API请求开始即记录；本地生图和视频等待单独记录队列/历史状态。密钥及媒体内容已移除。'},cfg)
