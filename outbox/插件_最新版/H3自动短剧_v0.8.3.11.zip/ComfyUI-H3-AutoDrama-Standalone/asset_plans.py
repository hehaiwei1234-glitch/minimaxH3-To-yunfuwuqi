"""Resolve AI-local asset names without changing saved pictures or identities."""
from __future__ import annotations

import copy
import hashlib

from .domain import safe_id


def normalize_asset_plan(plan, assets, key, *, namespace=None, aliases=None):
    if not isinstance(plan, dict):
        raise ValueError('AI素材计划必须是JSON对象。')
    result = copy.deepcopy(plan)
    generated = result.get(key, [])
    if generated is None:generated=[]
    if not isinstance(generated, list) or len(generated) > 100:
        raise ValueError('AI新增素材清单无效。')
    existing = {a['id']: a for a in assets}
    by_identity = {}
    for asset in assets:
        if asset.get('kind') == 'image':
            identity = (asset.get('role'), asset.get('label', '').strip())
            by_identity.setdefault(identity, []).append(asset['id'])
    # Historical AI-local names are a fallback. Names in this response take
    # precedence, so a new courtyard named "room" cannot select an old room.
    references = {k: v for k, v in (aliases or {}).items() if v in existing}
    references.update({aid: aid for aid in existing})
    local = {}
    new_by_identity = {}
    normalized = []
    for item in generated:
        if not isinstance(item, dict):
            raise ValueError('新增素材必须是JSON对象。')
        aid = item.get('id')
        if not isinstance(aid, str):
            raise ValueError('新增素材缺少文字编号。')
        safe_id(aid)
        role, label = item.get('role'), item.get('label')
        if role not in {'character', 'scene', 'prop', 'style'} or not isinstance(label, str) or not label.strip():
            raise ValueError('新增素材缺少有效的类型或名称。')
        identity = (role, label.strip())
        if aid in local:
            if local[aid][0] != identity:
                raise ValueError('素材编号'+aid+'同时指向不同素材，请为不同素材使用不同编号。')
            continue
        if aid in existing:
            old = existing[aid]
            if old.get('kind') != 'image' or (old.get('role'), old.get('label', '').strip()) != identity:
                raise ValueError('素材编号'+aid+'属于已有'+old.get('label', aid)+'，不能用于'+label+'。')
            target = aid
        elif identity in by_identity:
            matches = by_identity[identity]
            if len(matches) != 1:
                raise ValueError('已有多个同名素材'+label+'，请明确使用已有编号。')
            target = matches[0]
        elif identity in new_by_identity:
            target = new_by_identity[identity]
        else:
            target = ('b'+hashlib.sha256((namespace+':'+aid).encode()).hexdigest()[:40]) if namespace else aid
            item['id'] = target
            normalized.append(item)
            new_by_identity[identity] = target
        local[aid] = (identity, target)
    references.update({aid: target for aid, (_, target) in local.items()})

    def resolve(values):
        if values is None:values=[]
        if not isinstance(values, list) or any(not isinstance(value, str) for value in values):
            raise ValueError('素材引用必须是编号列表。')
        # Several AI aliases can resolve to the same saved picture.
        return list(dict.fromkeys(references.get(value, value) for value in values))

    for item in normalized:
        item['reference_asset_ids'] = resolve(item.get('reference_asset_ids', []))
    for segment in result.get('segments', []):
        if not isinstance(segment, dict):
            raise ValueError('分镜格式无效。')
        for field in ('asset_ids', 'image_reference_ids'):
            segment[field] = resolve(segment.get(field, []))
    result[key] = normalized
    return result
