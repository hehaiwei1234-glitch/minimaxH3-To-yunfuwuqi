"""Persist measured wall intervals. Parallel totals must not be added together."""
from contextlib import contextmanager
from contextvars import ContextVar
import time

_owner = ContextVar('h3ad_timing_owner', default=None)

@contextmanager
def scope(store, kind, identity):
    token = _owner.set((store, kind, identity))
    try:
        yield
    finally:
        _owner.reset(token)

@contextmanager
def measure(stage, detail=''):
    owner = _owner.get()
    start = time.time()
    outcome = 'ok'
    try:
        yield
    except BaseException:
        outcome = 'interrupted'
        raise
    finally:
        end = time.time()
        if owner:
            store, kind, identity = owner
            def save(record):
                timing = record.setdefault('timings', {})
                item = timing.setdefault(stage, {'seconds': 0, 'calls': 0, 'interrupted': 0})
                item['seconds'] = round(item['seconds'] + max(0, end-start), 3)
                item['calls'] += 1
                item['interrupted'] += outcome != 'ok'
                rows = record.setdefault('timing_intervals', [])
                rows.append({'stage': stage, 'detail': str(detail), 'start': start,
                             'end': end, 'outcome': outcome})
                record['timing_intervals'] = rows[-3000:]
            try:
                store.update(kind, identity, save)
            except KeyError:
                pass
