from __future__ import annotations
import asyncio
import json
import time
import aiohttp
from . import api_diagnostics as diagnostics

class SubmissionUnknown(RuntimeError):pass
class RenderFailed(RuntimeError):pass
class SubmissionRejected(RenderFailed):pass
class ExecutionFailed(RenderFailed):pass
class TaskMissing(SubmissionUnknown):pass

class ComfyClient:
    MISSING_CONFIRMATIONS=3
    MISSING_GRACE_SECONDS=15
    def __init__(self,config,session):
        self.config=config;self.session=session;self.base=config['comfy_url'].rstrip('/')
        self.headers={'Authorization':'Bearer '+config['comfy_api_key']} if config.get('comfy_api_key') else {}
        if not self.base:raise ValueError('请设置ComfyUI地址。')
    async def get(self,path):
        try:
            async with self.session.get(self.base+path,headers=self.headers,timeout=aiohttp.ClientTimeout(total=60)) as r:
                raw=await r.text()
                if r.status>=400:raise RuntimeError(f'ComfyUI HTTP {r.status}：'+raw[:1000])
                return json.loads(raw)
        except (aiohttp.ClientError,asyncio.TimeoutError) as e:raise RuntimeError('连接ComfyUI失败：'+str(e)) from e
    async def preflight(self,graph,output_node_id=None,*,dynamic_inputs=()):
        dynamic={(ref['node'],ref['input']) for ref in dynamic_inputs}
        info=await self.get('/object_info')
        missing=sorted({n['class_type'] for n in graph.values()}-set(info))
        if missing:raise ValueError('此工作流所需节点未安装：'+', '.join(missing))
        if output_node_id and info[graph[output_node_id]['class_type']].get('output_node') is False:
            raise ValueError('所选保存节点不是ComfyUI输出节点。')
        loaders={'VAELoader':'vae_name','UNETLoader':'unet_name','CLIPLoader':'clip_name','LoraLoaderModelOnly':'lora_name','MinimaxH3LatentUpscaler3D':'model_name'}
        for node in graph.values():
            field=loaders.get(node['class_type'])
            if not field:continue
            groups=info[node['class_type']].get('input',{})
            spec=(groups.get('required',{}).get(field) or groups.get('optional',{}).get(field))
            value=node['inputs'].get(field)
            seen=set()
            while isinstance(value,list) and len(value)==2 and isinstance(value[0],str) and value[0] in graph and value[0] not in seen and graph[value[0]]['class_type'].startswith('Primitive'):
                seen.add(value[0]);value=graph[value[0]]['inputs'].get('value')
            if isinstance(value,str) and spec and isinstance(spec[0],list) and value not in spec[0]:raise ValueError('服务器缺少工作流模型：'+str(value))
        for nid,node in graph.items():
            groups=info[node['class_type']].get('input',{})
            specs={**groups.get('required',{}),**groups.get('optional',{})}
            for field,value in node['inputs'].items():
                if (nid,field) in dynamic:continue
                spec=specs.get(field)
                if isinstance(value,(str,int,float,bool)) and isinstance(spec,(list,tuple)) and spec and isinstance(spec[0],list) and value not in spec[0]:
                    raise ValueError(f'工作流参数在当前ComfyUI不可用：{node["class_type"]}.{field} = {value}')
    @staticmethod
    def marker(entry):
        # Official history entry stores the original queue tuple under prompt.
        prompt=entry.get('prompt',[]) if isinstance(entry,dict) else entry
        if not isinstance(prompt,list) or len(prompt)<4:return None
        extra=prompt[3]
        return extra.get('h3_autodrama_v1',{}).get('job_id') if isinstance(extra,dict) else None
    async def find(self,job_id):
        queue=await self.get('/queue')
        for item in queue.get('queue_running',[])+queue.get('queue_pending',[]):
            if self.marker(item)==job_id:return str(item[1])
        history=await self.get('/history?max_items=2000')
        for id,entry in history.items():
            if self.marker(entry)==job_id:return id
        return None
    async def submit(self,graph,job_id,project_id):
        payload={'prompt':graph,'client_id':'h3_autodrama_v1_'+project_id,
                 'extra_data':{'h3_autodrama_v1':{'job_id':job_id,'project_id':project_id}}}
        try:
            async with self.session.post(self.base+'/prompt',json=payload,headers=self.headers,timeout=aiohttp.ClientTimeout(total=60)) as r:
                raw=await r.text()
                if r.status>=400:raise SubmissionRejected(f'ComfyUI未接受任务（HTTP {r.status}）：'+raw[:2000])
                data=json.loads(raw)
                if not data.get('prompt_id') or data.get('node_errors'):raise SubmissionRejected('工作流校验失败：'+str(data))
                return str(data['prompt_id'])
        except (aiohttp.ClientError,asyncio.TimeoutError,json.JSONDecodeError) as e:
            # POST may have succeeded. Never POST again before reconciling.
            for _ in range(3):
                try:
                    found=await self.find(job_id)
                    if found:return found
                except Exception:pass
                await asyncio.sleep(self.config['poll_seconds'])
            raise SubmissionUnknown('提交回复丢失，尚不能确认是否入队；已暂停，继续时会查找原任务，不会重复提交。') from e
    @staticmethod
    def output(entry,output_node_id='20',kind='video'):
        status=entry.get('status',{})
        for event in status.get('messages',[]):
            if event and event[0]=='execution_error':
                details=event[1] if len(event)>1 else {}
                if isinstance(details,dict):
                    message=str(details.get('exception_message') or details.get('message') or details.get('exception_type') or '未知执行错误').strip()
                    node=' '.join(str(details[k]) for k in ('node_id','node_type') if details.get(k) is not None)
                    if node:message='节点 '+node+'：'+message
                else:message=str(details)
                # ComfyUI includes tensors in current_inputs/current_outputs.
                # Keep the real cause visible instead of the tail of that payload.
                raise ExecutionFailed('ComfyUI执行失败：'+message[:2500])
        if status.get('status_str')=='error':
            raise ExecutionFailed('ComfyUI执行失败：未返回具体错误，请查看ComfyUI运行日志。')
        if not status.get('completed'):return None
        save=entry.get('outputs',{}).get(str(output_node_id),{})
        extensions=('.png','.jpg','.jpeg','.webp','.bmp') if kind=='image' else ('.mp4','.mkv','.mov','.webm')
        matches=[]
        for key in ('images','videos','gifs'):
            for item in save.get(key,[]):
                if item.get('filename','').lower().endswith(extensions):matches.append(item)
        if kind=='image' and len(matches)>1:raise RenderFailed('生图工作流一次输出了多张图片。请在工作流将生成数量设为1，再导入。')
        if matches:return matches[0]
        raise RenderFailed('任务结束，但所选输出节点没有返回'+('图片' if kind=='image' else '视频')+'文件：'+str(output_node_id))
    @staticmethod
    def queue_state(queue,prompt_id):
        # Only a complete, valid official queue response can prove absence.
        if not isinstance(queue,dict):return None
        groups=('queue_running','queue_pending')
        if any(not isinstance(queue.get(key),list) for key in groups):return None
        if any(not isinstance(item,(list,tuple)) or len(item)<2
               for key in groups for item in queue[key]):return None
        for key,state in (('queue_running','running'),('queue_pending','queued')):
            if any(str(item[1])==str(prompt_id) for item in queue[key]):return state
        return 'absent'

    async def wait(self,id,output_node_id='20',kind='video'):
        id=str(id);limit=60*self.config['render_timeout_minutes']
        started=time.monotonic();until=started+limit;failures=0
        missing_checks=0;missing_since=None
        record=diagnostics.begin(self.base+'/history/'+id,None)
        record.update(prompt_id=id,output_node_id=str(output_node_id),kind=kind,
                      timeout_seconds=limit,status='checking',missing_checks=0)
        def note(status,**details):
            record.update(status=status,elapsed_seconds=round(time.monotonic()-started,3),**details)
            diagnostics.save_wait(record,self.config)
        note('checking')
        try:
            while time.monotonic()<until:
                try:
                    data=await self.get('/history/'+id)
                    if not isinstance(data,dict):raise RuntimeError('ComfyUI历史响应格式无效，不能确认任务状态。')
                    if id in data:
                        missing_checks=0;missing_since=None
                        result=self.output(data[id],output_node_id,kind)
                        if result:
                            note('complete',finished_at=time.time(),missing_checks=0)
                            return result
                        note('history_pending',missing_checks=0)
                    else:
                        try:queue=await self.get('/queue')
                        except RuntimeError as error:
                            queue=None;note('queue_unavailable',queue_error=str(error))
                        state=self.queue_state(queue,id)
                        if state=='absent':
                            # A task may finish between the first history read
                            # and the queue read. Recheck before counting absence.
                            latest=await self.get('/history/'+id)
                            if not isinstance(latest,dict):raise RuntimeError('ComfyUI历史响应格式无效，不能确认任务状态。')
                            if id in latest:
                                missing_checks=0;missing_since=None
                                result=self.output(latest[id],output_node_id,kind)
                                if result:
                                    note('complete',finished_at=time.time(),missing_checks=0)
                                    return result
                                note('history_pending',missing_checks=0)
                            else:
                                missing_checks+=1
                                if missing_since is None:missing_since=time.monotonic()
                                note('checking_absence',missing_checks=missing_checks)
                                if (missing_checks>=self.MISSING_CONFIRMATIONS and
                                        time.monotonic()-missing_since>=self.MISSING_GRACE_SECONDS):
                                    label='图片' if kind=='image' else '视频'
                                    raise TaskMissing('ComfyUI队列和历史连续核对后均找不到原'+label+'任务：'+id+
                                        '。可能发生服务重启、清理任务或切换实例；将核对已有输出，不自动重复提交。')
                        else:
                            missing_checks=0;missing_since=None
                            note(state if state in {'running','queued'} else 'queue_unavailable',missing_checks=0)
                    failures=0
                except (RenderFailed,TaskMissing):raise
                except RuntimeError as error:
                    failures+=1;missing_checks=0;missing_since=None
                    note('connection_error',error=str(error),missing_checks=0)
                    if failures>self.config['retry_limit']+2:raise
                await asyncio.sleep(self.config['poll_seconds'])
            raise TimeoutError('等待'+('图片' if kind=='image' else '视频')+'超过设置时限。任务编号已保存；ComfyUI里的任务会继续，点击继续可重新查看结果。')
        except asyncio.CancelledError:
            note('interrupted',finished_at=time.time());raise
        except BaseException as error:
            note('missing' if isinstance(error,TaskMissing) else 'error',error=str(error),finished_at=time.time())
            raise
