from __future__ import annotations
import os
import re
import shutil
import time
import uuid
from pathlib import Path
from .domain import PREFIX, kind_for, safe_name, safe_id

def within(root,relative):
    root=Path(root).resolve();target=(root/relative).resolve()
    if not target.is_relative_to(root):raise ValueError('文件路径超出允许目录。')
    return target

def generated_image_name(label):
    value=re.sub(r'[<>:"/\\|?*\x00-\x1f]','_',str(label)).strip(' .')[:90] or '自动素材'
    if value.split('.')[0].upper() in {'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}:value='_'+value
    return value+'.png'

class Files:
    def __init__(self,input_dir,output_dir):
        self.input=Path(input_dir).resolve();self.output=Path(output_dir).resolve()
        (self.input/PREFIX/'assets').mkdir(parents=True,exist_ok=True)
        (self.output/PREFIX/'projects').mkdir(parents=True,exist_ok=True)
    def asset_path(self,asset):return within(self.input,asset['relative_path'])
    def output_path(self,item):
        if item.get('type','output')!='output':raise ValueError('成品必须在ComfyUI output目录。')
        return within(self.output,Path(item.get('subfolder',''))/safe_name(item['filename']))
    def project_dir(self,id):
        folder=self.output/PREFIX/'projects'/safe_id(id);folder.mkdir(parents=True,exist_ok=True);return folder
    def write_asset(self,store,name,blob,metadata=None,id=None):
        name=safe_name(name);kind=kind_for(name);id=safe_id(id or uuid.uuid4().hex)
        relative=f'{PREFIX}/assets/{id}/{name}';path=within(self.input,relative);path.parent.mkdir(parents=True,exist_ok=True)
        pending=path.with_name(path.name+'.partial');pending.write_bytes(blob);os.replace(pending,path)
        meta=metadata or {}
        asset={'id':id,'name':name,'kind':kind,'relative_path':relative,'label':str(meta.get('label') or name),
               'description':str(meta.get('description','')),'speaker':str(meta.get('speaker','')),
               'role':str(meta.get('role') or ('voice' if kind=='audio' else 'motion' if kind=='video' else 'scene')),
               'created_at':time.time(),'generated':bool(meta.get('generated',False))}
        try:asset['quality']=store.get('quality_asset',id)
        except KeyError:pass
        store.put('asset',id,asset);return asset
    def import_asset(self,store,relative,metadata=None):
        source=within(self.input,relative)
        if not source.is_file():raise ValueError('ComfyUI input目录里找不到此文件。')
        return self.write_asset(store,source.name,source.read_bytes(),metadata)
    def existing_input(self):
        result=[]
        for path in self.input.rglob('*'):
            if not path.is_file() or PREFIX in path.relative_to(self.input).parts:continue
            try:kind=kind_for(path.name)
            except ValueError:continue
            result.append({'relative_path':path.relative_to(self.input).as_posix(),'kind':kind,'name':path.name})
            if len(result)>=2000:break
        return result
    def recover_output(self,prefix,kind='video'):
        parent=within(self.output,Path(prefix).parent);stem=Path(prefix).name
        if not parent.exists():return None
        extensions={'.png','.jpg','.jpeg','.webp','.bmp'} if kind=='image' else {'.mp4','.mkv','.webm','.mov'}
        candidates=sorted((p for p in parent.glob(stem+'*') if p.is_file() and p.suffix.lower() in extensions),key=lambda p:p.stat().st_mtime,reverse=True)
        if kind=='image' and len(candidates)>1:raise ValueError('原生图任务有多个输出文件，请核对ComfyUI，不能自动选择其中一张。')
        if not candidates:return None
        p=candidates[0]
        return {'type':'output','subfolder':p.parent.relative_to(self.output).as_posix(),'filename':p.name}
    def descriptor(self,path):
        path=Path(path).resolve()
        if not path.is_relative_to(self.output):raise ValueError('输出文件不在output目录。')
        return {'type':'output','subfolder':path.parent.relative_to(self.output).as_posix(),'filename':path.name}
