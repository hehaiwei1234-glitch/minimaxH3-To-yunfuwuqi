﻿# Requires Windows PowerShell 5.1, Windows 10/11 x64.
# Downloads the Windows release build linked by ffmpeg.org.
# Only writes inside this independent plugin's tools directory.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$toolsDir = Join-Path $PSScriptRoot 'tools\ffmpeg'
$stageDir = Join-Path $toolsDir ('.prepare-' + [Guid]::NewGuid().ToString('N'))
$downloadUrl = 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip'
$ffmpegPath = Join-Path $toolsDir 'ffmpeg.exe'
$ffprobePath = Join-Path $toolsDir 'ffprobe.exe'

function Test-NativeTool([string]$ExePath) {
    if (-not (Test-Path -LiteralPath $ExePath -PathType Leaf)) { return $false }
    try {
        & $ExePath -version *> $null
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}

function Invoke-CheckedTool([string]$ExePath, [string[]]$NativeArgs) {
    $nativeOutput = & $ExePath @NativeArgs 2>&1
    if ($LASTEXITCODE -ne 0) { throw ("工具运行失败：" + ($nativeOutput -join [Environment]::NewLine)) }
    return ($nativeOutput -join [Environment]::NewLine)
}

function Get-ConcatLine([string]$VideoPath) {
    $normalizedPath = $VideoPath.Replace('\', '/').Replace("'", "'\''")
    return ("file '" + $normalizedPath + "'" + "`n")
}

try {
    Write-Host '此步目的：准备视频检查和合成工具。不会调用 AI，也不会启动 H3 渲染。' -ForegroundColor Cyan
    New-Item -ItemType Directory -Path $stageDir -Force | Out-Null
    if ((Test-NativeTool $ffmpegPath) -and (Test-NativeTool $ffprobePath)) {
        Write-Host '已有可用工具，跳过下载。'
    } else {
        Write-Host '正在下载 FFmpeg Windows 版，约 110 MB。请等待……'
        $zipPath = Join-Path $stageDir 'ffmpeg.zip'
        $hashPath = Join-Path $stageDir 'checksum.txt'
        Invoke-WebRequest -UseBasicParsing -Uri ($downloadUrl + '.sha256') -OutFile $hashPath -TimeoutSec 60
        $expectedHash = [regex]::Match((Get-Content -LiteralPath $hashPath -Raw -Encoding UTF8), '(?i)\b[0-9a-f]{64}\b').Value
        if (-not $expectedHash) { throw '下载来源没有返回有效的 SHA256 校验值。' }
        Invoke-WebRequest -UseBasicParsing -Uri $downloadUrl -OutFile $zipPath -TimeoutSec 1800
        $actualHash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash
        if ($actualHash -ne $expectedHash) { throw '下载文件校验不一致，请重新运行。' }
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $archive = [IO.Compression.ZipFile]::OpenRead($zipPath)
        try {
            foreach ($toolName in @('ffmpeg.exe', 'ffprobe.exe')) {
                $entry = @($archive.Entries | Where-Object { $_.FullName.Replace('\', '/').EndsWith('/bin/' + $toolName) })
                if ($entry.Count -ne 1) { throw ('压缩包中没有唯一的 ' + $toolName) }
                [IO.Compression.ZipFileExtensions]::ExtractToFile($entry[0], (Join-Path $stageDir $toolName), $true)
            }
            foreach ($entry in $archive.Entries) {
                if ($entry.Name -match '^(LICENSE|COPYING|README)(\..*)?$') {
                    [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, (Join-Path $stageDir $entry.Name), $true)
                }
            }
        } finally { $archive.Dispose() }
        if (-not ((Test-NativeTool (Join-Path $stageDir 'ffmpeg.exe')) -and (Test-NativeTool (Join-Path $stageDir 'ffprobe.exe')))) {
            throw '下载的工具无法运行；请确认使用 Windows 10/11 64 位系统。'
        }
        foreach ($toolName in @('ffmpeg.exe', 'ffprobe.exe')) {
            Copy-Item -LiteralPath (Join-Path $stageDir $toolName) -Destination (Join-Path $toolsDir $toolName) -Force
        }
        Get-ChildItem -LiteralPath $stageDir -File | Where-Object { $_.Name -match '^(LICENSE|COPYING|README)(\..*)?$' } | ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $toolsDir $_.Name) -Force
        }
        [IO.File]::WriteAllText((Join-Path $toolsDir 'download-source.txt'), ($downloadUrl + "`r`nSHA256: " + $actualHash), [Text.Encoding]::UTF8)
    }
    Write-Host '正在检查：生成半秒测试视频、拼接两段、读取画面和音轨信息……'
    $clipPath = Join-Path $stageDir '本机 检查片段.mp4'
    $concatPath = Join-Path $stageDir '检查清单.txt'
    $mergedPath = Join-Path $stageDir '合并检查.mp4'
    $null = Invoke-CheckedTool $ffmpegPath @('-y', '-v', 'error', '-f', 'lavfi', '-i', 'color=c=blue:s=64x64:r=24:d=0.5', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=0.5', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', $clipPath)
    $manifestText = (Get-ConcatLine $clipPath) + (Get-ConcatLine $clipPath)
    [IO.File]::WriteAllText($concatPath, $manifestText, (New-Object Text.UTF8Encoding($false)))
    $null = Invoke-CheckedTool $ffmpegPath @('-y', '-v', 'error', '-f', 'concat', '-safe', '0', '-i', $concatPath, '-map', '0:v:0', '-map', '0:a:0', '-c', 'copy', $mergedPath)
    $probeText = Invoke-CheckedTool $ffprobePath @('-v', 'error', '-show_streams', '-show_format', '-of', 'json', $mergedPath)
    $probe = $probeText | ConvertFrom-Json
    if (-not @($probe.streams | Where-Object { $_.codec_type -eq 'video' }).Count) { throw '自检结果缺少视频画面。' }
    if (-not @($probe.streams | Where-Object { $_.codec_type -eq 'audio' }).Count) { throw '自检结果缺少音轨。' }
    $duration = [double]::Parse([string]$probe.format.duration, [Globalization.CultureInfo]::InvariantCulture)
    if ($duration -lt 0.9 -or $duration -gt 2.0) { throw '自检合成时长不正确。' }
    $report = @{ ready = $true; ffmpeg = $ffmpegPath; ffprobe = $ffprobePath; duration = $duration; checked_at = (Get-Date).ToString('o') } | ConvertTo-Json
    [IO.File]::WriteAllText((Join-Path $toolsDir '工具自检结果.json'), $report, (New-Object Text.UTF8Encoding($false)))
    Write-Host ''
    Write-Host '准备完成：两个工具可运行，视频和音轨合成检查通过。' -ForegroundColor Green
    Write-Host '本更新包会自动识别，软件设置中的 ffmpeg / ffprobe 保持默认即可。'
    Write-Host '接下来按原来的方式启动 ComfyUI，打开 H3 自动短剧 → 设置 → 保存并检查连接。'
    Write-Host ('FFmpeg：' + $ffmpegPath)
    Write-Host ('FFprobe：' + $ffprobePath)
    exit 0
} catch {
    Write-Host ''
    Write-Host ('准备失败：' + $_.Exception.Message) -ForegroundColor Red
    Write-Host '请保留这个窗口的报错文字，方便定位。'
    exit 1
} finally {
    if (Test-Path -LiteralPath $stageDir) { Remove-Item -LiteralPath $stageDir -Recurse -Force -ErrorAction SilentlyContinue }
}
