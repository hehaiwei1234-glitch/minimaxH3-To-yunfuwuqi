"""Independent extension: new IDs, routes, files; no global on_prompt handlers."""
from .render_nodes import comfy_entrypoint
from .routes import register_routes
from server import PromptServer
import folder_paths

WEB_DIRECTORY='./web'
register_routes(PromptServer.instance,folder_paths)
__all__=['comfy_entrypoint','WEB_DIRECTORY']
