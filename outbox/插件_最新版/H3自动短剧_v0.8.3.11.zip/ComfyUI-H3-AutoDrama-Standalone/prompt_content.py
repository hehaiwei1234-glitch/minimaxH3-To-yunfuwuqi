"""Shared content normalization, durable partial results and bounded field repairs.

The compiler still owns references, dialogue and time validation. This layer
does not translate, invent missing shot design, or relax those validations.
"""
import copy
import json
import re
from .production import fingerprint
from .telemetry import measure
from .prompt_validation import InvalidContent, issues, recover_structure, text_issues
from .providers import ContentFormatError, format_retries

ZH_PENDING='【中文对照待补；英文原文已保留】'
VOICE_REFERENCE={'en':'Match the supplied voice-timbre reference for this speaker, speaking the authored words naturally.','zh':'跟随此角色的真实音色参考，自然说出剧本原句。'}

def reference_fallback(kind):
    return {'en':{'image':'Use the identity, appearance and environment shown in this supplied image reference.',
                  'video':'Use the visible identity and environment in this supplied video reference.',
                  'audio':'Use only the timbre or ambient characteristics of this supplied audio reference; do not repeat its words.'}[kind],
            'zh':{'image':'沿用这张真实参考图中的身份、外观和环境。','video':'沿用这段真实参考视频中的身份和环境。','audio':'仅使用真实音频参考的音色或环境特征，不复述其中台词。'}[kind]}

class MissingContent(ValueError):
    def __init__(self, paths):
        self.paths=paths
        super().__init__('缺少必要的提示词内容：'+', '.join(paths))

def pair(value,other=None):
    """Return actual text only. A Chinese-only string is never fake English."""
    if isinstance(value,str):
        value={'en':value} if re.search('[A-Za-z]',value) else {'zh':value}
    if not isinstance(value,dict): value={}
    result={}
    for key,aliases in (('en',('en','english')),('zh',('zh','chinese','cn'))):
        for alias in aliases:
            found=value.get(alias)
            if isinstance(found,str) and found.strip(): result[key]=found.strip();break
    if isinstance(other,str) and other.strip(): result.setdefault('zh',other.strip())
    elif isinstance(other,dict):
        for key,item in pair(other).items(): result.setdefault(key,item)
    return result

def pointer(key): return str(key).replace('~','~0').replace('/','~1')

def mapping(value): return value if isinstance(value,dict) else {}

def cached_pair(value):
    """A previously saved label is usable only if it still meets the contract."""
    saved=pair(value)
    if text_issues(saved.get('en'),'/en'): return {}
    if text_issues(saved.get('zh'),'/zh'): saved.pop('zh',None)
    return saved

def asset_key(asset):
    return fingerprint({k:asset.get(k) for k in ('id','kind','role','label','speaker','description','relative_path','sha256','size','created_at','updated_at','_file_version')})

def actual_assets(engine,assets):
    result=[]
    for asset in assets:
        path=engine.files.asset_path(asset)
        if asset.get('archived') or not path.is_file(): raise ValueError('真实参考文件不存在或已归档：'+asset.get('label',asset['id']))
        stat=path.stat();result.append({**asset,'_file_version':[stat.st_size,stat.st_mtime_ns]})
    return result

def can_reuse(engine,clip,assets):
    actual=actual_assets(engine,assets)
    bound=clip.get('compiled_media_bindings')
    if bound:
        if not isinstance(bound,list) or any(not isinstance(a,dict) or not isinstance(a.get('asset_id'),str) for a in bound): return False
        if [a['asset_id'] for a in bound]!=[a['id'] for a in actual]: return False
    versions=clip.get('compiled_asset_versions')
    if versions and (not isinstance(versions,list) or any(not isinstance(v,str) for v in versions)): return False
    return not versions or versions==[asset_key(a) for a in actual]

def voice_key(name,assets,bindings):
    ids=bindings.get(name,{})
    voice=ids.get('voice_id')
    candidates=[a for a in assets if a['kind']=='audio' and (a['id']==voice or a.get('speaker')==name or a.get('role')=='voice' and a.get('label')==name)]
    return fingerprint({'name':name,'binding':ids,'voices':[asset_key(a) for a in candidates]})

def normalize(result,assets,clip,bindings=None,cache=None,complete=True):
    if not isinstance(result,dict): raise ValueError('提示词内容须为JSON对象。')
    out=copy.deepcopy(result);bindings=bindings or {};cache=mapping(cache);missing=[];notes=[]
    refs=out.get('reference_descriptions')
    if not isinstance(refs,dict): refs={}
    descriptions={}
    def finish(value,path,fallback=None):
        p=pair(value)
        if not p.get('en') and fallback:
            previous=pair(fallback)
            for k,v in previous.items(): p.setdefault(k,v)
            if previous.get('en'): notes.append(path+' 已复用已保存或真实素材的描述')
        if not p.get('en'): missing.append(path+'/en')
        if not p.get('zh') or p['zh']==ZH_PENDING:
            p['zh']=ZH_PENDING;notes.append(path+' 中文对照待补（不阻断英文生成）')
        return p
    for i,a in enumerate(assets):
        key=f'ref_{i+1}';cached=cached_pair(mapping(cache.get('assets')).get(asset_key(a)))
        saved=pair(cached)
        description=a.get('description')
        if not cached and isinstance(description,str) and re.search('[A-Za-z]',description): cached={'en':description}
        if not cached:
            # This describes the actual reference relation, not invented visual
            # features. The real reference file is still sent to the model.
            cached=reference_fallback(a['kind'])
        descriptions[key]=finish(saved if saved.get('en') else refs.get(key),'/reference_descriptions/'+key,cached)
        if saved.get('en'): notes.append('/reference_descriptions/'+key+' 沿用同一真实素材的已保存描述')
    if set(refs)-set(descriptions): notes.append('已忽略不属于本次真实输入的多余素材描述；镜头中的引用仍严格校验')
    out['reference_descriptions']=descriptions
    voices=out.get('voices') if isinstance(out.get('voices'),dict) else {}
    out['voices']={}
    for name in dict.fromkeys(d['speaker'] for d in clip.get('dialogue',[])):
        cached=cached_pair(mapping(cache.get('voices')).get(voice_key(name,assets,bindings)))
        saved=pair(cached)
        if not cached and any(a['kind']=='audio' and (a['id']==bindings.get(name,{}).get('voice_id') or a.get('speaker')==name or a.get('role')=='voice' and a.get('label')==name) for a in assets):
            cached=VOICE_REFERENCE
        out['voices'][name]=finish(saved if saved.get('en') else voices.get(name),'/voices/'+pointer(name),cached)
        if saved.get('en'): notes.append('/voices/'+pointer(name)+' 沿用此角色的已保存音色设定')
    shots=out.get('shots')
    if not isinstance(shots,list) or not shots:
        missing.append('/shots')
    else:
        for i,shot in enumerate(shots):
            if not isinstance(shot,dict): missing.append('/shots/'+str(i));continue
            value=shot.get('visual_en',shot.get('visual'))
            p=finish(pair(value,shot.get('visual_zh')),f'/shots/{i}/visual')
            # Keep API repair paths aligned with the actual JSON layout.
            missing[:]=[x.replace(f'/shots/{i}/visual/en',f'/shots/{i}/visual_en') for x in missing]
            shot['visual_en']=p.get('en','');shot['visual_zh']=p['zh']
            for key in ('start_seconds','end_seconds','dialogue_indices'):
                if key not in shot or shot[key] is None: missing.append(f'/shots/{i}/{key}')
    p=finish(pair(out.get('sound_en',out.get('sound')),out.get('sound_zh')),'/sound')
    missing[:]=[x.replace('/sound/en','/sound_en') for x in missing]
    out['sound_en']=p.get('en','');out['sound_zh']=p['zh']
    prior=out.get('_content_warnings')
    if not isinstance(prior,list): prior=[]
    out['_content_warnings']=list(dict.fromkeys([x for x in prior if isinstance(x,str)]+notes))
    if missing and complete: raise MissingContent(missing)
    return out,list(dict.fromkeys(missing))

def cache_values(result,assets,clip,bindings):
    values={'assets':{},'voices':{}}
    for i,a in enumerate(assets):
        p=pair(result['reference_descriptions'].get(f'ref_{i+1}'))
        if p.get('en'): values['assets'][asset_key(a)]=p
    for name,p in result.get('voices',{}).items():
        if p.get('en'): values['voices'][voice_key(name,assets,bindings)]=p
    return values

def repair_paths(paths):
    """Do not request both a broken container and its inaccessible children."""
    paths=list(dict.fromkeys(paths))
    return [path for path in paths if not any(path.startswith(parent+'/') for parent in paths if parent!=path)]

def merge_patch(result,response,allowed):
    patches=response.get('patches') if isinstance(response,dict) else None
    if not isinstance(patches,list) or not patches: raise ValueError('缺项补全须返回非空patches数组。')
    out=copy.deepcopy(result);seen=set()
    for patch in patches:
        if not isinstance(patch,dict) or set(patch)!={'path','value'}: raise ValueError('每项补全仅包含path和value。')
        path=patch['path']
        if not isinstance(path,str) or path not in allowed or path in seen: raise ValueError('补全结果试图改写非缺失字段或重复字段：'+str(path))
        seen.add(path);parts=[p.replace('~1','/').replace('~0','~') for p in path.lstrip('/').split('/')]
        try:
            current=out
            for key in parts[:-1]:
                if isinstance(current,list): current=current[int(key)]
                elif isinstance(current,dict): current=current.setdefault(key,{})
                else: raise ValueError('补修路径的父容器无效：'+path)
            if isinstance(current,list): current[int(parts[-1])]=patch['value']
            elif isinstance(current,dict): current[parts[-1]]=patch['value']
            else: raise ValueError('补修路径的父容器无效：'+path)
        except (KeyError,IndexError,TypeError,OverflowError) as error:
            raise ValueError('补修路径无效：'+path) from error
    return out

async def compile_saved(engine,identity,index,ai,instructions,request,assets,media,axis):
    from . import prompt_compiler
    assets=actual_assets(engine,assets)
    p=engine.store.get('project',identity);clip=p['clips'][index];bindings=p.get('character_bindings',{})
    context=fingerprint({'request':request,'assets':[asset_key(a) for a in assets],'bindings':bindings})
    cache=copy.deepcopy(mapping(p.get('prompt_content_cache')))
    if p.get('series_id'):
        shared=mapping(engine.store.get('series',p['series_id']).get('prompt_content_cache'))
        for key in ('assets','voices'): cache[key]={**mapping(shared.get(key)),**mapping(cache.get(key))}
    saved=mapping(clip.get('prompt_content'))
    # The compiler's new timing bookkeeping does not invalidate an otherwise
    # identical failed/partial API response. Compare real old request contexts
    # rather than accepting arbitrary stale content or ignoring asset changes.
    prior_contexts=set()
    payload=json.loads(request)
    if payload.get('compiler_contract')==prompt_compiler.VERSION:
        for old_version in (2,3,4,5):
            prior_payload={**payload,'compiler_contract':old_version}
            prior_request=json.dumps(prior_payload,ensure_ascii=False)
            prior_contexts.add(fingerprint({'request':prior_request,
                'assets':[asset_key(a) for a in assets],'bindings':bindings}))
    compiler_upgrade_reuse=saved.get('context') in prior_contexts
    timing_reuse=(saved.get('timing_reuse') and saved.get('status')=='compiled_content'
                  and saved.get('timing_redo_feedback','')==clip.get('redo_feedback','')
                  and bool(clip.get('compiled_asset_versions')) and can_reuse(engine,clip,assets))
    upgrade_reuse=(clip.get('prompt_en') and clip.get('prompt_compiler_version') in (2,3,4,5)
                   and saved.get('status')=='compiled_content' and bool(clip.get('compiled_asset_versions'))
                   and can_reuse(engine,clip,assets))
    if (saved.get('context')==context or compiler_upgrade_reuse or timing_reuse or upgrade_reuse) and 'result' in saved:
        result=saved['result']
        received=saved.get('received_result',copy.deepcopy(result))
        received_format_error=saved.get('received_format_error','')
    else:
        payload=json.loads(request)
        payload['saved_reference_descriptions']={f'ref_{i+1}':cached_pair(mapping(cache.get('assets')).get(asset_key(a))) or None for i,a in enumerate(assets)}
        payload['saved_voices']={line['speaker']:cached_pair(mapping(cache.get('voices')).get(voice_key(line['speaker'],assets,bindings))) or None for line in clip.get('dialogue',[])}
        engine.paused(identity)
        received_format_error=''
        with measure('prompt_api'):
            try:
                result=await ai.text(instructions+'\n复用saved_reference_descriptions和saved_voices中已保存的固定描述，保持角色一致。',json.dumps(payload,ensure_ascii=False),engine.images(assets))
            except ContentFormatError as error:
                # HTTP/network/auth/refusal failures remain real API failures.
                # Invalid JSON has no reusable parsed fields, so fill only the
                # required content from the unchanged production context.
                result={};received_format_error=str(error)
        received=copy.deepcopy(result)
        # Persist even malformed content before validation or another HTTP call.
        engine.clip_set(identity,index,prompt_content={'version':2,'context':context,'result':result,'received_result':received,
                          'received_format_error':received_format_error,'status':'received','repair_attempts':0})
    repairs=0;limit=format_retries(ai.config) if 'format_retry_limit' in ai.config else max(1,int(ai.config.get('retry_limit',0)));last_repair_error=received_format_error
    while True:
        # Generated bookkeeping belongs to the program. This never changes
        # original dialogue, assets, visual prose or an authored draft.
        if not isinstance(result,dict): result={}
        result=recover_structure(result,clip,axis)
        result,missing=normalize(result,assets,clip,bindings,cache,complete=False)
        problems=issues(result,assets,clip)
        fields=repair_paths(missing+[path for path,_ in problems])
        state={'version':2,'context':context,'result':result,'received_result':received,'received_format_error':received_format_error,
               'missing':missing,'invalid_fields':problems,
               'fields_to_repair':fields,'status':'needs_fields' if fields else 'validated_content',
               'repair_attempts':repairs,'last_repair_error':last_repair_error}
        engine.clip_set(identity,index,prompt_content=state)
        if not fields:
            output=prompt_compiler.compile_prompt(result,assets,media,clip,axis,bindings)
            output['compiled_asset_versions']=[asset_key(a) for a in assets]
            output['compiler_warnings']=list(dict.fromkeys(output.get('compiler_warnings',[])+result.get('_content_warnings',[])))
            # Unvalidated responses must never poison the shared identity cache.
            values=cache_values(result,assets,clip,bindings)
            for kind,owner in [('project',identity)]+([('series',p['series_id'])] if p.get('series_id') else []):
                def save(record):
                    cache_record=copy.deepcopy(mapping(record.get('prompt_content_cache')))
                    for key,entries in values.items(): cache_record[key]={**mapping(cache_record.get(key)),**entries}
                    record['prompt_content_cache']=cache_record
                engine.store.update(kind,owner,save)
            engine.clip_set(identity,index,prompt_content={**state,'status':'compiled_content'})
            return output
        if repairs>=limit:
            if problems: raise InvalidContent(problems)
            raise MissingContent(missing)
        engine.paused(identity)
        engine.set(identity,phase=f'仅补修第{index+1}段的{len(fields)}个字段，保留有效内容')
        partial={'fields_to_fill':fields,'fields_to_repair':fields,'validation_errors':problems,
                 'last_repair_error':last_repair_error,'saved_result':result,'production_context':json.loads(request)}
        repairs+=1
        engine.clip_set(identity,index,prompt_content={**state,'status':'repairing','repair_attempts':repairs})
        try:
            with measure('prompt_field_repair',str(index+1)):
                response=await ai.text('你只补修给定JSON路径缺失或校验错误的字段。严禁修改路径以外的有效内容、剧本原句、说话人、真实素材绑定或任务总时长。只返回JSON {"patches":[{"path":"指定的待修路径","value":"该字段的正确内容"}]}。嵌套路径使用JSON Pointer。保留所有有效镜头表现和摄影描述；对白关联使用本任务原dialogue数组的0起始索引，按原顺序完整出现一次。镜头时间以本任务保留内容0秒开始，连续覆盖duration_seconds；不计入续接引导。中文对照缺失不是本次补全目标。',json.dumps(partial,ensure_ascii=False),engine.images(assets))
            result=merge_patch(result,response,fields)
            last_repair_error=''
        except (ValueError,ContentFormatError) as error:
            # A malformed patch consumes one bounded repair attempt, but it
            # cannot mutate good content or strand a cached response forever.
            last_repair_error=str(error)
        engine.clip_set(identity,index,prompt_content={**state,'result':result,'status':'repaired' if not last_repair_error else 'needs_fields',
                          'repair_attempts':repairs,'last_repair_error':last_repair_error})
