"""Draft-only planning and preparation. Rendering/recovery uses unchanged Engine methods."""
import copy
import hashlib
import secrets
from contextvars import ContextVar
from .. import workflows, dialogue_timing
from ..domain import media_state, validate_rewrite
from ..production import NO_SUBTITLES, binding_ids
from ..telemetry import measure
from . import compiler, schema

active = ContextVar('h3_production_draft_active', default=False)

def human_feedback(clip):
    """Only text the user typed in the redo dialog may reach the H3/image prompt.

    The app's own automatic-retry diagnosis is Chinese and would be read aloud by H3 as gibberish (F3),
    so it stays in the project record and is never put into a prompt.
    """
    return '' if clip.get('redo_feedback_auto') else str(clip.get('redo_feedback') or '').strip()

def materialize(project):
    d=project['production_draft'];mapping=project['draft_asset_bindings']
    return schema.bind_episode(d,d['episodes'][0],mapping)

def compiled(project,clip,assets,media,axis):
    d=project['production_draft'];mapping=project['draft_asset_bindings']
    by_id={mapping[a['key']]:a for a in d['assets']}
    keys={a['id']:f'ref_{i+1}' for i,a in enumerate(assets)}
    descriptions={}
    for asset in assets:
        item=by_id.get(asset['id'])
        if item: desc=item['description']
        elif asset['id']==clip.get('frame_asset_id'):
            desc={'en':'The adopted opening composition for this shot. Preserve the supplied character identities, clothing and environment.', 'zh':'本镜头采用的开场构图，保留提供的人物身份、服装和环境。'}
        else: raise ValueError('制作稿缺少真实输入素材的描述：'+asset.get('label',asset['id']))
        descriptions[keys[asset['id']]]=copy.deepcopy(desc)
    def replace(value):
        def bind(match):
            actual=mapping.get(match[1]);key=keys.get(actual)
            if not key: raise ValueError('制作稿视觉引用不在实际输入中：'+match[1])
            return '[['+key+']]'
        return schema.TOKEN.sub(bind,value)
    shots=copy.deepcopy(clip['shots'])
    for shot in shots:
        for k in ('visual_en','visual_zh'): shot[k]=replace(shot[k])
    result={'reference_descriptions':descriptions,
            'voices':{line['speaker']:d['characters'][line['speaker']]['voice_description'] for line in clip['dialogue']},
            'shots':shots,'sound_en':replace(clip['sound_en']),'sound_zh':replace(clip['sound_zh'])}
    out=compiler.compile_prompt(result,assets,media,clip,axis,project.get('character_bindings',{}))
    feedback='\n'.join(x for x in (project.get('instructions','').strip(),human_feedback(clip)) if x)
    if feedback:
        # Verbatim diagnostic feedback, without an extra design/translation request.
        import re
        feedback=re.sub(r'<[^>]*>|\[\[.*?\]\]|\(S\d+\)','',feedback)[:8000]
        for key,label in (('prompt_en','Production correction (retain the authored dialogue and timings): '),('prompt_zh','重做修正（保留制作稿对白与时间）：')):
            out[key]=out[key].replace('detailed_description:\n','detailed_description:\n'+label+feedback+'\n',1)
    out['draft_compiler_version']=1
    return validate_rewrite(out,media,clip['dialogue'])

def validate_compilation(project,catalog,workflow):
    """Dry-compile every task with a synthetic opening image before any generation."""
    plan=materialize(project);known={a['id']:a for a in catalog}
    for i,source_clip in enumerate(plan['segments']):
        clip=copy.deepcopy(source_clip)
        frame=clip.get('frame_asset_id') or '__draft_opening__'
        opening=known.get(frame,{'id':frame,'kind':'image','role':'scene','label':'开场图'})
        assets=[opening]+[known[k] for k in clip['asset_ids'] if k!=frame]
        if workflow['media_mode']=='single_image': assets=[opening]
        media=media_state([a['id'] for a in assets if a['kind']=='image'],[a['id'] for a in assets if a['kind']=='video'],[a['id'] for a in assets if a['kind']=='audio'])
        clip['frame_asset_id']=frame
        try: compiled(project,clip,assets,media,workflows.timing(workflow,clip,plan['segments'][i-1] if i else None))
        except ValueError as e: schema.fail(f'片段[{i}]',str(e))
    return plan

async def plan(engine,identity,cfg):
    p=engine.store.get('project',identity)
    if p.get('plan'): return
    engine.paused(identity)
    with measure('draft_compile','分镜直接读取'):
        result=materialize(p);clips=[]
        for s in result['segments']:
            dialogue_timing.prepare(p,s,cfg)
            seed=s.get('seed',secrets.randbits(63) if cfg['seed_mode']=='random' else cfg['seed'])
            if not p['workflow_snapshot']['bindings'].get('seed'): seed=None
            clips.append({**s,'status':'pending','seed':seed,'generation':1,'versions':[]})
        engine.set(identity,plan=result,clips=clips,planned_duration_seconds=sum(c['duration_seconds'] for c in clips))
    engine.store.event(identity,f'制作稿已直接读取{len(clips)}个任务；分镜、对白、提示词均不调用创作API。')

async def prepare(engine,identity,index,ai,cfg):
    engine.paused(identity);p=engine.store.get('project',identity);clip=p['clips'][index]
    if not clip.get('frame_asset_id'):
        aid=clip.get('image_asset_id') or hashlib.sha256(f'{identity}:clip:{index}:v{clip["generation"]}'.encode()).hexdigest()[:40]
        try: asset=engine.store.get('asset',aid)
        except KeyError: asset=None
        if asset and engine.files.asset_path(asset).is_file():
            engine.clip_set(identity,index,frame_asset_id=aid,image_asset_id=aid)
            p=engine.store.get('project',identity);clip=p['clips'][index]
    if any(clip.get(key) for key in dialogue_timing.COMMITTED): return
    p=engine.prepare_dialogue_timing(identity,index,cfg);clip=p['clips'][index]
    if clip.get('prompt_en') and clip.get('prompt_compiler_version')==compiler.VERSION:
        if clip.get('state_reference_source'): await engine.state_reference(identity,index,cfg)
        media,assets=engine.clip_media(p,clip)
        from ..prompt_content import can_reuse
        if can_reuse(engine,clip,assets):
            try:
                validate_rewrite({'prompt_en':clip['prompt_en'],'prompt_zh':clip.get('prompt_zh','')},media,clip['dialogue'])
            except ValueError as error:
                def clear_prompt(record):
                    item=record['clips'][index]
                    for key in ('prompt_en','prompt_zh','prompt_compiler_version','compiled_asset_versions'):
                        item.pop(key,None)
                engine.store.update('project',identity,clear_prompt)
                engine.store.event(identity,f'制作稿第{index+1}段已保存提示词需要本地重组，保留素材和进度：'+str(error))
                p=engine.store.get('project',identity);clip=p['clips'][index]
            else:return
    engine.clip_set(identity,index,status='preparing')
    if not clip.get('frame_asset_id'):
        engine.set(identity,phase=f'制作稿：准备第{index+1}段开场图')
        refs=[engine.store.get('asset',aid) for aid in clip['image_reference_ids']]
        if not refs: refs=[a for a in engine.clip_assets(p,clip) if a['kind']=='image']
        ref_paths=[engine.files.asset_path(a) for a in refs]
        state=await engine.state_reference(identity,index,cfg)
        if state:
            pinned=set(binding_ids(p.get('character_bindings',{})))
            fixed=[engine.files.asset_path(a) for a in refs if a['id'] in pinned]
            others=[r for r in ref_paths if r not in fixed]
            ref_paths=list(dict.fromkeys(fixed+[state]+others))
        wf=(p.get('image_workflow_snapshots') or {}).get('reference')
        capacity=min(8,wf.get('metadata',{}).get('reference_capacity',8)) if wf else 8
        if len(ref_paths)>capacity: raise ValueError(f'制作稿第{index+1}段需要{len(ref_paths)}张生图参考，当前工作流容量为{capacity}；请修改制作稿或工作流，不会丢弃参考。')
        prompt=clip['image_prompt']+'\nProduction style: '+p['plan']['style']+'\n'+p.get('instructions','')+'\n'+NO_SUBTITLES
        if human_feedback(clip): prompt+='\nCorrection: '+human_feedback(clip)
        if state: prompt+='\nThe previous adopted frame defines positions and props only. Follow the new composition; preserve identity from fixed character references. Do not copy malformed anatomy or text.'
        aid=clip.get('image_asset_id') or hashlib.sha256(f'{identity}:clip:{index}:v{clip["generation"]}'.encode()).hexdigest()[:40]
        engine.clip_set(identity,index,image_asset_id=aid)
        try: asset=engine.store.get('asset',aid)
        except KeyError:
            blob=await engine.generate_image(identity,ai,cfg,aid,prompt,ref_paths)
            asset=engine.files.write_asset(engine.store,f'片段_{index+1:03d}_开场图_v{clip["generation"]}.png',blob,{'label':clip['title'],'role':'scene','generated':True},id=aid)
        seed=None
        for kind in ('quality_asset','image_job'):
            try: seed=engine.store.get(kind,aid).get('seed');break
            except KeyError: pass
        engine.clip_set(identity,index,frame_asset_id=asset['id'],image_seed=str(seed) if seed is not None else None)
    engine.paused(identity);p=engine.store.get('project',identity);clip=p['clips'][index]
    media,assets=engine.clip_media(p,clip)
    from ..prompt_content import actual_assets, asset_key
    assets=actual_assets(engine,assets)
    axis=workflows.timing(p['workflow_snapshot'],clip,p['clips'][index-1] if index else None)
    with measure('draft_compile',str(index+1)):
        result=compiled(p,clip,assets,media,axis)
        result['compiled_asset_versions']=[asset_key(a) for a in assets]
    engine.clip_set(identity,index,**result,status='ready')
    engine.store.event(identity,f'第{index+1}段提示词已由制作稿本地编译；真实素材编号与原句时间已绑定，创作API调用0次。')
