"""Draft-only compiler. Forked contract; exact imported dialogue times, no AI."""
import copy
import math
import re
from ..domain import validate_rewrite
from ..dialogue_plan import line_seconds, budget, LEAD, TAIL
from ..production import NO_SUBTITLES
from ..dialogue_timing import shot_label
from ..dialogue_language import tag as language_tag, resolve

VERSION=1003
TOKEN=re.compile(r'\[\[(ref_\d+)\]\]')
RAW_REF=re.compile(r'<(Picture|Video|Audio|Subject)\s+\d+>',re.I)



def request_references(assets):
    return [{'key':f'ref_{i+1}',**{k:a.get(k,'') for k in ('id','kind','role','label','speaker','description','name')}} for i,a in enumerate(assets)]


def authoritative_audio(assets,dialogue,bindings,store):
    """Keep only current speakers' voice references; inject fixed pins last."""
    speakers=list(dict.fromkeys(x['speaker'] for x in dialogue))
    pinned={name:b.get('voice_id') for name,b in bindings.items() if b.get('voice_id')}
    pin_names={identity:{name for name,value in pinned.items() if value==identity} for identity in pinned.values()}
    result=[]
    for asset in assets:
        if asset['kind']=='audio':
            owners=pin_names.get(asset['id'])
            if owners:
                if not owners.intersection(speakers):continue
                result.append(asset);continue
            name=asset.get('speaker')
            if not name and asset.get('role')=='voice':name=asset.get('label')
            if name and (name not in speakers or (pinned.get(name) and pinned[name]!=asset['id'])):continue
        result.append(asset)
    for name in speakers:
        if pinned.get(name):
            asset=copy.deepcopy(store.get('asset',pinned[name]));asset['speaker']=name
            if asset.get('archived') or asset['kind']!='audio':raise ValueError('角色固定声音已失效：'+name)
            result=[a for a in result if a['id']!=asset['id']]+[asset]
    return result


def compile_prompt(result,assets,media,clip,axis,bindings=None):
    if not isinstance(result,dict):raise ValueError('提示词编译必须返回JSON对象。')
    from ..prompt_content import normalize
    result,_=normalize(result,assets,clip,bindings)
    refs=request_references(assets);descriptions=result.get('reference_descriptions')
    if not isinstance(descriptions,dict) or set(descriptions)!={x['key'] for x in refs}:
        raise ValueError('reference_descriptions必须逐项使用本次references的key，不能新增、遗漏或猜测编号。')
    voices=result.get('voices',{})
    if not isinstance(voices,dict):raise ValueError('voices须为按实际说话人姓名索引的对象。')
    lines=clip.get('dialogue',[]);speakers=list(dict.fromkeys(d['speaker'] for d in lines))
    speaker_ids={name:f'(S{i+1})' for i,name in enumerate(speakers)}
    bindings=bindings or {}
    fixed_names={a:name for name,b in bindings.items() for a in b.get('image_ids',[])}
    def voice_owners(asset):
        pinned=[name for name,b in bindings.items() if b.get('voice_id')==asset['id'] and name in speakers]
        if pinned:return pinned
        name=asset.get('speaker') or (asset.get('label') if asset.get('role')=='voice' else '')
        return [name] if name else []
    counters={'image':0,'video':0,'audio':0};media_ids={};subjects={};subject_names={};definitions=[];retention=[];zh_defs=[];zh_retention=[];warnings=list(result.get('_content_warnings',[]));bindings_map=[]
    def plain(value,label):
        if not isinstance(value,str) or not value.strip():raise ValueError(label+'须为非空文字。')
        if '<d>' in value or re.search(r'\(S\d+\)',value):raise ValueError(label+'中不要自行添加对白标签或说话人编号。')
        # Voice binding is reconstructed below from actual assets. A stray raw
        # Audio tag from model examples cannot create a nonexistent input.
        def unmanaged(match):
            if match.group(1).lower()=='audio':
                warnings.append('已由真实音色绑定替换AI自写的音频编号')
                return "the current speaker's voice as defined in subject_definitions"
            raise ValueError(label+'须用[[ref_编号]]表示视觉引用，禁止自行填写H3编号。')
        return RAW_REF.sub(unmanaged,value).strip()
    def pair(value,label):
        if not isinstance(value,dict):raise ValueError(label+'须包含en和zh。')
        return plain(value.get('en'),label+'.en'),plain(value.get('zh'),label+'.zh')
    for asset,ref in zip(assets,refs):
        kind=asset['kind'];counters[kind]+=1
        media_id=f'<{ {"image":"Picture","video":"Video","audio":"Audio"}[kind]} {counters[kind]}>'
        media_ids[ref['key']]=media_id
        bindings_map.append({'reference':media_id,'asset_id':asset['id'],'name':asset.get('name') or asset.get('relative_path') or asset.get('label','')})
        en,zh=pair(descriptions[ref['key']],ref['key'])
        if TOKEN.search(en) or TOKEN.search(zh):raise ValueError('素材自身描述不要嵌套引用。')
        name=fixed_names.get(asset['id']) or (asset.get('speaker') or asset.get('label')) if asset.get('role')=='character' or asset['id'] in fixed_names else None
        if kind!='audio':
            key=('character',name) if name else ('asset',asset['id'])
            if key not in subjects:subjects[key]=f'<Subject {sum(isinstance(k,tuple) for k in subjects)+1}>'
            tag=subjects[key]
            if name:subject_names[name]=tag
            subjects[ref['key']]=tag
            definitions.append(f'{tag}: {en} Reference: {media_id}.')
            retention.append(f'{tag}: '+('fully_preserved - keep the same character identity; pose and framing follow the new storyboard.' if name else 'partially_preserved - preserve the referenced environment, objects and visual style; actions follow this target shot.'))
            zh_defs.append(f'{tag}：{zh} 参考来源：{media_id}。')
            zh_retention.append(f'{tag}：'+('完整保留同一人物身份；姿势和构图遵循新分镜。' if name else '部分保留参考环境、物体和视觉风格；动作遵循本镜头。'))
        else:
            owners=voice_owners(asset)
            if owners:
                if any(name not in speaker_ids for name in owners):raise ValueError('声音素材不属于本段说话人：'+str(owners))
                people=', '.join(subject_names.get(name,name)+' '+speaker_ids[name] for name in owners)
                definitions.append(f'{media_id} is the voice-timbre reference for {people}. {en} Do not copy the reference recording\'s words or signal.')
                zh_defs.append(f'{media_id} 是 {people} 的音色参考。{zh} 不复制参考录音中的台词或信号。')
            else:
                definitions.append(f'{media_id}: ambient sound reference only. {en}')
                zh_defs.append(f'{media_id}：仅作为环境声音参考。{zh}')
            retention.append(f'{media_id}: reference - retain only the intended timbre or ambient characteristics, not source dialogue or music.')
            zh_retention.append(f'{media_id}：参考——仅保留所需音色或环境声音特征，不复制原对白或音乐。')
    available_voices={name for a in assets if a['kind']=='audio' for name in voice_owners(a)}
    for name in speakers:
        if name not in voices:raise ValueError('缺少实际说话人的声音描述：'+name)
        en,zh=pair(voices[name],name+'声音')
        definitions.append(f'{speaker_ids[name]} is {name}. {en}'+(' Match this speaker\'s assigned audio reference.' if name in available_voices else ' This speaker has no audio reference; generate the voice described here consistently.'))
        zh_defs.append(speaker_ids[name]+' 是 '+name+'。'+zh+(' 使用分配给此说话人的音频参考。' if name in available_voices else ' 此人无音频参考，按上述描述一致地生成声音。'))
    def render(text,label):
        text=plain(text,label)
        def token(match):
            key=match[1]
            if key not in media_ids:raise ValueError('描述引用了不存在的素材key：'+key)
            return subjects.get(key,media_ids[key])
        value=TOKEN.sub(token,text)
        if '[[' in value or ']]' in value:raise ValueError('素材占位格式无效，请使用[[ref_1]]格式。')
        return value
    shots=result.get('shots')
    if not isinstance(shots,list) or not 1<=len(shots)<=12:raise ValueError('shots须为1至12个镜头的列表。')
    duration=float(clip['duration_seconds']);cursor=0.;seen=[];details=[];zh_shots=[];guide=float(axis['new_content_start_seconds']);dialogue_windows=[]
    for n,shot in enumerate(shots,1):
        if not isinstance(shot,dict):raise ValueError('镜头项须为对象。')
        try:start=float(shot['start_seconds']);end=float(shot['end_seconds'])
        except (KeyError,TypeError,ValueError):raise ValueError('镜头须提供有效的开始和结束秒数。')
        if not all(math.isfinite(x) for x in (start,end)) or abs(start-cursor)>1/24+.001 or end<=start or end>duration+1/24+.001:
            raise ValueError('shots须按时间顺序连续覆盖本段保留时长，不能超过duration_seconds。')
        cursor=end;indices=shot.get('dialogue_indices',[])
        if not isinstance(indices,list) or any(type(i) is not int or i<0 or i>=len(lines) for i in indices):raise ValueError('dialogue_indices须使用原台词0起始索引。')
        seen+=indices
        visual=render(shot.get('visual_en'),'visual_en');zh=render(shot.get('visual_zh'),'visual_zh')
        block=f'{shot_label(n,guide+start)} {visual}'
        zh_block=f'[Shot {n}] {guide+start:.3f}–{guide+end:.3f}秒。{zh}'
        if indices:
            block+=' Speech follows the exact authored time windows; gestures and gaze changes happen concurrently, without a silent preamble. Natural speech, never accelerated.'
            zh_block+=' 按制作稿指定时间开口；手势和目光变化与说话并行，不先安排无声前戏。保持自然语速，不加速。'
            for index in indices:
                line=lines[index];at=float(line['start_seconds']);stop=float(line['end_seconds'])
                if at<start-1e-6 or stop>end+1e-6 or stop<=at:
                    raise ValueError('制作稿对白时间不在所属镜头内。')
                dialogue_windows.append({'index':index,'speaker':line['speaker'],'text':line['text'],'language':resolve(line,clip),
                    'start_seconds':at,'end_seconds':stop,'generated_start_seconds':guide+at,'generated_end_seconds':guide+stop})
                person=subject_names.get(line['speaker'],line['speaker'])+' '+speaker_ids[line['speaker']]
                block+=f' From {guide+at:.3f}s to {guide+stop:.3f}s, {person} says <d>[{language_tag(line,clip)}] {line["text"]}</d>.'
                zh_block+=f' 从{guide+at:.3f}秒到{guide+stop:.3f}秒，{person} 说 <d>[{language_tag(line,clip)}] {line["text"]}</d>。'
            block+=f' After the final complete word, allow a natural release and hold through {guide+end:.3f}s; the sentence must not spill into alignment frames.'
            zh_block+=f' 完整说完最后一个字后自然收尾，并保持到{guide+end:.3f}秒；句子不能延伸到对齐补帧中。'
        details.append(block);zh_shots.append(zh_block)
    if seen!=list(range(len(lines))):raise ValueError('dialogue_indices必须按原顺序完整出现一次，不能遗漏、重复或交换台词。')
    if abs(cursor-duration)>1/24+.001:raise ValueError('镜头时间未覆盖完整保留时长。')
    sound=render(result.get('sound_en'),'sound_en');sound_zh=render(result.get('sound_zh'),'sound_zh')
    mode='reference generation'+(' + audio reference' if counters['audio'] else '')
    opening=''
    if clip.get('frame_asset_id'):opening=f'At {guide:.3f}s, the new content follows the opening composition from <Picture 1>. '
    detail=f'{NO_SUBTITLES}\n{opening}The interval before {guide:.3f}s is continuation guidance only, with no new dialogue. All new content ends by {guide+duration:.3f}s; later alignment frames only hold the final state.\n\n'+'\n\n'.join(details)
    sections={'subject_definitions':'\n'.join(definitions),'summary':f'[{mode}] A {duration:.3f}-second dramatic scene preserving the supplied identities and storyboard.','retention_analysis':'\n'.join(dict.fromkeys(retention)),'detailed_description':detail,'overall_soundscape':sound+' Spoken dialogue and natural ambience only.','non_diegetic_music':'N/A'}
    prompt='\n\n'.join(name+':\n'+value for name,value in sections.items())
    zh_prefix='不生成字幕、说明文字或画面中的对白文字；台词仅作为声音。\n'
    if clip.get('frame_asset_id'):zh_prefix+=f'从{guide:.3f}秒开始，新内容遵循 <Picture 1> 的开场构图。'
    zh_prefix+=f'{guide:.3f}秒前仅为续接引导，不安排新对白。所有新内容在{guide+duration:.3f}秒前完成，之后的对齐帧只保持最终状态。\n\n'
    zh_sections={'subject_definitions':'\n'.join(zh_defs),'summary':f'[{mode}] 一段{duration:.3f}秒的戏剧场景，保留提供的人物身份并遵循分镜。','retention_analysis':'\n'.join(dict.fromkeys(zh_retention)),'detailed_description':zh_prefix+'\n\n'.join(zh_shots),'overall_soundscape':sound_zh+' 仅保留对白和自然环境音。','non_diegetic_music':'无背景音乐。'}
    out={'prompt_en':prompt,'prompt_zh':'\n\n'.join(name+':\n'+value for name,value in zh_sections.items()),'compiled_media_bindings':bindings_map,'compiler_warnings':list(dict.fromkeys(warnings)),'prompt_compiler_version':VERSION,'dialogue_windows':dialogue_windows}
    return validate_rewrite(out,media,lines)
