"""Opt-in production drafts. The two original modes remain in their own modules."""
MODE = 'production_draft'
SCHEMA = 'h3-production-draft'
VERSION = 1
