"""New endpoints only: offline preview and observed call evidence."""
import json
from collections import Counter
from pathlib import Path
from aiohttp import web
from .. import api_diagnostics
from ..domain import safe_id
from .service import is_draft

STAGES={'planning_api':'创作：分集/分镜/剧情记录','prompt_api':'创作：提示词',
        'prompt_field_repair':'创作：仅补必要缺项',
        'image_review':'图片审核','video_review_api':'视频审核','dialogue_asr':'音频识别',
        'image_generation':'图片生成'}

def evidence(store,kind,identity):
    record=store.get(kind,identity)
    if not is_draft(record): raise ValueError('此记录不是已编排制作稿。')
    records={identity:record}
    if kind=='series':
        for pid in record['project_ids']:
            try: records[pid]=store.get('project',pid)
            except KeyError: pass
    report=api_diagnostics.export(store,kind,identity)
    counts=Counter();rows=[]
    for request in report['requests']:
        intervals=records.get(request['owner_id'],{}).get('timing_intervals',[])
        matches=[r for r in intervals if r['stage'] in STAGES and r['start']<=request['started_at']<=r['end']]
        stage=min(matches,key=lambda r:r['end']-r['start'])['stage'] if matches else None
        purpose=STAGES.get(stage,'进行中或缺少完整时间记录，暂未分类')
        counts[purpose]+=1;rows.append({**request,'purpose':purpose})
    report.update(mode='已编排制作稿',draft_sha256=record.get('draft_sha256'),
                  requests=rows,api_counts_by_purpose=dict(counts),api_requests_total=len(rows),
                  creative_requests_recorded=sum(counts[k] for k in counts if k.startswith('创作：')),
                  unclassified_requests=counts.get('进行中或缺少完整时间记录，暂未分类',0),
                  blocked_creative_attempts=sum(r.get('draft_api_guard_blocks',0) for r in records.values()),
                  local_compilations=sum(r.get('timings',{}).get('draft_compile',{}).get('calls',0) for r in records.values()),
                  skipped_stages=['分集','写剧本','拆分镜','写/翻译提示词','格式修正','追加剧情总结'],
                  note='计数来自实际记录的HTTP请求，包含重试；ComfyUI提交/等待与本地编译不计入模型API。进行中的请求待阶段结束后再分类。图片生成只有明确允许且选用API时才使用模型API。')
    return report

async def handle(app,parts,method,body):
    if parts==['production-draft','preview'] and method=='POST':
        previous=app.series.record(safe_id(body['series_id'])) if body.get('series_id') else None
        values=app.series.prepared(body,previous)
        d,policy,wf,snapshot,mapping,catalog,generated,bindings,durations,allow,adopted=values
        return web.json_response({'ok':True,'episodes':len(d['episodes']),'tasks':sum(len(e['segments']) for e in d['episodes']),
            'seconds':sum(durations),'new_images':len(generated),'asset_bindings':mapping,
            'image_backend':('当前设置中的生图API（已允许）' if allow and app.store.settings()['image_provider']=='api' else '本地ComfyUI／已有图片'),
            'creative_api_calls':0,'adopted_declarations':adopted})
    if len(parts)==4 and parts[:2]==['production-draft','report'] and method=='GET':
        kind=parts[2]
        if kind not in {'series','project'}: raise web.HTTPNotFound()
        report=evidence(app.store,kind,safe_id(parts[3]))
        return web.Response(text=json.dumps(report,ensure_ascii=False,indent=2),content_type='application/json',headers={'Content-Disposition':'attachment; filename="production_draft_api_evidence.json"'})
    if len(parts)==3 and parts[:2]==['production-draft','examples'] and method=='GET':
        names={'example.json':'example.json','guide.md':'制作稿规范.md'}
        if parts[2] not in names: raise web.HTTPNotFound()
        return web.FileResponse(Path(__file__).parent/'examples'/names[parts[2]],headers={'Content-Disposition':'attachment; filename="'+parts[2]+'"'})
    raise web.HTTPNotFound()
