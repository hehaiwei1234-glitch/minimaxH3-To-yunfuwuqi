"""Explicit bindings for user-tested image graphs, independent of H3 video graphs."""
from __future__ import annotations
import copy
import hashlib
import json
import time
import uuid
from . import workflows
from .domain import safe_id

def api_graph(value):return workflows.api_graph(value,require_h3=False)

def preview(value):
    graph=api_graph(value)
    return {'graph':graph,'fields':workflows.fields(graph),'suggested':suggest_bindings(graph),
            'nodes':[{'id':nid,'title':n.get('_meta',{}).get('title') or n['class_type'],'class_type':n['class_type']} for nid,n in graph.items()]}

def suggest_bindings(graph):
    saves=[nid for nid,n in graph.items() if n['class_type']=='SaveImage']
    if len(saves)!=1:return {}
    output=saves[0];connected=workflows.upstream(graph,output)
    fields=[f for f in workflows.fields(graph) if f['node'] in connected]
    def unique(candidates):
        return {k:candidates[0][k] for k in ('node','input')} if len(candidates)==1 else None
    prompt=unique([f for f in fields if f['value_type']=='string' and f['input'] in {'prompt','positive_prompt','prompt_en'}])
    if not prompt:
        positive=set()
        for nid in connected:
            link=graph[nid]['inputs'].get('positive')
            if workflows.is_link(link):positive.update(workflows.upstream(graph,link[0]))
        prompt=unique([f for f in fields if f['node'] in positive and f['class_type']=='CLIPTextEncode' and f['input']=='text'])
    prefix=workflows.constant_ref(graph,output,'filename_prefix')
    bindings={k:v for k,v in {'prompt':prompt,'prefix':prefix,'seed':unique([f for f in fields if f['input'] in {'seed','noise_seed'} and f['value_type']=='number'])}.items() if v}
    refs=[{k:f[k] for k in ('node','input')} for f in fields if f['class_type']=='LoadImage' and f['input']=='image']
    batches=[{k:f[k] for k in ('node','input')} for f in fields if f['class_type']=='H3ADv1ImageReferenceBatch' and f['input']=='images_json']
    if len(batches)==1 and not refs:mode='batch';refs=batches
    else:mode='slots' if refs else 'none'
    suggestion={'bindings':bindings,'reference_mode':mode,'reference_bindings':refs,'output_node_id':output,'seed_mode':'original'}
    try:validate_bindings(graph,suggestion)
    except (ValueError,KeyError,TypeError):suggestion['complete']=False
    else:suggestion['complete']=True
    return suggestion

def validate_bindings(graph,body):
    bindings=copy.deepcopy(body.get('bindings',{}));seen=set()
    if not isinstance(bindings,dict) or set(bindings)-{'prompt','prefix','seed'}:raise ValueError('生图字段关联格式不正确。')
    output=str(body.get('output_node_id',''))
    if output not in graph or graph[output]['class_type']!='SaveImage':
        raise ValueError('本版本请使用标准SaveImage保存图片；其他保存节点需要另做适配。')
    connected=workflows.upstream(graph,output)
    def check(ref,role,number=False):
        if not isinstance(ref,dict) or set(ref)!={'node','input'}:raise ValueError('请明确关联生图字段：'+role)
        nid=ref['node'];field=ref['input']
        if nid not in connected or field not in graph[nid]['inputs']:raise ValueError('生图字段没有连接到所选图片输出：'+role)
        value=workflows.read(graph,ref)
        if workflows.is_link(value):raise ValueError('请关联存放常量的上游输入：'+role)
        if (nid,field) in seen:raise ValueError('一个生图输入不能关联两种用途。')
        seen.add((nid,field))
        if number:
            if isinstance(value,bool) or not isinstance(value,int) or not 0<=value<2**64:raise ValueError('生图Seed必须是有效整数。')
        elif not isinstance(value,str):raise ValueError('生图文字字段必须关联文字输入：'+role)
    for role in ('prompt','prefix'):check(bindings.get(role),role)
    # Recovery uses the actual SaveImage prefix. An unrelated string which is
    # merely upstream of the image output must never be treated as that prefix.
    expected={'node':output,'input':'filename_prefix'};visited=set()
    while workflows.is_link(workflows.read(graph,expected)):
        link=workflows.read(graph,expected);nid=link[0]
        if nid in visited or not graph[nid]['class_type'].startswith('Primitive') or 'value' not in graph[nid]['inputs']:
            raise ValueError('图片前缀请关联SaveImage.filename_prefix，或它直连的Primitive文字值；复杂前缀转换需适配。')
        visited.add(nid);expected={'node':nid,'input':'value'}
    if bindings['prefix']!=expected:raise ValueError('图片前缀没有关联到SaveImage的实际filename_prefix。')
    if bindings.get('seed'):check(bindings['seed'],'seed',True)
    else:bindings.pop('seed',None)
    mode=body.get('reference_mode','none');refs=copy.deepcopy(body.get('reference_bindings',[]))
    if mode not in {'none','slots','batch'}:raise ValueError('生图参考图片方式无效。')
    if not isinstance(refs,list) or len(refs)>8:raise ValueError('请最多关联8个参考图片输入。')
    if mode=='none' and refs:raise ValueError('纯文生图不能同时关联参考图输入。')
    if mode!='none' and not refs:raise ValueError('请关联参考图片输入。')
    if mode=='batch' and len(refs)!=1:raise ValueError('批量参考JSON只需关联一个输入。')
    for ref in refs:
        check(ref,'参考图片')
        node=graph[ref['node']]
        if mode=='slots' and (node['class_type']!='LoadImage' or ref['input']!='image'):
            raise ValueError('固定参考位置请关联标准LoadImage.image。')
        if mode=='batch' and (node['class_type']!='H3ADv1ImageReferenceBatch' or ref['input']!='images_json'):
            raise ValueError('批量参考请关联独立节点H3ADv1ImageReferenceBatch.images_json。')
    seed_mode=body.get('seed_mode','original')
    if seed_mode not in {'original','random'} or seed_mode=='random' and not bindings.get('seed'):raise ValueError('随机生图Seed需要关联Seed输入。')
    return {'bindings':bindings,'reference_mode':mode,'reference_bindings':refs,'output_node_id':output,'seed_mode':seed_mode,
            'metadata':{'reference_capacity':8 if mode=='batch' else len(refs),'accepts_empty_references':mode=='none'}}

def save(store,body):
    name=str(body.get('name','')).strip()
    if not name or len(name)>160:raise ValueError('请填写生图模板名称（最多160字）。')
    if body.get('tested_by_user') is not True and not body.get('configured_by_bundle'):raise ValueError('请先在ComfyUI跑通生图工作流。')
    graph=api_graph(body.get('graph'));contract=validate_bindings(graph,body)
    previous=store.get('image_workflow',safe_id(body['id'])) if body.get('id') else None
    if previous and body.get('expected_version')!=previous['version']:raise ValueError('生图模板版本已改变，请重新打开。')
    now=time.time();id=previous['id'] if previous else uuid.uuid4().hex
    return store.put('image_workflow',id,{'id':id,'name':name,'version':previous['version']+1 if previous else 1,
        'graph':graph,**contract,'sha256':hashlib.sha256(json.dumps(graph,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),
        'created_at':previous['created_at'] if previous else now,'updated_at':now,'checked_at':now,
        'tested_by_user':body.get('tested_by_user') is True,'configured_by_bundle':bool(body.get('configured_by_bundle'))})

def summary(record):
    return {**{k:copy.deepcopy(record[k]) for k in ('id','name','version','sha256','metadata','reference_mode','output_node_id','created_at')},'archived':bool(record.get('archived'))}

def snapshots(store,cfg):
    if cfg['image_provider']!='local':return None
    recovered={}
    for key,reference in (('image_workflow_id',False),('image_reference_workflow_id',True)):
        if not cfg[key]:
            candidates=[w for w in store.list('image_workflow') if not w.get('archived') and (w['reference_mode']!='none')==reference]
            if len(candidates)==1:recovered[key]=candidates[0]['id'];cfg[key]=candidates[0]['id']
    if recovered:store.save_settings(recovered)
    if not cfg['image_workflow_id']:raise ValueError('本地生图需要先选择“人物和场景基础图工作流”。')
    base=copy.deepcopy(store.get('image_workflow',cfg['image_workflow_id']))
    if base.get('archived'):raise ValueError('请重新选择未归档的基础图工作流。')
    if not base['metadata']['accepts_empty_references']:raise ValueError('基础图请使用不依赖参考图片的文生图工作流。')
    reference=None
    if cfg['image_reference_workflow_id']:
        reference=copy.deepcopy(store.get('image_workflow',cfg['image_reference_workflow_id']))
        if reference.get('archived'):raise ValueError('请重新选择未归档的镜头参考图工作流。')
        if reference['reference_mode']=='none':raise ValueError('镜头参考图工作流必须关联参考图片输入。')
    if cfg['generate_shot_images'] and not reference:
        raise ValueError('自动生成镜头开场图需要“带参考图工作流”，以复用人物和场景；请先导入并选择。')
    return {'base':base,'reference':reference}

def instantiate(record,prompt,references,prefix,seed=None):
    references=list(dict.fromkeys(references));mode=record['reference_mode']
    if not references and mode!='none':raise ValueError('带参考图工作流缺少参考图片；基础素材请使用文生图模板。')
    if references and mode=='none':raise ValueError('这份文生图工作流不能接收参考图，不能保证复用人物外观。')
    if len(references)>record['metadata']['reference_capacity']:
        raise ValueError(f'本次需要{len(references)}张参考图，工作流只关联了{record["metadata"]["reference_capacity"]}个位置。请增加参考位置或使用批量参考节点。')
    graph=copy.deepcopy(record['graph'])
    def write(ref,value):graph[ref['node']]['inputs'][ref['input']]=value
    write(record['bindings']['prompt'],prompt);write(record['bindings']['prefix'],prefix)
    if seed is not None and record['bindings'].get('seed'):write(record['bindings']['seed'],int(seed))
    if mode=='batch':write(record['reference_bindings'][0],json.dumps(references,ensure_ascii=False))
    elif mode=='slots':
        # Fixed LoadImage slots cannot be empty. Repeat the last reference in
        # spare slots; this behaviour is stated in the import form.
        for i,ref in enumerate(record['reference_bindings']):write(ref,references[min(i,len(references)-1)])
    return graph
