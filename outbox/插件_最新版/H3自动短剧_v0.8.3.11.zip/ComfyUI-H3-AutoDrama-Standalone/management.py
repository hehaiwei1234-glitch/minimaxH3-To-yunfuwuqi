"""Archive records and remove only owned, unshared files after a reviewed preview."""
from __future__ import annotations

import copy
import hashlib
import json
import os
import shutil
import time
import uuid
from pathlib import Path

from .domain import PREFIX, safe_id

KINDS = {'project', 'series', 'workflow', 'image_workflow', 'asset'}
ACTIVE = {'running', 'queued', 'pausing'}


def strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from strings(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            yield from strings(item)


class RecordsManager:
    def __init__(self, engine, series):
        self.engine = engine
        self.series = series
        self.store = engine.store
        self.files = engine.files

    def scope(self, kind, id):
        if kind not in KINDS:
            raise ValueError('不支持管理这种记录。')
        id = safe_id(id)
        record = self.store.get(kind, id)
        scope = {(kind, id)}
        if kind == 'series':
            scope.update(('project', p['id']) for p in self.store.list('project') if p.get('series_id') == id)
        return record, scope

    def idle(self, scope, deleting=False):
        owners = {id for kind, id in scope if kind in {'project', 'series'}}
        for kind, id in scope:
            record = self.store.get(kind, id)
            task = self.engine.tasks.get(id) or self.series.tasks.get(id)
            if kind in {'project', 'series'} and (record['status'] in ACTIVE or task and not task.done()):
                raise ValueError('请先暂停并等待当前任务结束，再归档或删除。')
            if kind == 'project' and record.get('series_id'):
                parent = self.store.get('series', record['series_id'])
                task = self.series.tasks.get(parent['id'])
                if parent['status'] in ACTIVE or task and not task.done():
                    raise ValueError('所属整剧正在执行，请先暂停整剧。')
            if deleting and kind == 'project':
                for clip in record.get('clips', []):
                    if not clip.get('output') and not clip.get('known_failed') and (
                            clip.get('submission_unknown') or clip.get('prompt_id') or
                            clip.get('status') in {'submitting', 'submitted'}):
                        raise ValueError('本项目还有可能正在ComfyUI执行的任务，请先继续核对原任务；提交结果不明时不能删除。')
        if deleting:
            for job in self.store.list('image_job'):
                if job['owner_id'] in owners and job['status'] in {'submitting', 'submitted'}:
                    raise ValueError('本项目还有未核对完成的生图任务，请先继续核对原任务后清理。')

    def archive(self, kind, id, archived):
        with self.store.lock:
            record, scope = self.scope(kind, id)
            self.idle(scope)
            writes = []
            for item_kind, item_id in scope:
                item = self.store.get(item_kind, item_id)
                if kind=='project':item.pop('archived_by_series',None)
                if kind == 'series' and item_kind == 'project':
                    if archived and item.get('archived'):
                        continue
                    if not archived and item.get('archived_by_series') != id:
                        continue
                    if archived:
                        item['archived_by_series'] = id
                    else:
                        item.pop('archived_by_series', None)
                item.update(archived=archived, updated_at=time.time())
                writes.append((item_kind, item_id, item))
            # Existing projects retain snapshots. A hidden template must not
            # remain a silent default for newly created projects.
            if archived and kind == 'image_workflow':
                cfg = self.store.settings()
                for key in ('image_workflow_id', 'image_reference_workflow_id'):
                    if cfg[key] == id:
                        cfg[key] = ''
                writes.append(('config', 'main', cfg))
            self.store.apply_changes(writes)
            return {'ok': True, 'archived': archived, 'records': len(scope)}

    @staticmethod
    def asset_ids(record):
        found = set(record.get('asset_ids', [])) | set(record.get('generated_assets', {}).values())
        for clip in record.get('clips', []):
            for item in [clip, *clip.get('versions', [])]:
                if item.get('frame_asset_id'):
                    found.add(item['frame_asset_id'])
                found.update(item.get('asset_ids', []))
                found.update(item.get('image_reference_ids', []))
        return found

    def uses_asset(self, asset, exclude=()):
        result = []
        aid = asset['id']
        relative = asset.get('relative_path', '')
        absolute = str(self.files.input / relative)
        records=getattr(self,'_asset_records',None)
        if records is None or getattr(self,'_asset_scope',None)!=set(exclude):
            records=[(kind,record) for kind in ('project','series') for record in self.store.list(kind)]
        for kind in ('project', 'series'):
            for item_kind,record in records:
                if item_kind!=kind:continue
                if (kind, record['id']) in exclude:
                    continue
                values = list(strings(record))
                if aid in self.asset_ids(record) or aid in values or relative and any(
                        value == absolute or value == relative or
                        relative in value and ('images' in value or 'videos' in value or 'audios' in value)
                        for value in values):
                    result.append({'kind': kind, 'id': record['id'], 'title': record.get('title', '')})
        return result

    def owned_file(self, path, root):
        path = Path(path).absolute()
        owned = root / PREFIX
        try:
            relative = path.relative_to(owned)
        except ValueError:
            raise ValueError('清理路径不属于本软件。')
        if not relative.parts or relative.parts[0] not in {'projects', 'images', 'assets'}:
            raise ValueError('清理路径不在软件生成文件目录内。')
        # Reject every symlink component, including the namespace root. Never
        # follow an output link into models or another user's directory.
        cursor = path
        while cursor != root:
            if cursor.is_symlink():
                raise ValueError('清理目录包含软链接，请先核对实际文件位置；软件不会沿链接删除。')
            cursor = cursor.parent
        if not path.resolve().is_relative_to(root.resolve()):
            raise ValueError('清理路径超出ComfyUI文件目录。')
        return path

    def output_used_elsewhere(self, path, scope):
        relative = path.relative_to(self.files.output).as_posix()
        descriptor = self.files.descriptor(path)
        if getattr(self,'_reference_cache',None) is not None:
            values,descriptors=self._reference_cache
            return str(path) in values or path.as_posix() in values or relative in values or (descriptor['subfolder'],path.name) in descriptors
        for kind in ('project', 'series', 'asset', 'image_job'):
            for record in self.store.list(kind):
                if (kind, record['id']) in scope:
                    continue
                if kind == 'image_job' and record.get('owner_id') in {id for k, id in scope}:
                    continue
                for value in strings(record):
                    if value == str(path) or value == relative or value == json.dumps(descriptor, ensure_ascii=False):
                        return True
                def references(value):
                    if isinstance(value, dict):
                        if value.get('filename') == path.name and value.get('subfolder', '') == descriptor['subfolder']:
                            return True
                        return any(references(v) for v in value.values())
                    if isinstance(value, (list, tuple)):
                        return any(references(v) for v in value)
                    return False
                if references(record):
                    return True
        return False

    def cache_output_references(self,scope):
        values=set();descriptors=set()
        owners={id for kind,id in scope if kind in {'project','series'}}
        def collect(value):
            if isinstance(value,str):
                values.add(value);values.add(value.replace('\\','/'))
                if value.endswith(' [output]'):
                    values.add(value[:-9]);values.add(value[:-9].replace('\\','/'))
                if value[:1] in {'[','{'}:
                    try:parsed=json.loads(value)
                    except (ValueError,TypeError):pass
                    else:collect(parsed)
            elif isinstance(value,dict):
                if isinstance(value.get('filename'),str):descriptors.add((value.get('subfolder',''),value['filename']))
                for item in value.values():collect(item)
            elif isinstance(value,(list,tuple)):
                for item in value:collect(item)
        for kind in ('project','series','asset','image_job'):
            for record in self.store.list(kind):
                if (kind,record['id']) in scope:continue
                if kind=='image_job' and record.get('owner_id') in owners:continue
                collect(record)
        self._reference_cache=(values,descriptors)

    def plan(self, kind, id):
        record, scope = self.scope(kind, id)
        self.idle(scope, deleting=True)
        all_assets = {a['id']: a for a in self.store.list('asset')}
        self._asset_records=[(k,r) for k in ('project','series') for r in self.store.list(k) if (k,r['id']) not in scope]
        self._asset_scope=set(scope)
        if kind == 'asset':
            users = self.uses_asset(record,scope)
            if users:
                titles = '、'.join(x['title'] or x['id'] for x in users[:3])
                raise ValueError('这个素材仍被使用，不能删除：' + titles + '。归档项目也保留素材引用。')
        candidates = {id} if kind == 'asset' else set()
        for item_kind, item_id in scope:
            if item_kind in {'project', 'series'}:
                candidates.update(aid for aid in self.asset_ids(self.store.get(item_kind, item_id))
                                  if aid in all_assets and all_assets[aid].get('generated'))
        removable = {aid for aid in candidates if aid in all_assets and not self.uses_asset(all_assets[aid], scope)}
        protected = candidates - removable
        cleanup_scope = scope | {('asset', aid) for aid in removable}
        cleanup_scope.update(('image_job',aid) for aid in removable)
        self.cache_output_references(cleanup_scope)
        paths = set()
        kept_files = 0
        for item_kind, item_id in scope:
            if item_kind != 'project':
                continue
            folder = self.files.output / PREFIX / 'projects' / item_id
            self.owned_file(folder, self.files.output)
            if folder.exists():
                for path in folder.rglob('*'):
                    self.owned_file(path, self.files.output)
                    if path.is_file():
                        if self.output_used_elsewhere(path, cleanup_scope):
                            kept_files += 1
                        else:
                            paths.add(path)
        for aid in removable:
            asset = all_assets[aid]
            path = self.files.input / asset['relative_path']
            # A legacy reference to an external input is detached without
            # ever deleting the user's original file.
            try:
                path.relative_to(self.files.input / PREFIX / 'assets' / aid)
            except ValueError:
                kept_files += int(path.exists())
                continue
            self.owned_file(path, self.files.input)
            if path.is_file():
                paths.add(path)
        jobs = []
        owners = {item_id for item_kind, item_id in scope if item_kind in {'project', 'series'}}
        for job in self.store.list('image_job'):
            if job['id'] in removable or job['owner_id'] in owners and job['id'] not in protected:
                if job['status'] in {'submitting','submitted'}:raise ValueError('相关生图任务尚未核对完成，不能清理。')
                jobs.append(job['id'])
                prefix = job.get('output_prefix', '')
                if not prefix:
                    continue
                folder = self.files.output / Path(prefix).parent
                self.owned_file(folder, self.files.output)
                # Prefix includes a full asset ID plus attempt marker; never
                # use only a common model/name prefix to find outputs.
                stem = Path(prefix).name
                if not stem.startswith(job['id'] + '_a'):
                    raise ValueError('生图输出前缀不能确定归属，已停止清理。')
                if folder.exists():
                    for path in folder.glob(job['id'] + '_a*'):
                        self.owned_file(path, self.files.output)
                        if path.is_file() and not self.output_used_elsewhere(path, cleanup_scope):
                            paths.add(path)
        fingerprint = {'scope': sorted(scope), 'records': [self.store.get(k, i) for k, i in sorted(scope)],
                       'assets': sorted(removable), 'protected': sorted(protected),
                       'files': [(str(p), p.stat().st_size, p.stat().st_mtime_ns) for p in sorted(paths)],
                       'jobs': sorted(jobs), 'settings': self.store.settings().get('image_workflow_id', '') + ':' + self.store.settings().get('image_reference_workflow_id', '')}
        token = hashlib.sha256(json.dumps(fingerprint, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        return {'record': record, 'scope': scope, 'assets': removable, 'protected': protected,
                'paths': paths, 'jobs': jobs, 'token': token, 'kept_files': kept_files}

    def preview(self, kind, id):
        with self.store.lock:
            plan = self.plan(kind, id)
            record = plan['record']
            configured = kind == 'image_workflow' and id in [self.store.settings().get(k) for k in ('image_workflow_id', 'image_reference_workflow_id')]
            return {'kind': kind, 'id': id, 'title': record.get('title') or record.get('name') or record.get('label'),
                    'review_token': plan['token'], 'projects': sum(k == 'project' for k, _ in plan['scope']),
                    'files': len(plan['paths']), 'bytes': sum(p.stat().st_size for p in plan['paths']),
                    'unused_generated_assets': len(plan['assets']), 'shared_assets_kept': len(plan['protected']),
                    'files_kept': plan['kept_files'], 'clears_image_selection': configured,
                    'episode_number_kept': kind == 'project' and bool(record.get('series_id'))}

    def delete(self, kind, id, body):
        if not isinstance(body.get('delete_files'),bool):
            raise ValueError('请选择是否清理对应文件。')
        with self.store.lock:
            plan = self.plan(kind, id)
            if body.get('review_token') != plan['token']:
                raise ValueError('记录或文件引用已变化，请重新查看删除范围再操作。')
            clean = body['delete_files']
            deletes = list(plan['scope'])
            owners={item_id for item_kind,item_id in plan['scope'] if item_kind in {'project','series'}}
            deletes += [(diagnostic_kind,row['id']) for diagnostic_kind in ('api_request','comfy_wait')
                        for row in self.store.list(diagnostic_kind) if row.get('owner_id') in owners]
            writes = []
            if clean:
                deletes += [('asset', aid) for aid in plan['assets']]
                deletes += [('image_job', jid) for jid in plan['jobs']]
            record = plan['record']
            if kind == 'project' and record.get('series_id'):
                parent = self.series.record(record['series_id'])
                parent['removed_episodes'][id] = {'title': record['title'], 'was_complete': record['status'] == 'complete'}
                parent['project_ids'] = [pid for pid in parent['project_ids'] if pid != id]
                parent.update(revision=parent['revision'] + 1, updated_at=time.time())
                writes.append(('series', parent['id'], parent))
            if kind == 'image_workflow':
                cfg = self.store.settings()
                for key in ('image_workflow_id', 'image_reference_workflow_id'):
                    if cfg[key] == id:
                        cfg[key] = ''
                writes.append(('config', 'main', cfg))
            # Stage on the same input/output filesystem. If any rename fails,
            # all staged files return to their original names and no records
            # are removed. This also handles Windows file-in-use errors.
            operation = uuid.uuid4().hex
            staged = []
            roots = set()
            try:
                if clean:
                    for path in sorted(plan['paths']):
                        root = self.files.input if path.is_relative_to(self.files.input) else self.files.output
                        trash = root / PREFIX / '.delete' / operation
                        self.owned_file(path, root)
                        if (root / PREFIX / '.delete').is_symlink():
                            raise ValueError('待清理目录包含软链接，已停止删除。')
                        target = trash / path.relative_to(root)
                        target.parent.mkdir(parents=True, exist_ok=True)
                        os.replace(path, target)
                        roots.add(trash)
                        staged.append((path, target))
                self.store.apply_changes(writes, deletes)
            except Exception:
                for original, target in reversed(staged):
                    os.replace(target, original)
                for trash in roots:
                    shutil.rmtree(trash, ignore_errors=True)
                raise
            pending = []
            for trash in roots:
                try:
                    shutil.rmtree(trash)
                except OSError:
                    pending.append(str(trash))
            if pending:
                self.store.put('cleanup_job', operation, {'id': operation, 'paths': pending, 'created_at': time.time()})
            return {'ok': True, 'records_deleted': len(deletes), 'files_deleted': len(staged) if not pending else 0,
                    'pending_cleanup': bool(pending), 'shared_assets_kept': len(plan['protected'])}

    def retry_cleanup(self):
        jobs = self.store.list('cleanup_job')
        removed = []
        for job in jobs:
            for value in job['paths']:
                path = Path(value)
                valid = any(path.parent == root / PREFIX / '.delete' and path.name == job['id'] for root in (self.files.input, self.files.output))
                if not valid or path.is_symlink() or path.parent.is_symlink():
                    raise ValueError('待清理路径异常，已停止操作。')
                root=next(root for root in (self.files.input,self.files.output) if path.parent==root/PREFIX/'.delete')
                cursor=path
                while cursor!=root:
                    if cursor.is_symlink():raise ValueError('待清理目录包含软链接，已停止操作。')
                    cursor=cursor.parent
                if path.exists():
                    shutil.rmtree(path)
            removed.append(('cleanup_job', job['id']))
        self.store.apply_changes(deletes=removed)
        return {'ok': True, 'operations': len(removed)}
