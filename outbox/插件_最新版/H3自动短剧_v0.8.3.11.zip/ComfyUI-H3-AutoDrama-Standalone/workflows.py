"""User-owned API graphs with explicit inputs and recognized H3 continuation controls."""
from __future__ import annotations
import copy
import hashlib
import json
import math
import time
import uuid

ROLES = ('prompt','media','duration','prefix','seed','fps','width','height','previous_video','continuation_enable','overlap','continue_audio')
REQUIRED = ('prompt','media','duration','prefix')
PREPARE_NODES = {'H3ContinuePrepare', 'H3ADv1Prepare'}
CONTINUATION_NODES = PREPARE_NODES | {
    'H3ContinueModelCompat', 'H3ContinueRefitGuide', 'H3ContinueTrim',
    'H3ADv1ModelCompat', 'H3ADv1RefitGuide', 'H3ADv1Trim',
}

def api_graph(value, require_h3=True):
    if isinstance(value,str):
        try:value=json.loads(value)
        except json.JSONDecodeError as e:raise ValueError('工作流JSON无法读取：'+str(e)) from e
    for wrapper in ('prompt','output','graph'):
        if isinstance(value,dict) and isinstance(value.get(wrapper),dict) and 'class_type' not in value[wrapper]:value=value[wrapper]
    if isinstance(value,dict) and isinstance(value.get('nodes'),list):
        raise ValueError('这是普通画布JSON。请在ComfyUI打开并跑通后，导出API格式；也可点ComfyUI右下角“导入当前工作流”。程序不会猜测画布控件的顺序。')
    if not isinstance(value,dict) or not value or len(value)>5000:raise ValueError('请输入有效的ComfyUI API工作流JSON。')
    graph=copy.deepcopy(value)
    for nid,node in graph.items():
        if not isinstance(nid,str) or not nid or not isinstance(node,dict) or not isinstance(node.get('class_type'),str) or not isinstance(node.get('inputs'),dict):
            raise ValueError('API工作流节点格式不正确：'+str(nid))
        # This optional hidden widget can be absent from a canvas API export.
        # Its documented empty default is safe; other node interfaces are not guessed.
        if node['class_type'] in PREPARE_NODES:
            node['inputs'].setdefault('previous_video_name', '')
    if require_h3 and not any('h3' in node['class_type'].lower() for node in graph.values()):
        raise ValueError('当前提示词和素材适配面向MiniMax H3；其他生成模型需要对应适配。')
    # The API uses [node_id, output_index] for a connection; dangling connections
    # are rejected rather than silently replaced by a default value.
    for nid,node in graph.items():
        for field,value in node['inputs'].items():
            if is_link(value):
                if value[0] not in graph:raise ValueError(f'节点{nid}的{field}连接了不存在的节点{value[0]}。')
    active=set();done=set()
    def visit(nid):
        if nid in active:raise ValueError('工作流存在循环连接：'+nid)
        if nid in done:return
        active.add(nid)
        for value in graph[nid]['inputs'].values():
            if is_link(value):visit(value[0])
        active.remove(nid);done.add(nid)
    for nid in graph:visit(nid)
    return graph

def is_link(value):
    return isinstance(value,list) and len(value)==2 and isinstance(value[0],str) and isinstance(value[1],int) and not isinstance(value[1],bool) and value[1]>=0

def fields(graph):
    result=[]
    for nid,node in graph.items():
        title=node.get('_meta',{}).get('title') or node['class_type']
        for name,value in node['inputs'].items():
            if isinstance(value,(str,int,float,bool)) and not is_link(value):
                result.append({'node':nid,'input':name,'title':title,'class_type':node['class_type'],'value':value,
                               'value_type':'boolean' if isinstance(value,bool) else 'number' if isinstance(value,(int,float)) else 'string','display_value':str(value)})
    return result

def read(graph,ref):return graph[ref['node']]['inputs'][ref['input']]

def constant_ref(graph, nid, field):
    """Follow a primitive value connection without replacing the original wire."""
    ref={'node':nid,'input':field};seen=set()
    while is_link(read(graph,ref)):
        link=read(graph,ref)
        if link[0] in seen:raise ValueError('续接字段存在循环连接。')
        seen.add(link[0]);node=graph[link[0]]
        if link[1]!=0 or not node['class_type'].startswith('Primitive') or 'value' not in node['inputs']:
            raise ValueError(f'续接字段 {nid}.{field} 必须使用常量或 Primitive 常量节点，不能自动控制动态计算。')
        ref={'node':link[0],'input':'value'}
    return ref

def continuation_contract(graph, output):
    if output not in graph:return {'bindings':{},'switches':[]}
    active=upstream(graph,output)
    prepare=[nid for nid in graph if nid in active and graph[nid]['class_type'] in PREPARE_NODES]
    if len(prepare)>1:raise ValueError('所选视频输出包含多个续接准备节点，无法确定上一段应接入哪一个；请使用单一路径工作流。')
    if not prepare:return {'bindings':{},'switches':[]}
    nid=prepare[0]
    required={'previous_video':'previous_video_name','continuation_enable':'enable_continue','overlap':'overlap_seconds'}
    refs={}
    for role,field in required.items():
        if field not in graph[nid]['inputs']:raise ValueError(f'续接准备节点 {nid} 缺少 {field}，请重新导出完整API工作流。')
        refs[role]=constant_ref(graph,nid,field)
    if 'include_audio' in graph[nid]['inputs']:
        refs['continue_audio']=constant_ref(graph,nid,'include_audio')
    switches=[]
    for other in graph:
        node=graph[other]
        if other in active and node['class_type'] in CONTINUATION_NODES:
            if 'enable_continue' not in node['inputs']:raise ValueError(f'续接节点 {other} 缺少 enable_continue。')
            ref=constant_ref(graph,other,'enable_continue')
            if not isinstance(read(graph,ref),bool):raise ValueError(f'续接节点 {other} 的开关必须为布尔值。')
            if ref not in switches:switches.append(ref)
    return {'bindings':refs,'switches':switches}

def validate_bindings(graph,body):
    body=copy.deepcopy(body)
    bindings=body.get('bindings',{})
    if not isinstance(bindings,dict):raise ValueError('字段关联格式不正确。')
    automatic=continuation_contract(graph,str(body.get('output_node_id','')))
    for role,ref in automatic['bindings'].items():
        if bindings.get(role) and bindings[role]!=ref:
            raise ValueError('续接字段关联未指向实际续接准备节点：'+role+'；请使用自动识别的关联。')
        bindings[role]=ref
    if not automatic['bindings']:
        active=upstream(graph,str(body['output_node_id'])) if str(body.get('output_node_id','')) in graph else set()
        unknown=[nid for nid in active if 'previous_video_name' in graph[nid]['inputs'] and 'enable_continue' in graph[nid]['inputs']]
        if unknown and not bindings.get('previous_video'):
            raise ValueError('发现尚未适配的续接节点 '+', '.join(unknown)+'，必须先关联续接输入，不能保留未接管的开关。')
    if set(bindings)-set(ROLES):raise ValueError('字段关联包含未知用途。')
    seen=set()
    for role in REQUIRED:
        if not bindings.get(role):raise ValueError('请关联字段：'+role)
    for role,ref in list(bindings.items()):
        if not ref:
            del bindings[role];continue
        if not isinstance(ref,dict) or set(ref)!={'node','input'}:raise ValueError('字段关联必须明确指定节点和输入：'+role)
        nid=ref['node'];field=ref['input']
        if nid not in graph or field not in graph[nid]['inputs']:raise ValueError('字段关联不存在：'+role)
        value=read(graph,ref)
        if is_link(value) or not isinstance(value,(str,int,float,bool)):
            raise ValueError('请选实际保存常量的上游输入，不要选连线端口：'+role)
        if (nid,field) in seen:raise ValueError('同一个输入不能同时关联两种用途。')
        seen.add((nid,field))
        if role in {'prompt','media','prefix','previous_video'} and not isinstance(value,str):raise ValueError(role+'应关联文字输入。')
        if role in {'continuation_enable','continue_audio'} and not isinstance(value,bool):raise ValueError(role+'应关联布尔开关。')
        if role in {'duration','seed','fps','width','height','overlap'} and (isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value)):
            raise ValueError(role+'应关联数值输入。')
    if bool(bindings.get('previous_video'))!=bool(bindings.get('continuation_enable')):raise ValueError('续接必须同时关联上段视频输入和续接开关。')
    if bindings.get('previous_video') and not bindings.get('overlap'):raise ValueError('续接还需关联工作流的重叠秒数，供AI安排台词时间。')
    output=str(body.get('output_node_id',''))
    if output not in graph:raise ValueError('请选择保存视频的输出节点。')
    if graph[output]['inputs'].get('save_output') is False:raise ValueError('所选输出节点关闭了保存文件，请先在工作流启用保存视频，再导出。')
    if bindings['prefix']['node'] not in upstream(graph,output):raise ValueError('输出文件名前缀字段没有连接到所选视频输出。')
    for role in ('prompt','media','duration'):
        if bindings[role]['node'] not in upstream(graph,output):raise ValueError(role+'字段没有连接到所选视频输出。')
    for role in ('previous_video','continuation_enable','overlap','continue_audio'):
        if bindings.get(role) and bindings[role]['node'] not in upstream(graph,output):raise ValueError(role+'字段没有连接到所选视频输出。')
    mode=body.get('media_mode','batch')
    if mode not in {'batch','single_image'}:raise ValueError('素材接入方式无效。')
    if mode=='single_image' and graph[bindings['media']['node']]['class_type']!='LoadImage':raise ValueError('单张开场图方式请关联LoadImage的image输入。')
    if mode=='single_image' and bindings['media']['input']!='image':raise ValueError('单张开场图请关联LoadImage.image。')
    if mode=='batch' and bindings['media']['input']!='batch_media_json':raise ValueError('批量素材方式需节点支持batch_media_json（images/videos/audios格式）；其他接口需适配。')
    unit=body.get('duration_mode','seconds')
    if unit not in {'seconds','frames'}:raise ValueError('时长单位无效。')
    fps=float(read(graph,bindings['fps'])) if bindings.get('fps') else 24.0
    if not 1<=fps<=240:raise ValueError('工作流帧率超出范围。')
    # MiniMax H3's generation/audio time base is 24 FPS. Encoding may be set
    # differently by the user's graph; never extend dialogue to encoding time.
    raw=read(graph,bindings['duration']);duration=float(raw)/(24.0 if unit=='frames' else 1)
    if not 2<=duration<=15:raise ValueError('当前H3自动分镜支持每段2至15秒；请先在工作流设置合适时长。')
    if unit=='frames' and (int(raw)!=raw):raise ValueError('视频帧数必须是整数。')
    seed_mode=body.get('seed_mode','original')
    if seed_mode not in {'original','random'}:raise ValueError('Seed模式无效。')
    if seed_mode=='random' and not bindings.get('seed'):raise ValueError('每段随机Seed需要关联Seed输入。')
    seed=read(graph,bindings['seed']) if bindings.get('seed') else None
    if seed is not None and (int(seed)!=seed or not 0<=seed<2**64):raise ValueError('工作流Seed无效。')
    metadata={'duration_seconds':duration,'fps':fps,'content_fps':24.0,'seed':int(seed) if seed is not None else None,
              'seed_mode':seed_mode,'media_mode':mode,'continuation':bool(bindings.get('previous_video'))}
    for role in ('width','height','overlap','continue_audio'):
        if bindings.get(role):metadata[role]=read(graph,bindings[role])
    for role in ('width','height'):
        if role in metadata and (int(metadata[role])!=metadata[role] or not 256<=metadata[role]<=5760):raise ValueError('工作流'+role+'无效。')
    if 'overlap' in metadata and not .21<=metadata['overlap']<=5:raise ValueError('工作流续接重叠时长无效。')
    return {'bindings':bindings,'output_node_id':output,'media_mode':mode,'duration_mode':unit,'seed_mode':seed_mode,'metadata':metadata,
            'continuation_switches':automatic['switches']}

def resolved(record):
    """Upgrade the binding contract of a saved snapshot, preserving its source graph."""
    graph=api_graph(record['graph'])
    return {**copy.deepcopy(record),'graph':graph,**validate_bindings(graph,record)}

def upstream(graph,output):
    found=set()
    def walk(nid):
        if nid in found:return
        found.add(nid)
        for value in graph[nid]['inputs'].values():
            if is_link(value):walk(value[0])
    walk(output);return found

def preview(value):
    graph=api_graph(value)
    saves=[nid for nid,node in graph.items() if node['class_type'] in {'SaveVideo','VHS_VideoCombine'}]
    automatic=continuation_contract(graph,saves[0]) if len(saves)==1 else {'bindings':{},'switches':[]}
    return {'graph':graph,'fields':fields(graph),'automatic_bindings':automatic['bindings'],
            'nodes':[{'id':nid,'title':n.get('_meta',{}).get('title') or n['class_type'],'class_type':n['class_type']} for nid,n in graph.items()]}

def save(store,body):
    name=str(body.get('name','')).strip()
    if not name or len(name)>160:raise ValueError('请填写工作流名称（最多160字）。')
    if body.get('tested_by_user') is not True:raise ValueError('请先在ComfyUI实际跑通该工作流，再导入。')
    graph=api_graph(body.get('graph'));contract=validate_bindings(graph,body)
    previous=store.get('workflow',str(body['id'])) if body.get('id') else None
    if previous and body.get('expected_version')!=previous['version']:raise ValueError('模板版本已改变，请重新打开后再保存。')
    now=time.time();id=previous['id'] if previous else uuid.uuid4().hex
    record={'id':id,'name':name,'version':previous['version']+1 if previous else 1,'graph':graph,**contract,
            'sha256':hashlib.sha256(json.dumps(graph,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),
            'checked_at':now,'tested_by_user':True,'created_at':previous['created_at'] if previous else now,'updated_at':now}
    return store.put('workflow',id,record)

def summary(record):
    record=resolved(record)
    result={k:copy.deepcopy(record[k]) for k in ('id','name','version','sha256','metadata','output_node_id','checked_at','created_at')}
    result['archived']=bool(record.get('archived'))
    if result['metadata']['seed'] is not None:result['metadata']['seed']=str(result['metadata']['seed'])
    return result

def timing(record,clip,previous_clip=None):
    record=resolved(record)
    meta=record['metadata'];fps=meta['content_fps'];duration=clip['duration_seconds'] if clip.get('timing_version') else meta['duration_seconds'];guide=0
    if clip.get('continuity')=='continue':
        if 'overlap' not in meta:raise ValueError('续接工作流需要关联重叠秒数，供AI安排新台词的时间。')
        requested=max(5,round(meta['overlap']*fps));guide=(5+17*((requested-5)//17))/fps
        if previous_clip and previous_clip.get('timing_version'):
            available=max(5,round(previous_clip['duration_seconds']*fps));guide=min(guide,(5+17*((available-5)//17))/fps)
        from .dialogue_retention import actual_guide_frames
        actual=actual_guide_frames(previous_clip)
        if actual is not None:guide=min(5+17*((requested-5)//17),actual)/fps
    generated=guide+duration
    if clip.get('timing_version'):
        from .domain import h3_frames
        request=float(clip['generation_seconds'])
        if record['duration_mode']=='seconds' and isinstance(read(record['graph'],record['bindings']['duration']),int):request=math.ceil(request)
        generated=h3_frames((h3_frames(request)+round(guide*fps))/fps)/fps
    return {'new_content_start_seconds':guide,'new_content_end_seconds':guide+duration,
            'effective_new_video_seconds':duration,'generated_total_seconds':generated,
            'guide_frames':round(guide*fps),'output_frames':round(duration*fps)}

def instantiate(record,clip,media,previous,prefix):
    record=resolved(record)
    graph=copy.deepcopy(record['graph']);bindings=record['bindings']
    def put(role,value):
        if role in bindings:
            ref=bindings[role];graph[ref['node']]['inputs'][ref['input']]=value
    put('prompt',clip['prompt_en']);put('prefix',prefix)
    if record['media_mode']=='batch':put('media',json.dumps(media,ensure_ascii=False))
    else:
        if len(media.get('images',[]))!=1 or media.get('videos') or media.get('audios'):raise ValueError('此工作流只接收一张开场图；音视频参考需要批量素材工作流。')
        put('media',media['images'][0])
    if bindings.get('seed') and clip.get('seed') is not None:put('seed',int(clip['seed']))
    if clip.get('timing_version'):
        from .domain import h3_frames
        duration=float(clip['generation_seconds'])
        if not math.isfinite(duration) or not 2<=duration<=15:raise ValueError('单次H3生成请求须为2至15秒。')
        raw=h3_frames(duration) if record['duration_mode']=='frames' else duration
        if isinstance(read(graph,bindings['duration']),int):
            if clip.get('generation_exact') and int(raw)!=raw:raise ValueError('这份工作流的任务时长输入只接收整数，请填写整数秒。')
            raw=math.ceil(raw)
        put('duration',raw)
    continued=clip.get('continuity')=='continue'
    if continued and not record['metadata']['continuation']:raise ValueError('所选工作流没有关联续接输入。')
    if continued and not previous:raise ValueError('续接任务缺少上段视频。')
    put('continuation_enable',continued);put('previous_video',previous if continued else '')
    for ref in record.get('continuation_switches',[]):
        graph[ref['node']]['inputs'][ref['input']]=continued
    # Model/precision/size/steps/LoRA/upscale/encoding/fps remain exactly
    # as imported, including every original connection and all other outputs.
    return graph
