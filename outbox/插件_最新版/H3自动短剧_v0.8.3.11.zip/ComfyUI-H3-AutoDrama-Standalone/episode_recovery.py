"""Isolate bounded AI content failures without hiding unfinished episodes."""
import copy


def content_failure(error):
    from .providers import ContentFormatError, AIFormatExhausted
    from .prompt_validation import InvalidContent
    from .prompt_content import MissingContent
    return isinstance(error, (ContentFormatError, AIFormatExhausted, InvalidContent, MissingContent))


def can_defer(project, config, store=None):
    # Continuing another episode never grants permission to resubmit an
    # uncertain paid job. All its durable IDs stay attached to the failed item.
    # The user's production policy is unconditional automatic isolation;
    # only a deliberate pause/cancellation stops the remaining schedule.
    return bool(project.get('series_id') and not project.get('pause_requested')
                and not project.get('archived')
                and project.get('status') in {'error', 'deferred'})


def missing_previous(engine, project):
    prior = project.get('previous_episode_id')
    if not prior:
        return None
    try:
        previous = engine.store.get('project', prior)
    except KeyError:
        return None  # 上一集已被删除
    return previous if previous.get('status') == 'deferred' else None


def prepare_boundary(engine, identity):
    """Use the authored story, never a partial video from a deferred episode."""
    project = engine.store.get('project', identity)
    previous = missing_previous(engine, project)
    if not previous or not project.get('clips'):
        return
    first = project['clips'][0]
    note = {'episode_id': previous['id'],
            'episode_number': previous.get('episode_number'),
            'mode': 'script_and_fixed_assets',
            'reason': '上一集待补做；剧情沿用原剧本，开场使用固定人物和场景重新构图'}
    if first.get('job_id') or first.get('prompt_id') or first.get('output'):
        # Submitted graphs and accepted work are immutable on resume.
        return
    if project.get('previous_episode_gap') == note:
        return
    def change(p):
        clip = p['clips'][0]
        # Only derived, unsubmitted opening-state content is invalidated.
        for key in ('state_reference_id', 'state_reference_source', 'frame_asset_id',
                    'image_asset_id', 'prompt_en', 'prompt_zh', 'prompt_content'):
            clip.pop(key, None)
        clip.update(use_previous_episode_state=False, continuity='cut', status='pending')
        p['previous_episode_gap'] = copy.deepcopy(note)
        if p.get('plan') and p['plan'].get('segments'):
            p['plan']['segments'][0].update(use_previous_episode_state=False, continuity='cut')
    engine.store.update('project', identity, change)
    engine.store.event(identity, note['reason'])


def terminal(project):
    return project.get('status') in {'complete', 'deferred'}
