// “追加后续剧本”整条流程的真实浏览器测试（假后端，不调用付费接口）。
// 运行：node tests/test_append_browser.cjs   需要 playwright 和 Chromium。
const assert = require('node:assert/strict');
const F = require('./fake_backend.cjs');

const DRAFT_TEXT = JSON.stringify({schema: 'h3-production-draft', version: 1, title: '第二批', episodes: []});
const LONG_ERROR = '追加制作稿与本剧已有声明不一致，同名声明必须逐字相同：\n- 风格 style（本剧原文“Natural cinematic light.”，这份是“Cold blue light.”）\n处理办法：把这份制作稿里的对应内容改成与原文一致；或在追加窗口勾选“沿用本剧原声明”。';
const timing = on => ({version: 1, episode: {enabled: false, seconds: null}, total: {enabled: on, seconds: on ? 18 : null}, task: {enabled: false, seconds: null}});

function draftSeries(over = {}) {
  const s = F.seriesRecord({input_type: 'production_draft', allow_image_api: true, ...over});
  s.batches[0].timing_policy = timing(true);   // 上一批勾选了“全剧 18 秒”，新批次不能被它预先勾选
  return s;
}

async function open(browser, series, extra = {}) {
  const state = {series: {ser1: series}, assets: [], fail: extra.fail || [], appendHandler: extra.appendHandler};
  const {server, url} = await F.startServer(state);
  const page = await F.openPage(browser, url, {viewport: extra.viewport || {width: 1100, height: 800}, timeoutMs: extra.timeoutMs});
  await F.waitReady(page);
  await page.click('[data-series]');
  await page.waitForSelector('#series-detail:not(.hidden)');
  return {state, server, page};
}

const dialogOpen = page => page.evaluate(() => document.querySelector('#append-dialog').open);
const appendPosts = state => state.calls.filter(c => c.method === 'POST' && /\/append$/.test(c.route));
const formState = page => page.evaluate(() => {
  const f = document.querySelector('#append-form'), sel = f.elements.input_type;
  return {mode: sel.value, optionsDisabled: [...sel.options].filter(o => o.disabled).map(o => o.value),
    draftPanelVisible: !f.querySelector('[data-draft-panel]').classList.contains('hidden'),
    imageApi: f.querySelector('[data-draft-image-api]').checked, adopt: f.querySelector('[data-draft-adopt]')?.checked ?? null,
    timingTicked: [...f.querySelectorAll('[data-timing-fields] input[type=checkbox]')].filter(x => x.checked).length,
    disabledControls: [...f.elements].filter(e => e.disabled && !/_time_seconds$/.test(e.name)).map(e => e.name || e.type)};
});
async function fillAndSubmit(page, text = DRAFT_TEXT) {
  await page.fill('#append-form [name=text]', text);
  await page.click('#append-form button[type=submit]');
}

async function main() {
  const browser = await F.launch();
  try {
    // 1. 制作稿剧集：窗口默认值正确；服务器拒绝时，原因显示在窗口里面；勾选“沿用本剧原声明”后提交成功。
    {
      let reply = (body, json) => json({error: LONG_ERROR}, 400);
      const ctx = await open(browser, draftSeries(), {appendHandler: (body, json) => reply(body, json)});
      const {state, server, page} = ctx;
      await page.click('#append-series');
      await page.waitForFunction(() => document.querySelector('#append-dialog').open);
      let st = await formState(page);
      assert.equal(st.mode, 'production_draft');
      assert.deepEqual(st.optionsDisabled.sort(), ['outline', 'script']);
      assert.equal(st.draftPanelVisible, true);
      assert.equal(st.imageApi, true, '图片 API 的勾选应沿用本剧上一批');
      assert.equal(st.adopt, false);
      assert.equal(st.timingTicked, 0, '上一批勾选的时长不能带进新批次');
      await fillAndSubmit(page);
      await page.waitForFunction(() => { const n = document.querySelector('#append-dialog [data-dialog-notice]'); return n && !n.classList.contains('hidden') && n.classList.contains('fail') && /风格 style/.test(n.textContent); }, null, {timeout: 3000});
      const shown = await page.evaluate(() => {
        const d = document.querySelector('#append-dialog'), n = d.querySelector('[data-dialog-notice]'), a = d.getBoundingClientRect(), b = n.getBoundingClientRect();
        const top = document.elementFromPoint(b.left + 5, b.top + b.height / 2);
        return {text: n.textContent, inside: b.top >= a.top - 1 && b.bottom <= a.bottom + 1 && b.left >= a.left - 1 && b.right <= a.right + 1, visibleTop: d.contains(top), fail: n.classList.contains('fail')};
      });
      assert.match(shown.text, /风格 style/);
      assert.ok(shown.inside && shown.visibleTop && shown.fail, '错误必须在弹窗里面、可见、是红色：' + JSON.stringify(shown));
      assert.equal(await dialogOpen(page), true);
      assert.deepEqual((await formState(page)).disabledControls, [], '失败后所有控件要恢复可用');
      const firstPost = appendPosts(state)[0].body;
      assert.equal(firstPost.input_type, 'production_draft');
      assert.equal(firstPost.adopt_series_declarations, false);
      assert.equal(firstPost.allow_image_api, true);
      assert.ok(firstPost.request_id && firstPost.expected_revision === 1);
      // 勾选后重试：同一个窗口里 request_id 不变（服务器据此防止重复追加）。
      reply = (body, json) => json({...state.series.ser1, revision: 2});
      await page.check('#append-form [data-draft-adopt]');
      await page.click('#append-form button[type=submit]');
      await page.waitForFunction(() => !document.querySelector('#append-dialog').open, null, {timeout: 4000});
      const posts = appendPosts(state);
      assert.equal(posts.length, 2);
      assert.equal(posts[1].body.adopt_series_declarations, true);
      assert.equal(posts[1].body.request_id, posts[0].body.request_id);
      // 窗口在追加保存后立刻关闭，“开始”请求稍后才发出：等它出现再检查顺序。
      for (let waited = 0; waited < 5000 && !state.calls.some(c => c.route === 'series/ser1/start'); waited += 50) await F.sleep(50);
      const order = state.calls.filter(c => c.method === 'POST').map(c => c.route);
      assert.ok(order.indexOf('series/ser1/start') > order.lastIndexOf('series/ser1/append'), '追加成功后才开始：' + order);
      assert.deepEqual(page.pageErrors, []);
      server.close(); await page.context().close();
      console.log('  ok 制作稿剧集：默认值、窗口内报错、沿用原声明、同一 request_id 重试');
    }

    // 2. 追加成功但自动开始失败：说清楚“已保存，只是没开始”。
    {
      const ctx = await open(browser, draftSeries(), {fail: [{method: 'POST', match: /^series\/ser1\/start$/, mode: 500, times: 1, error: '服务器忙'}]});
      const {page, server} = ctx;
      await page.click('#append-series');
      await page.waitForFunction(() => document.querySelector('#append-dialog').open);
      await fillAndSubmit(page);
      await page.waitForFunction(() => /后续剧本已保存，但没能自动开始/.test(document.querySelector('#notice').textContent), null, {timeout: 4000});
      assert.match(await page.textContent('#notice'), /继续整剧/);
      server.close(); await page.context().close();
      console.log('  ok 追加成功但开始失败：提示“已保存”');
    }

    // 3. 提交后服务器一直不回复：到时限后在窗口里说明，窗口恢复可用，重试用同一个 request_id。
    {
      const ctx = await open(browser, draftSeries(), {fail: [{method: 'POST', match: /^series\/ser1\/append$/, mode: 'hang', times: 1}]});
      const {page, state, server} = ctx;
      await page.evaluate(() => { APPEND_POST.timeoutMs = 1200; });
      await page.click('#append-series');
      await page.waitForFunction(() => document.querySelector('#append-dialog').open);
      await fillAndSubmit(page);
      await page.waitForFunction(() => /请求超时/.test(document.querySelector('#append-dialog [data-dialog-notice]')?.textContent || ''), null, {timeout: 5000});
      assert.match(await page.textContent('#append-dialog [data-dialog-notice]'), /不会重复保存/);
      assert.deepEqual((await formState(page)).disabledControls, []);
      await page.click('#append-form button[type=submit]');
      await page.waitForFunction(() => !document.querySelector('#append-dialog').open, null, {timeout: 4000});
      const posts = appendPosts(state);
      assert.equal(posts.length, 2);
      assert.equal(posts[0].body.request_id, posts[1].body.request_id);
      server.close(); await page.context().close();
      console.log('  ok 服务器不回复：超时说明、控件恢复、同一 request_id 重试');
    }

    // 4. 不能追加时：按钮禁用，旁边写明原因（不再是“点了没反应”）。
    {
      const reason = '这些集还没有完成：第1集（需要处理）。请先点“继续整剧”，或对该集使用补做／重做。';
      const ctx = await open(browser, draftSeries({can_append: false, append_block_reason: reason, status: 'error'}));
      const {page, server} = ctx;
      assert.equal(await page.isDisabled('#append-series'), true);
      const hint = await page.textContent('#append-hint');
      assert.match(hint, /暂时不能追加后续剧本/);
      assert.match(hint, /第1集（需要处理）/);
      assert.equal(await page.isVisible('#append-hint'), true);
      server.close(); await page.context().close();
      console.log('  ok 不能追加：按钮旁写明原因');
    }

    // 5. 剧本剧集：窗口默认值、提交内容里明确带 input_type，制作稿选项被禁用。
    {
      const series = F.seriesRecord({input_type: 'script'});
      series.batches[0].timing_policy = timing(true);
      const ctx = await open(browser, series);
      const {page, state, server} = ctx;
      await page.click('#append-series');
      await page.waitForFunction(() => document.querySelector('#append-dialog').open);
      const st = await formState(page);
      assert.equal(st.mode, 'script');
      assert.deepEqual(st.optionsDisabled, ['production_draft']);
      assert.equal(st.draftPanelVisible, false);
      assert.equal(st.timingTicked, 1, '剧本方式仍恢复上一批的时长设置');
      await page.fill('#append-form [name=text]', '第二批：夜晚。\n莉莉：你好。');
      await page.click('#append-form button[type=submit]');
      await page.waitForFunction(() => !document.querySelector('#append-dialog').open, null, {timeout: 4000});
      const body = appendPosts(state)[0].body;
      assert.equal(body.input_type, 'script');
      assert.ok(body.request_id && body.expected_revision === 1);
      server.close(); await page.context().close();
      console.log('  ok 剧本剧集：默认值与提交内容');
    }

    // 6. 窄窗口（850px 以下弹窗盖住状态栏）：报错仍在弹窗里面可见。
    {
      const ctx = await open(browser, draftSeries(), {viewport: {width: 700, height: 800}, appendHandler: (b, json) => json({error: LONG_ERROR}, 400)});
      const {page, server} = ctx;
      await page.click('#append-series');
      await page.waitForFunction(() => document.querySelector('#append-dialog').open);
      await fillAndSubmit(page);
      await page.waitForFunction(() => { const n = document.querySelector('#append-dialog [data-dialog-notice]'); return n && !n.classList.contains('hidden') && n.classList.contains('fail') && /风格 style/.test(n.textContent); }, null, {timeout: 3000});
      const ok = await page.evaluate(() => { const n = document.querySelector('#append-dialog [data-dialog-notice]'), r = n.getBoundingClientRect(); return r.bottom > 0 && r.top < innerHeight && document.querySelector('#append-dialog').contains(document.elementFromPoint(r.left + 5, Math.min(r.top + 5, innerHeight - 2))); });
      assert.ok(ok, '窄窗口里错误提示要在可视范围内');
      server.close(); await page.context().close();
      console.log('  ok 窄窗口：报错在弹窗内可见');
    }

    // 7. 追加已保存之后页面刷新失败：照样自动开始，并说明“已保存并已开始，只是页面没刷新”。
    {
      const ctx = await open(browser, draftSeries());
      const {page, state, server} = ctx;
      await page.click('#append-series');
      await page.waitForFunction(() => document.querySelector('#append-dialog').open);
      state.fail.push({method: 'GET', match: /^series\/ser1$/, mode: 500, forMs: 1500, error: '服务器忙'});
      await fillAndSubmit(page);
      await page.waitForFunction(() => /已保存并已开始，但页面没能刷新/.test(document.querySelector('#notice').textContent), null, {timeout: 6000});
      assert.ok(state.calls.some(c => c.method === 'POST' && c.route === 'series/ser1/start'), '页面刷新失败也必须自动开始');
      server.close(); await page.context().close();
      console.log('  ok 追加后刷新失败：仍自动开始并说明');
    }

    // 8. 提交还没返回时按 Esc 再点“追加后续剧本”：窗口说明还在处理，已填内容不丢，处理完后能用同一个 request_id 重试。
    {
      const ctx = await open(browser, draftSeries(), {fail: [{method: 'POST', match: /^series\/ser1\/append$/, mode: 'hang', times: 1}]});
      const {page, state, server} = ctx;
      await page.evaluate(() => { APPEND_POST.timeoutMs = 3000; });
      await page.click('#append-series');
      await page.waitForFunction(() => document.querySelector('#append-dialog').open);
      await page.check('#append-form [data-draft-adopt]');
      await page.uncheck('#append-form [data-draft-image-api]');   // 与默认值（沿用本剧上一批＝勾选）不同
      await fillAndSubmit(page);
      await page.waitForFunction(() => document.querySelector('#append-form button[type=submit]').disabled);
      await page.keyboard.press('Escape');
      await page.waitForFunction(() => !document.querySelector('#append-dialog').open);
      await page.click('#append-series');
      await page.waitForFunction(() => document.querySelector('#append-dialog').open);
      assert.match(await page.textContent('#append-dialog [data-dialog-notice]'), /上一次提交还在处理中/);
      assert.equal(await page.inputValue('#append-form [name=text]'), DRAFT_TEXT, '已填内容不能被清空');
      const keep = await formState(page);
      assert.equal(keep.adopt, true, '重新打开不能把已勾选的“沿用本剧原声明”重置');
      assert.equal(keep.imageApi, false, '重新打开不能把图片 API 的选择重置');
      await page.waitForFunction(() => /请求超时/.test(document.querySelector('#append-dialog [data-dialog-notice]')?.textContent || ''), null, {timeout: 6000});
      assert.deepEqual((await formState(page)).disabledControls, []);
      await page.click('#append-form button[type=submit]');
      await page.waitForFunction(() => !document.querySelector('#append-dialog').open, null, {timeout: 4000});
      const posts = appendPosts(state);
      assert.equal(posts.length, 2);
      assert.equal(posts[0].body.request_id, posts[1].body.request_id);
      assert.equal(posts[1].body.adopt_series_declarations, true);
      assert.equal(posts[1].body.allow_image_api, false);
      server.close(); await page.context().close();
      console.log('  ok 提交未返回时 Esc 再打开：说明、保留内容和勾选、同一 request_id 重试');
    }

    // 9. 仅校验通过后，上一次的红色报错必须消失（不能一边写“校验通过”一边挂着旧错误）。
    {
      const ctx = await open(browser, draftSeries(), {appendHandler: (body, json) => json({error: LONG_ERROR}, 400)});
      const {page, server} = ctx;
      await page.click('#append-series');
      await page.waitForFunction(() => document.querySelector('#append-dialog').open);
      await fillAndSubmit(page);
      await page.waitForFunction(() => { const n = document.querySelector('#append-dialog [data-dialog-notice]'); return n && !n.classList.contains('hidden') && n.classList.contains('fail'); }, null, {timeout: 3000});
      await page.click('#append-form [data-draft-validate]');
      await page.waitForFunction(() => /校验通过/.test(document.querySelector('#append-form [data-draft-result]').textContent), null, {timeout: 3000});
      assert.equal(await page.evaluate(() => document.querySelector('#append-dialog [data-dialog-notice]').classList.contains('hidden')), true);
      server.close(); await page.context().close();
      console.log('  ok 校验通过后清除旧报错');
    }

    // 10. 追加已保存、窗口已关，页面还在刷新（网络慢）时再点“追加后续剧本”：不再弹出一个锁死的窗口，只在顶部说明。
    {
      const ctx = await open(browser, draftSeries(), {timeoutMs: 3500});
      const {page, state, server} = ctx;
      await page.click('#append-series');
      await page.waitForFunction(() => document.querySelector('#append-dialog').open);
      state.fail.push({method: 'GET', match: /^series\/ser1$/, mode: 'hang', times: 1});
      await fillAndSubmit(page);
      await page.waitForFunction(() => !document.querySelector('#append-dialog').open, null, {timeout: 4000});
      await page.evaluate(() => document.querySelector('#append-series').click());
      await page.waitForTimeout(300);
      assert.equal(await dialogOpen(page), false, '已保存后不能再弹出窗口');
      assert.match(await page.textContent('#notice'), /后续剧本已保存/);
      await page.waitForFunction(() => /(后续剧本|制作稿)已开始/.test(document.querySelector("#notice").textContent), null, {timeout: 9000});
      assert.ok(state.calls.some(c => c.method === 'POST' && c.route === 'series/ser1/start'));
      server.close(); await page.context().close();
      console.log('  ok 已保存后页面刷新中：不弹锁死窗口');
    }
    console.log('append browser: all scenarios passed');
  } finally { await browser.close(); }
}
main().catch(error => { console.error(error); process.exit(1); });
