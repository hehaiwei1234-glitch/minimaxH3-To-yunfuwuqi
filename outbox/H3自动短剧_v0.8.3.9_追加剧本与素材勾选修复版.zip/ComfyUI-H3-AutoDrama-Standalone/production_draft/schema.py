"""Strict, offline validation of a portable production draft; never repairs with AI."""
from __future__ import annotations
import copy
import json
import math
import re
from .. import dialogue_plan, dialogue_language, timing_policy, workflows
from ..domain import safe_id, validate_plan
from . import SCHEMA, VERSION

TOKEN = re.compile(r'\[\[asset:([A-Za-z0-9_-]+)\]\]')

def fail(path, message):
    raise ValueError('制作稿 '+path+'：'+message)

def obj(value, path, allowed):
    if not isinstance(value, dict): fail(path, '须为对象')
    extra = set(value)-set(allowed.split())
    if extra: fail(path, '不支持的字段 '+', '.join(sorted(extra)))
    return value

def text(value, path, limit=16000, empty=False):
    if not isinstance(value, str) or (not empty and not value.strip()) or len(value)>limit:
        fail(path, f'须为有效文字（最多{limit}字）')
    return value

def pair(value, path, fallback=None):
    from ..prompt_content import pair as normalize_pair, ZH_PENDING
    result=normalize_pair(value)
    if not result.get('en') and fallback:
        for k,v in fallback.items(): result.setdefault(k,v)
    text(result.get('en'),path+'.en')
    result.setdefault('zh',ZH_PENDING)
    return result

def seq(value, path, maximum, minimum=0):
    if not isinstance(value,list) or not minimum<=len(value)<=maximum:
        fail(path, f'须为{minimum}至{maximum}项的列表')
    return value

def number(value, path, minimum, maximum):
    if type(value) not in (int,float) or not math.isfinite(value) or not minimum<=value<=maximum:
        fail(path, f'须为{minimum:g}至{maximum:g}的数值')
    return float(value)

def names(value, path, known, maximum=100):
    seq(value,path,maximum)
    if any(not isinstance(k,str) or k not in known for k in value): fail(path,'包含不存在的名称/素材键')
    if len(value)!=len(set(value)): fail(path,'存在重复项')
    return value

def loads(raw):
    def unique(pairs):
        value={}
        for key,item in pairs:
            if key in value: fail(key,'JSON字段重复')
            value[key]=item
        return value
    if isinstance(raw,str):
        if len(raw.encode('utf-8'))>3*1024*1024: fail('文件','超过3MB，请分批导入')
        try: value=json.loads(raw.lstrip('\ufeff'),object_pairs_hook=unique)
        except json.JSONDecodeError as e: fail('JSON',f'第{e.lineno}行第{e.colno}列：{e.msg}')
    else: value=copy.deepcopy(raw)
    return validate(value)

def script_lines(script,characters,path):
    """Draft dialogue is explicit and line based; legacy prose stays untouched."""
    names=sorted(characters,key=len,reverse=True)
    modifier=r'(?:\s*[（(][^\n）)]{0,100}[）)])?(?:\s*(?:轻声说|低声说|平静地说|轻声|低声|说道|问道|喊道|回答|喃喃|说|问|喊))?'
    speaker_pattern=re.compile('('+ '|'.join(re.escape(name) for name in names)+')'+modifier) if names else None
    quotes={'“':'”','「':'」','『':'』','"':'"'}
    result=[]
    for number,raw in enumerate(script.splitlines(),1):
        line=raw.strip()
        if not line: continue
        parts=re.split('[：:]',line,maxsplit=1)
        if len(parts)==1: continue
        prefix,spoken=parts[0].strip(),parts[1].strip()
        match=speaker_pattern.fullmatch(prefix) if speaker_pattern else None
        if not match:
            # Only explicit metadata may be skipped. A declared character
            # named "声音" or "动作" is resolved above before this branch.
            metadata=prefix.strip('【】[]')
            if dialogue_plan.is_script_heading(metadata): continue
            fail(path,f'第{number}行说话人“{prefix}”未声明；对白须每句一行，动作说明另起行')
        if spoken[:1] in quotes:
            closing=quotes[spoken[0]]
            if len(spoken)<2 or not spoken.endswith(closing):
                fail(path,f'第{number}行对白引号未闭合')
            spoken=spoken[1:-1]
        text(spoken,path+f'.line[{number}]',500000)
        result.append({'speaker':match.group(1),'text':spoken})
    return result

def validate(d):
    obj(d,'根对象','schema version title style assets characters episodes dialogue_language')
    dialogue_language.canonical(d.get('dialogue_language','auto'))
    if d.get('schema')!=SCHEMA or type(d.get('version')) is not int or d['version']!=VERSION:
        fail('schema/version',f'只支持 {SCHEMA} / {VERSION}')
    text(d.get('title'),'title',160);text(d.get('style'),'style',8000)
    assets={}
    for i,a in enumerate(seq(d.get('assets'),'assets',200)):
        path=f'assets[{i}]';obj(a,path,'key kind role label description source generate')
        try: key=safe_id(a.get('key'))
        except (ValueError,TypeError): fail(path+'.key','须为字母、数字、下划线或短横线组成的素材键')
        if key in assets: fail(path+'.key','重复')
        if a.get('kind') not in {'image','video','audio'}: fail(path+'.kind','须为image/video/audio')
        if a.get('role') not in {'character','scene','prop','style','voice','other'}: fail(path+'.role','素材角色类型无效')
        from ..prompt_content import reference_fallback
        text(a.get('label'),path+'.label',160);a['description']=pair(a.get('description'),path+'.description',reference_fallback(a['kind']))
        if ('source' in a)==('generate' in a): fail(path,'source与generate须且只能提供一项')
        if 'source' in a:
            source=obj(a['source'],path+'.source','id label')
            if len(source)!=1: fail(path+'.source','按id或label任选一项绑定')
            text(next(iter(source.values())),path+'.source',160)
        else:
            if a['kind']!='image' or a['role'] not in {'character','scene','prop','style'}: fail(path,'只支持自动创建人物、场景、道具或风格图片')
            gen=obj(a['generate'],path+'.generate','image_prompt reference_keys')
            text(gen.get('image_prompt'),path+'.generate.image_prompt')
            refs=names(gen.get('reference_keys',[]),path+'.generate.reference_keys',assets,8)
            if any(assets[k]['kind']!='image' for k in refs): fail(path,'生图只可引用之前声明的图片')
        for part in a['description'].values():
            if '[[' in part or re.search(r'<(?:Picture|Audio|Video|Subject)\s+\d+>',part,re.I): fail(path+'.description','素材自身描述不使用编号或占位引用')
        assets[key]=a
    chars=d.get('characters')
    if not isinstance(chars,dict) or len(chars)>100: fail('characters','须为最多100名角色的对象')
    for name,c in chars.items():
        path='characters.'+name;text(name,path,100)
        obj(c,path,'image_keys voice_key voice_description')
        keys=names(c.get('image_keys',[]),path+'.image_keys',assets,4)
        if any(assets[k]['kind']!='image' for k in keys): fail(path,'人物参考须为图片')
        if c.get('voice_key'):
            names([c['voice_key']],path+'.voice_key',assets,1)
            if assets[c['voice_key']]['kind']!='audio': fail(path+'.voice_key','须为音频素材')
        from ..prompt_content import VOICE_REFERENCE
        c['voice_description']=pair(c.get('voice_description'),path+'.voice_description',VOICE_REFERENCE if c.get('voice_key') else None)
    episodes=seq(d.get('episodes'),'episodes',100,1)
    for i,e in enumerate(episodes):
        ep=f'episodes[{i}]';obj(e,ep,'title script summary segments dialogue_language')
        dialogue_language.canonical(e.get('dialogue_language','auto'))
        text(e.get('title'),ep+'.title',160);text(e.get('script'),ep+'.script',500000);text(e.get('summary'),ep+'.summary',6000)
        all_lines=[]
        for j,s in enumerate(seq(e.get('segments'),ep+'.segments',5000,1)):
            path=f'{ep}.segments[{j}]'
            obj(s,path,'title duration_seconds generation_seconds continuity depends_on_previous use_previous_episode_state characters asset_keys image_reference_keys opening_frame_key image_prompt visual_zh camera_zh dialogue shots sound_en sound_zh seed dialogue_language')
            dialogue_language.canonical(s.get('dialogue_language','auto'))
            from ..prompt_content import pair as normalize_pair, ZH_PENDING
            for k in ('title','image_prompt'): text(s.get(k),path+'.'+k)
            for k in ('visual_zh','camera_zh'):
                if not isinstance(s.get(k),str) or not s[k].strip(): s[k]=ZH_PENDING
            sound=pair(normalize_pair(s.get('sound_en'),s.get('sound_zh')),path+'.sound')
            s['sound_en']=sound['en'];s['sound_zh']=sound['zh']
            duration=number(s.get('duration_seconds'),path+'.duration_seconds',.25,15)
            if abs(duration*24-round(duration*24))>1e-5: fail(path+'.duration_seconds','须对齐到1/24秒；不自动改变制作安排')
            generation=number(s.get('generation_seconds'),path+'.generation_seconds',2,15)
            if generation+1e-6<duration: fail(path,'生成时长不能短于保留时长')
            if s.get('continuity') not in {'cut','continue'}: fail(path+'.continuity','须为cut或continue')
            if not j and s['continuity']!='cut': fail(path+'.continuity','每集首段须为cut；跨集画面状态使用use_previous_episode_state')
            for k in ('depends_on_previous','use_previous_episode_state'):
                if type(s.get(k)) is not bool: fail(path+'.'+k,'须明确填写true或false')
            if not j and s['depends_on_previous']: fail(path,'首段depends_on_previous须为false')
            if s['continuity']=='continue' and not s['depends_on_previous']: fail(path,'continue必须依赖前段')
            names(s.get('characters'),path+'.characters',chars)
            names(s.get('asset_keys'),path+'.asset_keys',assets,11)
            refs=names(s.get('image_reference_keys'),path+'.image_reference_keys',assets,8)
            if any(assets[k]['kind']!='image' for k in refs): fail(path+'.image_reference_keys','须为图片')
            if s.get('opening_frame_key'):
                names([s['opening_frame_key']],path+'.opening_frame_key',assets,1)
                if assets[s['opening_frame_key']]['kind']!='image': fail(path+'.opening_frame_key','须为图片')
                if s['depends_on_previous'] or s['use_previous_episode_state']: fail(path,'固定开场图不能同时要求接入尚未生成的前段状态')
            if 'seed' in s and (type(s['seed']) is not int or not 0<=s['seed']<2**64): fail(path+'.seed','须为0至2^64−1的整数')
            lines=seq(s.get('dialogue'),path+'.dialogue',200)
            cursor=0
            for n,line in enumerate(lines):
                lp=f'{path}.dialogue[{n}]';obj(line,lp,'speaker text start_seconds end_seconds language')
                dialogue_language.canonical(line.get('language','auto'))
                if line.get('speaker') not in chars: fail(lp+'.speaker','须为已声明的角色')
                text(line.get('text'),lp+'.text',8000)
                if any(t in line['text'] for t in ('<d>','</d>','[[',']]')): fail(lp+'.text','不能包含提示词控制标签')
                start=number(line.get('start_seconds'),lp+'.start_seconds',0,duration)
                end=number(line.get('end_seconds'),lp+'.end_seconds',0,duration)
                if start<cursor-1e-6 or end<=start: fail(lp,'对白时间重叠或倒序')
                if end-start+1/24<dialogue_plan.line_seconds(line['text'],dialogue_language.resolve(line,s,e,d)): fail(lp,'自然语速预算不足；请提前延长时间或在自然停顿处拆分原文')
                if duration-end+1/24<dialogue_plan.TAIL: fail(lp,'句尾至少预留0.65秒，避免裁掉尾字')
                cursor=end;all_lines.append({'speaker':line['speaker'],'text':line['text']})
            if lines and duration+1/24<dialogue_plan.budget([{**line,'language':dialogue_language.resolve(line,s,e,d)} for line in lines])['minimum_seconds']: fail(path+'.dialogue','整段对白自然表达预算不足')
            cursor=0;seen=[]
            for n,shot in enumerate(seq(s.get('shots'),path+'.shots',12,1)):
                sp=f'{path}.shots[{n}]';obj(shot,sp,'start_seconds end_seconds visual_en visual_zh dialogue_indices')
                start=number(shot.get('start_seconds'),sp+'.start_seconds',0,duration)
                end=number(shot.get('end_seconds'),sp+'.end_seconds',0,duration)
                if abs(start-cursor)>1e-6 or end<=start: fail(sp,'镜头须连续且不重叠')
                cursor=end
                visual=pair(normalize_pair(shot.get('visual_en'),shot.get('visual_zh')),sp+'.visual')
                shot['visual_en']=visual['en'];shot['visual_zh']=visual['zh']
                indices=seq(shot.get('dialogue_indices'),sp+'.dialogue_indices',len(lines))
                if any(type(x) is not int or not 0<=x<len(lines) for x in indices): fail(sp,'对白索引无效')
                for idx in indices:
                    if lines[idx]['start_seconds']<start-1e-6 or lines[idx]['end_seconds']>end+1e-6: fail(sp,'对白时间超出所属镜头')
                seen+=indices
            if abs(cursor-duration)>1e-6: fail(path+'.shots','须覆盖整段保留时长')
            if seen!=list(range(len(lines))): fail(path+'.shots','对白须按原顺序完整出现一次')
            available=set(s['asset_keys']+s['image_reference_keys'])
            for name in s['characters']: available.update(chars[name]['image_keys'])
            if s.get('opening_frame_key'): available.add(s['opening_frame_key'])
            for value in [s['sound_en'],s['sound_zh']]+[shot[k] for shot in s['shots'] for k in ('visual_en','visual_zh')]:
                for key in TOKEN.findall(value):
                    if key not in available or assets[key]['kind']=='audio': fail(path,'视觉描述引用了本段未使用的视觉素材：'+key)
                if '[[' in TOKEN.sub('',value) or ']]' in TOKEN.sub('',value) or re.search(r'<(?:Picture|Video|Audio|Subject)\s+\d+>|<d>|\(S\d+\)',value,re.I): fail(path,'使用[[asset:素材键]]，不手填H3编号或对白标签')
        expected=script_lines(e['script'],chars,ep+'.script')
        if expected!=all_lines: fail(ep+'.script','说话人：原句的逐行列表与分镜对白不一致；必须逐字、逐句、按顺序覆盖')
    return d

def needs_images(d):
    return any('generate' in a for a in d['assets']) or any(not s.get('opening_frame_key') for e in d['episodes'] for s in e['segments'])

def resolve_assets(d,store,files,selected=(),aliases=None,appending=False):
    """Resolve semantic keys; ambiguity is an error, never a fuzzy guess."""
    mapping={};catalog=[];generated=[];known={};aliases=aliases or {}
    for a in d['assets']:
        key=a['key'];path='assets.'+key
        if key in aliases:
            asset=store.get('asset',aliases[key])
            # A pin may have been deliberately replaced after the first batch.
            # The approved real binding wins over the original label selector.
        elif 'generate' in a:
            if key in aliases:
                asset=store.get('asset',aliases[key])
                if asset['kind']!='image' or asset.get('label')!=a['label']: fail(path,'追加批次的素材键与原素材身份冲突')
            else:
                refs=[mapping[k] for k in a['generate'].get('reference_keys',[])]
                item={'id':key,'role':a['role'],'label':a['label'],'description':a['description']['zh'],'image_prompt':a['generate']['image_prompt'],'reference_asset_ids':refs}
                generated.append(item);asset={'id':key,'kind':'image',**item}
                mapping[key]=key;catalog.append(asset);known[key]=asset;continue
        else:
            source=a['source']
            if 'id' in source:
                try: asset=store.get('asset',source['id'])
                except KeyError: fail(path,'指定id不存在；换环境请改用素材名称绑定')
            else:
                matches=[x for x in store.list('asset') if not x.get('archived') and x['kind']==a['kind'] and x.get('label')==source['label']]
                chosen=[x for x in matches if x['id'] in selected]
                if chosen: matches=chosen
                if len(matches)!=1: fail(path,'名称“'+source['label']+'”'+('未找到' if not matches else ('有多个候选；追加窗口没有素材清单，请把这个素材改为按 id 绑定（source: {"id": ...}），或沿用本剧已有的素材键' if appending else '有多个候选，请在下方只勾选要使用的一份')))
                asset=matches[0]
        if asset.get('archived') or asset['kind']!=a['kind'] or not files.asset_path(asset).is_file(): fail(path,'素材已归档、文件丢失或类型不符')
        if asset['id'] in known: fail(path,'同一真实文件不能声明为两个素材键，请复用原键')
        mapping[key]=asset['id'];catalog.append(asset);known[asset['id']]=asset
    bindings={name:{'image_ids':[mapping[k] for k in c['image_keys']], 'voice_id':mapping.get(c.get('voice_key'),'')} for name,c in d['characters'].items()}
    return mapping,catalog,generated,bindings

def bind_episode(d,episode,mapping):
    result={'style':d['style'],'assets_to_create':[],'segments':[]}
    for source in episode['segments']:
        s=copy.deepcopy(source)
        dialogue_language.apply(s,episode,d)
        keys=list(dict.fromkeys(s['asset_keys']+s['image_reference_keys']))
        for name in s['characters']: keys+=d['characters'][name]['image_keys']
        for line in s['dialogue']:
            voice=d['characters'][line['speaker']].get('voice_key')
            if voice: keys.append(voice)
        s['asset_ids']=list(dict.fromkeys(mapping[k] for k in keys))
        refs=s['image_reference_keys'][:]
        for name in s['characters']: refs+=d['characters'][name]['image_keys']
        s['image_reference_ids']=list(dict.fromkeys(mapping[k] for k in refs))
        s.update(timing_version=1,generation_exact=True,dialogue_budget=dialogue_plan.budget(s['dialogue']))
        if s.get('opening_frame_key'): s['frame_asset_id']=mapping[s['opening_frame_key']]
        result['segments'].append(s)
    return result

def validate_execution(d,mapping,catalog,generated,workflow,cfg,policy,count=0):
    if count and count!=len(d['episodes']): fail('episodes','集数与界面指定值不符')
    timing_policy.check_workflow(policy,workflow)
    durations=[]
    for i,e in enumerate(d['episodes']):
        plan=bind_episode(d,e,mapping)
        validate_plan(plan,catalog,cfg['max_segments'],min_duration=.25)
        duration=sum(s['duration_seconds'] for s in plan['segments']);durations.append(duration)
        target=timing_policy.seconds(policy,'episode')
        if target and timing_policy.frames(target)!=timing_policy.frames(duration): fail(f'episodes[{i}]','保留时长与用户勾选的每集时长不符')
        for j,s in enumerate(plan['segments']):
            path=f'episodes[{i}].segments[{j}]';task=timing_policy.seconds(policy,'task')
            if task and abs(task-s['generation_seconds'])>1e-6: fail(path,'生成时长与用户勾选的每次任务时长不符')
            if workflow['media_mode']=='single_image':
                if any(a['kind']!='image' and a['id'] in s['asset_ids'] for a in catalog): fail(path,'单图视频工作流不能接收音视频参考')
                if any(TOKEN.search(shot[k]) for shot in s['shots'] for k in ('visual_en','visual_zh')) or TOKEN.search(s['sound_en']+s['sound_zh']):
                    fail(path,'单图视频工作流只能看到开场图；描述请使用角色名而非独立素材占位引用')
            workflows.instantiate(workflow,{**s,'prompt_en':'validation','seed':s.get('seed')},
                                  {'images':['frame.png'],'audios':[],'videos':[]},'previous.mp4' if j else None,'validation')
            if 'seed' in s and not workflow['bindings'].get('seed'): fail(path+'.seed','工作流未关联Seed，不能执行指定值')
    total=timing_policy.seconds(policy,'total')
    if total and timing_policy.frames(sum(durations))!=timing_policy.frames(total): fail('episodes','合计保留时长与用户勾选的全剧时长不符')
    return durations
