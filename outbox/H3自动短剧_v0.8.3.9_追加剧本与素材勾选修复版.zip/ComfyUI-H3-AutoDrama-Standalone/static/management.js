"use strict";
// appendPhase：""＝没有在提交；"posting"＝追加请求已发出、还在等服务器回复；"saved"＝已保存、窗口已关，正在刷新页面和自动开始。
let deleteReview=null,scriptEdit=null,appendingSeries=false,appendPhase="",appendRequestId="",appendContext=null;
const managementPending=new Set();
const managementViews={series:"loadSeries",project:"loadProjects",asset:"loadAssets",workflow:"loadWorkflows",image_workflow:"loadImageWorkflows"};
function managementQuery(kind){return $("#show-archived-"+kind)?.checked?"?include_archived=1":""}
function managementButtons(kind,id,archived){return `<span class="record-actions"><button type="button" data-manage="${archived?"restore":"archive"}" data-kind="${kind}" data-id="${esc(id)}">${archived?"恢复":"归档"}</button><button type="button" class="danger" data-manage="delete-preview" data-kind="${kind}" data-id="${esc(id)}">删除</button></span>`}
// 待清理文件的提示只是附加信息，查询失败不能影响其他按钮或掩盖操作结果。
async function loadCleanupHint(){try{const cleanup=await api("manage/cleanup");$("#retry-cleanup").classList.toggle("hidden",!cleanup.pending)}catch{}}
async function refreshManagement(){
 if(current){try{current=await api("projects/"+current.id);renderProject()}catch{current=null;$("#project-detail").classList.add("hidden");$("#project-form").classList.remove("hidden")}}
 if(currentSeries){try{currentSeries=await api("series/"+currentSeries.id);renderSeries()}catch{currentSeries=null;$("#series-detail").classList.add("hidden");$("#series-form").classList.remove("hidden")}}
 await loadSettings();await Promise.all([loadAssets(),loadProjects(),loadSeries(),loadWorkflows(),loadImageWorkflows()]);
 await loadCleanupHint();
}
function renderDeleteReview(){
 const r=deleteReview,lines=[`将删除：${r.title}`,`包含 ${r.projects} 个单集项目；可清理 ${r.files} 个文件，约 ${(r.bytes/1024/1024).toFixed(1)} MB。`];
 if(r.unused_generated_assets)lines.push(`同时清理文件时，可删除 ${r.unused_generated_assets} 个无人使用的自动素材。`);
 if(r.shared_assets_kept)lines.push(`${r.shared_assets_kept} 个共享素材会保留。`);
 if(r.files_kept)lines.push(`${r.files_kept} 个被其他项目引用或不属本软件的文件会保留。`);
 if(r.kind==="workflow"||r.kind==="image_workflow")lines.push("已有项目保留工作流副本，可继续执行。");
 if(r.clears_image_selection)lines.push("这是当前选用的生图模板；删除后，新项目需要重新选择模板。");
 if(r.episode_number_kept)lines.push("本集编号保留，后续追加不会复用这个编号。");
 $("#delete-scope").textContent=lines.join("\n");
 $("#delete-form").elements.delete_files.disabled=!r.files&&!r.unused_generated_assets;
 $("#delete-form").elements.delete_files.checked=!!(r.files||r.unused_generated_assets);
}
function bindManagement(){
 $$("[data-manage]").forEach(button=>button.onclick=guarded(async()=>{
   const {kind,id,manage:action}=button.dataset,key=kind+":"+id;if(managementPending.has(key))return;
   managementPending.add(key);button.disabled=true;
   try{
     const response=await api("manage/"+kind+"/"+id+"/"+action,{});
     if(action==="delete-preview"){deleteReview=response;renderDeleteReview();$("#delete-dialog").showModal()}
     else{await refreshManagement();notice(action==="archive"?"已归档；勾选显示已归档可恢复":"已恢复")}
   }finally{managementPending.delete(key);button.disabled=false}
 }));
}
function scriptEditable(p){return !p.archived&&!p.plan&&!p.clips?.length&&!Object.keys(p.generated_assets||{}).length&&!p.final&&!['running','queued','pausing','complete'].includes(p.status)}
async function openScriptEditor(id){
 const p=await api("projects/"+id);if(!scriptEditable(p))throw Error("本集已开始准备，请使用镜头重做。");
 scriptEdit={id:p.id,series_id:p.series_id,revision:p.script_revision||1};
 $("#script-edit-title").textContent=p.title;$("#script-edit-form").elements.script.value=p.script;$("#script-edit-dialog").showModal();
}
function requestId(){return globalThis.crypto?.randomUUID?.()||"request-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2)}
// 追加窗口的输入方式只由这里决定：下拉框选中项、可选项（production_draft.js）和提交内容都用同一个值，不会出现“选中了被禁用的选项”。
function appendMode(series){
 if(series?.input_type==="production_draft")return "production_draft";
 const last=(series?.batches||[]).at(-1)?.input_type;
 return last&&last!=="production_draft"?last:"script";
}
// 追加成功后自动开始；这一步失败时说清楚“已保存，只是没开始”，避免用户以为追加没成功。
// 错误信息去掉结尾的句号再接后面的说明，避免“……失败 请点…”这种没有标点的拼接。
const plainMessage=e=>String(e?.message??e).replace(/[。.！!]+$/,"");
async function startAfterAppend(id){
 // 开始是幂等的（已在运行就直接返回），所以可以设上限：网络卡住时不会让“已保存”的提示永远挂着。
 try{await api(`series/${id}/start`,{},{timeoutMs:60000})}catch(e){throw Error("后续剧本已保存，但没能自动开始："+plainMessage(e)+"。请点“继续整剧”。")}
}
// 追加已保存之后：先刷新页面显示新批次，再自动开始，最后再刷新。页面刷新失败不能拦住“开始”，也不能掩盖“已保存”。
async function afterAppendSaved(id){
 try{await openSeries(id)}catch{} // 3 秒一次的自动刷新会补上
 await startAfterAppend(id);
 try{await openSeries(id)}catch(e){throw Error("后续剧本已保存并已开始，但页面没能刷新："+plainMessage(e)+"。页面会自动重试，也可以刷新页面。")}
}
const APPEND_POST={timeoutMs:120000,timeoutHint:"追加可能已经保存：请刷新页面，看这部剧是否多出新一批；没有的话再点一次保存即可，同一次追加不会重复保存。"};
function openAppendDialog(){
 // 已保存、窗口已关，只是在刷新页面／自动开始：不要再弹出一个永远不会自动关闭的窗口。
 if(appendPhase==="saved"){notice("后续剧本已保存，页面正在刷新并自动开始，请稍候…");return}
 // 上一次提交还在等服务器回复：不要清空表单，也不能让用户面对一个锁死的窗口而没有说明。
 if(appendPhase==="posting"){
   const dialog=$("#append-dialog");if(!dialog.open)dialog.showModal();
   dialogNotice(dialog,"上一次提交还在处理中（最长约 2 分钟），请稍候。成功后这个窗口会自动关闭；失败会在这里显示原因。",false);
   return;
 }
 if(!currentSeries?.can_append)throw Error(currentSeries?.append_block_reason||"请先完成当前批次，再追加后续剧本。");
 const last=(currentSeries.batches||[]).at(-1)||{},form=$("#append-form");form.reset();appendRequestId=requestId();appendContext={id:currentSeries.id,revision:currentSeries.revision};
 form.elements.input_type.value=appendMode(currentSeries);form.elements.episode_count.value=0;
 // 制作稿自带每集和每次任务的时长，沿用上一批勾选的秒数会与新制作稿冲突，所以只对剧本／大纲恢复。
 restoreTiming(form,currentSeries.input_type==="production_draft"?{}:last.timing_policy);
 $("#append-start").textContent=`属于《${currentSeries.title}》，从第${currentSeries.next_episode_number}集开始；自动复用本剧人物、场景和风格。`;
 form.elements.workflow_id.innerHTML='<option value="">沿用上一批的视频工作流</option>'+workflowTemplates.filter(w=>!w.archived).map(w=>`<option value="${esc(w.id)}">${esc(w.name)} · v${w.version}</option>`).join("");
 $("#append-dialog").showModal();
}
function bindManagementControls(){
 for(const [kind,name]of Object.entries(managementViews))$("#show-archived-"+kind).onchange=guarded(()=>globalThis[name]());
 $("#delete-refresh").onclick=guarded(async()=>{deleteReview=await api(`manage/${deleteReview.kind}/${deleteReview.id}/delete-preview`,{});renderDeleteReview()});
 $("#delete-form").onsubmit=guarded(async event=>{
   event.preventDefault();const form=event.target,button=form.querySelector('button[type="submit"]');if(button.disabled)return;button.disabled=true;
   try{
     const r=deleteReview,result=await api(`manage/${r.kind}/${r.id}/delete`,{review_token:r.review_token,delete_files:form.elements.delete_files.checked});
     $("#delete-dialog").close();
     if(r.kind==="project"&&current?.id===r.id||r.kind==="series"&&current?.series_id===r.id){current=null;$("#project-detail").classList.add("hidden");$("#project-form").classList.remove("hidden")}
     if(r.kind==="series"&&currentSeries?.id===r.id){currentSeries=null;$("#series-detail").classList.add("hidden");$("#series-form").classList.remove("hidden")}
     await refreshManagement();notice(result.pending_cleanup?"记录已删除；部分文件待清理，请关闭占用后到设置重试":"已删除；仍被其他项目使用的素材和文件已保留");
   }finally{button.disabled=false}
 });
 $("#retry-cleanup").onclick=guarded(async()=>{await api("manage/cleanup",{});await refreshManagement();notice("待清理文件已清理")});
 $("#script-edit-form").onsubmit=guarded(async event=>{
   event.preventDefault();const form=event.target,button=form.querySelector('button[type="submit"]');if(button.disabled)return;button.disabled=true;
   try{const edit=scriptEdit,route=edit.series_id?`series/${edit.series_id}/episodes/${edit.id}/script`:`projects/${edit.id}/script`;
     await api(route,{script:form.elements.script.value,expected_revision:edit.revision});$("#script-edit-dialog").close();await refreshManagement();notice("未开始的本集剧本已保存")
   }finally{button.disabled=false}
 });
 $("#edit-project-script").onclick=guarded(()=>openScriptEditor(current.id));
 $("#append-series").onclick=guarded(openAppendDialog);
 $("#append-text-file").onchange=guarded(async event=>{const file=event.target.files[0];if(file){if(file.size>3*1024*1024)throw Error("TXT超过3MB，请分批输入。");const value=await file.text();if(value.includes("\ufffd"))throw Error("请将TXT另存为UTF-8。");$("#append-form").elements.text.value=value}});
 $("#append-form").onsubmit=guarded(async event=>{
   event.preventDefault();if(appendingSeries)return;
   const form=event.target,id=appendContext.id,body={...Object.fromEntries(new FormData(form)),input_type:form.elements.input_type.value,expected_revision:appendContext.revision,request_id:appendRequestId};
   body.timing_policy=timingFromForm(form);
   appendingSeries=true;appendPhase="posting";const controls=[...form.elements].map(el=>[el,el.disabled]);controls.forEach(([el])=>el.disabled=true);
   notice("正在保存并校验后续剧本，请稍候…");
   try{await api(`series/${id}/append`,body,APPEND_POST);appendPhase="saved";$("#append-dialog").close();await afterAppendSaved(id);notice("后续剧本已开始，集数和人物场景沿用原剧")}
   finally{appendingSeries=false;appendPhase="";controls.forEach(([el,disabled])=>el.disabled=disabled)}
 });
}
async function initManagement(){bindManagementControls();await loadCleanupHint()}
