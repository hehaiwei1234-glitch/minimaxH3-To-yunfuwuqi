"""Only new-mode coverage. Mock services and tiny FFmpeg files; no paid API/GPU."""
import asyncio
import copy
import importlib
import json
import unittest
from unittest.mock import AsyncMock, patch
from aiohttp import web
from test_core import ROOT, domain
import test_integration as integration
import test_image_series as images

service=importlib.import_module('h3ad_test.production_draft.service')
schema=importlib.import_module('h3ad_test.production_draft.schema')
runtime=importlib.import_module('h3ad_test.production_draft.runtime')
evidence=importlib.import_module('h3ad_test.production_draft.http').evidence
providers=importlib.import_module('h3ad_test.providers')
review=importlib.import_module('h3ad_test.review')

def draft():
    return {'schema':'h3-production-draft','version':1,'title':'离线制作稿测试','style':'Natural cinematic light.',
        'assets':[{'key':'hero','kind':'image','role':'character','label':'女主','source':{'label':'女主'},
                   'description':{'en':'The same woman wearing a white coat.','zh':'同一名穿白衣的女子。'}}],
        'characters':{'女主':{'image_keys':['hero'],'voice_description':{'en':'A restrained, natural adult voice.','zh':'克制自然的成年声线。'}}},
        'episodes':[{'title':'见面','script':'女主：你好。','summary':'女主打招呼。','segments':[
            {'title':'问候','duration_seconds':2,'generation_seconds':2,'continuity':'cut','depends_on_previous':False,
             'use_previous_episode_state':False,'characters':['女主'],'asset_keys':['hero'],'image_reference_keys':['hero'],
             'image_prompt':'A medium shot of the supplied woman, soft light.','visual_zh':'女主打招呼。','camera_zh':'缓慢推进',
             'dialogue':[{'speaker':'女主','text':'你好。','start_seconds':.10,'end_seconds':1.25}],
             'shots':[{'start_seconds':0,'end_seconds':2,'visual_en':'Slow dolly toward [[asset:hero]] as she greets someone off camera.',
                       'visual_zh':'缓慢推向[[asset:hero]]，她向画外人问好。','dialogue_indices':[0]}],
             'sound_en':'Quiet room ambience.','sound_zh':'安静的室内环境声。'}]}]}

class SchemaTests(unittest.TestCase):
    def test_valid_and_exact_dialogue(self): self.assertEqual(schema.loads(draft()),draft())
    def test_malformed_types_unknown_fields_and_versions(self):
        for change in [lambda d:d.update(version=2),lambda d:d.update(typo=1),lambda d:d['episodes'][0]['segments'][0].update(dialogue=None)]:
            d=draft();change(d)
            with self.assertRaises(ValueError):schema.loads(d)
    def test_incomplete_translation_pending_is_not_fake(self):
        d=draft();d['assets'][0]['description']='The same supplied woman.'
        d['characters']['女主']['voice_description']={'en':'A calm adult voice.'}
        d['episodes'][0]['segments'][0]['shots'][0]['visual_zh']=None
        parsed=schema.loads(d)
        self.assertIn('待补',parsed['assets'][0]['description']['zh'])
        self.assertIn('待补',parsed['episodes'][0]['segments'][0]['shots'][0]['visual_zh'])
    def test_timeline_dialogue_and_reference_faults_rejected(self):
        changes=[lambda s:s.update(generation_seconds=1),lambda s:s.update(duration_seconds=2.01),
                 lambda s:s['dialogue'][0].update(end_seconds=2),lambda s:s['dialogue'][0].update(text='再见。'),
                 lambda s:s['shots'][0].update(dialogue_indices=[]),lambda s:s['shots'][0].update(visual_en='[[asset:missing]]'),
                 lambda s:s.update(continuity='continue'),lambda s:s.update(opening_frame_key='hero',use_previous_episode_state=True)]
        for change in changes:
            d=draft();change(d['episodes'][0]['segments'][0])
            with self.assertRaises(ValueError): schema.loads(d)
    def test_duplicate_json_keys_rejected(self):
        with self.assertRaisesRegex(ValueError,'重复'):schema.loads('{"version":1,"version":1}')

class Fixture(unittest.IsolatedAsyncioTestCase): pass
for _source in (integration.IntegrationTests,images.NewPipelineTests):
    for _name,_method in vars(_source).items():
        if callable(_method) and not _name.startswith('test_'):setattr(Fixture,_name,_method)
del _source,_name,_method

class DraftExecutionTests(Fixture):
    async def asyncSetUp(self):
        await Fixture.asyncSetUp(self)
        self.engine=service.Engine(self.store,self.files,ROOT,self.url);self.manager=service.SeriesManager(self.engine)
        self.local();self.store.save_settings({'openai_api_key':'','provider':'local','local_model':'','review_image_enabled':False,'review_video_enabled':False})
    def create(self,d=None,**options):
        return self.manager.create({'input_type':'production_draft','text':json.dumps(d or draft(),ensure_ascii=False),
                                   'workflow_id':self.video['id'],**options})
    async def test_two_episodes_complete_with_zero_creative_calls_and_resume_reuses(self):
        d=draft();d['episodes'].append(copy.deepcopy(d['episodes'][0]));d['episodes'][1]['title']='再见面'
        d['episodes'][1]['segments'][0]['use_previous_episode_state']=True
        with patch.object(providers.AIClient,'text',AsyncMock(side_effect=AssertionError('creative API prohibited'))):
            s=await self.finish_series(self.create(d)['id'])
        self.assertEqual(s['status'],'complete',s['error']);self.assertEqual(self.ai_calls,0);self.assertEqual(self.image_calls,0)
        self.assertEqual(len(self.graphs),4)
        p=self.store.get('project',s['project_ids'][1]);c=p['clips'][0]
        self.assertTrue(c.get('state_reference_source'));self.assertIn('0.100s to 1.250s',c['prompt_en'])
        self.assertNotIn('<Audio 1>',c['prompt_en']);self.assertEqual(c['dialogue'][0]['text'],'你好。')
        self.assertEqual(evidence(self.store,'series',s['id'])['api_requests_total'],0)
        self.assertEqual(s['input_type'],'production_draft')
    async def test_partial_failure_restart_keeps_first_output_and_seed(self):
        d=draft();d['episodes'][0]['segments'].append(copy.deepcopy(d['episodes'][0]['segments'][0]));d['episodes'][0]['script']='女主：你好。\n女主：你好。'
        s=self.create(d);original=self.engine.prepare_clip
        async def failure(identity,index,ai,cfg):
            if index==1:raise RuntimeError('mock stop')
            return await original(identity,index,ai,cfg)
        self.engine.prepare_clip=failure
        s=await self.finish_series(s['id']);self.assertEqual(s['status'],'partial');p=self.store.get('project',s['project_ids'][0]);first=copy.deepcopy(p['clips'][0])
        self.assertTrue(first.get('output'))
        self.engine=service.Engine(self.store,self.files,ROOT,self.url);self.manager=service.SeriesManager(self.engine)
        with patch.object(providers.AIClient,'text',AsyncMock(side_effect=AssertionError('creative'))):
            self.manager.retry_episode(s['id'],s['project_ids'][0]);await asyncio.wait_for(self.manager.tasks[s['id']],40)
            s=self.store.get('series',s['id'])
        self.assertEqual(s['status'],'complete',s['error']);p=self.store.get('project',s['project_ids'][0]);self.assertEqual(p['clips'][0]['seed'],first['seed'])
        self.assertEqual(p['clips'][0]['output'],first['output']);self.assertEqual(len(self.graphs),4)
    async def test_invalid_import_is_atomic_before_gpu_and_api(self):
        d=draft();d['episodes'][0]['segments'][0]['shots'][0]['visual_en']='[[asset:missing]]'
        with self.assertRaises(ValueError):self.create(d)
        self.assertFalse(self.store.list('series'));self.assertFalse(self.graphs);self.assertFalse(self.ai_calls)
    async def test_manual_timing_constraints_are_not_ignored(self):
        for policy in ({'episode':{'enabled':True,'seconds':10}},{'task':{'enabled':True,'seconds':4}},{'total':{'enabled':True,'seconds':3}}):
            with self.assertRaisesRegex(ValueError,'时长'):self.create(timing_policy=policy)
        self.assertFalse(self.store.list('series'))
    async def test_duplicate_named_assets_need_explicit_selection(self):
        self.files.write_asset(self.store,'other.png',self.png,{'role':'character','label':'女主'})
        with self.assertRaisesRegex(ValueError,'多个候选'):self.create()
        s=self.create(asset_ids=[self.asset['id']]);self.assertEqual(s['draft_asset_bindings']['hero'],self.asset['id'])
    async def test_reused_shared_assets_generated_once_then_append_no_memory_api(self):
        d=draft();d['assets'].append({'key':'room','kind':'image','role':'scene','label':'房间',
                                    'description':{'en':'A small room.','zh':'小房间。'},'generate':{'image_prompt':'Small quiet room.','reference_keys':[]}})
        d['episodes'][0]['segments'][0]['image_reference_keys'].append('room')
        s=await self.finish_series(self.create(d)['id']);self.assertEqual(s['status'],'complete',s['error']);self.assertEqual(len(self.graphs),3)
        body={'input_type':'production_draft','text':json.dumps(d,ensure_ascii=False),'expected_revision':s['revision'],'request_id':'batch-two'}
        appended=self.manager.append(s['id'],body);again=self.manager.append(s['id'],body);self.assertEqual(again['revision'],appended['revision'])
        with patch.object(providers.AIClient,'text',AsyncMock(side_effect=AssertionError('creative'))):s=await self.finish_series(s['id'])
        self.assertEqual(s['status'],'complete',s['error']);self.assertEqual(len(self.graphs),5);self.assertEqual(len(s['project_ids']),2)
        self.assertIn('女主打招呼',s['continuity_summary'])
    async def test_video_ng_retry_has_no_creative_request_and_keeps_authored_timing(self):
        self.store.save_settings({'review_video_enabled':True,'review_model':'mock','review_api_key':'mock','review_base_url':self.url,'review_video_attempts':2})
        check=AsyncMock(side_effect=[{'passed':False,'reasons':['wrong pose'],'summary':'NG'},{'passed':True,'reasons':[],'summary':'OK'}])
        with patch.object(review.Reviewer,'video',check),patch.object(providers.AIClient,'text',AsyncMock(side_effect=AssertionError('creative'))):
            s=await self.finish_series(self.create()['id'])
        self.assertEqual(s['status'],'complete',s['error']);self.assertEqual(check.await_count,2);self.assertEqual(len(self.graphs),3)
        c=self.store.get('project',s['project_ids'][0])['clips'][0];self.assertEqual(c['quality_attempt'],2);self.assertIn('0.100s to 1.250s',c['prompt_en'])
    async def test_existing_opening_image_requires_no_image_workflow_or_model(self):
        d=draft();d['episodes'][0]['segments'][0]['opening_frame_key']='hero'
        self.store.save_settings({'image_workflow_id':'','image_reference_workflow_id':''})
        with patch.object(providers.AIClient,'text',AsyncMock(side_effect=AssertionError('creative'))):s=await self.finish_series(self.create(d)['id'])
        self.assertEqual(s['status'],'complete',s['error']);self.assertEqual(len(self.graphs),1)
    async def test_image_api_is_opt_in_and_local_default_does_not_change_settings(self):
        self.store.save_settings({'image_provider':'api'})
        s=await self.finish_series(self.create()['id']);self.assertEqual(s['status'],'complete',s['error']);self.assertEqual(self.image_calls,0)
        self.assertEqual(self.store.settings()['image_provider'],'api')
        s=await self.finish_series(self.create(allow_image_api=True)['id']);self.assertEqual(s['status'],'complete',s['error']);self.assertEqual(self.image_calls,1)
        report=evidence(self.store,'series',s['id']);self.assertEqual(report['api_counts_by_purpose'].get('图片生成'),1)
    async def test_missing_voice_is_explicit_error_never_audio_one_guess(self):
        d=draft();d['assets'].append({'key':'voice','kind':'audio','role':'voice','label':'女主声音','source':{'label':'女主声音'},'description':{'en':'Natural voice.','zh':'自然人声。'}});d['characters']['女主']['voice_key']='voice'
        with self.assertRaisesRegex(ValueError,'未找到'):self.create(d)
        self.assertFalse(self.graphs)

    async def test_real_mock_review_http_and_asr_are_only_model_requests(self):
        checks=[]
        async def visual(request):
            payload=await request.json();checks.append('visual')
            self.assertTrue(any(item.get('type')=='image_url' for item in payload['messages'][1]['content']))
            return web.json_response({'choices':[{'finish_reason':'stop','message':{'content':json.dumps({'passed':True,'reasons':[],'summary':'OK'})}}]})
        async def asr(request):
            await request.post();checks.append('audio');return web.json_response({'text':'你好。'})
        app=web.Application();app.router.add_post('/chat/completions',visual);app.router.add_post('/audio/transcriptions',asr)
        runner=web.AppRunner(app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start();url=f'http://127.0.0.1:{site._server.sockets[0].getsockname()[1]}'
        try:
            self.store.save_settings({'review_image_enabled':True,'review_video_enabled':True,'review_model':'mock-vision','review_api_key':'mock','review_base_url':url,
                                     'review_audio':True,'asr_provider':'compatible','asr_base_url':url,'asr_model':'mock-asr','asr_api_key':'mock'})
            with patch.object(providers.AIClient,'text',AsyncMock(side_effect=AssertionError('creative'))):s=await self.finish_series(self.create()['id'])
            self.assertEqual(s['status'],'complete',s['error']);report=evidence(self.store,'series',s['id'])
            self.assertEqual(checks.count('visual'),2);self.assertEqual(checks.count('audio'),1)
            self.assertEqual(report['api_counts_by_purpose'],{'图片审核':1,'视频审核':1,'音频识别':1})
            self.assertEqual(report['creative_requests_recorded'],0);self.assertEqual(report['unclassified_requests'],0)
        finally:await runner.cleanup()

    async def test_continue_shot_offsets_dialogue_and_uses_adopted_previous_output(self):
        w=copy.deepcopy(self.video)
        d=draft();s=copy.deepcopy(d['episodes'][0]['segments'][0]);s.update(continuity='continue',depends_on_previous=True)
        d['episodes'][0]['segments'].append(s);d['episodes'][0]['script']+='\n女主：你好。'
        record=await self.finish_series(self.create(d,workflow_id=w['id'])['id'])
        self.assertEqual(record['status'],'complete',record['error'])
        p=self.store.get('project',record['project_ids'][0]);c=p['clips'][1]
        axis=images.w.timing(w,c,p['clips'][0]);start=axis['new_content_start_seconds']+.1
        self.assertIn(f'{start:.3f}s to',c['prompt_en']);self.assertTrue(c.get('state_reference_source'))
        graph=next(g for g in reversed(self.graphs) if 'node_40' in g)
        self.assertEqual(graph['node_40']['inputs']['previous_video_name'],self.files.output_path(p['clips'][0]['output']).relative_to(self.files.output).as_posix()+' [output]')

    async def test_existing_voice_and_pin_replacement_are_real_bindings(self):
        voice=self.files.write_asset(self.store,'voice.wav',b'voice fixture',{'role':'voice','label':'女主声音','speaker':'女主'})
        d=draft();d['assets'].append({'key':'voice','kind':'audio','role':'voice','label':'女主声音','source':{'label':'女主声音'},'description':{'en':'A natural voice sample.','zh':'自然人声样本。'}})
        d['characters']['女主']['voice_key']='voice'
        s=self.create(d);self.manager.create_children(s['id']);pid=self.store.get('series',s['id'])['project_ids'][0]
        replacement=self.files.write_asset(self.store,'new_voice.wav',b'new voice fixture',{'role':'voice','label':'新的声音','speaker':'女主'})
        report=service.save_bindings(self.store,'series',s['id'],{'expected_revision':1,'character_bindings':{'女主':{'image_ids':[self.asset['id']],'voice_id':replacement['id']}}})
        self.assertEqual(report['updated_episodes'],1)
        record=await self.finish_series(s['id']);self.assertEqual(record['status'],'complete',record['error'])
        clip=self.store.get('project',pid)['clips'][0]
        self.assertEqual([x['asset_id'] for x in clip['compiled_media_bindings'] if x['reference'].startswith('<Audio')],[replacement['id']])
        self.assertIn('<Audio 1>',clip['prompt_en']);self.assertNotIn('<Audio 2>',clip['prompt_en'])

    async def test_new_http_entry_previews_without_records_then_creates_draft_mode(self):
        from aiohttp.test_utils import TestClient,TestServer
        routes=importlib.import_module('h3ad_test.routes')
        application=routes.Application(self.store.root,self.files.input,self.files.output,self.url)
        app=web.Application();app.router.add_route('*','/{path:.*}',application.handle)
        async with TestClient(TestServer(app)) as client:
            body={'input_type':'production_draft','text':json.dumps(draft(),ensure_ascii=False),'workflow_id':self.video['id']}
            response=await client.post('/api/production-draft/preview',json=body)
            data=await response.json();self.assertEqual(response.status,200,data);self.assertEqual(data['creative_api_calls'],0)
            self.assertFalse(self.store.list('series'));self.assertFalse(self.graphs)
            response=await client.post('/api/series',json=body);data=await response.json()
            self.assertEqual(response.status,200,data);self.assertEqual(data['input_type'],'production_draft')
            self.assertNotIn('production_draft',data)
            response=await client.get('/production_draft.js');self.assertEqual(response.status,200)
            response=await client.get('/api/production-draft/examples/example.json');self.assertEqual(response.status,200)
            response=await client.get('/api/production-draft/report/series/'+data['id']);data=await response.json()
            self.assertEqual(response.status,200);self.assertEqual(data['api_requests_total'],0)

if __name__=='__main__': unittest.main()
