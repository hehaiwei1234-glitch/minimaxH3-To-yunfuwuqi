"use strict";
const BASE=location.pathname.replace(/\/?$/,"/"), $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
let assets=[],projects=[],current=null,selected=new Set(),redoIndices=[],settings={},creatingProject=false;
const FRONTEND_VERSION="0.8.3.10";
let runtimeIssue="",runtimeVersionFailed=false;
const statuses={draft:"等待开始",running:"运行中",queued:"排队中",pausing:"准备暂停",paused:"已暂停",error:"需要处理",complete:"已完成",partial:"本批已处理，有集待补做",deferred:"待补做（后续已继续）",deleted:"已删除",pending:"待准备",preparing:"准备图像和提示词",ready:"待生成视频",submitting:"正在提交",submitted:"ComfyUI 渲染中",generated:"视频已生成，待核对",blocked:"等待前段或对白处理"};
function dialogNotice(dialog,message,failed){
 // <dialog>.showModal() 会盖住页面顶部的状态栏，弹窗里的失败原因必须显示在弹窗自己里面。
 let box=dialog.querySelector("[data-dialog-notice]");
 if(!box){
   box=document.createElement("p");box.dataset.dialogNotice="";box.setAttribute("role","alert");box.className="dialog-notice hidden";
   const rows=dialog.querySelectorAll("form > .row,form .row:last-child"),anchor=rows[rows.length-1];
   if(anchor?.parentNode)anchor.parentNode.insertBefore(box,anchor);else (dialog.querySelector("form")||dialog).appendChild(box);
   dialog.addEventListener("close",()=>box.classList.add("hidden"));
 }
 const changed=box.textContent!==message||box.classList.contains("hidden");
 box.textContent=message;box.classList.toggle("fail",!!failed);box.classList.remove("hidden");
 if(changed)box.scrollIntoView?.({block:"nearest"}); // 同一条错误重复出现（如自动刷新失败）时不要反复拉动滚动条
}
function clearDialogNotice(dialog){const box=dialog?.querySelector?.("[data-dialog-notice]");if(box)box.classList.add("hidden")}
function notice(message,failed=false,background=false){
 $("#notice").textContent=message;$("#notice").classList.toggle("fail",failed);
 // background：后台自动刷新的提示，只放在状态栏，不打扰正在填写的弹窗。
 const dialog=!background&&typeof document!=="undefined"&&document.querySelector?.("dialog[open]");
 if(dialog)dialogNotice(dialog,message,failed);
}
// 读取（GET）请求 45 秒没有任何结果就中止并报错，避免网络卡住时页面永远不动。
// 提交（POST）默认不设上限，因为服务器可能仍在处理；需要时用 opts.timeoutMs 指定，超时后的提示由 opts.timeoutHint 补充。
const GET_TIMEOUT_MS=globalThis.H3_GET_TIMEOUT_MS||45000; // 测试时可在页面加载前覆盖
async function api(path,body,opts={}){
 const read=body===undefined,limit=opts.timeoutMs||(read?GET_TIMEOUT_MS:0),ctl=limit&&typeof AbortController!=="undefined"?new AbortController():null,timer=ctl?setTimeout(()=>ctl.abort(),limit):0;
 const timedOut=()=>`请求超时（${Math.round(limit/1000)}秒没有响应），请检查 ComfyUI 是否在线、网络是否稳定。${opts.timeoutHint||""}`;
 try{
   let r;
   try{r=await fetch(BASE+"api/"+path,read?{cache:"no-store",signal:ctl?.signal}:body instanceof FormData?{method:"POST",body,signal:ctl?.signal}:{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body),signal:ctl?.signal})}
   catch(e){throw Error(e?.name==="AbortError"?timedOut():read?"无法连接到服务器：网络中断或 ComfyUI 已停止。":"没有收到服务器的回复：网络中断或 ComfyUI 已停止。这次操作可能已经执行，请刷新页面确认后再重试。")}
   let data;try{data=await r.json()}catch(e){throw Error(e?.name==="AbortError"?timedOut():"服务器没有返回有效内容，请检查 ComfyUI 是否在线。")}
   if(!r.ok)throw Error(data.error||"请求失败");return data;
 }finally{if(timer)clearTimeout(timer)}
}
function guarded(fn){return async(...args)=>{try{return await fn(...args)}catch(e){notice(e.message,true)}}}
async function loadRuntimeVersion(){
 const label=$("#runtime-version");runtimeVersionFailed=false;
 try{const result=await api("version");label.textContent=`页面 v${FRONTEND_VERSION} · 后端 v${result.software_version}`;if(result.software_version!==FRONTEND_VERSION)runtimeIssue="页面和后端版本不一致，请完全停止 ComfyUI 后重新启动并刷新。"}
 catch{runtimeVersionFailed=true;label.textContent=`页面 v${FRONTEND_VERSION} · 后端版本未确认`;runtimeIssue="无法确认后端版本，请完全停止 ComfyUI 后重新启动并刷新。"}
}
function tab(name){$$(".tab").forEach(e=>e.classList.toggle("active",e.id===name));$$("nav button").forEach(e=>e.classList.toggle("active",e.dataset.tab===name))}
$$("nav button").forEach(b=>b.onclick=guarded(async()=>{tab(b.dataset.tab);if(b.dataset.tab==="assets")await loadAssets();if(b.dataset.tab==="workflows")await loadWorkflows();if(b.dataset.tab==="image-workflows")await loadImageWorkflows();if(b.dataset.tab==="series")await loadSeries()}));$$("[data-close]").forEach(b=>b.onclick=()=>$("#"+b.dataset.close).close());
async function loadSettings(){settings=await api("settings");for(let [k,v]of Object.entries(settings)){let input=$("#settings-form").elements.namedItem(k);if(!input)continue;if(input.type==="checkbox")input.checked=!!v;else input.value=String(v);if(k.endsWith("_api_key"))input.placeholder=settings[k+"_configured"]?"已保存；留空保留":"尚未填写"}const policy=$("#settings-form").elements.namedItem("series_continue_on_error");if(policy){policy.checked=true;policy.disabled=true}imageProviderView()}
function formSettings(){const data={};for(let input of $("#settings-form").elements){if(!input.name)continue;data[input.name]=input.type==="checkbox"?input.checked:input.type==="number"?Number(input.value):input.value.trim()}return data}
async function saveSettings(){const body=formSettings();settings=await api("settings",body);const persisted=await api("settings");for(const key of ["image_workflow_id","image_reference_workflow_id"]){if(body[key]!==persisted[key])throw Error("模板选择未保存成功，请重试。")}await loadSettings();$("#image-settings-status").textContent="设置已保存并核对。";notice("设置已保存并核对")}
$("#settings-form").onsubmit=guarded(async e=>{e.preventDefault();await saveSettings()});
$("#test-connection").onclick=guarded(async()=>{await saveSettings();$("#connection-result").textContent="正在检查 ComfyUI 和视频工具…";try{const result=await api("connection",{});$("#connection-result").textContent=`已连接 · 独立节点 ${result.independent_nodes.length} 个 · 视频工具就绪`;notice("ComfyUI 和视频工具检查通过")}catch(e){$("#connection-result").textContent=e.message;throw e}});
$("#clear-keys").onclick=guarded(async()=>{if(!confirm("清除软件保存的所有 API Key？"))return;await api("settings",{clear_keys:["openai_api_key","deepseek_api_key","image_api_key","comfy_api_key","local_api_key","review_api_key","asr_api_key"]});await loadSettings();notice("Key 已清除")});
async function loadAssets(){
 assets=await api("assets"+managementQuery("asset"));const available=assets.filter(a=>!a.archived);
 renderAssetChoices(available);
 $("#asset-list").innerHTML=assets.map(a=>{const source=BASE+"api/assets/"+a.id+"/file";const preview=a.kind==="image"?`<img loading="lazy" src="${source}" alt="${esc(a.label)}">`:a.kind==="audio"?`<audio controls preload="none" src="${source}"></audio>`:`<video controls preload="none" src="${source}"></video>`;
   return `<div class="asset-card">${preview}<h3>${esc(a.label)}${a.archived?" · 已归档":""}</h3><p class="muted">${esc(a.name)}</p><p>${esc(a.speaker)} ${esc(a.description)}</p><button data-edit="${esc(a.id)}">编辑人物 / 用途</button>${managementButtons("asset",a.id,a.archived)}</div>`
 }).join("");
 $$("[data-edit]").forEach(b=>b.onclick=()=>{const a=assets.find(a=>a.id===b.dataset.edit);for(const k of ["id","label","role","speaker","description"])$("#asset-edit").elements.namedItem(k).value=a[k]||"";$("#asset-dialog").showModal()});bindManagement();
}
$("#upload-form").onsubmit=guarded(async e=>{e.preventDefault();let form=new FormData();for(let file of $("#upload-form").elements.files.files)form.append("file",file,file.name);notice("正在上传素材…");await api("upload",form);$("#upload-form").reset();await loadAssets();notice("上传完成，请填写人物和用途")});
$("#asset-edit").onsubmit=guarded(async e=>{e.preventDefault();let body=Object.fromEntries(new FormData(e.target));await api("assets/"+body.id,body);$("#asset-dialog").close();await loadAssets();notice("素材说明已保存")});
$("#existing-open").onclick=guarded(async()=>{let list=await api("existing",undefined,{timeoutMs:180000});$("#existing-list").innerHTML=list.length?list.map((a,i)=>`<div class="existing-item"><span>${esc(a.relative_path)}</span><button data-import="${i}">加入</button></div>`).join(""):"input 目录没有可用素材。";$$("[data-import]").forEach(b=>b.onclick=guarded(async()=>{b.disabled=true;await api("import",list[Number(b.dataset.import)]);await loadAssets();b.textContent="已加入";notice("已加入素材库")}));$("#existing-dialog").showModal()});
async function loadProjects(){projects=await api("projects"+managementQuery("project"));$("#project-list").innerHTML=projects.map(p=>`<div class="record-item"><button class="project-item ${current?.id===p.id?"active":""}" data-project="${p.id}">${esc(p.title)}<small>${p.archived?"已归档 · ":""}${statuses[p.status]||esc(p.status)} · 创建 ${esc(new Date(p.created_at*1000).toLocaleString())}</small></button>${managementButtons("project",p.id,p.archived)}</div>`).join("");$$("[data-project]").forEach(b=>b.onclick=guarded(()=>openProject(b.dataset.project)));bindManagement()}
$("#new-project").onclick=guarded(async()=>{if(creatingProject)return;current=null;selected.clear();$("#project-form").classList.remove("hidden");$("#project-detail").classList.add("hidden");await Promise.all([loadProjects(),loadAssets(),loadWorkflows()])});
$("#project-form").onsubmit=guarded(async e=>{
 e.preventDefault();if(creatingProject)return;
 const form=e.target,body=Object.fromEntries(new FormData(form));
 body.timing_policy=timingFromForm(form);
 body.asset_ids=$$("#asset-choices input:checked").map(x=>x.value);
 if(!body.workflow_id)throw Error("请先选择本集使用的工作流。");
 creatingProject=true;const controls=[...form.elements,$("#new-project")].map(el=>[el,el.disabled]);
 controls.forEach(([el])=>el.disabled=true);
 try {
   const p=await api("projects",body);resetAssetPicker("#asset-choices"); // 已创建：清空勾选，避免上一集的人物绑定带进下一集
   // Once created, show the existing project even if starting it fails.
   await openProject(p.id);
   await api("projects/"+p.id+"/start",{});
   await openProject(p.id);notice("已加入整集队列，按提交顺序自动制作");
 } finally {creatingProject=false;controls.forEach(([el,disabled])=>el.disabled=disabled)}
});
async function openProject(id){tab("projects");if(current?.id!==id)selected.clear();current=await api("projects/"+id);$("#project-form").classList.add("hidden");$("#project-detail").classList.remove("hidden");renderProject();await renderImageJobs(id,$("#project-image-jobs"));await loadProjects()}
function renderProject(){const p=current;if(typeof renderProduction==="function")renderProduction(p,"project");showProjectWorkflow(p);const active=!!p.archived||["running","queued","pausing"].includes(p.status),done=p.clips.filter(c=>c.output).length;$("#project-title").textContent=p.title;$("#export-project").href=BASE+"api/projects/"+p.id+"/export";$("#project-progress").innerHTML=`<div class="progress"><b>${esc(p.phase)}</b><p class="muted">视频完成 ${done} / ${p.clips.length||"待拆分"} · ${statuses[p.status]||esc(p.status)}</p><progress max="${p.clips.length||1}" value="${done}"></progress></div>`;$("#project-error").textContent=p.error?(p.status==="deferred"?"待补做原因：":"任务记录：")+p.error:"";$("#project-error").classList.toggle("hidden",!p.error);$("#resume-project").disabled=active||p.status==="complete";$("#resume-project").textContent=p.status==="deferred"?"补做缺失镜头":"开始 / 继续";$("#pause-project").disabled=!active||p.status==="pausing";$("#redo-open").disabled=active||!selected.size;$("#edit-project-script").disabled=!scriptEditable(p);const final=$("#final-video");if(p.final){if(final.dataset.version!==p.id+"_"+p.final.filename){final.innerHTML=`<div class="final"><h2>${p.final.partial?"已有素材合辑（缺第"+esc((p.final.missing_clips||[]).join("、"))+"段）":"整集成片"} · ${Number(p.final.duration).toFixed(1)} 秒</h2><video controls preload="metadata" src="${BASE}api/projects/${p.id}/final?v=${encodeURIComponent(p.final.filename)}"></video><a class="link" href="${BASE}api/projects/${p.id}/final" download="${esc(p.title)}.mp4">${p.final.partial?"下载已有素材合辑":"下载成片"}</a></div>`;final.dataset.version=p.id+"_"+p.final.filename}}else{final.innerHTML="";final.dataset.version=""}
 const clipsKey=JSON.stringify({active,final:!!p.final,clips:p.clips.map(c=>[c.status,c.duration_seconds,c.generation_seconds,c.dialogue_timing,c.retention_audit,c.quality_accepted,c.adopted_ng,c.quality_verdict,c.dialogue_check,c.dialogue_adoption,c.generation,!!c.output,c.frame_asset_id,c.prompt_en,c.submission_unknown,c.task_failure,c.recovery_unchecked,c.recovery_gap,c.image_quality])});if($("#clips").dataset.key!==p.id+clipsKey){$("#clips").dataset.key=p.id+clipsKey;$("#clips").innerHTML=p.clips.map((c,i)=>{let media=c.output?`<video controls preload="none" src="${BASE}api/projects/${p.id}/clips/${i}/video?v=${c.generation}"></video>`:c.frame_asset_id?`<img loading="lazy" src="${BASE}api/projects/${p.id}/clips/${i}/image?v=${c.generation}" alt="开场图">`:c.status==="deferred"?"<span class='muted'>NG · 无视频，待补做</span>":"<span class='muted'>等待准备</span>";return `<div class="clip"><div>${media}</div><div><div class="row spread"><label class="check"><input data-select="${i}" type="checkbox" ${selected.has(i)?"checked":""}><b>${i+1}. ${esc(c.title)}</b></label><span class="badge">${statuses[c.status]||esc(c.status)}</span></div><p>${esc(c.visual_zh)}</p>${c.image_quality?.adopted_ng?`<p class="badge">开场图采用NG${c.image_quality.verdict?.unchecked?"（图片审核未完成）":"（图片审核未通过，次数耗尽）"}</p>`:""}${c.task_failure?`<p class="muted">任务失败记录：${esc(c.task_failure.message)} · 已保留已有素材，后续继续。</p>`:""}${c.recovery_gap?`<p class="muted">前段缺失，本段使用固定素材独立生成；连续性降级。</p>`:""}${renderDialogueCheck(c,i,active)}${c.quality_accepted?`<p class="badge">${c.recovery_unchecked?"自动步骤失败，已保留NG（未完成核对）":c.adopted_ng?"未通过核对，次数耗尽已采用NG":c.video_reviewed===false?"已采用（视频视觉未审核）":"自检通过"}</p>`:""}${c.quality_verdict?`<p class="muted">自检第 ${c.quality_attempt||1} 次：${esc(c.quality_verdict.summary||"")} ${esc((c.quality_verdict.reasons||[]).join("；"))}</p>`:""}<p class="muted">${c.timing_version?"安排 "+c.duration_seconds+" 秒 · 生成请求 "+c.generation_seconds+" 秒":c.duration_seconds+" 秒"}${c.dialogue_timing?.extra_seconds?" · 对白余量累计 +"+Number(c.dialogue_timing.extra_seconds).toFixed(2)+" 秒":""} · ${c.continuity==="continue"?"续接上一段":"独立镜头"} · 第 ${c.generation} 次</p><p class="muted">视频Seed：${esc(c.seed??"工作流原值")} · 图片Seed：${esc(c.image_seed??"未记录／API未提供")}</p><div class="row">${c.prompt_en?`<button data-prompt="${i}">查看中英提示词</button>`:""}${c.output?`<a class="link" href="${BASE}api/projects/${p.id}/clips/${i}/video" download>下载镜头</a>`:""}${c.job_id?`<a class="link" href="${BASE}api/projects/${p.id}/clips/${i}/workflow" download>API 工作流</a>`:""}${c.submission_unknown&&!c.prompt_id?`<button data-resubmit="${i}">原任务不存在，允许重新提交</button>`:""}</div></div></div>`}).join("");$$("[data-select]").forEach(b=>b.onchange=()=>{b.checked?selected.add(Number(b.dataset.select)):selected.delete(Number(b.dataset.select));$("#redo-open").disabled=active||!selected.size});$$("[data-prompt]").forEach(b=>b.onclick=()=>{let c=current.clips[Number(b.dataset.prompt)];$("#prompt-content").innerHTML=`${c.compiled_media_bindings?.length?`<h3>实际绑定素材</h3><pre>${esc(c.compiled_media_bindings.map(a=>a.reference+" = "+a.name).join("\n"))}</pre>`:""}<h3>中文直译</h3><pre>${esc(c.prompt_zh)}</pre><h3>发送给 H3 的英文正文</h3><pre>${esc(c.prompt_en)}</pre>`;$("#prompt-dialog").showModal()});$$("[data-resubmit]").forEach(b=>b.onclick=guarded(async()=>{if(!confirm("请先在 ComfyUI 核对队列和输出。确定原任务没有提交、没有生成视频，再允许重新提交。"))return;await api("projects/"+current.id+"/resubmit",{index:Number(b.dataset.resubmit)});await openProject(current.id)}))}
 bindDialogueActions();
 $("#events").innerHTML=[...p.events].reverse().map(e=>`<div>${new Date(e.time*1000).toLocaleTimeString()} ${esc(e.message)}</div>`).join("")}
$("#resume-project").onclick=guarded(async()=>{await api("projects/"+current.id+"/start",{});await openProject(current.id);notice("已继续，先核对已提交任务")});
$("#pause-project").onclick=guarded(async()=>{await api("projects/"+current.id+"/pause",{});await openProject(current.id);notice("当前 ComfyUI 视频完成后暂停")});
$("#redo-open").onclick=()=>{redoIndices=[...selected].sort((a,b)=>a-b);let affected=new Set(redoIndices);current.clips.forEach((c,i)=>{if(i&&(c.continuity==="continue"||c.depends_on_previous)&&affected.has(i-1))affected.add(i)});$("#redo-scope").textContent="将重做片段："+[...affected].map(i=>i+1).join("、")+"。其余镜头保留。";const canSeed=!current.workflow_snapshot||current.workflow_snapshot.metadata.seed!==null;$("#redo-form").elements.new_seed.disabled=!canSeed;$("#redo-form").elements.new_seed.checked=canSeed;$("#redo-dialog").showModal()};
$("#redo-form").onsubmit=guarded(async e=>{e.preventDefault();const f=e.target;await api("projects/"+current.id+"/redo",{indices:redoIndices,feedback:f.elements.feedback.value,new_seed:f.elements.new_seed.checked,regenerate_image:f.elements.regenerate_image.checked});$("#redo-dialog").close();selected.clear();await openProject(current.id);notice("已开始重做，完成后会重新合成整集")});
// 每 3 秒刷新一次。上一次还没结束就跳过（网络慢时不要堆积请求）；连接出问题只提示一次、恢复后提示一次，且不打断打开着的弹窗。
let polling=false,pollFailure="";
async function pollOnce(){if(current){let id=current.id;let p=await api("projects/"+id);if(current?.id!==id)return;current=p;renderProject();await renderImageJobs(id,$("#project-image-jobs"))}if(currentSeries){const id=currentSeries.id;const s=await api("series/"+id);if(currentSeries?.id===id){currentSeries=s;renderSeries();await renderImageJobs(id,$("#series-image-jobs"))}}await Promise.all([loadProjects(),loadSeries()])}
setInterval(async()=>{
 if(polling)return;polling=true;
 try{await pollOnce();if(pollFailure){if($("#notice").textContent===pollFailure)notice("与服务器的连接已恢复",false,true);pollFailure=""}}
 catch(e){const message="与服务器的连接不稳定："+plainMessage(e)+"。页面会自动重试。";if(pollFailure!==message){pollFailure=message;notice(message,true,true)}}
 finally{polling=false}
},3000);
timingFields();
if(typeof initProduction==="function")initProduction();
// 启动分两步。第一步先把所有按钮接好，不发任何请求，所以后面的请求无论失败、变慢还是卡住，“追加后续剧本”等按钮都立即可用。
// 第二步加载各个列表，每一步各自捕获错误；失败时状态栏说明原因，4 秒后重新加载一次，仍失败就保留红字提示。
const startupBinders=[["工作流按钮",()=>bindWorkflows()],["生图按钮",()=>bindImageWorkflows()],["整剧按钮",()=>bindSeries()],["管理按钮",()=>bindManagementControls()]];
const startupLoaders=[["版本",()=>loadRuntimeVersion()],["设置",()=>loadSettings()],["素材",()=>loadAssets()],["单集",()=>loadProjects()],["工作流",()=>loadWorkflows()],["生图工作流",()=>loadImageWorkflows()],["整剧",()=>loadSeries()],["待清理文件",()=>loadCleanupHint()],["工作流草稿",()=>draftImportStep()]];
// 工作流草稿导入最多等 5 秒：卡住时，其他加载的失败说明和自动重试不受它拖累（单次飞行，重复调用不会再导入一次）。
const draftImportStep=()=>Promise.race([openWorkflowDraftFromUrl(),new Promise(resolve=>setTimeout(resolve,5000))]);
const failureText=(name,e)=>`${name}：${String(e?.message||e).replace(/[。.]+$/,"")}`;
async function collectFailures(steps){
 const failed=[];
 for(const [name,fn]of steps){try{await fn()}catch(e){failed.push(failureText(name,e))}}
 if(runtimeVersionFailed&&!failed.some(x=>x.startsWith("版本")))failed.unshift("版本：无法连接后端");
 return failed;
}
// 启动阶段的提示只写在页面顶部状态栏（background），不会冲掉用户此刻打开的弹窗里的内容。
async function startApp(){
 const failed=[],step=async(name,fn)=>{try{await fn()}catch(e){failed.push(failureText(name,e))}};
 for(const [name,fn]of startupBinders){try{fn()}catch(e){failed.push(failureText(name,e))}}
 await Promise.all([step("版本",loadRuntimeVersion),step("设置",loadSettings),step("素材",loadAssets),step("单集",loadProjects)]);
 await step("工作流",loadWorkflows);await step("生图工作流",loadImageWorkflows);await step("整剧",loadSeries);await step("待清理文件",loadCleanupHint);
 // 放在最后：即使草稿导入卡住，各个列表也已经加载好。
 await step("工作流草稿",draftImportStep);
 if(runtimeVersionFailed)failed.unshift("版本：无法连接后端");
 if(!failed.length){notice(runtimeIssue||"就绪：默认由 AI 安排时长",!!runtimeIssue,true);return}
 notice(`页面有 ${failed.length} 项数据没有加载成功（${failed.join("；")}）。按钮仍可使用，4 秒后自动重试。`,true,true);
 await new Promise(resolve=>setTimeout(resolve,4000));
 runtimeIssue="";const again=await collectFailures(startupLoaders);
 if(again.length)notice(`仍有 ${again.length} 项数据没有加载成功（${again.join("；")}）。请检查 ComfyUI 是否在线，然后刷新页面。`,true,true);
 else notice(runtimeIssue||"就绪：默认由 AI 安排时长",!!runtimeIssue,true);
}
startApp();
