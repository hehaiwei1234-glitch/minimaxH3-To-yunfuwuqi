// 浏览器测试共用：一个假的 ComfyUI 后端（只返回预设数据，可注入失败／卡住／断线），不调用任何付费接口。
// 用法见 test_asset_picker_browser.cjs、test_startup_browser.cjs。
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const {createRequire} = require('node:module');
const runtimeRequire = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES
  ? createRequire(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'package.json'))
  : require;
let chromium;
try { ({chromium} = runtimeRequire('playwright')); } catch { ({chromium} = require('/opt/node-tools/node_modules/playwright')); }

const STATIC = path.resolve(__dirname, '../static'), PREFIX = '/h3_autodrama_v1/';
const VERSION = fs.readFileSync(path.resolve(__dirname, '../version.py'), 'utf8').match(/'([^']+)'/)[1];
const MIME = {'.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8'};
const timing = () => ({version: 1, episode: {enabled: false, seconds: null}, total: {enabled: false, seconds: null}, task: {enabled: false, seconds: null}});
const workflow = {id: 'wf1', name: 'H3 视频工作流', version: 1, sha256: 'x', metadata: {media_mode: 'batch', continuation: true, seed: '1', duration_seconds: 4}, output_node_id: '9', checked_at: 1, created_at: 1};
const settings = {provider: 'openai', image_provider: 'api', generate_shot_images: true, review_image_enabled: true, dialogue_padding_seconds: 1.5,
  review_image_attempts: 3, review_video_attempts: 1, series_continue_on_error: true, image_workflow_id: '', image_reference_workflow_id: ''};

// 与 SeriesManager.public() 返回的形状一致。
function seriesRecord(over = {}) {
  const inputType = over.input_type || 'script';
  const batch = {id: 'initial', input_type: inputType, episode_count: 1, target_episode_seconds: 0, timing_policy: timing(), instructions: '',
    workflow_snapshot: workflow, image_workflow_snapshots: null, status: 'planned', start_index: 0, episode_total: 1, created_at: 1700000000};
  return {id: 'ser1', title: '测试剧', status: 'complete', phase: '全部成片已完成', error: '', input_type: inputType, asset_ids: [], character_bindings: {},
    generated_assets: {}, plan: {style: 'x', episode_count: 1}, project_ids: ['p1'], events: [], pause_requested: false, created_at: 1700000000, updated_at: 1700000100,
    revision: 1, continuity_summary: '第1集：…', memory_through: 1, removed_episodes: {}, workflow_snapshot: workflow, image_workflow_snapshots: null, batches: [batch],
    episodes: [{id: 'p1', title: '第1集：开始', status: 'complete', phase: '成片完成', error: '', final: {duration: 30, filename: 'f.mp4'}, archived: false, script_revision: 1, planned_duration_seconds: 30, editable: false}],
    active: false, deferred_count: 0, can_resume: false, can_append: true, next_episode_number: 2, shared_asset_count: 0, archived: false, ...over};
}

/**
 * state: {assets, projects, series: {id: record}, calls: [], fail: [rule], appendHandler(body, json), created}
 * rule: {method, match: RegExp(route), mode: 'html'|'drop'|'hang'|status code, times | forMs, error}
 */
async function startServer(state) {
  state.calls = state.calls || [];
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    const json = (obj, status = 200) => { res.writeHead(status, {'Content-Type': 'application/json'}); res.end(JSON.stringify(obj)); };
    if (!url.pathname.startsWith(PREFIX)) { res.writeHead(302, {Location: PREFIX}); return res.end(); }
    const rest = url.pathname.slice(PREFIX.length);
    if (!rest.startsWith('api/')) {
      const file = path.join(STATIC, rest || 'index.html');
      if (!file.startsWith(STATIC) || !fs.existsSync(file)) { res.writeHead(404); return res.end('nf'); }
      res.writeHead(200, {'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store'});
      return res.end(fs.readFileSync(file));
    }
    const route = rest.slice(4);
    let raw = '';
    req.on('data', c => raw += c);
    req.on('end', () => {
      let body; try { body = raw ? JSON.parse(raw) : undefined; } catch { body = raw; }
      state.calls.push({method: req.method, route, body});
      for (const rule of state.fail || []) {
        if (rule.method !== req.method || !rule.match.test(route) || (rule.times !== undefined && rule.times <= 0)) continue;
        // forMs：从第一次命中起的这段时间内一直失败（Chrome 会自动重试被切断的 GET，用次数没法稳定控制）。
        if (rule.forMs !== undefined) { rule.t0 = rule.t0 || Date.now(); if (Date.now() - rule.t0 > rule.forMs) continue; }
        if (rule.times !== undefined) rule.times--;
        rule.hits = (rule.hits || 0) + 1;
        if (rule.mode === 'drop') { req.socket.destroy(); return; }
        if (rule.mode === 'hang') return;
        if (rule.mode === 'html') { res.writeHead(502, {'Content-Type': 'text/html'}); return res.end('<html>Bad Gateway</html>'); }
        return json({error: rule.error || 'injected failure'}, typeof rule.mode === 'number' ? rule.mode : 500);
      }
      const key = req.method + ' ' + route.split('?')[0];
      const series = state.series || {};
      if (key === 'GET version') return json({software_version: VERSION});
      if (key === 'GET settings') return json(settings);
      if (key === 'POST settings') return json({...settings, ...body});
      if (key === 'GET assets') return json(state.assets || []);
      // 可选：state.projectRecords = {id: 完整项目记录}；state.clipsZip = Buffer（打包下载接口返回的内容）。
      const pm = route.split('?')[0].match(/^projects\/([^/]+)(?:\/(clips-zip))?$/);
      if (pm && state.projectRecords && state.projectRecords[pm[1]] && req.method === 'GET') {
        if (!pm[2]) return json(state.projectRecords[pm[1]]);
        res.writeHead(200, {'Content-Type': 'application/zip', 'Content-Disposition': "attachment; filename=\"clips.zip\"; filename*=UTF-8''%E7%AC%AC1%E9%9B%86_%E5%85%A8%E9%83%A8%E9%95%9C%E5%A4%B4.zip"});
        return res.end(state.clipsZip);
      }
      if (key === 'GET projects') return json(state.projects || []);
      if (key === 'GET workflows') return json([workflow]);
      if (key === 'GET image-workflows') return json([]);
      if (key === 'GET manage/cleanup') return json({pending: 0});
      if (route.startsWith('image-jobs')) return json([]);
      if (key === 'GET series') return json(Object.values(series).map(({id, title, status, phase, created_at, project_ids, archived}) => ({id, title, status, phase, created_at, project_ids, archived})));
      if (key === 'POST series') { state.created = body; return json(series[Object.keys(series)[0]] || seriesRecord()); }
      const m = route.split('?')[0].match(/^series\/([^/]+)(?:\/(\w+))?$/);
      if (m && series[m[1]]) {
        if (req.method === 'GET' && !m[2]) return json(series[m[1]]);
        if (req.method === 'POST' && m[2] === 'append') return state.appendHandler ? state.appendHandler(body, json) : json(series[m[1]]);
        if (req.method === 'POST' && m[2] === 'start') return json(series[m[1]]);
      }
      if (key === 'POST production-draft/preview') return json({episodes: 1, tasks: 3, seconds: 12.5, image_backend: '本地'});
      return json({error: 'not found: ' + key}, 404);
    });
  });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  return {server, url: `http://127.0.0.1:${server.address().port}${PREFIX}`};
}

// 记录状态栏文字、弹窗调用和页面错误，便于断言“用户实际看到了什么”。
const INIT_SCRIPT = `
(() => {
  const log = window.__log = {notices: [], dialogs: [], errors: []};
  window.addEventListener('error', e => log.errors.push(String(e.message)));
  window.addEventListener('unhandledrejection', e => log.errors.push(String(e.reason && e.reason.message || e.reason)));
  for (const name of ['showModal', 'close']) {
    const orig = HTMLDialogElement.prototype[name];
    HTMLDialogElement.prototype[name] = function (...a) { log.dialogs.push(name + ':' + this.id); return orig.apply(this, a); };
  }
  document.addEventListener('DOMContentLoaded', () => {
    const n = document.querySelector('#notice');
    new MutationObserver(() => log.notices.push((n.classList.contains('fail') ? '[FAIL] ' : '') + n.textContent)).observe(n, {childList: true, characterData: true, subtree: true, attributes: true});
  });
})();
`;

async function launch() { return chromium.launch({headless: true, args: ['--no-sandbox']}); }
async function openPage(browser, url, {viewport, timeoutMs} = {}) {
  const page = await (await browser.newContext({viewport: viewport || {width: 1280, height: 800}})).newPage();
  await page.addInitScript(INIT_SCRIPT);
  if (timeoutMs) await page.addInitScript(`window.H3_GET_TIMEOUT_MS=${timeoutMs}`);
  page.pageErrors = [];
  page.on('pageerror', e => page.pageErrors.push(e.message));
  await page.goto(url);
  return page;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
const getLog = page => page.evaluate(() => window.__log);
const waitReady = (page, ms = 6000) => page.waitForFunction(() => document.querySelector('#notice').textContent.includes('就绪：'), null, {timeout: ms});
const handlersBound = (page, ids) => page.evaluate(list => Object.fromEntries(list.map(([id, prop]) => [id + '.' + prop, !!document.getElementById(id)?.[prop]])), ids);

module.exports = {startServer, launch, openPage, sleep, getLog, waitReady, handlersBound, seriesRecord, workflow, settings, timing, VERSION, STATIC, PREFIX};
