// “下载本集全部镜头”按钮的浏览器测试：真浏览器 + 假后端；打开单集页面后按钮的显示、数量、地址、点击提示、真实触发 zip 下载。
// 运行：node tests/test_clips_download_browser.cjs   需要 playwright 和 Chromium；不调用付费接口。
const assert = require('node:assert/strict');
const F = require('./fake_backend.cjs');

const clip = (n, title, done) => ({title, status: done ? 'complete' : 'pending', visual_zh: '画面', duration_seconds: 6, generation_seconds: 6,
  ...(done ? {output: {type: 'output', subfolder: 'x', filename: `c${n}.mp4`}} : {})});
const project = (id, clips, over = {}) => ({id, title: `第${id}集`, script: 'x', status: 'complete', phase: '完成', error: '', plan: null, clips,
  generated_assets: {}, events: [], script_revision: 1, pause_requested: false, final: null, series_id: null, archived: false,
  settings: {}, character_bindings: {}, asset_ids: [], workflow_snapshot: null, created_at: 1700000000, updated_at: 1700000100, ...over});
// 最小的真 zip（空压缩包的 22 字节结尾记录），够浏览器当作下载。
const EMPTY_ZIP = Buffer.from('504b0506000000000000000000000000000000000000', 'hex');

(async () => {
  const browser = await F.launch();
  const projects = {
    p1: project('p1', [clip(1, '躲进婚纱架', true), clip(2, '捂住嘴', true), clip(3, '开门', false)]),
    p2: project('p2', [clip(1, '甲', false), clip(2, '乙', false)]),
  };
  const state = {series: {}, assets: [], projectRecords: projects, clipsZip: EMPTY_ZIP, projects: Object.values(projects).map(p => ({id: p.id, title: p.title, status: p.status, phase: p.phase, created_at: 1, updated_at: 1, series_id: null, archived: false}))};
  const {server, url} = await F.startServer(state);
  try {
    const context = await browser.newContext({viewport: {width: 1280, height: 800}, acceptDownloads: true});
    const page = await context.newPage();
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.goto(url);
    await F.waitReady(page);
    await page.click('nav [data-tab="projects"]');

    // 有 2 个已完成镜头：显示按钮、数量正确、地址指向打包接口
    await page.click('[data-project="p1"]');
    await page.waitForSelector('#project-detail:not(.hidden)');
    await page.waitForFunction(() => !document.querySelector('#download-clips').classList.contains('hidden'));
    assert.match((await page.textContent('#download-clips')).trim(), /下载本集全部镜头（2 个，zip）/);
    assert.match(await page.getAttribute('#download-clips', 'href'), /api\/projects\/p1\/clips-zip$/);
    // 原来的按钮都还在：单个镜头下载、重做、整集成片区域不受影响
    assert.equal(await page.locator('a:has-text("下载镜头")').count(), 2);
    assert.equal(await page.isVisible('#redo-open'), true);

    // 点击：提示一句话，并真的发出下载
    const [download] = await Promise.all([page.waitForEvent('download', {timeout: 8000}), page.click('#download-clips')]);
    // 文件名由服务器的 Content-Disposition 决定（Python 测试里核对）；这里核对真的下到了接口返回的内容。
    assert.match(download.url(), /api\/projects\/p1\/clips-zip$/);
    assert.deepEqual(require('node:fs').readFileSync(await download.path()), EMPTY_ZIP);
    assert.match(await page.textContent('#notice'), /正在打包本集的镜头视频/);
    assert.equal(state.calls.filter(c => /clips-zip$/.test(c.route)).length, 1, '后台应只收到一次打包请求');

    // 一个镜头都没完成：按钮隐藏
    await page.click('[data-project="p2"]');
    await page.waitForFunction(() => document.querySelector('#download-clips').classList.contains('hidden'), null, {timeout: 6000});
    assert.equal(await page.locator('a:has-text("下载镜头")').count(), 0);

    assert.deepEqual(errors, []);
    console.log('clips download browser: all scenarios passed');
    await context.close();
  } finally { await browser.close(); server.close(); }
})().catch(error => { console.error(error); process.exit(1); });
