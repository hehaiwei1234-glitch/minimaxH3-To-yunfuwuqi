"""一键下载某一集全部镜头（zip）：打包内容、命名、缺失说明、临时文件清理、磁盘不足、真实 HTTP 路由、不影响原有下载。"""
from __future__ import annotations

import asyncio
import importlib
import io
import json
import os
import tempfile
import time
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
from urllib.parse import unquote

import aiohttp
from aiohttp import web

from test_core import ROOT, Store, Files

clip_archive = importlib.import_module('h3ad_test.clip_archive')
routes = importlib.import_module('h3ad_test.routes')


def temp_zips(directory):
    return sorted(Path(directory).glob(clip_archive.TEMP_PREFIX + '*.zip'))


class ArchiveFixture(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.dir = Path(self.temp.name)
        self.scratch = self.dir / 'scratch'
        self.scratch.mkdir()
        self.files = Files(self.dir / 'input', self.dir / 'output')
        self.bodies = {}

    def tearDown(self):
        self.temp.cleanup()

    def clip(self, number, title, content=True):
        """生成一个任务记录；content=False 表示还没有视频，None 表示记录有但文件丢了。"""
        record = {'title': title, 'status': 'complete' if content else 'pending'}
        if content is not False:
            name = f'clip_{number}.mp4'
            path = self.files.output / 'h3_autodrama_v1' / 'projects' / 'p1' / name
            path.parent.mkdir(parents=True, exist_ok=True)
            if content:
                body = (f'视频{number}-' * 50 + 'x' * number).encode()
                path.write_bytes(body)
                self.bodies[number] = body
            record['output'] = self.files.descriptor(path) if content else {'type': 'output', 'subfolder': 'gone', 'filename': name}
        return record

    def project(self, clips, title='(欧美)狼人兄妹·第8集：剧本第6集 | 绿茶修罗场'):
        return {'id': 'p1', 'title': title, 'clips': clips}


class CollectAndBuildTests(ArchiveFixture):
    def test_names_keep_order_pad_numbers_and_clean_titles(self):
        clips = [self.clip(1, '躲进婚纱架'), self.clip(2, 'a/b:c*d?"e<f>g|h'), self.clip(3, ''), self.clip(4, 'CON'), self.clip(5, '  . ')]
        items, missing = clip_archive.collect(self.files, self.project(clips))
        self.assertEqual(missing, [])
        self.assertEqual([name for _, name in items], ['01_躲进婚纱架.mp4', '02_a_b_c_d__e_f_g_h.mp4', '03.mp4', '04__CON.mp4', '05.mp4'])

    def test_width_grows_past_99_tasks(self):
        clips = [self.clip(i, f't{i}') for i in range(1, 102)]
        names = [name for _, name in clip_archive.collect(self.files, self.project(clips))[0]]
        self.assertEqual(names[0], '001_t1.mp4')
        self.assertEqual(names[-1], '101_t101.mp4')

    def test_missing_clips_are_reported_not_fatal(self):
        clips = [self.clip(1, '甲'), self.clip(2, '乙', content=False), self.clip(3, '丙', content=None), self.clip(4, '丁')]
        items, missing = clip_archive.collect(self.files, self.project(clips))
        self.assertEqual([name for _, name in items], ['01_甲.mp4', '04_丁.mp4'])
        self.assertEqual([(n, t) for n, t, _ in missing], [(2, '乙'), (3, '丙')])
        self.assertIn('还没有生成', missing[0][2])
        self.assertIn('找不到', missing[1][2])

    def test_zip_contents_are_byte_identical_and_stored_not_recompressed(self):
        project = self.project([self.clip(1, '甲'), self.clip(2, '乙')])
        path, count, missing = clip_archive.build(self.files, project, directory=self.scratch)
        self.assertEqual((count, missing), (2, []))
        with zipfile.ZipFile(path) as archive:
            self.assertEqual(archive.namelist(), ['01_甲.mp4', '02_乙.mp4'])
            self.assertIsNone(archive.testzip())
            self.assertEqual(archive.read('01_甲.mp4'), self.bodies[1])
            self.assertEqual(archive.read('02_乙.mp4'), self.bodies[2])
            self.assertTrue(all(i.compress_type == zipfile.ZIP_STORED for i in archive.infolist()))
        self.assertTrue(path.parent == self.scratch)

    def test_note_lists_skipped_tasks_only_when_something_is_missing(self):
        path, count, missing = clip_archive.build(self.files, self.project([self.clip(1, '甲'), self.clip(2, '乙', content=False)]), directory=self.scratch)
        with zipfile.ZipFile(path) as archive:
            self.assertEqual(count, 1)
            self.assertIn('说明.txt', archive.namelist())
            note = archive.read('说明.txt').decode('utf-8')
            self.assertIn('第 2 个任务（乙）：还没有生成视频', note)
            self.assertIn('已打包 1 个', note)
        path2, _, _ = clip_archive.build(self.files, self.project([self.clip(1, '甲')]), directory=self.scratch)
        with zipfile.ZipFile(path2) as archive:
            self.assertNotIn('说明.txt', archive.namelist())

    def test_nothing_to_pack_raises_clear_error_and_leaves_no_temp_file(self):
        for clips in ([], [self.clip(1, '甲', content=False)], [self.clip(1, '甲', content=None)]):
            with self.assertRaisesRegex(ValueError, '还没有做好的镜头视频'):
                clip_archive.build(self.files, self.project(clips), directory=self.scratch)
        self.assertEqual(temp_zips(self.scratch), [])

    def test_not_enough_disk_space_refuses_before_writing(self):
        usage = type('U', (), {'total': 10, 'used': 10, 'free': 1024})()
        with patch.object(clip_archive.shutil, 'disk_usage', return_value=usage):
            with self.assertRaisesRegex(ValueError, '临时空间'):
                clip_archive.build(self.files, self.project([self.clip(1, '甲')]), directory=self.scratch)
        self.assertEqual(temp_zips(self.scratch), [])

    def test_failure_while_writing_cleans_up_the_temp_file(self):
        with patch.object(zipfile.ZipFile, 'write', side_effect=OSError('disk full')):
            with self.assertRaises(OSError):
                clip_archive.build(self.files, self.project([self.clip(1, '甲')]), directory=self.scratch)
        self.assertEqual(temp_zips(self.scratch), [])

    def test_stale_temp_files_are_removed_but_recent_and_unrelated_are_kept(self):
        old = self.scratch / (clip_archive.TEMP_PREFIX + 'old.zip')
        recent = self.scratch / (clip_archive.TEMP_PREFIX + 'recent.zip')
        other = self.scratch / 'someone_else.zip'
        for entry in (old, recent, other):
            entry.write_bytes(b'x')
        long_ago = time.time() - clip_archive.STALE_SECONDS - 60
        os.utime(old, (long_ago, long_ago))
        os.utime(other, (long_ago, long_ago))
        clip_archive.clear_stale(self.scratch)
        self.assertFalse(old.exists())
        self.assertTrue(recent.exists())
        self.assertTrue(other.exists(), '不是本功能产生的文件绝不能碰')

    def test_download_headers_carry_the_unicode_filename_safely(self):
        headers = clip_archive.download_headers('(欧美)狼人兄妹·第8集：剧本第6集 | 绿茶修罗场')
        disposition = headers['Content-Disposition']
        self.assertIn('filename="clips.zip"', disposition)
        encoded = disposition.split("filename*=UTF-8''")[1]
        self.assertTrue(encoded.isascii())
        self.assertEqual(unquote(encoded), '(欧美)狼人兄妹·第8集：剧本第6集 _ 绿茶修罗场_全部镜头.zip')
        self.assertEqual(unquote(clip_archive.download_headers('')['Content-Disposition'].split("filename*=UTF-8''")[1]), '本集_全部镜头.zip')


class HttpRouteTests(ArchiveFixture):
    async def serve(self):
        self.app = routes.Application(self.dir / 'data', self.files.input, self.files.output, 'http://127.0.0.1:1')
        host = web.Application()
        host.router.add_route('*', '/h3_autodrama_v1/{path:.*}', self.app.handle)
        self.runner = web.AppRunner(host)
        await self.runner.setup()
        site = web.TCPSite(self.runner, '127.0.0.1', 0)
        await site.start()
        port = site._server.sockets[0].getsockname()[1]
        self.url = f'http://127.0.0.1:{port}/h3_autodrama_v1/api/'

    def make_project(self, clips, title='第1集：测试'):
        # 直接写入一个最小项目记录（路由只读 title 和 clips）。
        record = {'id': 'proj1', 'title': title, 'clips': clips, 'status': 'complete', 'script': 'x', 'archived': False}
        self.app.store.put('project', 'proj1', record)
        return record

    def run_async(self, coroutine):
        return asyncio.run(coroutine)

    def test_download_returns_a_valid_zip_and_removes_the_temp_file_and_changes_nothing(self):
        async def scenario():
            await self.serve()
            clips = [self.clip(1, '躲进婚纱架'), self.clip(2, '捂住嘴')]
            self.make_project(clips)
            before = json.dumps(self.app.store.get('project', 'proj1'), sort_keys=True)
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(self.url + 'projects/proj1/clips-zip') as r:
                        self.assertEqual(r.status, 200, await r.text() if r.status != 200 else '')
                        self.assertEqual(r.content_type, 'application/zip')
                        self.assertIn("filename*=UTF-8''", r.headers['Content-Disposition'])
                        self.assertIn('no-store', r.headers['Cache-Control'])
                        blob = await r.read()
                    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
                        self.assertEqual(archive.namelist(), ['01_躲进婚纱架.mp4', '02_捂住嘴.mp4'])
                        self.assertEqual(archive.read('01_躲进婚纱架.mp4'), self.bodies[1])
                    # 原来的单个镜头下载照常
                    async with session.get(self.url + 'projects/proj1/clips/1/video') as r:
                        self.assertEqual(r.status, 200)
                        self.assertEqual(await r.read(), self.bodies[2])
            finally:
                await self.runner.cleanup()
            self.assertEqual(json.dumps(self.app.store.get('project', 'proj1'), sort_keys=True), before, '下载不得修改项目记录')
            self.assertEqual(temp_zips(self.tempdir), [], '临时 zip 必须在发送后删除')
        with tempfile.TemporaryDirectory() as tempdir:
            self.tempdir = tempdir
            with patch.object(tempfile, 'tempdir', tempdir):
                self.run_async(scenario())

    def test_nothing_ready_returns_a_readable_error(self):
        async def scenario():
            await self.serve()
            self.make_project([self.clip(1, '甲', content=False)])
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(self.url + 'projects/proj1/clips-zip') as r:
                        data = await r.json()
                        self.assertEqual(r.status, 400, data)
                        self.assertIn('没有可下载的内容', data['error'])
                    async with session.get(self.url + 'projects/nope/clips-zip') as r:
                        self.assertGreaterEqual(r.status, 400)
            finally:
                await self.runner.cleanup()
        self.run_async(scenario())

    def test_two_clicks_at_once_both_get_a_complete_zip(self):
        async def scenario():
            await self.serve()
            self.make_project([self.clip(i, f't{i}') for i in range(1, 6)])
            try:
                async with aiohttp.ClientSession() as session:
                    async def fetch():
                        async with session.get(self.url + 'projects/proj1/clips-zip') as r:
                            self.assertEqual(r.status, 200)
                            return await r.read()
                    first, second = await asyncio.gather(fetch(), fetch())
                for blob in (first, second):
                    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
                        self.assertIsNone(archive.testzip())
                        self.assertEqual(len(archive.namelist()), 5)
            finally:
                await self.runner.cleanup()
        with tempfile.TemporaryDirectory() as tempdir:
            self.tempdir = tempdir
            with patch.object(tempfile, 'tempdir', tempdir):
                self.run_async(scenario())
            self.assertEqual(temp_zips(tempdir), [])

    def test_the_static_page_and_script_expose_the_button(self):
        html = (ROOT / 'static' / 'index.html').read_text(encoding='utf-8')
        script = (ROOT / 'static' / 'app.js').read_text(encoding='utf-8')
        self.assertIn('id="download-clips"', html)
        self.assertIn('/clips-zip', script)


if __name__ == '__main__':
    unittest.main()
