"""把一集里每个任务（镜头）已经生成好的原始视频打成一个 zip，方便一次下载。

只读：不修改任何项目记录、不重新生成、不合并视频。zip 先写到系统临时文件夹，发送完成后立即删除。
"""
from __future__ import annotations

import os
import re
import shutil
import tempfile
import time
import zipfile
from pathlib import Path
from urllib.parse import quote

from aiohttp import web

TEMP_PREFIX = 'h3ad_clips_'
STALE_SECONDS = 3600
_BAD = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_RESERVED = {'CON', 'PRN', 'AUX', 'NUL', *[f'COM{i}' for i in range(1, 10)], *[f'LPT{i}' for i in range(1, 10)]}


def safe_part(text, limit=60):
    value = _BAD.sub('_', str(text or '')).strip(' .')[:limit].strip(' .')
    if value.split('.')[0].upper() in _RESERVED:
        value = '_' + value
    return value


def collect(files, project):
    """返回 (可打包的 [(文件路径, zip 内文件名)], 缺失的 [(序号, 标题, 原因)])。"""
    clips = project.get('clips') or []
    width = max(2, len(str(len(clips))))
    items, missing = [], []
    for index, clip in enumerate(clips):
        number = index + 1
        title = clip.get('title') or ''
        output = clip.get('output')
        if not output:
            missing.append((number, title, '还没有生成视频'))
            continue
        try:
            path = files.output_path(output)
        except Exception:
            path = None
        if path is None or not path.is_file():
            missing.append((number, title, '视频文件找不到（可能已被清理）'))
            continue
        label = safe_part(title)
        items.append((path, f'{number:0{width}d}' + (f'_{label}' if label else '') + (path.suffix or '.mp4')))
    return items, missing


def _missing_note(project, items, missing):
    lines = [f'《{project.get("title") or "本集"}》共 {len(items) + len(missing)} 个任务，已打包 {len(items)} 个。', '', '以下任务没有放进这个压缩包：']
    lines += [f'  第 {number} 个任务{f"（{title}）" if title else ""}：{reason}' for number, title, reason in missing]
    return '\n'.join(lines) + '\n'


def clear_stale(directory=None, now=None):
    """删除上次异常中断遗留的临时 zip（超过 1 小时的）。"""
    directory = Path(directory or tempfile.gettempdir())
    now = time.time() if now is None else now
    try:
        entries = list(directory.glob(TEMP_PREFIX + '*.zip'))
    except OSError:
        return
    for entry in entries:
        try:
            if now - entry.stat().st_mtime > STALE_SECONDS:
                entry.unlink()
        except OSError:
            pass


def build(files, project, directory=None):
    """打包并返回 (临时 zip 路径, 已打包数量, 缺失列表)。无可打包内容或磁盘空间不足时抛 ValueError。"""
    items, missing = collect(files, project)
    if not items:
        raise ValueError('这一集还没有做好的镜头视频，没有可下载的内容。')
    directory = Path(directory or tempfile.gettempdir())
    clear_stale(directory)
    need = sum(path.stat().st_size for path, _ in items)
    free = shutil.disk_usage(directory).free
    if free < need * 1.1 + 50 * 1024 * 1024:
        raise ValueError(f'打包需要约 {need / 1048576:.0f} MB 临时空间，但临时文件夹（{directory}）只剩 {free / 1048576:.0f} MB。请先清理磁盘，或逐个下载镜头。')
    handle, name = tempfile.mkstemp(prefix=TEMP_PREFIX, suffix='.zip', dir=directory)
    os.close(handle)
    try:
        # mp4 本来就是压缩过的，只装箱不再压缩（ZIP_STORED），又快又不占 CPU。
        with zipfile.ZipFile(name, 'w', zipfile.ZIP_STORED, allowZip64=True) as archive:
            for path, arcname in items:
                archive.write(path, arcname)
            if missing:
                archive.writestr('说明.txt', _missing_note(project, items, missing))
    except BaseException:
        try:
            os.unlink(name)
        except OSError:
            pass
        raise
    return Path(name), len(items), missing


def download_headers(title):
    label = safe_part(title, 80) or '本集'
    return {'Content-Disposition': f"attachment; filename=\"clips.zip\"; filename*=UTF-8''{quote(label + '_全部镜头.zip')}",
            'Cache-Control': 'no-store'}


class TempFileResponse(web.FileResponse):
    """发送完（或客户端中断）后删除临时文件。"""

    def __init__(self, path, **kwargs):
        super().__init__(path, **kwargs)
        self._temp_path = Path(path)

    async def prepare(self, request):
        try:
            return await super().prepare(request)
        finally:
            try:
                self._temp_path.unlink()
            except OSError:
                pass  # 下次打包时 clear_stale 会清掉
