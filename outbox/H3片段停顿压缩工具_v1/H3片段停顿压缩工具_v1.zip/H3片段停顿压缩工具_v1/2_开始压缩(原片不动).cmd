@echo off
chcp 65001 >nul
setlocal
set "PY="
where python >nul 2>nul && set "PY=python"
if not defined PY where py >nul 2>nul && set "PY=py -3"
if not defined PY for %%P in ("%~dp0..\python_embeded\python.exe" "%~dp0..\..\python_embeded\python.exe" "%~dp0..\..\..\python_embeded\python.exe" "%~dp0..\..\..\..\python_embeded\python.exe") do if exist "%%~P" set PY="%%~P"
if not defined PY (
  echo Python not found. Put this folder next to ComfyUI's python_embeded folder, or install Python 3.
  pause
  exit /b 1
)
%PY% -c "import numpy" >nul 2>nul
if errorlevel 1 (
  echo numpy is missing. Run:  %PY% -m pip install numpy
  pause
  exit /b 1
)
if "%~1"=="" (
  echo Drag a folder of mp4 files, or some mp4 files, onto this .cmd file.
  pause
  exit /b 1
)
%PY% "%~dp0trim_dead_time.py" %* 
echo.
pause
