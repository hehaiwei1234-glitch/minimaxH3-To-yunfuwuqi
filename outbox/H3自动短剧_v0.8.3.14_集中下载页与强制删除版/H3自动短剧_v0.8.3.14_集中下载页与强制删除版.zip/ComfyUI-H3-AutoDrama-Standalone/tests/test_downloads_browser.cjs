// 集中下载页 + 删除窗口“强制删除”的浏览器测试：真浏览器 + 假后端，不调用付费接口。
// 运行：node tests/test_downloads_browser.cjs   需要 playwright 和 Chromium。
const assert = require('node:assert/strict');
const fs = require('node:fs');
const F = require('./fake_backend.cjs');

const GB = 1073741824, MB = 1048576;
const ep = (id, number, title, {final, clips, done = false} = {}) => ({id, number, title, status: 'complete', archived: false,
  final: final ? {size: final, name: `极寒末日_第${String(number).padStart(3, '0')}集_成片.mp4`, url: `downloads/${id}/final`, version: 'f1.mp4', partial: false, duration: 30} : null,
  clips: clips ? {size: clips, count: 7, total: 7, name: `极寒末日_第${String(number).padStart(3, '0')}集_分镜头.zip`, url: `downloads/${id}/clips`, version: '7-' + clips} : null});
const data = () => ({groups: [
  {kind: 'series', id: 's2', title: '极寒末日', archived: false, episodes: [
    ep('e45', 45, '标题45', {final: 1 * GB, clips: 512 * MB}), ep('e44', 44, '标题44', {final: 2 * GB, clips: 256 * MB}),
    ep('e12', 12, '标题12（没合成）', {clips: 100 * MB})]},
  {kind: 'loose', id: '', title: '单独制作的集', archived: false, episodes: [ep('solo', 0, '单集', {final: 10 * MB})]}]});
const names = page => page.$$eval('.dl-ep .dl-name', els => els.map(e => e.textContent.replace(/\s+/g, ' ').trim()));
const summary = page => page.textContent('#dl-summary');
const checkedKeys = page => page.$$eval('[data-dl-key]:checked', els => els.map(e => e.dataset.dlKey));

(async () => {
  const browser = await F.launch();
  const state = {series: {ser1: F.seriesRecord()}, assets: [], projects: [], downloads: q => { const d = data(); if (q.get('include_archived') === '1') d.groups.push({kind: 'series', id: 'sa', title: '归档剧', archived: true, episodes: [ep('a1', 1, '归档集', {final: MB})]}); return d; }};
  const {server, url} = await F.startServer(state);
  try {
    const context = await browser.newContext({viewport: {width: 1280, height: 900}, acceptDownloads: true});
    await context.addInitScript('window.H3_DOWNLOAD_GAP_MS=120');
    const page = await context.newPage();
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.goto(url); await F.waitReady(page);

    // 1. 新的“下载”标签；打开时才读取一次；其他页面不受影响
    assert.equal((await page.textContent('nav [data-tab="downloads"]')).trim(), '下载');
    assert.equal(state.calls.filter(c => /^downloads/.test(c.route)).length, 0, '没打开下载页之前不读取');
    await page.click('nav [data-tab="downloads"]');
    await page.waitForSelector('.dl-ep');
    assert.equal(state.calls.filter(c => /^downloads/.test(c.route)).length, 1);
    assert.equal(await page.isVisible('#downloads'), true);
    assert.match((await names(page))[0], /^第045集 标题45/);
    assert.match((await names(page))[1], /^第044集 标题44/);
    assert.equal((await names(page)).length, 3, '默认不显示只有分镜头、没有成片的集');
    assert.equal(await page.locator('.dl-group summary').count(), 2);
    assert.match(await page.textContent('.dl-group summary'), /极寒末日/);
    // 每一项：大小、地址、文件名
    const first = page.locator('[data-dl-link="e45:final"]');
    assert.match(await first.getAttribute('href'), /api\/downloads\/e45\/final$/);
    assert.equal(await first.getAttribute('download'), '极寒末日_第045集_成片.mp4');
    assert.match(await page.textContent('.dl-ep:first-of-type'), /1\.00 GB/);
    assert.match(await page.textContent('.dl-ep:first-of-type'), /512\.0 MB/);

    // 标题自己已经带“第N集”时不再重复加编号
    // 2. 显示未完成的集：多出只有分镜头压缩包的第 12 集，排在第 44 集之后（集号从大到小）
    await page.check('#dl-show-unfinished');
    const withUnfinished = await names(page);
    assert.equal(withUnfinished.length, 4);
    assert.match(withUnfinished[2], /第012集/);
    assert.match(await page.textContent('.dl-ep:nth-of-type(3)'), /还没有/);
    assert.equal(state.calls.filter(c => /^downloads/.test(c.route)).length, 1, '切换显示不重新读取');
    await page.uncheck('#dl-show-unfinished');

    // 3. 选择按钮与合计
    assert.equal(await summary(page), '已选 0 项 · 共 0.0 MB');
    assert.equal(await page.isDisabled('#dl-start'), true);
    await page.click('#dl-all');
    assert.equal((await checkedKeys(page)).length, 5);       // 3 个成片 + 2 个压缩包
    assert.equal(await summary(page), '已选 5 项 · 共 3.76 GB');
    await page.click('#dl-only-final');
    assert.deepEqual((await checkedKeys(page)).sort(), ['e44:final', 'e45:final', 'solo:final']);
    assert.equal(await summary(page), '已选 3 项 · 共 3.01 GB');
    await page.click('#dl-only-clips');
    assert.deepEqual((await checkedKeys(page)).sort(), ['e44:clips', 'e45:clips']);
    assert.equal(await summary(page), '已选 2 项 · 共 768.0 MB');
    await page.click('#dl-none');
    assert.equal(await summary(page), '已选 0 项 · 共 0.0 MB');
    // 显示未完成的集之后，“全选”包括它的压缩包
    await page.check('#dl-show-unfinished'); await page.click('#dl-all');
    assert.equal((await checkedKeys(page)).length, 6);
    await page.uncheck('#dl-show-unfinished');
    assert.equal((await checkedKeys(page)).length, 5, '隐藏的集不再算入已选');
    await page.click('#dl-none');
    // 本组全选
    await page.check('[data-dl-group="s2"]');
    assert.equal((await checkedKeys(page)).length, 4);
    await page.uncheck('[data-dl-group="s2"]');
    assert.equal((await checkedKeys(page)).length, 0);

    // 4. 单个下载链接：真的下载，并记为“已下载✓”（刷新页面后仍记得）
    const [one] = await Promise.all([page.waitForEvent('download', {timeout: 8000}), page.click('[data-dl-link="e45:final"]')]);
    assert.match(one.url(), /api\/downloads\/e45\/final$/);
    assert.equal(one.suggestedFilename().length > 0, true);
    await page.waitForSelector('.dl-ep:first-of-type .badge');
    assert.match(await page.textContent('.dl-ep:first-of-type'), /已下载✓/);
    await page.click('#dl-only-new');
    assert.deepEqual((await checkedKeys(page)).sort(), ['e44:clips', 'e44:final', 'e45:clips', 'solo:final'], '只选没下载过的');
    await page.reload(); await F.waitReady(page);
    await page.click('nav [data-tab="downloads"]'); await page.waitForSelector('.dl-ep');
    assert.match(await page.textContent('.dl-ep:first-of-type'), /已下载✓/);
    assert.equal(await page.locator('.badge:has-text("已下载✓")').count(), 1);

    // 5. 批量下载：依次触发，每个文件一次请求，下载完记为已下载
    await page.click('#dl-only-new');
    const before = state.calls.filter(c => /^downloads\/[^/]+\/(final|clips)$/.test(c.route)).length;
    const got = [];
    page.on('download', d => got.push(d.url().split('/api/')[1]));
    await page.click('#dl-start');
    await page.waitForFunction(() => document.querySelector('#dl-status').textContent.includes('4/4'), null, {timeout: 8000});
    await F.sleep(600);
    assert.deepEqual(got.sort(), ['downloads/e44/clips', 'downloads/e44/final', 'downloads/e45/clips', 'downloads/solo/final']);
    assert.equal(state.calls.filter(c => /^downloads\/[^/]+\/(final|clips)$/.test(c.route)).length - before, 4);
    assert.equal(await page.locator('.badge:has-text("已下载✓")').count(), 5);
    await page.click('#dl-only-new');
    assert.equal(await summary(page), '已选 0 项 · 共 0.0 MB', '全部下载过后，只选没下载过的 = 空');
    assert.match(await page.textContent('#notice'), /已把 4 个文件交给浏览器下载/);

    // 6. 刷新：重新读取，保留仍存在的勾选
    await page.click('#dl-none'); await page.check('[data-dl-key="e44:final"]');
    const reads = () => state.calls.filter(c => /^downloads(\?|$)/.test(c.route)).length;
    const n0 = reads();
    await page.click('#dl-refresh'); await F.sleep(400);
    assert.equal(reads(), n0 + 1);
    assert.deepEqual(await checkedKeys(page), ['e44:final']);
    // 服务器那边这一集没了：勾选自动去掉，不报错
    state.downloads = () => ({groups: [data().groups[1]]});
    await page.click('#dl-refresh'); await F.sleep(400);
    assert.deepEqual(await checkedKeys(page), []);
    assert.deepEqual(await names(page), ['单集 已完成']);

    // 7. 显示已归档：带参数重新读取；空列表显示说明
    state.downloads = q => q.get('include_archived') === '1' ? {groups: [{kind: 'series', id: 'sa', title: '归档剧', archived: true, episodes: [ep('a1', 1, '归档集', {final: MB})]}]} : {groups: []};
    await page.click('#dl-refresh'); await F.sleep(300);
    assert.match(await page.textContent('#dl-list'), /暂时没有可下载的内容/);
    await page.check('#dl-show-archived'); await F.sleep(400);
    assert.ok(state.calls.some(c => c.route === 'downloads' && c.query === '?include_archived=1'));
    assert.match(await page.textContent('#dl-list'), /归档剧[\s\S]*已归档/);

    // 8. 读取失败：状态栏说明原因，页面不报错，之后恢复
    state.fail = [{method: 'GET', match: /^downloads/, mode: 500, error: '读取失败测试', times: 1}];
    await page.click('#dl-refresh'); await F.sleep(400);
    assert.match(await page.textContent('#notice'), /读取失败测试/);
    await page.click('#dl-refresh'); await F.sleep(400);
    assert.match(await page.textContent('#dl-status'), /已读取/);

    // 9. 手机宽度也能用（不出现横向滚动）
    await page.setViewportSize({width: 400, height: 800});
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), true);
    await page.setViewportSize({width: 1280, height: 900});

    // 10. 删除窗口：普通删除不出现“强制删除”；有未核对任务时出现，默认不勾，勾选后才发 force_unchecked
    await page.click('nav [data-tab="series"]'); await page.waitForSelector('[data-manage="delete-preview"][data-kind="series"]');
    await page.click('[data-manage="delete-preview"][data-kind="series"]');
    await page.waitForSelector('#delete-dialog[open]');
    assert.equal(await page.isVisible('#delete-force-row'), false);
    assert.doesNotMatch(await page.textContent('#delete-scope'), /强制删除/);
    state.deleteHandler = (body, json) => json({});
    await page.click('#delete-form button[type=submit]'); await F.sleep(500);
    let del = state.calls.filter(c => c.route.endsWith('/delete')).pop();
    assert.equal(del.body.force_unchecked, false);
    assert.equal(await page.evaluate(() => document.querySelector('#delete-dialog').open), false);

    state.deletePreview = {unchecked_clips: 2, unchecked_image_jobs: 1};
    await page.click('[data-manage="delete-preview"][data-kind="series"]'); await page.waitForSelector('#delete-dialog[open]');
    assert.equal(await page.isVisible('#delete-force-row'), true);
    assert.equal(await page.isChecked('[name=force_unchecked]'), false, '默认不勾选');
    assert.match(await page.textContent('#delete-scope'), /2 个镜头任务、1 个生图任务/);
    assert.equal((await page.textContent('#delete-force-text')).trim(), '我确认 ComfyUI 里已经没有这部剧的任务了（比如刚重启或崩溃过），强制删除');
    // 不勾选直接删除 → 服务器拒绝，窗口保持打开并说明原因
    state.deleteHandler = (body, json) => body.force_unchecked ? json({}) : json({error: '本项目还有可能正在ComfyUI执行的任务…可以在删除窗口勾选“强制删除”。'}, 400);
    await page.click('#delete-form button[type=submit]'); await F.sleep(500);
    assert.equal(await page.evaluate(() => document.querySelector('#delete-dialog').open), true);
    assert.match(await page.textContent('[data-dialog-notice]'), /强制删除/);
    assert.equal(state.calls.filter(c => c.route.endsWith('/delete')).pop().body.force_unchecked, false);
    // 勾选后删除 → 带 force_unchecked: true，窗口关闭
    await page.check('[name=force_unchecked]');
    await page.click('#delete-form button[type=submit]'); await F.sleep(500);
    assert.equal(state.calls.filter(c => c.route.endsWith('/delete')).pop().body.force_unchecked, true);
    assert.equal(await page.evaluate(() => document.querySelector('#delete-dialog').open), false);
    // 再次打开：勾选自动复位为不勾；单集删除时文字用“这集”
    await page.click('[data-manage="delete-preview"][data-kind="series"]'); await page.waitForSelector('#delete-dialog[open]');
    assert.equal(await page.isChecked('[name=force_unchecked]'), false);
    await page.click('#delete-form [data-close]');

    assert.deepEqual(errors, []);
    console.log('downloads browser: all scenarios passed');
    await context.close();
  } finally { await browser.close(); server.close(); }
})().catch(error => { console.error(error); process.exit(1); });
