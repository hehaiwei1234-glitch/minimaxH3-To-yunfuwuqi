"""集中下载页：清单分组与排序、文件名、大小、只读、真实 HTTP 下载；以及删除窗口的“强制删除”走真实路由。"""
from __future__ import annotations

import asyncio
import importlib
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
from urllib.parse import unquote

import aiohttp
from aiohttp import web

from test_core import ROOT, Files

downloads = importlib.import_module('h3ad_test.downloads')
clip_archive = importlib.import_module('h3ad_test.clip_archive')
routes = importlib.import_module('h3ad_test.routes')


class Fixture(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.dir = Path(self.temp.name)
        self.files = Files(self.dir / 'input', self.dir / 'output')
        self.app = routes.Application(self.dir / 'data', self.files.input, self.files.output, 'http://127.0.0.1:1')
        self.store = self.app.store
        self.counter = 0

    def tearDown(self):
        self.temp.cleanup()

    def video(self, pid, name, size):
        path = self.files.output / 'h3_autodrama_v1' / 'projects' / pid / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((name.encode() * size)[:size])
        return self.files.descriptor(path)

    def series(self, sid, title, created, archived=False):
        self.store.put('series', sid, {'id': sid, 'title': title, 'created_at': created, 'archived': archived, 'status': 'complete', 'project_ids': []})

    def episode(self, pid, title, number=None, series_id=None, final=None, clips=0, created=0, archived=False, partial=False):
        record = {'id': pid, 'title': title, 'status': 'complete', 'created_at': created, 'archived': archived, 'clips': []}
        if number is not None:
            record['episode_number'] = number
        if series_id:
            record['series_id'] = series_id
        for i in range(clips):
            record['clips'].append({'title': f'镜头{i + 1}', 'status': 'complete', 'output': self.video(pid, f'clip_{i + 1}.mp4', 100 + i)})
        if final:
            record['final'] = {**self.video(pid, 'final_v1.mp4', final), 'duration': 12.5, **({'partial': True} if partial else {})}
        self.store.put('project', pid, record)
        return record


class ListingTests(Fixture):
    def test_groups_sorting_names_sizes_and_defaults(self):
        self.series('s_old', '旧剧', 100)
        self.series('s_new', '极寒/末日:安全屋', 200)
        self.episode('e1', '第1集', 1, 's_new', final=5000, clips=3)
        self.episode('e45', '第45集', 45, 's_new', final=7000, clips=2)
        self.episode('e12', '第12集', 12, 's_new', clips=2)            # 没有成片，但有已做好的镜头
        self.episode('e0', '空集', 3, 's_new')                         # 什么都没有
        self.episode('o1', '旧剧第1集', 1, 's_old', final=10, clips=1)
        self.episode('solo_a', '单集甲', None, None, final=99, created=5)
        self.episode('solo_b', '单集乙', None, None, clips=1, created=9)
        data = downloads.listing(self.store, self.files)
        titles = [g['title'] for g in data['groups']]
        self.assertEqual(titles, ['极寒/末日:安全屋', '旧剧', '单独制作的集'], '新剧在前，单独制作的集最后')
        new = data['groups'][0]['episodes']
        self.assertEqual([e['number'] for e in new], [45, 12, 3, 1], '集号从大到小')
        e45 = new[0]
        self.assertEqual(e45['final']['name'], '极寒_末日_安全屋_第045集_成片.mp4')
        self.assertEqual(e45['clips']['name'], '极寒_末日_安全屋_第045集_分镜头.zip')
        self.assertEqual(e45['final']['size'], 7000)
        self.assertEqual(e45['clips']['size'], 100 + 101)
        self.assertEqual((e45['clips']['count'], e45['clips']['total']), (2, 2))
        self.assertEqual(e45['final']['url'], 'downloads/e45/final')
        self.assertIsNone(new[1]['final'])
        self.assertEqual(new[1]['clips']['count'], 2)
        self.assertEqual((new[2]['final'], new[2]['clips']), (None, None))
        loose = data['groups'][2]['episodes']
        self.assertEqual([e['title'] for e in loose], ['单集乙', '单集甲'], '单独制作的集：新的在前')
        self.assertEqual(loose[1]['final']['name'], '单集甲_成片.mp4')

    def test_missing_final_file_and_partial_flag_and_unfinished_clips(self):
        self.series('s', '剧', 1)
        record = self.episode('e1', '一', 1, 's', final=50, clips=1, partial=True)
        self.assertTrue(downloads.listing(self.store, self.files)['groups'][0]['episodes'][0]['final']['partial'])
        self.files.output_path(record['final']).unlink()
        episode = downloads.listing(self.store, self.files)['groups'][0]['episodes'][0]
        self.assertIsNone(episode['final'], '成片文件被清理后不能再列出')
        self.assertIsNotNone(episode['clips'])
        # 镜头文件丢了一个：数量如实显示
        record = self.store.get('project', 'e1')
        record['clips'].append({'title': '没做好', 'status': 'pending'})
        self.store.put('project', 'e1', record)
        clips = downloads.listing(self.store, self.files)['groups'][0]['episodes'][0]['clips']
        self.assertEqual((clips['count'], clips['total']), (1, 2))

    def test_archived_hidden_unless_requested(self):
        self.series('s_arch', '归档剧', 5, archived=True)
        self.episode('a1', '归档集', 1, 's_arch', final=10, archived=True)
        self.series('s', '正常剧', 1)
        self.episode('e1', '一', 1, 's', final=10)
        self.episode('e2', '二（单独归档）', 2, 's', final=10, archived=True)
        self.assertEqual([(g['title'], [e['number'] for e in g['episodes']]) for g in downloads.listing(self.store, self.files)['groups']], [('正常剧', [1])])
        groups = downloads.listing(self.store, self.files, include_archived=True)['groups']
        self.assertEqual([(g['title'], [e['number'] for e in g['episodes']]) for g in groups], [('归档剧', [1]), ('正常剧', [2, 1])])
        self.assertTrue(groups[0]['archived'] and groups[1]['episodes'][0]['archived'])

    def test_episode_whose_series_is_gone_is_listed_as_loose(self):
        self.episode('orphan', '孤儿集', 4, 'no_such_series', final=10)
        groups = downloads.listing(self.store, self.files)['groups']
        self.assertEqual([g['title'] for g in groups], ['单独制作的集'])

    def test_listing_does_not_modify_anything(self):
        self.series('s', '剧', 1)
        self.episode('e1', '一', 1, 's', final=50, clips=2)
        before = json.dumps([self.store.list('project'), self.store.list('series')], sort_keys=True)
        downloads.listing(self.store, self.files)
        self.assertEqual(json.dumps([self.store.list('project'), self.store.list('series')], sort_keys=True), before)

    def test_file_names_are_safe_and_zero_padded(self):
        self.assertEqual(downloads.file_names('剧名', {'id': 'x', 'episode_number': 7})['final'], '剧名_第007集_成片.mp4')
        self.assertEqual(downloads.file_names('剧名', {'id': 'x', 'episode_number': 1234})['clips'], '剧名_第1234集_分镜头.zip')
        self.assertEqual(downloads.file_names('CON', {'id': 'x', 'episode_number': 1})['final'], '_CON_第001集_成片.mp4')
        self.assertEqual(downloads.file_names(None, {'id': 'abcdef123456', 'title': ''})['final'], '单集_abcdef12_成片.mp4')
        self.assertEqual(downloads.file_names('剧', {'id': 'x', 'title': '标题', 'episode_number': True})['final'], '标题_成片.mp4')


class HttpTests(Fixture):
    async def serve(self):
        host = web.Application()
        host.router.add_route('*', '/h3_autodrama_v1/{path:.*}', self.app.handle)
        self.runner = web.AppRunner(host)
        await self.runner.setup()
        site = web.TCPSite(self.runner, '127.0.0.1', 0)
        await site.start()
        port = site._server.sockets[0].getsockname()[1]
        self.url = f'http://127.0.0.1:{port}/h3_autodrama_v1/api/'

    def test_listing_and_both_downloads_over_real_http(self):
        self.series('s', '极寒末日', 1)
        self.episode('e45', '第45集', 45, 's', final=3000, clips=2)
        self.episode('solo', '单集', None, None, clips=1)
        async def scenario():
            await self.serve()
            before = json.dumps([self.store.list('project'), self.store.list('series')], sort_keys=True)
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(self.url + 'downloads') as r:
                        self.assertEqual(r.status, 200)
                        self.assertIn('no-store', r.headers['Cache-Control'])
                        data = await r.json()
                    self.assertEqual([g['title'] for g in data['groups']], ['极寒末日', '单独制作的集'])
                    ep = data['groups'][0]['episodes'][0]
                    async with session.get(self.url + ep['final']['url']) as r:
                        self.assertEqual(r.status, 200)
                        self.assertEqual(unquote(r.headers['Content-Disposition'].split("filename*=UTF-8''")[1]), '极寒末日_第045集_成片.mp4')
                        self.assertIn('attachment', r.headers['Content-Disposition'])
                        blob = await r.read()
                        self.assertEqual(len(blob), 3000)
                    async with session.get(self.url + ep['clips']['url']) as r:
                        self.assertEqual(r.status, 200)
                        self.assertEqual(unquote(r.headers['Content-Disposition'].split("filename*=UTF-8''")[1]), '极寒末日_第045集_分镜头.zip')
                        with zipfile.ZipFile(io.BytesIO(await r.read())) as archive:
                            
                            self.assertEqual(len(archive.namelist()), 2)
                    # 没有成片 → 清楚的错误；不存在的集 → 错误；其他方法/路径 → 404
                    async with session.get(self.url + 'downloads/solo/final') as r:
                        self.assertEqual(r.status, 400)
                        self.assertIn('还没有整集成片', (await r.json())['error'])
                    async with session.get(self.url + 'downloads/nope/final') as r:
                        self.assertGreaterEqual(r.status, 400)
                    async with session.get(self.url + 'downloads/e45/other') as r:
                        self.assertEqual(r.status, 404)
                    async with session.get(self.url + 'downloads?include_archived=1') as r:
                        self.assertEqual(r.status, 200)
                    # 原有的下载地址不受影响
                    async with session.get(self.url + 'projects/e45/final') as r:
                        self.assertEqual(r.status, 200)
                        self.assertEqual(len(await r.read()), 3000)
            finally:
                await self.runner.cleanup()
            self.assertEqual(json.dumps([self.store.list('project'), self.store.list('series')], sort_keys=True), before, '下载不得修改任何记录')
        with tempfile.TemporaryDirectory() as tempdir, patch.object(tempfile, 'tempdir', tempdir):
            asyncio.run(scenario())
            self.assertEqual(list(Path(tempdir).glob(clip_archive.TEMP_PREFIX + '*.zip')), [], '临时 zip 必须在发送后删除')

    def test_zero_clips_gives_readable_error_and_static_files_are_served(self):
        self.series('s', '剧', 1)
        self.episode('e1', '一', 1, 's')
        async def scenario():
            await self.serve()
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(self.url + 'downloads/e1/clips') as r:
                        self.assertEqual(r.status, 400)
                        self.assertIn('没有可下载的内容', (await r.json())['error'])
                    async with session.get(self.url[:-4] + 'downloads.js') as r:
                        self.assertEqual(r.status, 200)
                        self.assertIn('loadDownloads', await r.text())
            finally:
                await self.runner.cleanup()
        asyncio.run(scenario())

    def test_force_delete_over_real_routes(self):
        self.series('s', '剧', 1)
        record = self.episode('e1', '一', 1, 's', clips=0)
        record['status'] = 'paused'
        record['clips'] = [{'title': 'x', 'status': 'submitted', 'prompt_id': 'lost'}]
        self.store.put('project', 'e1', record)
        async def scenario():
            await self.serve()
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(self.url + 'manage/project/e1/delete-preview', json={}) as r:
                        preview = await r.json()
                        self.assertEqual(r.status, 200, preview)
                        self.assertEqual((preview['unchecked_clips'], preview['unchecked_image_jobs']), (1, 0))
                    body = {'review_token': preview['review_token'], 'delete_files': False}
                    async with session.post(self.url + 'manage/project/e1/delete', json=body) as r:
                        self.assertEqual(r.status, 400)
                        self.assertIn('强制删除', (await r.json())['error'])
                    async with session.post(self.url + 'manage/project/e1/delete', json={**body, 'force_unchecked': True}) as r:
                        self.assertEqual(r.status, 200, await r.text())
                    async with session.get(self.url + 'projects?include_archived=1') as r:
                        self.assertEqual(await r.json(), [])
            finally:
                await self.runner.cleanup()
        asyncio.run(scenario())


class StaticPageTests(unittest.TestCase):
    def test_page_has_download_tab_section_and_force_checkbox(self):
        html = (ROOT / 'static' / 'index.html').read_text(encoding='utf-8')
        for needle in ('data-tab="downloads"', 'id="downloads"', 'id="dl-list"', 'id="dl-start"', 'downloads.js', 'name="force_unchecked"', 'id="delete-force-row"'):
            self.assertIn(needle, html)
        self.assertIn("'downloads.js'", (ROOT / 'routes.py').read_text(encoding='utf-8'))


if __name__ == '__main__':
    unittest.main()
