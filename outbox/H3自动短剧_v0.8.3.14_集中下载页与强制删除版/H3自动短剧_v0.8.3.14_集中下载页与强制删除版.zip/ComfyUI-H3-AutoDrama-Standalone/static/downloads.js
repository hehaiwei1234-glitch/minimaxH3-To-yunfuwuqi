"use strict";
// 集中下载页：把每一集的“整集成片”和“分镜头压缩包”的下载地址集中在一起，可勾选后依次下载。
// 只读：不改任何记录，不播放视频。哪些文件下载过，只记在这个浏览器里（localStorage），换浏览器会重新显示“没下载过”。
(function(){
 const DONE_KEY="h3ad_downloaded",GAP_MS=globalThis.H3_DOWNLOAD_GAP_MS||1500;
 let groups=[],selected=new Set(),downloaded={},busy=false,loaded=false;
 try{downloaded=JSON.parse(localStorage.getItem(DONE_KEY)||"{}")||{};if(typeof downloaded!=="object"||Array.isArray(downloaded))downloaded={}}catch{downloaded={}}
 const LABEL={final:"整集成片",clips:"分镜头压缩包"};
 function saveDone(){try{localStorage.setItem(DONE_KEY,JSON.stringify(downloaded))}catch{}}
 function fmtSize(bytes){const n=Number(bytes)||0;return n>=1073741824?(n/1073741824).toFixed(2)+" GB":(n/1048576).toFixed(1)+" MB"}
 function key(ep,kind){return ep.id+":"+kind}
 function doneKey(ep,kind){return ep.id+":"+kind+":"+ep[kind].version}
 const isDone=(ep,kind)=>!!downloaded[doneKey(ep,kind)];
 function showUnfinished(){return !!$("#dl-show-unfinished")?.checked}
 // 默认只列有整集成片的集；勾选“显示未完成的集”后，没有成片但已有做好镜头的集也列出（只有分镜头压缩包）。
 function visibleEpisodes(group){return group.episodes.filter(ep=>ep.final||(showUnfinished()&&ep.clips))}
 function items(){
  const list=[];
  for(const group of groups)for(const ep of visibleEpisodes(group))for(const kind of ["final","clips"])if(ep[kind])list.push({ep,kind,key:key(ep,kind)});
  return list;
 }
 function pruneSelection(){const valid=new Set(items().map(i=>i.key));selected=new Set([...selected].filter(k=>valid.has(k)))}
 function summary(){
  const chosen=items().filter(i=>selected.has(i.key)),bytes=chosen.reduce((sum,i)=>sum+(i.ep[i.kind].size||0),0);
  $("#dl-summary").textContent=`已选 ${chosen.length} 项 · 共 ${fmtSize(bytes)}`;
  $("#dl-start").disabled=busy||!chosen.length;
 }
 function itemHtml(ep,kind){
  const info=ep[kind],k=key(ep,kind);
  if(!info)return `<span class="dl-item dl-none muted">${LABEL[kind]}：${kind==="final"?"还没有":"还没有做好的镜头"}</span>`;
  const note=kind==="final"?(info.partial?"（未做完的素材合辑）":""):`（${info.count}/${info.total} 个镜头）`;
  return `<span class="dl-item"><label class="check"><input type="checkbox" data-dl-key="${esc(k)}" ${selected.has(k)?"checked":""}>${LABEL[kind]}${esc(note)} · ${fmtSize(info.size)}</label><a class="link" data-dl-link="${esc(k)}" href="${BASE}api/${esc(info.url)}" download="${esc(info.name)}">下载</a>${isDone(ep,kind)?'<span class="badge">已下载✓</span>':""}</span>`;
 }
 function render(){
  const box=$("#dl-list");if(!box)return;
  pruneSelection();
  const parts=[];
  for(const group of groups){
   const eps=visibleEpisodes(group);if(!eps.length)continue;
   const keys=eps.flatMap(ep=>["final","clips"].filter(kind=>ep[kind]).map(kind=>key(ep,kind))),all=keys.every(k=>selected.has(k));
   parts.push(`<details class="panel dl-group" open><summary><b>${esc(group.title)}</b> <span class="muted">${eps.length} 集${group.archived?" · 已归档":""}</span></summary><label class="check dl-all"><input type="checkbox" data-dl-group="${esc(group.id||"_loose")}" ${all?"checked":""}>本组全选</label>${eps.map(ep=>`<div class="dl-ep"><div class="dl-name">${ep.number&&!/^第\s*\d+\s*集/.test(ep.title)?`<b>第${String(ep.number).padStart(3,"0")}集</b> `:""}<b>${esc(ep.title)}</b>${ep.archived?' <span class="badge">已归档</span>':""} <span class="muted">${esc(statuses[ep.status]||ep.status||"")}</span></div>${itemHtml(ep,"final")}${itemHtml(ep,"clips")}</div>`).join("")}</details>`);
  }
  box.innerHTML=parts.join("")||'<p class="muted">暂时没有可下载的内容。整集成片做好后会出现在这里；勾选“显示未完成的集”可以看到只做好了部分镜头的集。</p>';
  box.querySelectorAll("[data-dl-key]").forEach(input=>input.onchange=()=>{input.checked?selected.add(input.dataset.dlKey):selected.delete(input.dataset.dlKey);render()});
  box.querySelectorAll("[data-dl-group]").forEach(input=>input.onchange=()=>{
   const id=input.dataset.dlGroup,group=groups.find(g=>(g.id||"_loose")===id);if(!group)return;
   for(const ep of visibleEpisodes(group))for(const kind of ["final","clips"])if(ep[kind])input.checked?selected.add(key(ep,kind)):selected.delete(key(ep,kind));
   render();
  });
  // 单个“下载”链接：照常下载，同时记为“已下载”。
  box.querySelectorAll("[data-dl-link]").forEach(a=>a.addEventListener("click",()=>{
   const [id,kind]=a.dataset.dlLink.split(":"),item=items().find(i=>i.key===a.dataset.dlLink);
   if(item){downloaded[doneKey(item.ep,kind)]=Date.now();saveDone();setTimeout(render,0)}
  }));
  summary();
 }
 async function load(){
  const include=$("#dl-show-archived")?.checked?"?include_archived=1":"";
  $("#dl-status").textContent="正在读取…";
  try{
   const data=await api("downloads"+include);
   groups=Array.isArray(data.groups)?data.groups:[];loaded=true;
   $("#dl-status").textContent=`已读取（${new Date().toLocaleTimeString()}）`;
   render();
  }catch(e){$("#dl-status").textContent="读取失败";throw e}
 }
 function choose(predicate){selected=new Set(items().filter(predicate).map(i=>i.key));render()}
 // 依次触发浏览器下载：每个文件间隔约 1.5 秒。浏览器第一次可能询问“是否允许下载多个文件”，请点允许。
 async function startDownloads(){
  if(busy)return;
  const chosen=items().filter(i=>selected.has(i.key));if(!chosen.length)return;
  busy=true;summary();
  try{
   for(let n=0;n<chosen.length;n++){
    const {ep,kind}=chosen[n],info=ep[kind],a=document.createElement("a");
    a.href=BASE+"api/"+info.url;a.download=info.name;a.style.display="none";
    document.body.appendChild(a);a.click();a.remove();
    downloaded[doneKey(ep,kind)]=Date.now();saveDone();
    $("#dl-status").textContent=`已发出 ${n+1}/${chosen.length} 个下载请求：${info.name}`;
    if(n<chosen.length-1)await new Promise(resolve=>setTimeout(resolve,GAP_MS));
   }
   notice(`已把 ${chosen.length} 个文件交给浏览器下载。分镜头压缩包要先在服务器上打包，开始下载会慢一点；请在浏览器的下载列表里查看进度。`);
  }finally{busy=false;render()}
 }
 // 本脚本比 app.js 先执行：guarded 等公共函数要到点击时才取用。
 const safe=fn=>(...args)=>guarded(fn)(...args);
 function bind(){
  const need=id=>document.querySelector(id);
  if(!need("#dl-list"))return;
  need("#dl-refresh").onclick=safe(load);
  need("#dl-show-unfinished").onchange=()=>render();
  need("#dl-show-archived").onchange=safe(load);
  need("#dl-all").onclick=()=>choose(()=>true);
  need("#dl-only-final").onclick=()=>choose(i=>i.kind==="final");
  need("#dl-only-clips").onclick=()=>choose(i=>i.kind==="clips");
  need("#dl-only-new").onclick=()=>choose(i=>!isDone(i.ep,i.kind));
  need("#dl-none").onclick=()=>choose(()=>false);
  need("#dl-start").onclick=safe(startDownloads);
 }
 if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",bind);else bind();
 // 只在打开“下载”页或点“刷新”时读取一次，不自动刷新。
 globalThis.loadDownloads=load;
})();
