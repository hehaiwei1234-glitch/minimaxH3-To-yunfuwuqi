"""集中下载页的数据：列出每一集的“整集成片”和“分镜头压缩包”，并给出统一的下载文件名。

只读：不修改任何项目记录、不重新生成、不合并视频。真正的文件仍由 `projects/<id>/final`
和 `clip_archive` 提供；这里只负责清单、大小和文件名。
"""
from __future__ import annotations

from . import clip_archive

LOOSE_GROUP_TITLE = '单独制作的集'


def _size(path):
    try:
        return path.stat().st_size
    except OSError:
        return None


def episode_base(series_title, project):
    """下载文件名前缀：整剧里的集是“剧名_第045集”，单独制作的集用它自己的标题。"""
    number = project.get('episode_number')
    if series_title and isinstance(number, int) and not isinstance(number, bool) and number > 0:
        return f'{clip_archive.safe_part(series_title, 50) or "剧"}_第{number:03d}集'
    return clip_archive.safe_part(project.get('title'), 60) or f'单集_{str(project.get("id", ""))[:8]}'


def final_path(files, project):
    """整集成片文件（存在才返回），否则 None。"""
    final = project.get('final')
    if not final:
        return None
    try:
        path = files.output_path(final)
    except Exception:  # noqa: BLE001 - 记录异常或文件被清理，都当作“没有成片”
        return None
    return path if path.is_file() else None


def file_names(series_title, project):
    base = episode_base(series_title, project)
    return {'final': base + '_成片.mp4', 'clips': base + '_分镜头.zip'}


def episode_entry(files, series_title, project):
    names = file_names(series_title, project)
    pid = project['id']
    entry = {'id': pid, 'number': project.get('episode_number'), 'title': project.get('title') or pid,
             'status': project.get('status'), 'archived': bool(project.get('archived')),
             'final': None, 'clips': None}
    path = final_path(files, project)
    if path is not None:
        final = project.get('final') or {}
        entry['final'] = {'size': _size(path) or 0, 'name': names['final'], 'url': f'downloads/{pid}/final',
                          'version': str(final.get('filename') or path.name), 'partial': bool(final.get('partial')),
                          'duration': final.get('duration')}
    items, missing = clip_archive.collect(files, project)
    if items:
        total = sum(_size(item[0]) or 0 for item in items)
        entry['clips'] = {'size': total, 'count': len(items), 'total': len(items) + len(missing), 'name': names['clips'],
                          'url': f'downloads/{pid}/clips', 'version': f'{len(items)}-{total}'}
    return entry


def _sort_key(entry):
    number = entry['number'] if isinstance(entry['number'], int) else -1
    return -number


def listing(store, files, include_archived=False):
    """按剧分组：新建的剧在前；组内集号从大到小（最新的在最上面）；最后是“单独制作的集”。"""
    def shown(record):
        return include_archived or not record.get('archived')
    all_series = {s['id']: s for s in store.list('series')}
    members = {}
    loose = []
    for project in store.list('project'):
        if not shown(project):
            continue
        sid = project.get('series_id')
        if sid and sid in all_series:
            if shown(all_series[sid]):
                members.setdefault(sid, []).append(project)
        else:
            loose.append(project)
    groups = []
    for series in sorted((s for s in all_series.values() if shown(s)), key=lambda s: -(s.get('created_at') or 0)):
        episodes = sorted((episode_entry(files, series.get('title'), p) for p in members.get(series['id'], [])), key=_sort_key)
        groups.append({'kind': 'series', 'id': series['id'], 'title': series.get('title') or series['id'],
                       'archived': bool(series.get('archived')), 'episodes': episodes})
    if loose:
        loose.sort(key=lambda p: -(p.get('created_at') or 0))
        groups.append({'kind': 'loose', 'id': '', 'title': LOOSE_GROUP_TITLE, 'archived': False,
                       'episodes': [episode_entry(files, None, p) for p in loose]})
    return {'groups': groups}
