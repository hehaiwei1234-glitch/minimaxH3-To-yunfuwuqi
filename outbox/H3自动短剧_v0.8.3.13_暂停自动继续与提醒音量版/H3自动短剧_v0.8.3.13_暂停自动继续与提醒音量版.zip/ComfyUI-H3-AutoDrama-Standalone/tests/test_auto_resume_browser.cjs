// 自动继续的页面部分：页眉开关、设置项、整剧页说明行、暂停前的确认。真浏览器 + 假后端，不调用付费接口。
// 后台“每隔几分钟检查并继续”的逻辑在 tests/test_auto_resume.py 里测。
// 运行：node tests/test_auto_resume_browser.cjs
const assert = require('node:assert/strict');
const F = require('./fake_backend.cjs');

const clip = (n, title, done) => ({title, status: done ? 'complete' : 'pending', visual_zh: '画面', duration_seconds: 6, generation_seconds: 6,
  ...(done ? {output: {type: 'output', subfolder: 'x', filename: `c${n}.mp4`}} : {})});
const label = page => page.textContent('#auto-resume-toggle').then(t => t.trim());
const calls = (state, method, re) => state.calls.filter(c => c.method === method && re.test(c.route));

async function withPage(browser, state, fn) {
  const {server, url} = await F.startServer(state);
  const context = await browser.newContext({viewport: {width: 1280, height: 800}});
  const page = await context.newPage();
  page.pageErrors = [];
  page.on('pageerror', e => page.pageErrors.push(e.message));
  try { await page.goto(url); await F.waitReady(page); await fn(page, url); assert.deepEqual(page.pageErrors, []); }
  finally { await context.close(); server.close(); }
}
const openSeries = async page => { await page.click('[data-series]'); await page.waitForSelector('#series-detail:not(.hidden)'); };

(async () => {
  const browser = await F.launch();
  try {
    // 1. 页眉开关：读取服务器设置、点击保存、刷新后仍然记得
    {
      const state = {series: {}, assets: []};
      await withPage(browser, state, async page => {
        await page.click('#auto-resume-toggle');
        await page.waitForFunction(() => document.querySelector('#auto-resume-toggle').textContent.includes('关'));
        assert.deepEqual(calls(state, 'POST', /^settings$/).map(c => c.body), [{auto_resume_enabled: false}]);
        assert.match(await page.textContent('#notice'), /自动继续已关闭/);
        assert.equal(await page.getAttribute('#auto-resume-toggle', 'aria-pressed'), 'false');
        await page.reload(); await F.waitReady(page);
        assert.equal(await label(page), '自动继续：关', '刷新后读取服务器上保存的设置');
        await page.click('#auto-resume-toggle');
        await page.waitForFunction(() => document.querySelector('#auto-resume-toggle').textContent.includes('开'));
        assert.deepEqual(calls(state, 'POST', /^settings$/).map(c => c.body).pop(), {auto_resume_enabled: true});
        assert.match(await page.textContent('#notice'), /每 5 分钟/);
      });
      console.log('  ok 页眉开关：保存、刷新后记得');
    }

    // 2. 保存失败：开关不变，状态栏说明
    {
      const state = {series: {}, assets: [], fail: [{method: 'POST', match: /^settings$/, mode: 500, times: 1}]};
      await withPage(browser, state, async page => {
        await page.click('#auto-resume-toggle');
        await page.waitForFunction(() => /没能保存自动继续的开关/.test(document.querySelector('#notice').textContent));
        assert.equal(await label(page), '自动继续：开');
        assert.equal(await page.isVisible('#notice.fail'), true);
      });
      console.log('  ok 保存失败：开关不变并说明原因');
    }

    // 3. 设置页里的两个设置项
    {
      const state = {series: {}, assets: [], settingsPatch: {auto_resume_enabled: false, auto_resume_minutes: 12}};
      await withPage(browser, state, async page => {
        assert.equal(await label(page), '自动继续：关');
        await page.click('nav [data-tab="settings"]');
        await page.click('summary:has-text("等待与重试设置")');
        assert.equal(await page.inputValue('[name="auto_resume_minutes"]'), '12');
        assert.equal(await page.isChecked('[name="auto_resume_enabled"]'), false);
        await page.fill('[name="auto_resume_minutes"]', '7');
        await page.check('[name="auto_resume_enabled"]');
        await page.click('#settings-form button[type="submit"]:has-text("保存设置")');
        await page.waitForFunction(() => /设置已保存并核对|设置/.test(document.querySelector('#notice').textContent));
        const body = calls(state, 'POST', /^settings$/).pop().body;
        assert.equal(body.auto_resume_minutes, 7);
        assert.equal(body.auto_resume_enabled, true);
        assert.equal(await label(page), '自动继续：开');
      });
      console.log('  ok 设置页：读取、修改、保存，并同步页眉');
    }

    // 4. 整剧页说明行
    const notes = [
      ['已暂停（不是用户点的）', {status: 'paused', phase: 'x'}, {}, /不是你点的.*每 5 分钟/, false],
      ['已暂停（用户点的）', {status: 'paused', user_paused: true}, {}, /你点了“暂停”.*不会被自动继续/, false],
      ['自动继续已停止（连续没有进展）', {status: 'paused', auto_resume: {blocked: true, blocked_reason: '连续 3 次自动继续都没有新增视频，已停止自动继续。'}}, {}, /自动继续已停止：连续 3 次.*手动点“继续整剧”/, true],
      ['运行中', {status: 'running', active: true}, {}, /自动继续已开启.*每 5 分钟/, false],
      ['已关闭', {status: 'paused'}, {auto_resume_enabled: false}, /自动继续已关闭/, false],
      ['已完成：不显示', {status: 'complete'}, {}, null, false],
    ];
    for (const [name, over, patch, expected, warn] of notes) {
      const state = {series: {ser1: F.seriesRecord(over)}, assets: [], settingsPatch: patch};
      await withPage(browser, state, async page => {
        await openSeries(page);
        const hidden = await page.evaluate(() => document.querySelector('#auto-resume-note').classList.contains('hidden'));
        if (expected === null) { assert.equal(hidden, true, name); return; }
        assert.equal(hidden, false, name);
        assert.match(await page.textContent('#auto-resume-note'), expected, name);
        const colored = await page.evaluate(() => document.querySelector('#auto-resume-note').style.color !== '');
        assert.equal(colored, warn, name + '：警告颜色');
      });
      console.log('  ok 整剧页说明：' + name);
    }

    // 5. 点“当前任务完成后暂停”前要确认；取消就什么也不发
    {
      const state = {series: {ser1: F.seriesRecord({status: 'running', active: true})}, assets: []};
      await withPage(browser, state, async page => {
        await openSeries(page);
        const dialogs = [];
        page.once('dialog', d => { dialogs.push(d.message()); d.dismiss(); });
        await page.click('#pause-series');
        await F.sleep(500);
        assert.equal(calls(state, 'POST', /^series\/ser1\/pause$/).length, 0, '取消确认后不能发出暂停请求');
        assert.match(dialogs[0], /确定暂停整剧吗.*不会再被自动继续/s);
        page.once('dialog', d => { dialogs.push(d.message()); d.accept(); });
        await page.click('#pause-series');
        await page.waitForFunction(() => /当前任务完成后暂停/.test(document.querySelector('#notice').textContent));
        assert.equal(calls(state, 'POST', /^series\/ser1\/pause$/).length, 1);
      });
      console.log('  ok 暂停整剧前确认：取消不发请求，确认才发');
    }

    // 6. 单集页的暂停也要确认，并说明会连带整剧
    {
      const project = {id: 'p1', title: '第1集', script: 'x', status: 'running', phase: '做', error: '', plan: null, clips: [clip(1, '甲', true)], generated_assets: {}, events: [],
        script_revision: 1, pause_requested: false, final: null, series_id: 'ser1', archived: false, settings: {}, character_bindings: {}, asset_ids: [], workflow_snapshot: null,
        created_at: 1700000000, updated_at: 1700000100};
      const state = {series: {}, assets: [], projectRecords: {p1: project},
        projects: [{id: 'p1', title: '第1集', status: 'running', phase: '做', created_at: 1, updated_at: 1, series_id: 'ser1', archived: false}]};
      await withPage(browser, state, async page => {
        await page.click('nav [data-tab="projects"]');
        await page.click('[data-project="p1"]');
        await page.waitForSelector('#project-detail:not(.hidden)');
        const dialogs = [];
        page.once('dialog', d => { dialogs.push(d.message()); d.dismiss(); });
        await page.click('#pause-project');
        await F.sleep(500);
        assert.equal(calls(state, 'POST', /pause$/).length, 0);
        assert.match(dialogs[0], /整剧也会一起暂停.*不会被自动继续/s);
      });
      console.log('  ok 单集暂停前确认并说明会连带整剧');
    }
    console.log('auto resume browser: all scenarios passed');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });
