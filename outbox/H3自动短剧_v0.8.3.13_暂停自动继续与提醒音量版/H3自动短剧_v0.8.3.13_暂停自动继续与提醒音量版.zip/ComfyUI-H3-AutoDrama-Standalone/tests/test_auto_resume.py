"""整剧暂停后自动继续：设置、策略（什么时候继续、什么时候不动）、防空烧上限、用户暂停记号、重启、后台循环、启动时唤醒。"""
from __future__ import annotations

import asyncio
import importlib
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import aiohttp
from aiohttp import web

from test_core import ROOT, Store, Files, domain
import test_image_series as image_tests

Engine = importlib.import_module('h3ad_test.engine').Engine
SeriesManager = importlib.import_module('h3ad_test.series').SeriesManager
auto_resume = importlib.import_module('h3ad_test.auto_resume')
routes = importlib.import_module('h3ad_test.routes')


def timing():
    return {'version': 1, 'episode': {'enabled': False, 'seconds': None}, 'total': {'enabled': False, 'seconds': None}, 'task': {'enabled': False, 'seconds': None}}


class SettingsTests(unittest.TestCase):
    def test_defaults_and_validation(self):
        self.assertIs(domain.DEFAULTS['auto_resume_enabled'], True)
        self.assertEqual(domain.DEFAULTS['auto_resume_minutes'], 5)
        ok = domain.validate_settings({**domain.DEFAULTS})
        self.assertEqual((ok['auto_resume_enabled'], ok['auto_resume_minutes']), (True, 5))
        for minutes in (1, 60):
            domain.validate_settings({**domain.DEFAULTS, 'auto_resume_minutes': minutes})
        for bad in (0, 61, -1, 5.5, '5', True, None):
            with self.assertRaisesRegex(ValueError, '1–60'):
                domain.validate_settings({**domain.DEFAULTS, 'auto_resume_minutes': bad})
        for bad in ('yes', 1, None):
            with self.assertRaisesRegex(ValueError, '开关'):
                domain.validate_settings({**domain.DEFAULTS, 'auto_resume_enabled': bad})

    def test_old_saved_settings_without_the_new_keys_still_load(self):
        with tempfile.TemporaryDirectory() as temp:
            store = Store(Path(temp) / 'data')
            store.put('config', 'main', {'poll_seconds': 7})  # 旧版本保存的设置里没有新键
            settings = store.settings()
            self.assertEqual((settings['auto_resume_enabled'], settings['auto_resume_minutes']), (True, 5))
            saved = store.save_settings({'auto_resume_enabled': False})
            self.assertIs(store.settings()['auto_resume_enabled'], False)
            self.assertEqual(store.settings()['poll_seconds'], 7)
            self.assertIsNotNone(saved)


class Fixture(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.dir = Path(self.temp.name)
        self.store = Store(self.dir / 'data')
        self.files = Files(self.dir / 'input', self.dir / 'output')
        self.video = image_tests.w.save(self.store, image_tests.video_fixture())
        self.engine = Engine(self.store, self.files, ROOT, 'http://127.0.0.1:1')
        self.series = SeriesManager(self.engine)
        self.watch = auto_resume.AutoResume(self.series)
        self.starts = []

        def fake_start(series_id, auto=False):
            self.starts.append((series_id, auto))
            self.series.set(series_id, status='queued')
        patcher = patch.object(self.series, 'start', side_effect=fake_start)
        patcher.start()
        self.addCleanup(patcher.stop)

    async def asyncTearDown(self):
        self.temp.cleanup()

    def make_series(self, sid='s1', status='paused', episodes=3, done=0, **extra):
        """手工搭一部整剧：episodes 集，前 done 集已完成。"""
        pids = [self.series.episode_id(sid, i) for i in range(episodes)]
        batch = {'id': 'initial', 'input_type': 'script', 'episode_count': episodes, 'target_episode_seconds': 0, 'timing_policy': timing(), 'instructions': '',
                 'workflow_snapshot': self.video, 'image_workflow_snapshots': None, 'status': 'planned', 'start_index': 0, 'episode_total': episodes, 'created_at': 1}
        record = {'id': sid, 'title': '测试剧', 'text': 'x', 'input_type': 'script', 'episode_count': episodes, 'target_episode_seconds': 0, 'instructions': '',
                  'timing_policy': timing(), 'workflow_snapshot': self.video, 'image_workflow_snapshots': None, 'asset_ids': [], 'character_bindings': {},
                  'generated_assets': {}, 'plan': {'style': 's', 'episodes': [{'title': f'e{i}', 'script': 'x'} for i in range(episodes)]}, 'project_ids': pids,
                  'events': [], 'status': status, 'phase': 'x', 'error': '', 'pause_requested': False, 'created_at': 1, 'updated_at': 1, 'revision': 1,
                  'continuity_summary': '', 'memory_through': episodes, 'removed_episodes': {}, 'batches': [batch], **extra}
        self.store.put('series', sid, record)
        for i, pid in enumerate(pids):
            self.store.create_project({'title': f'e{i}', 'script': 'x', 'series_id': sid}, project_id=pid)
            if i < done:
                self.store.update('project', pid, lambda p: p.update(status='complete', clips=[{'title': 'c', 'output': {'type': 'output', 'filename': 'a.mp4'}}]))
        return sid

    def add_output(self, sid, count=1):
        pid = self.store.get('series', sid)['project_ids'][-1]
        self.store.update('project', pid, lambda p: p.update(clips=p.get('clips', []) + [{'title': 'n', 'output': {'type': 'output', 'filename': 'b.mp4'}}] * count))

    def repause(self, sid):
        self.series.set(sid, status='paused')

    def events(self, sid):
        return [event['message'] for event in self.store.get('series', sid)['events']]


class PolicyTests(Fixture):
    async def test_resumes_a_paused_series_that_the_user_did_not_pause(self):
        sid = self.make_series(done=1)
        self.assertEqual(self.watch.check_once(), [sid])
        self.assertEqual(self.starts, [(sid, True)])
        state = self.store.get('series', sid)['auto_resume']
        self.assertEqual((state['attempts'], state['blocked']), (1, False))
        self.assertTrue(any('自动继续' in m and '第 1 次' in m for m in self.events(sid)))
        self.assertFalse(self.store.get('series', sid).get('user_paused'))

    async def test_nothing_happens_when_disabled(self):
        sid = self.make_series()
        self.store.save_settings({'auto_resume_enabled': False})
        self.assertEqual(self.watch.check_once(), [])
        self.assertEqual(self.starts, [])
        self.store.save_settings({'auto_resume_enabled': True})
        self.assertEqual(self.watch.check_once(), [sid])

    async def test_does_not_touch_series_the_user_paused_archived_complete_or_other_states(self):
        for sid, status, extra in (('a', 'paused', {'user_paused': True}), ('b', 'paused', {'archived': True}), ('c', 'complete', {}),
                                   ('d', 'draft', {}), ('e', 'partial', {}), ('f', 'running', {}), ('g', 'pausing', {})):
            self.make_series(sid, status, **extra)
        # running / pausing 代表“正在做”，整体被视为忙碌；先把它们改成完成，单独验证其余各项都不动
        for sid in ('f', 'g'):
            self.series.set(sid, status='complete')
        self.assertEqual(self.watch.check_once(), [])
        self.assertEqual(self.starts, [])

    async def test_skips_while_anything_is_running(self):
        sid = self.make_series('s1')
        busy = self.make_series('s2', 'running')
        self.assertEqual(self.watch.check_once(), [], '别的整剧在跑时不动')
        self.series.set(busy, status='complete')
        pid = self.store.get('series', sid)['project_ids'][0]
        self.store.update('project', pid, lambda p: p.update(status='running'))
        self.assertEqual(self.watch.check_once(), [], '有单集在跑时不动')
        self.store.update('project', pid, lambda p: p.update(status='paused'))
        self.assertEqual(self.watch.check_once(), [sid])

    async def test_skips_while_a_background_task_is_still_alive(self):
        sid = self.make_series()
        never = asyncio.get_running_loop().create_future()

        async def hang():
            await never
        task = asyncio.get_running_loop().create_task(hang())
        self.engine.tasks['x'] = task
        try:
            self.assertEqual(self.watch.check_once(), [])
        finally:
            task.cancel()
            del self.engine.tasks['x']
        self.assertEqual(self.watch.check_once(), [sid])

    async def test_nothing_to_do_means_no_resume(self):
        sid = self.make_series(episodes=2, done=2)  # 全部完成，只是状态停在 paused
        self.assertFalse(self.series.public(sid)['can_resume'])
        self.assertEqual(self.watch.check_once(), [])

    async def test_only_one_series_is_started_per_check(self):
        first, second = self.make_series('s1'), self.make_series('s2')
        started = self.watch.check_once()
        self.assertEqual(len(started), 1)
        self.assertIn(started[0], (first, second))

    async def test_one_broken_series_does_not_stop_the_watchdog(self):
        self.make_series('bad')
        good = self.make_series('good')
        original = self.series.public

        def public(sid):
            if sid == 'bad':
                raise RuntimeError('boom')
            return original(sid)
        with patch.object(self.series, 'public', side_effect=public):
            self.assertEqual(self.watch.check_once(), [good])


class FutileAttemptTests(Fixture):
    async def test_gives_up_after_three_attempts_without_new_video_and_says_why(self):
        sid = self.make_series(done=1)
        for attempt in (1, 2, 3):
            self.assertEqual(self.watch.check_once(), [sid], f'第 {attempt} 次')
            self.repause(sid)  # 立刻又停了，没有新增视频
        self.assertEqual(self.watch.check_once(), [], '第 4 次不再继续')
        state = self.store.get('series', sid)['auto_resume']
        self.assertTrue(state['blocked'])
        self.assertIn('连续 3 次', state['blocked_reason'])
        self.assertTrue(any('自动继续已停止' in m for m in self.events(sid)))
        self.assertEqual(len(self.starts), 3)
        stopped_events = [m for m in self.events(sid) if '自动继续已停止' in m]
        self.watch.check_once()
        self.assertEqual([m for m in self.events(sid) if '自动继续已停止' in m], stopped_events, '只记一次，不刷屏')

    async def test_new_video_resets_the_counter(self):
        sid = self.make_series()
        for _ in range(2):
            self.watch.check_once()
            self.repause(sid)
        self.add_output(sid)  # 这一轮做出了新视频
        self.assertEqual(self.watch.check_once(), [sid])
        self.assertEqual(self.store.get('series', sid)['auto_resume']['attempts'], 1)
        self.repause(sid)
        self.add_output(sid)
        for _ in range(3):
            self.assertEqual(self.watch.check_once(), [sid])
            self.repause(sid)
        self.assertEqual(self.watch.check_once(), [])

    async def test_manual_start_clears_the_block_and_the_user_pause_mark(self):
        sid = self.make_series()
        for _ in range(3):
            self.watch.check_once()
            self.repause(sid)
        self.watch.check_once()
        self.assertTrue(self.store.get('series', sid)['auto_resume']['blocked'])
        patch.stopall()  # 用真正的 start（run 换成空函数，只看它设置了什么）
        with patch.object(SeriesManager, 'run', new=AsyncMock()):
            self.series.start(sid)
            await asyncio.sleep(0.02)
        record = self.store.get('series', sid)
        self.assertEqual(record['auto_resume'], {})
        self.assertIs(record['user_paused'], False)
        self.repause(sid)
        self.assertEqual(self.watch.check_once(), [sid], '手动继续后重新开始计数')


class RealStartAndPauseTests(Fixture):
    async def test_auto_start_keeps_marks_manual_start_clears_them(self):
        patch.stopall()
        sid = self.make_series(user_paused=True, auto_resume={'attempts': 2, 'mark': 1})
        with patch.object(SeriesManager, 'run', new=AsyncMock()):
            self.series.start(sid, auto=True)
            await asyncio.sleep(0.02)
            record = self.store.get('series', sid)
            self.assertIs(record['user_paused'], True)
            self.assertEqual(record['auto_resume']['attempts'], 2)
            self.repause(sid)
            self.series.tasks.clear()
            self.series.start(sid)
            await asyncio.sleep(0.02)
        record = self.store.get('series', sid)
        self.assertIs(record['user_paused'], False)
        self.assertEqual(record['auto_resume'], {})

    async def test_series_pause_button_marks_user_paused(self):
        patch.stopall()
        sid = self.make_series(status='running')
        self.series.pause(sid)
        record = self.store.get('series', sid)
        self.assertEqual((record['status'], record['pause_requested'], record['user_paused']), ('pausing', True, True))

    async def test_episode_pause_button_also_marks_the_series_user_paused(self):
        patch.stopall()
        sid = self.make_series(status='running')
        pid = self.store.get('series', sid)['project_ids'][0]
        self.store.update('project', pid, lambda p: p.update(status='running'))
        self.engine.pause(pid)
        record = self.store.get('series', sid)
        self.assertEqual((record['pause_requested'], record['user_paused']), (True, True))

    async def test_restart_resumes_what_was_running_but_not_what_the_user_paused(self):
        patch.stopall()
        interrupted = self.make_series('a', 'running')
        user_pause = self.make_series('b', 'pausing', user_paused=True, pause_requested=True)
        series = SeriesManager(self.engine)  # 相当于 ComfyUI 重启后重新创建
        self.assertEqual((self.store.get('series', interrupted)['status'], self.store.get('series', user_pause)['status']), ('paused', 'paused'))
        self.assertFalse(self.store.get('series', interrupted).get('user_paused'))
        self.assertTrue(self.store.get('series', user_pause)['user_paused'])
        calls = []
        with patch.object(series, 'start', side_effect=lambda sid, auto=False: (calls.append(sid), series.set(sid, status='queued'))):
            watch = auto_resume.AutoResume(series)
            self.assertEqual(watch.check_once(), [interrupted])
        self.assertEqual(calls, [interrupted])


class LoopTests(Fixture):
    async def test_loop_checks_on_schedule_and_survives_errors(self):
        self.store.save_settings({'auto_resume_minutes': 1})
        now = [1000.0]
        watch = auto_resume.AutoResume(self.series, clock=lambda: now[0])
        calls = []

        def check():
            calls.append(now[0])
            if len(calls) == 1:
                raise RuntimeError('boom')  # 第一次检查出错，循环必须继续
        with patch.object(watch, 'check_once', side_effect=check), patch.object(auto_resume, 'TICK_SECONDS', 0.01):
            task = asyncio.get_running_loop().create_task(watch.run_forever(first_delay=0))
            await asyncio.sleep(0.1)
            self.assertEqual(len(calls), 1, '没到 1 分钟不应再检查')
            now[0] += 61
            await asyncio.sleep(0.1)
            self.assertEqual(len(calls), 2, '过了 1 分钟再检查，且之前的错误没有杀死循环')
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task

    async def test_start_watchdog_is_idempotent(self):
        first = self.watch.start_watchdog(first_delay=999)
        second = self.watch.start_watchdog(first_delay=999)
        try:
            self.assertIs(first, second)
        finally:
            first.cancel()
            await asyncio.gather(first, return_exceptions=True)

    def test_interval_is_clamped(self):
        with tempfile.TemporaryDirectory() as temp:
            engine = SimpleNamespace(tasks={})
            store = Store(Path(temp) / 'data')
            watch = auto_resume.AutoResume(SimpleNamespace(engine=engine, store=store, tasks={}))
            self.assertEqual(watch.interval_seconds(), 300)
            store.save_settings({'auto_resume_minutes': 60})
            self.assertEqual(watch.interval_seconds(), 3600)


class StartupWakeTests(unittest.IsolatedAsyncioTestCase):
    """ComfyUI 一启动就叫醒插件（不等有人打开页面），并且和第一次打开页面不会重复初始化。"""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        base = Path(self.temp.name)
        for name in ('user', 'input', 'output'):
            (base / name).mkdir()
        self.folder_paths = SimpleNamespace(get_user_directory=lambda: str(base / 'user'), get_input_directory=lambda: str(base / 'input'),
                                            get_output_directory=lambda: str(base / 'output'))

    def tearDown(self):
        self.temp.cleanup()

    async def run_server(self, prompt_server):
        holder = routes.register_routes(prompt_server, self.folder_paths)
        prompt_server.app.add_routes(prompt_server.routes)
        runner = web.AppRunner(prompt_server.app)
        await runner.setup()  # 触发 on_startup
        return holder, runner

    async def stop(self, holder, runner):
        for key in ('bootstrap',):
            if holder.get(key):
                holder[key].cancel()
        app = holder.get('app')
        if app and app.auto_resume.task:
            app.auto_resume.task.cancel()
            await asyncio.gather(app.auto_resume.task, return_exceptions=True)
        await asyncio.gather(*(holder[k] for k in ('bootstrap',) if holder.get(k)), return_exceptions=True)
        await runner.cleanup()

    async def test_application_and_watchdog_start_without_any_page_request(self):
        server = SimpleNamespace(app=web.Application(), routes=web.RouteTableDef(), port=18188, address='0.0.0.0')
        holder, runner = await self.run_server(server)
        try:
            await asyncio.wait_for(holder['bootstrap'], 5)
            app = holder['app']
            self.assertEqual(app.engine.local_url, 'http://127.0.0.1:18188', '监听 0.0.0.0 时要改用 127.0.0.1 访问自己')
            self.assertFalse(app.auto_resume.task.done())
        finally:
            await self.stop(holder, runner)

    async def test_waits_for_the_port_then_wakes_up(self):
        server = SimpleNamespace(app=web.Application(), routes=web.RouteTableDef(), port=None, address='127.0.0.1')
        holder, runner = await self.run_server(server)
        try:
            await asyncio.sleep(0.3)
            self.assertNotIn('app', holder)
            server.port = 18188
            await asyncio.wait_for(holder['bootstrap'], 5)
            self.assertIn('app', holder)
        finally:
            await self.stop(holder, runner)

    async def test_first_page_request_reuses_the_app_woken_at_startup(self):
        server = SimpleNamespace(app=web.Application(), routes=web.RouteTableDef(), port=18188, address='127.0.0.1')
        holder, runner = await self.run_server(server)
        site = web.TCPSite(runner, '127.0.0.1', 0)
        await site.start()
        port = site._server.sockets[0].getsockname()[1]
        try:
            await asyncio.wait_for(holder['bootstrap'], 5)
            woken = holder['app']
            async with aiohttp.ClientSession() as session:
                async with session.get(f'http://127.0.0.1:{port}/h3_autodrama_v1/api/settings') as response:
                    self.assertEqual(response.status, 200)
                    data = await response.json()
            self.assertIs(holder['app'], woken, '不能重复初始化')
            self.assertIs(data['auto_resume_enabled'], True)
            self.assertEqual(data['auto_resume_minutes'], 5)
        finally:
            await self.stop(holder, runner)

    async def test_page_request_still_initialises_when_the_startup_hook_is_unavailable(self):
        server = SimpleNamespace(app=None, routes=web.RouteTableDef(), port=None, address='127.0.0.1')
        host = web.Application()
        holder = routes.register_routes(server, self.folder_paths)  # app=None：登记钩子失败，只记日志，不抛错
        host.add_routes(server.routes)
        runner = web.AppRunner(host)
        await runner.setup()
        site = web.TCPSite(runner, '127.0.0.1', 0)
        await site.start()
        port = site._server.sockets[0].getsockname()[1]
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f'http://127.0.0.1:{port}/h3_autodrama_v1/api/settings') as response:
                    self.assertEqual(response.status, 200)
            self.assertIn('app', holder)
            self.assertFalse(holder['app'].auto_resume.task.done(), '第一次请求也要把看守启动起来')
        finally:
            await self.stop(holder, runner)


if __name__ == '__main__':
    unittest.main()
