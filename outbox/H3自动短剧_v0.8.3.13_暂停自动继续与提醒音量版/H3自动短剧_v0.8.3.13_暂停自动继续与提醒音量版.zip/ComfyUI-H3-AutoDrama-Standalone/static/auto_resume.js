"use strict";
// 自动继续：页眉开关 + 整剧页说明。真正的“每隔几分钟检查并继续”在后台（auto_resume.py）做，这里只负责开关和把状态讲清楚。
(function(){
 let enabled=true,minutes=5;
 function render(){
  const toggle=document.querySelector("#auto-resume-toggle");
  if(toggle){toggle.textContent=enabled?"自动继续：开":"自动继续：关";toggle.setAttribute("aria-pressed",enabled?"true":"false")}
 }
 // 整剧页下方一行说明：现在处于什么状态、会不会被自动继续。
 function noteFor(series){
  if(!series)return null;
  const auto=series.auto_resume||{};
  if(auto.blocked)return {text:"自动继续已停止："+(auto.blocked_reason||"连续多次自动继续都没有新增视频。")+" 查明原因后请手动点“继续整剧”。",warn:true};
  if(!enabled)return {text:"自动继续已关闭（页面左上角可以打开）。",warn:false};
  if(series.status==="paused"){
   if(series.user_paused)return {text:"这是你点了“暂停”的，不会被自动继续；要继续请手动点“继续整剧”。",warn:false};
   return {text:`已暂停，不是你点的。自动继续已开启：每 ${minutes} 分钟检查一次，没有任务在跑且还有能做的任务时会自动继续。`,warn:false};
  }
  if(["running","queued","pausing"].includes(series.status))return {text:`自动继续已开启：每 ${minutes} 分钟检查一次（运行中不会打扰）。`,warn:false};
  return null;
 }
 function renderNote(series){
  try{
   const box=document.querySelector("#auto-resume-note");
   if(!box)return;
   const note=noteFor(series||(typeof currentSeries!=="undefined"?currentSeries:null));
   box.textContent=note?note.text:"";
   box.classList.toggle("hidden",!note);
   box.style.color=note&&note.warn?"#ffb899":"";
  }catch{}
 }
 function sync(values){
  try{
   if(values){enabled=values.auto_resume_enabled!==false;minutes=Number(values.auto_resume_minutes)||5}
   render();renderNote();
  }catch{}
 }
 async function toggle(){
  const next=!enabled;
  try{
   await api("settings",{auto_resume_enabled:next});
   enabled=next;
   notice(next?`自动继续已打开：整剧暂停且没有任务在跑时，每 ${minutes} 分钟左右会自动继续。`:"自动继续已关闭。",false,true);
  }catch(error){
   notice("没能保存自动继续的开关："+(typeof plainMessage==="function"?plainMessage(error):String(error&&error.message||error)),true);
  }
  render();renderNote();
 }
 function bind(){
  const button=document.querySelector("#auto-resume-toggle");
  if(button)button.onclick=toggle;
  render();
 }
 if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",bind);else bind();
 globalThis.h3AutoResume={sync,renderNote,noteFor};
})();
