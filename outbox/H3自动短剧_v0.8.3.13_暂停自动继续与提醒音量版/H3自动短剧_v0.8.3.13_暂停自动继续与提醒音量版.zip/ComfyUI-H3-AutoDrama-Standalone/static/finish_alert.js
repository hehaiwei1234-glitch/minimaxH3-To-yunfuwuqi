"use strict";
// 完成提醒声：整剧（或单独制作的一集）从“制作中”变成“已完成”时响三声由低到高；变成“需要处理”（出错、停住）时响两声低而短的。
// 只读页面本来就在刷新的状态，不发任何请求，不碰后台；任何一步出错都静默跳过，不影响页面其他功能。
// 整剧里的每一集不单独提醒（它们带 series_id），只在整剧全部做完、没有下一个任务时才响。
(function(){
 const PREF_KEY="h3ad_finish_alert",VOLUME_KEY="h3ad_finish_alert_volume",ACTIVE=["running","queued","pausing"];
 let enabled=true,ctx=null,volume=40;
 try{enabled=localStorage.getItem(PREF_KEY)!=="off"}catch{}
 // 音量 5–100（滑条），保存在浏览器里；读到不合理的值就用默认 40。
 function clampVolume(value){const n=Math.round(Number(value));return Number.isFinite(n)&&n>=5&&n<=100?n:40}
 try{volume=clampVolume(localStorage.getItem(VOLUME_KEY))}catch{}
 const seen={series:new Map(),project:new Map()};

 function context(){
  if(ctx)return ctx;
  const Ctor=globalThis.AudioContext||globalThis.webkitAudioContext;
  if(!Ctor)return null;
  ctx=new Ctor();return ctx;
 }
 // 浏览器规定：用户在页面里点过一下之后才允许出声。第一次点击（任意位置）时准备好声音通道。
 function unlock(){try{const c=context();if(c&&c.state==="suspended")c.resume()}catch{}}
 ["pointerdown","keydown","click"].forEach(name=>{try{document.addEventListener(name,unlock,true)}catch{}});

 const TUNES={
  done:{type:"sine",notes:[523.25,659.25,783.99],length:0.24,step:0.3},      // 三声由低到高：全部完成
  attention:{type:"triangle",notes:[330,330],length:0.16,step:0.26},          // 两声低而短：需要处理
 };
 // 返回 true 表示声音已交给浏览器播放；false 表示浏览器还没允许出声（页面里从没点过）。
 function beep(kind){
  try{
   const tune=TUNES[kind],c=context();
   if(!tune||!c)return false;
   if(c.state==="suspended")c.resume();
   if(c.state==="suspended")return false;
   const t0=c.currentTime+0.05;
   tune.notes.forEach((hz,i)=>{
    const osc=c.createOscillator(),gain=c.createGain(),t=t0+i*tune.step;
    osc.type=tune.type;osc.frequency.value=hz;
    gain.gain.setValueAtTime(0.0001,t);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.01,volume/100),t+0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001,t+tune.length);
    osc.connect(gain);gain.connect(c.destination);
    osc.start(t);osc.stop(t+tune.length+0.05);
   });
   return true;
  }catch{return false}
 }

 function say(message){try{if(typeof notice==="function")notice(message,false,true)}catch{}}

 // items：本次刷新得到的列表。只和“上一次刷新里同一个 id 的状态”比较，所以刚打开页面、刚切换列表时不会误响。
 function observe(kind,items){
  try{
   const before=seen[kind],after=new Map();
   if(!before||!Array.isArray(items))return;
   let done=[],attention=[];
   for(const item of items){
    if(!item||!item.id)continue;
    if(kind==="project"&&item.series_id){continue}
    const prev=before.get(item.id),running=ACTIVE.includes(item.status);
    // 用户自己点了“当前任务完成后暂停”（状态走过“准备暂停”）之后停下，是预期的，不响。
    const askedPause=item.status==="pausing"||!!(prev&&prev.askedPause&&running);
    after.set(item.id,{status:item.status,askedPause});
    if(!prev||!ACTIVE.includes(prev.status)||running||item.archived)continue;
    const name=item.title||item.id;
    if(item.status==="complete")done.push(name);
    else if(item.status==="paused"&&prev.askedPause)continue;
    else attention.push(name+"（"+(statusText(item.status))+"）");
   }
   seen[kind]=after;
   if(!done.length&&!attention.length)return;
   const label=kind==="series"?"整剧":"单集";
   const text=(attention.length?label+"停下来了，需要处理："+attention.join("、"):label+"已全部完成："+done.join("、"));
   const played=enabled?beep(attention.length?"attention":"done"):true;
   say(text+(played?"":"（提醒声没响：浏览器还没允许出声，请在页面里点一下或点“试听”）"));
  }catch{}
 }
 function statusText(status){
  try{if(typeof statuses==="object"&&statuses[status])return statuses[status]}catch{}
  return status;
 }

 function render(){
  const toggle=document.querySelector("#finish-alert-toggle"),slider=document.querySelector("#finish-alert-volume");
  if(toggle){toggle.textContent=enabled?"提醒声：开":"提醒声：关";toggle.setAttribute("aria-pressed",enabled?"true":"false")}
  if(slider){slider.value=String(volume);slider.title="提醒音量 "+volume+"（拖动后会试听一下）"}
 }
 function bind(){
  const toggle=document.querySelector("#finish-alert-toggle"),test=document.querySelector("#finish-alert-test"),slider=document.querySelector("#finish-alert-volume");
  if(slider)slider.onchange=()=>{
   volume=clampVolume(slider.value);
   try{localStorage.setItem(VOLUME_KEY,String(volume))}catch{}
   render();
   unlock();beep("done");
  };
  if(toggle)toggle.onclick=()=>{
   enabled=!enabled;
   try{localStorage.setItem(PREF_KEY,enabled?"on":"off")}catch{}
   render();
   if(enabled)beep("done");
  };
  if(test)test.onclick=()=>{
   unlock();
   if(!beep("done"))say("没有响：浏览器还没允许出声。请再点一次“试听”，仍不响请检查电脑音量和这个标签页是否被静音。");
  };
  render();
 }
 if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",bind);else bind();
 globalThis.h3FinishAlert={observe,beep,isEnabled:()=>enabled,volume:()=>volume};
})();
