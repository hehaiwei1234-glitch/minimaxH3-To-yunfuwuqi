"""整剧暂停后自动继续（后台看守）。

每隔几分钟检查一次：现在没有任何任务在跑，且某部整剧处于“已暂停”（不是用户自己点的暂停）并且还有能做的任务，
就执行和手动点“继续整剧”完全一样的动作（SeriesManager.start）。

安全措施：
- 用户自己点了“当前任务完成后暂停”的整剧不会被自动继续（直到用户手动点继续）。
- 同一部剧连续自动继续 3 次都没有新增视频（说明有硬性原因，比如服务没起来、欠费），就停止自动继续并写明，避免反复空烧。
- 设置里可以关闭，也可以改检查间隔。
- 任何一步出错都只记日志，看守本身不会退出，也不会影响正在运行的任务。
"""
from __future__ import annotations

import asyncio
import logging
import time

ACTIVE = {'running', 'queued', 'pausing'}
MAX_FUTILE_ATTEMPTS = 3
FIRST_CHECK_DELAY = 90      # 启动后先等 ComfyUI 完全起来
TICK_SECONDS = 30           # 每 30 秒看一眼是否到了检查时间（这样改设置能很快生效）
log = logging.getLogger(__name__)


class AutoResume:
    def __init__(self, series, clock=time.time):
        self.series = series
        self.engine = series.engine
        self.store = series.store
        self.clock = clock
        self.task = None
        self.last_check = None

    # ---- 设置 ----
    def enabled(self):
        return bool(self.store.settings().get('auto_resume_enabled', True))

    def interval_seconds(self):
        minutes = self.store.settings().get('auto_resume_minutes', 5)
        return max(1, min(60, int(minutes))) * 60

    # ---- 状态判断 ----
    def busy(self):
        """只要还有任何整剧、单集或后台任务在跑，这一轮就不动。"""
        for kind in ('series', 'project'):
            if any(item.get('status') in ACTIVE for item in self.store.list(kind)):
                return True
        tasks = list(getattr(self.series, 'tasks', {}).values()) + list(getattr(self.engine, 'tasks', {}).values())
        return any(not task.done() for task in tasks)

    def progress(self, record):
        total = 0
        for pid in record.get('project_ids') or []:
            try:
                project = self.store.get('project', pid)
            except KeyError:
                continue
            total += sum(1 for clip in project.get('clips') or [] if clip.get('output'))
        return total

    # ---- 一轮检查 ----
    def check_once(self):
        """返回本轮自动继续的整剧 id 列表（便于测试）。"""
        if not self.enabled() or self.busy():
            return []
        started = []
        for item in self.store.list('series'):
            if item.get('archived') or item.get('status') != 'paused' or item.get('user_paused'):
                continue
            try:
                if self.resume_one(item['id']):
                    started.append(item['id'])
            except Exception:  # noqa: BLE001 - 一部剧出错不影响其他剧，也不让看守退出
                log.exception('auto resume failed for series %s', item.get('id'))
            if started:
                break  # 一次只启动一部，避免同时抢资源
        return started

    def resume_one(self, series_id):
        public = self.series.public(series_id)
        if not public.get('can_resume') or public.get('active'):
            return False
        record = self.store.get('series', series_id)
        state = dict(record.get('auto_resume') or {})
        progress = self.progress(record)
        if state.get('mark') is None or progress > state['mark']:
            state.update(attempts=0, blocked=False, blocked_reason='')  # 有新进展：重新计数
        if state.get('blocked'):
            return False
        if state.get('attempts', 0) >= MAX_FUTILE_ATTEMPTS:
            reason = f'连续 {MAX_FUTILE_ATTEMPTS} 次自动继续都没有新增视频，已停止自动继续。请先查明暂停原因（例如服务是否正常、接口是否欠费），再手动点“继续整剧”。'
            state.update(blocked=True, blocked_reason=reason)
            self.series.set(series_id, auto_resume=state)
            self.series.event(series_id, '自动继续已停止：' + reason)
            return False
        state.update(attempts=state.get('attempts', 0) + 1, mark=progress, last_at=self.clock(), blocked=False, blocked_reason='')
        self.series.set(series_id, auto_resume=state)
        self.series.event(series_id, f'自动继续：检测到整剧已暂停且还有可执行的任务，已自动继续（第 {state["attempts"]} 次，当前已有 {progress} 个镜头视频）。')
        self.series.start(series_id, auto=True)
        return True

    # ---- 后台循环 ----
    async def run_forever(self, first_delay=FIRST_CHECK_DELAY):
        await asyncio.sleep(first_delay)
        while True:
            try:
                now = self.clock()
                if self.last_check is None or now - self.last_check >= self.interval_seconds():
                    self.last_check = now
                    self.check_once()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                log.exception('auto resume check failed')
            await asyncio.sleep(TICK_SECONDS)

    def start_watchdog(self, first_delay=FIRST_CHECK_DELAY):
        if self.task is None or self.task.done():
            self.task = asyncio.get_running_loop().create_task(self.run_forever(first_delay), name='h3ad_auto_resume')
        return self.task
